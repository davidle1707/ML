﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Models.ExcludedOperator
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

namespace CodeEffects.Rule.Models
{
  public enum ExcludedOperator
  {
    Equal = 1,
    NotEqual = 2,
    Less = 4,
    LessOrEqual = 8,
    Greater = 16,
    GreaterOrEqual = 32,
    Contains = 64,
    DoesNotContain = 128,
    EndsWith = 256,
    DoesNotEndWith = 512,
    StartsWith = 1024,
    DoesNotStartWith = 2048,
  }
}
