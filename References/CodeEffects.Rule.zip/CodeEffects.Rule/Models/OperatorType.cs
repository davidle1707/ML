﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Models.OperatorType
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

namespace CodeEffects.Rule.Models
{
  public enum OperatorType
  {
    String = 0,
    Numeric = 1,
    Date = 2,
    Time = 3,
    Bool = 4,
    Enum = 6,
    Collection = 8,
    None = 16,
  }
}
