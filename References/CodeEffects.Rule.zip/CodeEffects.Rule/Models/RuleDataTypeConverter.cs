﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Models.RuleDataTypeConverter
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using CodeEffects.Rule.Core;
using System;
using System.Collections;
using System.ComponentModel;
using System.Globalization;
using System.Web.Script.Serialization;
using System.Xml;

namespace CodeEffects.Rule.Models
{
  public class RuleDataTypeConverter : TypeConverter
  {
    public override object ConvertFrom(ITypeDescriptorContext context, CultureInfo culture, object value)
    {
      if (value is string)
        return (object) this.GetRuleModel(value as string);
      return base.ConvertFrom(context, culture, value);
    }

    public override object ConvertTo(ITypeDescriptorContext context, CultureInfo culture, object value, Type destinationType)
    {
      if (destinationType == typeof (string))
        return (object) new JavaScriptSerializer().Serialize((object) (value as RuleModel));
      return base.ConvertTo(context, culture, value, destinationType);
    }

    public override bool CanConvertFrom(ITypeDescriptorContext context, Type sourceType)
    {
      if (sourceType == typeof (string))
        return true;
      return base.CanConvertFrom(context, sourceType);
    }

    public override bool CanConvertTo(ITypeDescriptorContext context, Type destinationType)
    {
      return base.CanConvertTo(context, destinationType);
    }

    public override object CreateInstance(ITypeDescriptorContext context, IDictionary propertyValues)
    {
      return base.CreateInstance(context, propertyValues);
    }

    internal RuleModel GetRuleModel(string ruleClientData)
    {
      return this.GetRuleModel(ruleClientData, (string) null, (string) null, (XmlDocument) null);
    }

    internal RuleModel GetRuleModel(string ruleClientData, string sourceAssembly, string sourceType, XmlDocument sourceXml)
    {
      RuleModel ruleModel = new JavaScriptSerializer().Deserialize<RuleModel>(ruleClientData);
      if (string.IsNullOrWhiteSpace(ruleModel.Id))
        ruleModel.Id = Guid.NewGuid().ToString();
      if (ruleModel.Name != null)
        ruleModel.Name = Encoder.Desanitize(ruleModel.Name);
      if (ruleModel.Desc != null)
        ruleModel.Desc = Encoder.Desanitize(ruleModel.Desc);
      if (sourceAssembly != null && sourceType != null)
      {
        ruleModel.SourceAssembly = sourceAssembly;
        ruleModel.SourceType = sourceType;
      }
      if (sourceXml != null)
        ruleModel.SourceXml = sourceXml;
      return ruleModel;
    }
  }
}
