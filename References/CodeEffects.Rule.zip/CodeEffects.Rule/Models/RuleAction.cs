﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Models.RuleAction
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using CodeEffects.Rule.Client;
using System.Collections.Generic;

namespace CodeEffects.Rule.Models
{
  internal class RuleAction
  {
    public Element Action { get; set; }

    public List<Element> Parameters { get; set; }

    public RuleAction()
    {
      this.Parameters = new List<Element>();
    }
  }
}
