﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Models.RuleModel
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using CodeEffects.Rule.Client;
using CodeEffects.Rule.Common;
using CodeEffects.Rule.Core;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Xml;

namespace CodeEffects.Rule.Models
{
  [TypeConverter(typeof (RuleDataTypeConverter))]
  public class RuleModel
  {
    private bool validated;
    private bool valid;
    private RuleType mode;

    internal bool NameIsInvalid { get; set; }

    internal RuleFormatType Format { get; set; }

    internal string SourceType { get; set; }

    internal string SourceAssembly { get; set; }

    internal string SourceXmlFile { get; set; }

    internal XmlDocument SourceXml { get; set; }

    public string Id { get; set; }

    public string Name { get; set; }

    public string Desc { get; set; }

    public bool SkipNameValidation { get; set; }

    public string Command { get; set; }

    public bool? IsLoadedRuleOfEvalType { get; set; }

    public RuleType Mode
    {
      get
      {
        return this.mode;
      }
      set
      {
        if (value == RuleType.Filter)
          this.SkipNameValidation = true;
        this.mode = value;
      }
    }

    public List<Element> Elements { get; set; }

    public List<InvalidElement> InvalidElements { get; set; }

    public RuleModel()
    {
      this.Mode = RuleType.Evaluation;
      this.NameIsInvalid = this.validated = this.valid = this.SkipNameValidation = false;
      this.Format = RuleFormatType.CodeEffects;
      this.Elements = new List<Element>();
      this.InvalidElements = new List<InvalidElement>();
    }

    public static RuleModel Create(string sourceAssembly, string sourceType)
    {
      return new RuleModel()
      {
        SourceAssembly = sourceAssembly,
        SourceType = sourceType
      };
    }

    public static RuleModel Create(string sourceXmlFile)
    {
      return new RuleModel()
      {
        SourceXmlFile = sourceXmlFile
      };
    }

    public static RuleModel Create(XmlDocument sourceXml)
    {
      return new RuleModel()
      {
        SourceXml = sourceXml
      };
    }

    public static RuleModel Create(Type sourceType)
    {
      return new RuleModel()
      {
        SourceType = sourceType.FullName,
        SourceAssembly = sourceType.Assembly.FullName
      };
    }

    public static RuleModel Create(string ruleXml, string sourceAssembly, string sourceType)
    {
      return RuleModel.Create(ruleXml, sourceAssembly, sourceType, (GetRuleDelegate) null);
    }

    public static RuleModel Create(string ruleXml, string sourceAssembly, string sourceType, GetRuleDelegate ruleDelegate)
    {
      List<Type> processedTypes = new List<Type>();
      RuleModel ruleModel = RuleModel.LoadModel(ruleXml, SourceLoader.GetXml(sourceAssembly, sourceType, processedTypes), ruleDelegate);
      ruleModel.SourceAssembly = sourceAssembly;
      ruleModel.SourceType = sourceType;
      return ruleModel;
    }

    public static RuleModel Create(string ruleXml, XmlDocument sourceXml)
    {
      return RuleModel.Create(ruleXml, sourceXml, (GetRuleDelegate) null);
    }

    public static RuleModel Create(string ruleXml, XmlDocument sourceXml, GetRuleDelegate ruleDelegate)
    {
      return RuleModel.LoadModel(ruleXml, sourceXml, ruleDelegate);
    }

    public static RuleModel Create(string ruleXml, Type sourceType)
    {
      return RuleModel.Create(ruleXml, sourceType, (GetRuleDelegate) null);
    }

    public static RuleModel Create(string ruleXml, Type sourceType, GetRuleDelegate ruleDelegate)
    {
      List<Type> processedTypes = new List<Type>();
      RuleModel ruleModel = RuleModel.LoadModel(ruleXml, SourceLoader.GetXml(sourceType, processedTypes), ruleDelegate);
      ruleModel.SourceAssembly = sourceType.Assembly.FullName;
      ruleModel.SourceType = sourceType.FullName;
      return ruleModel;
    }

    public string GetRuleXml()
    {
      if (this.IsEmpty())
        return (string) null;
      if (!this.validated)
        throw new InvalidRuleException(InvalidRuleException.ErrorIds.FailtureToValidate, new string[0]);
      if (!this.valid)
        throw new InvalidRuleException(InvalidRuleException.ErrorIds.RuleIsInvalid, new string[0]);
      List<Element> items = this.CopyElements(this.Elements);
      XmlDocument xmlDocument = this.LoadSourceXml();
      RuleValidator.EnsureIgnoredProperties(items, xmlDocument);
      RuleValidator.EnsureValues(items);
      return RuleLoader.GetXml(items, string.IsNullOrWhiteSpace(this.Id) ? Guid.NewGuid().ToString() : this.Id, this.Name, this.Desc, xmlDocument, RuleFormatType.CodeEffects, this.Mode, this.IsLoadedRuleOfEvalType.Value);
    }

    public bool IsValid()
    {
      return this.IsValid((GetRuleDelegate) null);
    }

    public bool IsValid(GetRuleDelegate ruleDelegate)
    {
      if (!this.IsLoadedRuleOfEvalType.HasValue)
        this.IsLoadedRuleOfEvalType = new bool?(!RuleValidator.HasActions(this.Elements));
      List<InvalidElement> invalidElementList = RuleValidator.Validate(this.Elements, this.LoadSourceXml(), this.IsLoadedRuleOfEvalType.GetValueOrDefault());
      if (invalidElementList.Count > 0)
        this.InvalidElements = invalidElementList;
      else if (ruleDelegate != null)
      {
        this.valid = this.validated = true;
        invalidElementList = RuleValidator.CheckRecursion(this.Elements, this.GetRuleXml(), (XmlDocument) null, ruleDelegate);
      }
      this.InvalidElements = invalidElementList.Count <= 0 ? new List<InvalidElement>() : invalidElementList;
      this.NameIsInvalid = !this.SkipNameValidation && string.IsNullOrWhiteSpace(this.Name);
      if (string.IsNullOrWhiteSpace(this.Desc))
        this.Desc = (string) null;
      this.validated = true;
      this.valid = this.InvalidElements.Count == 0 && !this.NameIsInvalid;
      return this.valid;
    }

    public bool IsEmpty()
    {
      if (this.Elements != null)
        return this.Elements.Count == 0;
      return true;
    }

    public void BindSource(string sourceAssembly, string sourceType)
    {
      this.SourceAssembly = sourceAssembly;
      this.SourceType = sourceType;
      this.BindSource(this.LoadSourceXml());
    }

    public void BindSource(string sourceXmlFile)
    {
      this.SourceXmlFile = sourceXmlFile;
      this.BindSource(this.LoadSourceXml());
    }

    public void BindSource(Type sourceType)
    {
      this.SourceAssembly = sourceType.Assembly.FullName;
      this.SourceType = sourceType.FullName;
      this.BindSource(this.LoadSourceXml());
    }

    public void BindSource(XmlDocument sourceXml)
    {
      if (sourceXml == null)
        throw new SourceException(SourceException.ErrorIds.FailureToLoadSourceXML, new string[0]);
      this.SourceXml = sourceXml;
      if (this.Elements == null || this.Elements.Count <= 0)
        return;
      RuleValidator.EnsureTokens(this.Elements, this.SourceXml);
    }

    internal XmlDocument LoadSourceXml()
    {
      if (this.SourceXml != null)
        return this.SourceXml;
      this.SourceXml = SourceLoader.LoadSourceXml(this.SourceAssembly, this.SourceType, this.SourceXmlFile, new List<Type>());
      return this.SourceXml;
    }

    private List<Element> CopyElements(List<Element> list)
    {
      List<Element> elementList = new List<Element>();
      foreach (Element element in list)
      {
        if (element.FuncType != FunctionType.Comma)
          elementList.Add(element.Clone());
      }
      return elementList;
    }

    private static RuleModel LoadModel(string ruleXml, XmlDocument sourceXml, GetRuleDelegate ruleDelegate)
    {
      RuleModel ruleModel = RuleLoader.LoadXml(ruleXml, sourceXml, ruleDelegate);
      ruleModel.IsLoadedRuleOfEvalType = new bool?(!RuleValidator.HasActions(ruleModel.Elements));
      return ruleModel;
    }
  }
}
