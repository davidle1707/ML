﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Models.MarkupData
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using CodeEffects.Rule.Client;
using CodeEffects.Rule.Common;
using CodeEffects.Rule.Core;

namespace CodeEffects.Rule.Models
{
  internal class MarkupData
  {
    public string ControlServerID { get; set; }

    public string PostBackFunctionName { get; set; }

    public ActionUrls MvcActions { get; set; }

    public ThemeManager ThemeFactory { get; set; }

    public Settings Settings { get; set; }

    public Pattern Pattern { get; set; }

    public bool IsLoadedRuleOfEvalType { get; set; }

    public RuleType Mode { get; set; }

    public MarkupData()
    {
      this.IsLoadedRuleOfEvalType = true;
      this.Mode = RuleType.Evaluation;
      this.Pattern = Pattern.None;
    }
  }
}
