﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Models.ActionUrls
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using System.Text;

namespace CodeEffects.Rule.Models
{
  internal sealed class ActionUrls
  {
    internal string SaveAction { get; set; }

    internal string DeleteAction { get; set; }

    internal string LoadAction { get; set; }

    internal ActionUrls()
    {
    }

    public override string ToString()
    {
      StringBuilder stringBuilder = new StringBuilder("{");
      stringBuilder.Append("\"s\":");
      if (string.IsNullOrEmpty(this.SaveAction))
        stringBuilder.Append("null");
      else
        stringBuilder.Append("\"").Append(this.SaveAction).Append("\"");
      stringBuilder.Append(",\"d\":");
      if (string.IsNullOrEmpty(this.DeleteAction))
        stringBuilder.Append("null");
      else
        stringBuilder.Append("\"").Append(this.DeleteAction).Append("\"");
      stringBuilder.Append(",\"l\":");
      if (string.IsNullOrEmpty(this.LoadAction))
        stringBuilder.Append("null");
      else
        stringBuilder.Append("\"").Append(this.LoadAction).Append("\"");
      stringBuilder.Append("}");
      return stringBuilder.ToString();
    }
  }
}
