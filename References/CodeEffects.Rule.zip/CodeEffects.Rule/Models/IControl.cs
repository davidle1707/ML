﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Models.IControl
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using CodeEffects.Rule.Common;
using System.Collections.Generic;

namespace CodeEffects.Rule.Models
{
  internal interface IControl
  {
    bool ShowHelpString { get; set; }

    bool ClientOnly { get; set; }

    bool ShowLineDots { get; set; }

    bool ShowMenuOnRightArrowKey { get; set; }

    bool ShowMenuOnElementClicked { get; set; }

    bool ShowDescriptionsOnMouseHover { get; set; }

    bool ShowToolBar { get; set; }

    bool KeepDeclaredOrder { get; set; }

    RuleType Mode { get; set; }

    ThemeType Theme { get; set; }

    ICollection<Operator> ExcludedOperators { get; set; }
  }
}
