﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Formats.Ce
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using CodeEffects.Rule.Client;
using CodeEffects.Rule.Common;
using CodeEffects.Rule.Core;
using CodeEffects.Rule.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Xml;

namespace CodeEffects.Rule.Formats
{
  internal sealed class Ce
  {
    private Ce()
    {
    }

    internal static string GetXml(List<Element> items, XmlDocument source, string ruleID, string ruleName, string ruleDescription, RuleType mode, bool isCurrentRuleOfEvalType)
    {
      XmlDocument emptyRuleDocument = CodeEffects.Rule.Common.Xml.GetEmptyRuleDocument();
      int index = 0;
      Ce.FillDefinition(items, emptyRuleDocument, ruleID, ruleName, ruleDescription, source, source.DocumentElement.ChildNodes[0].Attributes["name"] == null ? (string) null : Encoder.GetHashToken(source.DocumentElement.ChildNodes[0].Attributes["name"].Value), mode, isCurrentRuleOfEvalType, true, ref index);
      return emptyRuleDocument.OuterXml;
    }

    internal static List<Element> LoadXml(XmlDocument rule, XmlDocument source, GetRuleDelegate ruleDelegate)
    {
      List<Element> list = new List<Element>();
      Ce.FillRule(list, rule.DocumentElement.ChildNodes[0], source, ruleDelegate);
      return list;
    }

    private static void FillRule(List<Element> list, XmlNode ruleXml, XmlDocument sourceXml, GetRuleDelegate ruleDelegate)
    {
      try
      {
        string namespaceByRuleNamespace = CodeEffects.Rule.Common.Xml.GetUiNamespaceByRuleNamespace(ruleXml.OwnerDocument.DocumentElement.NamespaceURI);
        XmlNamespaceManager nsmgr = new XmlNamespaceManager(ruleXml.OwnerDocument.NameTable);
        nsmgr.AddNamespace(CodeEffects.Rule.Common.Xml.RuleNamespaceTag, ruleXml.OwnerDocument.DocumentElement.NamespaceURI);
        nsmgr.AddNamespace(CodeEffects.Rule.Common.Xml.UiNamespaceTag, namespaceByRuleNamespace);
        XmlNode parent = ruleXml.SelectSingleNode(string.Format("{0}:{1}", (object) CodeEffects.Rule.Common.Xml.RuleNamespaceTag, (object) "definition"), nsmgr);
        XmlNode source = (XmlNode) null;
        if (ruleXml.Attributes["type"] == null || string.IsNullOrWhiteSpace(ruleXml.Attributes["type"].Value))
        {
          source = sourceXml.DocumentElement.ChildNodes[0];
        }
        else
        {
          Type type = Type.GetType(ruleXml.Attributes["type"].Value, true, false);
          foreach (XmlNode childNode in sourceXml.DocumentElement.ChildNodes)
          {
            if (childNode.Attributes["name"] == null || childNode.Attributes["name"].Value == type.FullName)
            {
              source = childNode;
              break;
            }
          }
          if (source == null)
            throw new SourceException(SourceException.ErrorIds.SourceNodeNotFound, new string[1]{ type.FullName });
        }
        int count = list.Count;
        bool flag = false;
        XmlNode xmlNode = parent.SelectSingleNode(string.Format("{0}:{1}", (object) CodeEffects.Rule.Common.Xml.RuleNamespaceTag, (object) "if"), nsmgr);
        if (xmlNode == null)
          xmlNode = parent.SelectSingleNode(string.Format("{0}:{1}", (object) CodeEffects.Rule.Common.Xml.RuleNamespaceTag, (object) "while"), nsmgr);
        else if (parent.ChildNodes.Count > 1 && parent.ChildNodes[1].Name == "if")
          flag = true;
        if (xmlNode == null)
        {
          if (list.Count == 0)
          {
            list.Add(new Element()
            {
              Type = ElementType.Flow,
              Value = "if"
            });
            ++count;
          }
          Ce.FillEvaluationElements(list, source, parent, namespaceByRuleNamespace, ruleDelegate);
        }
        else if (flag)
        {
          if (list.Count == 0)
            ++count;
          for (int index = 0; index < parent.ChildNodes.Count; ++index)
            Ce.FillExecutionElements(list, source, parent.ChildNodes[index], namespaceByRuleNamespace, index == 0 ? "if" : "elseIf", ruleDelegate);
        }
        else
        {
          if (list.Count == 0)
            ++count;
          Ce.FillExecutionElements(list, source, parent.ChildNodes[0], namespaceByRuleNamespace, "if", ruleDelegate);
        }
        foreach (XmlNode childNode in ruleXml.SelectSingleNode(string.Format("{0}:{1}/{0}:{2}", (object) CodeEffects.Rule.Common.Xml.RuleNamespaceTag, (object) "format", (object) "lines"), nsmgr).ChildNodes)
        {
          Element element1 = new Element();
          element1.Type = ElementType.NewLine;
          int index1 = count + int.Parse(childNode.Attributes["index"].Value);
          if (index1 >= list.Count)
            list.Add(element1);
          else
            list.Insert(index1, element1);
          int num1 = int.Parse(childNode.Attributes["tabs"].Value);
          if (num1 > 0)
          {
            int index2 = index1 + 1;
            int num2 = 0;
            while (num2 < num1)
            {
              Element element2 = new Element();
              element2.Type = ElementType.Tab;
              if (index2 >= list.Count)
                list.Add(element2);
              else
                list.Insert(index2, element2);
              ++num2;
              ++index2;
            }
          }
        }
      }
      catch (SourceException ex)
      {
        throw;
      }
      catch (MalformedXmlException ex)
      {
        throw;
      }
      catch (InvalidRuleException ex)
      {
        throw;
      }
      catch (RuleException ex)
      {
        throw;
      }
      catch (Exception ex)
      {
        throw new InvalidRuleException(InvalidRuleException.ErrorIds.RuleXMLIsInvalid2, new string[1]{ ex.Message });
      }
    }

    private static void FillExecutionElements(List<Element> list, XmlNode source, XmlNode node, string uiNamespace, string ifValue, GetRuleDelegate ruleDelegate)
    {
      if (node.Name == "else")
        node = node.ChildNodes[0];
      switch (node.Name)
      {
        case "if":
        case "while":
          if (node.ChildNodes.Count < 2 || node.ChildNodes.Count > 3)
            throw new InvalidRuleException(InvalidRuleException.ErrorIds.RuleXMLIsInvalid, new string[0]);
          list.Add(new Element()
          {
            Type = ElementType.Flow,
            Value = ifValue
          });
          IEnumerator enumerator = node.ChildNodes.GetEnumerator();
          try
          {
            while (enumerator.MoveNext())
            {
              XmlNode xmlNode = (XmlNode) enumerator.Current;
              switch (xmlNode.Name)
              {
                case "clause":
                  Ce.FillEvaluationElements(list, source, xmlNode, uiNamespace, ruleDelegate);
                  continue;
                case "else":
                  Ce.FillExecutionElements(list, source, xmlNode, uiNamespace, "elseIf", ruleDelegate);
                  continue;
                case "then":
                  list.Add(new Element()
                  {
                    Type = ElementType.Clause,
                    Value = "then"
                  });
                  Ce.AppendActionElements(list, source, xmlNode, uiNamespace);
                  continue;
                default:
                  throw new InvalidRuleException(InvalidRuleException.ErrorIds.RuleXMLIsInvalid, new string[0]);
              }
            }
            break;
          }
          finally
          {
            IDisposable disposable = enumerator as IDisposable;
            if (disposable != null)
              disposable.Dispose();
          }
        case "method":
        case "set":
          list.Add(new Element()
          {
            Type = ElementType.Flow,
            Value = "else"
          });
          Ce.AppendActionElements(list, source, node.ParentNode, uiNamespace);
          break;
        default:
          throw new InvalidRuleException(InvalidRuleException.ErrorIds.RuleXMLIsInvalid, new string[0]);
      }
    }

    private static void FillEvaluationElements(List<Element> list, XmlNode source, XmlNode parent, string uiNamespace, GetRuleDelegate ruleDelegate)
    {
      foreach (XmlNode childNode1 in parent.ChildNodes)
      {
        switch (childNode1.Name)
        {
          case "and":
          case "or":
            bool flag = childNode1.Attributes["block", uiNamespace] != null && childNode1.Attributes["block", uiNamespace].Value == "true";
            if (flag)
              Ce.AppendClauseElement(list, ElementType.LeftParenthesis, (string) null);
            Ce.FillEvaluationElements(list, source, childNode1, uiNamespace, ruleDelegate);
            if (flag)
              Ce.AppendClauseElement(list, ElementType.RightParenthesis, (string) null);
            if (childNode1.NextSibling != null && parent.Name != "definition" && parent.Name != "clause")
            {
              Ce.AppendClauseElement(list, ElementType.Clause, parent.Name);
              continue;
            }
            continue;
          case "condition":
            if (childNode1.ChildNodes.Count < 1 || childNode1.ChildNodes.Count > 2)
              throw new InvalidRuleException(InvalidRuleException.ErrorIds.InvalidNumberOfConditionChildNodes, new string[0]);
            Ce.AppendConditionElements(list, source, new Element()
            {
              Type = ElementType.Operator,
              Value = childNode1.Attributes["type"].Value
            }, childNode1.ChildNodes[0], childNode1.ChildNodes.Count > 1 ? childNode1.ChildNodes[1] : (XmlNode) null, uiNamespace);
            if (childNode1.NextSibling != null && parent.Name != "definition" && parent.Name != "clause")
            {
              Ce.AppendClauseElement(list, ElementType.Clause, parent.Name);
              continue;
            }
            continue;
          case "rule":
            if (childNode1.ChildNodes.Count != 1)
              throw new InvalidRuleException(InvalidRuleException.ErrorIds.InvalidNumberOfChildNodes, new string[0]);
            XmlNode ruleXml = (XmlNode) null;
            if (ruleDelegate != null)
            {
              string xml = ruleDelegate(childNode1.Attributes["id"].Value);
              if (!string.IsNullOrWhiteSpace(xml))
              {
                XmlDocument xmlDocument = new XmlDocument();
                xmlDocument.LoadXml(xml);
                if (xmlDocument.DocumentElement.ChildNodes.Count != 0)
                  ruleXml = xmlDocument.DocumentElement.ChildNodes[0];
              }
            }
            if (ruleXml == null)
            {
              foreach (XmlNode childNode2 in parent.OwnerDocument.DocumentElement.ChildNodes)
              {
                if (childNode2.Attributes["id"].Value.ToLower() == childNode1.Attributes["id"].Value.ToLower())
                {
                  ruleXml = childNode2;
                  break;
                }
              }
            }
            if (ruleXml == null)
              throw new InvalidRuleException(InvalidRuleException.ErrorIds.RuleXMLNotFound, new string[1]{ childNode1.Attributes["id"].Value });
            SelectionType selectionType = Converter.StringToSelectionType(childNode1.Attributes["operator"].Value);
            Ce.AppendExistsElement(list, ElementType.Exists, selectionType);
            Element element = new Element();
            element.Value = childNode1.ChildNodes[0].Attributes["name"].Value;
            try
            {
              SourceLoader.GetFieldByPropertyName(source, element.Value);
            }
            catch (SourceException ex)
            {
              element.NotFound = true;
            }
            element.Type = ElementType.Field;
            element.Oper = OperatorType.Collection;
            element.CollType = CollectionType.Reference;
            list.Add(element);
            Ce.AppendExistsElement(list, ElementType.Where, selectionType);
            Type type1 = Type.GetType(ruleXml.Attributes["type"].Value, true, false);
            Ce.AppendClauseElement(list, ElementType.LeftSource, Encoder.GetHashToken(type1.FullName));
            Ce.FillRule(list, ruleXml, source.OwnerDocument, ruleDelegate);
            Type type2 = Type.GetType(source.Attributes["type"].Value, true, false);
            Ce.AppendClauseElement(list, ElementType.RightSource, Encoder.GetHashToken(type2.FullName));
            if (childNode1.NextSibling != null && parent.Name != "definition" && parent.Name != "clause")
            {
              Ce.AppendClauseElement(list, ElementType.Clause, parent.Name);
              continue;
            }
            continue;
          default:
            throw new InvalidRuleException(InvalidRuleException.ErrorIds.RuleXMLIsInvalid, new string[0]);
        }
      }
    }

    private static void FillPropertyElement(Element field, XmlNode fieldNode, XmlNode source)
    {
      XmlNode node = (XmlNode) null;
      try
      {
        node = SourceLoader.GetFieldByPropertyName(source, fieldNode.Attributes["name"].Value);
      }
      catch (SourceException ex)
      {
        field.NotFound = true;
      }
      field.Type = ElementType.Field;
      field.Value = fieldNode.Attributes["name"].Value;
      field.Oper = field.NotFound ? OperatorType.String : Converter.ClientStringToClientType(node.Name);
      if (field.NotFound)
        return;
      Ce.SetElementValues(field, node, false);
    }

    private static void FillParamOperatorType(Element par, XmlNode paramNode)
    {
      if (paramNode.Name == "collection")
      {
        par.Oper = OperatorType.Collection;
        par.CollType = Converter.StringToCollectionType(paramNode.ChildNodes[0].Name);
      }
      else
        par.Oper = Converter.ClientStringToClientType(paramNode.Attributes["type"].Value);
    }

    private static void FillFunctionElements(out Element field, out List<Element> parameters, out Element end, XmlNode fieldNode, XmlNode source, bool isFunctionValue, bool isCalculation)
    {
      field = new Element();
      if (isCalculation)
      {
        field.Type = ElementType.Calculation;
        field.CalType = CalculationType.Function;
      }
      else
        field.Type = ElementType.Function;
      field.FuncType = FunctionType.Name;
      field.IsFuncValue = isFunctionValue;
      XmlNode xmlNode1 = (XmlNode) null;
      try
      {
        field.Token = field.Value = SourceLoader.GetTokenByRuleMethodNode(source, fieldNode, true);
        if (fieldNode.Attributes["type"] != null)
          Ce.SetElementType(field, fieldNode.Attributes["type"].Value);
        xmlNode1 = SourceLoader.GetFunctionByToken(source, field.Token);
      }
      catch (SourceException ex)
      {
        field.NotFound = true;
        if (string.IsNullOrWhiteSpace(field.Value))
          field.Token = field.Value = fieldNode.Attributes["name"].Value;
      }
      parameters = new List<Element>();
      if (!field.NotFound)
      {
        if (xmlNode1.ChildNodes.Count != 2)
          throw new SourceException(SourceException.ErrorIds.InvalidSourceXML, new string[0]);
        XmlNode xmlNode2 = xmlNode1.ChildNodes[0];
        if (xmlNode2.ChildNodes.Count != fieldNode.ChildNodes.Count)
          throw new EvaluationException(EvaluationException.ErrorIds.ParameterCountMismatch, new string[1]{ fieldNode.Attributes["name"].Value });
        if (xmlNode2.ChildNodes.Count > 0)
        {
          for (int index = 0; index < xmlNode2.ChildNodes.Count; ++index)
          {
            XmlNode xmlNode3 = xmlNode2.ChildNodes[index];
            if (!(xmlNode3.Name == "constant") && !(xmlNode3.Name == "source"))
            {
              Element element = new Element();
              element.Type = ElementType.Function;
              element.FuncType = FunctionType.Param;
              element.ParameterType = ParameterType.Input;
              Ce.FillParamOperatorType(element, xmlNode3);
              element.InpType = fieldNode.ChildNodes[index].Name == "property" ? InputType.Field : InputType.Input;
              if (element.InpType == InputType.Field)
              {
                element.Value = fieldNode.ChildNodes[index].Attributes["name"].Value;
              }
              else
              {
                element.Value = Encoder.Sanitize(fieldNode.ChildNodes[index].InnerText);
                Ce.SetElementValues(element, xmlNode3, true);
              }
              parameters.Add(element);
            }
          }
        }
        XmlNode xmlNode4 = xmlNode1.ChildNodes[1];
        field.Oper = Converter.ClientStringToClientType(xmlNode4.Attributes["type"].Value);
        switch (field.Oper)
        {
          case OperatorType.String:
            field.Max = new Decimal?((Decimal) new int?(int.Parse(xmlNode4.Attributes["maxLength"].Value)).Value);
            break;
          case OperatorType.Numeric:
            field.Dec = xmlNode4.Attributes["allowDecimal"].Value == "true";
            field.Min = new Decimal?(Decimal.Parse(xmlNode4.Attributes["min"].Value));
            field.Max = new Decimal?(Decimal.Parse(xmlNode4.Attributes["max"].Value));
            field.Cal = xmlNode4.Attributes["allowCalculation"].Value == "true";
            break;
          case OperatorType.Date:
          case OperatorType.Time:
            field.Format = xmlNode4.Attributes["format"].Value;
            break;
          case OperatorType.Enum:
            if (xmlNode4.Attributes["class"] == null)
              throw new MalformedXmlException(MalformedXmlException.ErrorIds.MissingReturnClassAttribute, new string[0]);
            Ce.SetElementType(field, xmlNode4.Attributes["class"].Value, true);
            break;
        }
      }
      else
      {
        field.Oper = OperatorType.String;
        parameters = (List<Element>) null;
      }
      end = new Element();
      if (isCalculation)
      {
        end.Type = ElementType.Calculation;
        end.CalType = CalculationType.Function;
      }
      else
        end.Type = ElementType.Function;
      end.FuncType = FunctionType.End;
      end.NotFound = field.NotFound;
      end.Value = end.Token = field.Token;
      end.IsFuncValue = isFunctionValue;
      end.Oper = field.Oper;
    }

    private static void AppendActionElements(List<Element> list, XmlNode source, XmlNode parent, string uiNamespace)
    {
      bool flag = true;
      foreach (XmlNode childNode in parent.ChildNodes)
      {
        if (!flag)
          Ce.AppendClauseElement(list, ElementType.Clause, "and");
        else
          flag = false;
        switch (childNode.Name)
        {
          case "method":
            Ce.AppendActionElement(list, source, childNode);
            continue;
          case "set":
            Ce.AppendSetterElement(list, source, childNode, uiNamespace);
            continue;
          default:
            throw new InvalidRuleException(InvalidRuleException.ErrorIds.RuleXMLIsInvalid, new string[0]);
        }
      }
    }

    private static void AppendClauseElement(List<Element> list, ElementType type, string value)
    {
      Element element = new Element();
      element.Type = type;
      if (value != null)
        element.Value = value;
      list.Add(element);
    }

    private static void AppendExistsElement(List<Element> list, ElementType type, SelectionType selType)
    {
      list.Add(new Element()
      {
        Type = type,
        SelType = selType
      });
    }

    private static void AppendSetterElement(List<Element> list, XmlNode source, XmlNode node, string uiNamespace)
    {
      if (node.ChildNodes.Count != 2)
        throw new InvalidRuleException(InvalidRuleException.ErrorIds.RuleXMLIsInvalid, new string[0]);
      Ce.AppendClauseElement(list, ElementType.Setter, "set");
      Element field1 = (Element) null;
      Element element1 = (Element) null;
      Element element2 = (Element) null;
      Element end = (Element) null;
      List<Element> parameters = (List<Element>) null;
      List<Element> list1 = (List<Element>) null;
      switch (node.ChildNodes[0].Name)
      {
        case "property":
          Element field2 = new Element();
          Ce.FillPropertyElement(field2, node.ChildNodes[0], source);
          list.Add(field2);
          list.Add(new Element()
          {
            Type = ElementType.Setter,
            Value = "to",
            Oper = field2.Oper
          });
          XmlNode xmlNode = node.ChildNodes[1];
          switch (xmlNode.Name)
          {
            case "expression":
              element1 = new Element();
              element1.Type = ElementType.LeftBracket;
              element2 = new Element();
              element2.Type = ElementType.RightBracket;
              list1 = new List<Element>();
              Ce.AppendExpressionElements(list1, source, xmlNode, uiNamespace);
              break;
            case "property":
              field1 = new Element();
              field1.Type = ElementType.Value;
              field1.InpType = InputType.Field;
              field1.Value = xmlNode.Attributes["name"].Value;
              field1.Oper = field2.Oper;
              break;
            case "method":
              Ce.FillFunctionElements(out field1, out parameters, out end, xmlNode, source, true, false);
              break;
            case "value":
              field1 = new Element();
              field1.Type = ElementType.Value;
              field1.InpType = InputType.Input;
              field1.Oper = field2.Oper;
              field1.Value = field1.Oper == OperatorType.String ? Encoder.Sanitize(xmlNode.InnerText) : xmlNode.InnerText;
              break;
            default:
              throw new InvalidRuleException(InvalidRuleException.ErrorIds.RuleXMLIsInvalid, new string[0]);
          }
          if (field1 != null)
            list.Add(field1);
          if (parameters != null && parameters.Count > 0)
            Ce.AppendParameterElements(list, parameters);
          if (end != null)
          {
            list.Add(end);
            break;
          }
          if (element1 == null)
            break;
          list.Add(element1);
          foreach (Element element3 in list1)
            list.Add(element3);
          list.Add(element2);
          break;
        default:
          throw new InvalidRuleException(InvalidRuleException.ErrorIds.RuleXMLIsInvalid, new string[0]);
      }
    }

    private static void AppendActionElement(List<Element> list, XmlNode source, XmlNode node)
    {
      List<Element> elementList = (List<Element>) null;
      Element el = new Element();
      el.Type = ElementType.Action;
      el.FuncType = FunctionType.Name;
      XmlNode xmlNode1 = (XmlNode) null;
      string str = (string) null;
      try
      {
        str = SourceLoader.GetTokenByRuleMethodNode(source, node, false);
        el.Token = el.Value = str;
        if (node.Attributes["type"] != null)
          Ce.SetElementType(el, node.Attributes["type"].Value);
        xmlNode1 = SourceLoader.GetActionByToken(source, el.Token);
      }
      catch (SourceException ex)
      {
        el.NotFound = true;
        if (string.IsNullOrWhiteSpace(el.Value))
          el.Token = el.Value = node.Attributes["name"].Value;
      }
      list.Add(el);
      if (!el.NotFound)
      {
        if (xmlNode1.ChildNodes.Count > 0)
        {
          XmlNode xmlNode2 = xmlNode1.ChildNodes[0];
          if (node.ChildNodes.Count != xmlNode2.ChildNodes.Count)
            throw new EvaluationException(EvaluationException.ErrorIds.ParameterCountMismatch, new string[1]{ node.Attributes["name"].Value });
          elementList = new List<Element>();
          for (int index = 0; index < xmlNode2.ChildNodes.Count; ++index)
          {
            XmlNode xmlNode3 = xmlNode2.ChildNodes[index];
            if (!(xmlNode3.Name == "constant") && !(xmlNode3.Name == "source"))
            {
              Element element = new Element();
              element.Type = ElementType.Action;
              element.FuncType = FunctionType.Param;
              element.ParameterType = ParameterType.Input;
              Ce.FillParamOperatorType(element, xmlNode3);
              element.InpType = node.ChildNodes[index].Name == "property" ? InputType.Field : InputType.Input;
              if (element.InpType == InputType.Field)
              {
                element.Value = node.ChildNodes[index].Attributes["name"].Value;
              }
              else
              {
                element.Value = Encoder.Sanitize(node.ChildNodes[index].InnerText);
                Ce.SetElementValues(element, xmlNode3, true);
              }
              elementList.Add(element);
            }
          }
        }
      }
      else
        elementList = (List<Element>) null;
      if (elementList != null && elementList.Count > 0)
      {
        for (int index = 0; index < elementList.Count; ++index)
        {
          if (index > 0)
            list.Add(new Element()
            {
              Type = ElementType.Action,
              FuncType = FunctionType.Comma
            });
          list.Add(elementList[index]);
        }
      }
      bool notFound = el.NotFound;
      Element element1 = new Element();
      element1.NotFound = notFound;
      element1.Type = ElementType.Action;
      element1.FuncType = FunctionType.End;
      element1.Token = element1.Value = str;
      list.Add(element1);
    }

    private static void AppendConditionElements(List<Element> list, XmlNode source, Element oper, XmlNode fieldNode, XmlNode valueNode, string uiNamespace)
    {
      Element field1 = (Element) null;
      Element end1 = (Element) null;
      Element field2 = (Element) null;
      Element end2 = (Element) null;
      Element element1 = (Element) null;
      Element element2 = (Element) null;
      List<Element> parameters1 = (List<Element>) null;
      List<Element> list1 = (List<Element>) null;
      List<Element> parameters2 = (List<Element>) null;
      switch (fieldNode.Name)
      {
        case "rule":
          field1 = new Element();
          field1.IsRule = true;
          field1.Type = ElementType.Field;
          field1.Value = fieldNode.Attributes["id"].Value;
          field1.Oper = oper.Oper = OperatorType.Bool;
          break;
        case "property":
          field1 = new Element();
          Ce.FillPropertyElement(field1, fieldNode, source);
          oper.Oper = field1.Oper;
          break;
        case "method":
          Ce.FillFunctionElements(out field1, out parameters1, out end1, fieldNode, source, false, false);
          oper.Oper = field1.Oper;
          break;
        default:
          throw new InvalidRuleException(InvalidRuleException.ErrorIds.UnexpectedChildNodeInCondition, new string[0]);
      }
      if (valueNode != null)
      {
        switch (valueNode.Name)
        {
          case "expression":
            element2 = new Element();
            element2.Type = ElementType.LeftBracket;
            element1 = new Element();
            element1.Type = ElementType.RightBracket;
            list1 = new List<Element>();
            Ce.AppendExpressionElements(list1, source, valueNode, uiNamespace);
            break;
          case "property":
            field2 = new Element();
            field2.Type = ElementType.Value;
            field2.InpType = InputType.Field;
            field2.Value = valueNode.Attributes["name"].Value;
            field2.Oper = field1.Oper;
            break;
          case "method":
            Ce.FillFunctionElements(out field2, out parameters2, out end2, valueNode, source, true, false);
            break;
          case "value":
            if (((XmlElement) valueNode).IsEmpty)
            {
              oper.Value = RuleValidator.GetNullableOperatorByOperType(field1.Oper, RuleValidator.IsNegativeOperator(oper.Value));
              break;
            }
            field2 = new Element();
            field2.Type = ElementType.Value;
            field2.InpType = InputType.Input;
            if (field1.Oper == OperatorType.Collection)
            {
              XmlNode fieldByPropertyName = SourceLoader.GetFieldByPropertyName(source, field1.Value);
              field2.Oper = Converter.ClientStringToClientType(fieldByPropertyName.ChildNodes[0].Attributes["type"].Value);
            }
            else
              field2.Oper = field1.Oper;
            field2.Value = field2.Oper != OperatorType.String ? valueNode.InnerText : Encoder.Sanitize(valueNode.InnerText);
            break;
          default:
            throw new InvalidRuleException(InvalidRuleException.ErrorIds.UnexpectedChildNodeInCondition, new string[0]);
        }
      }
      list.Add(field1);
      if (parameters1 != null && parameters1.Count > 0)
        Ce.AppendParameterElements(list, parameters1);
      if (end1 != null)
        list.Add(end1);
      list.Add(oper);
      if (field2 != null)
        list.Add(field2);
      if (parameters2 != null && parameters2.Count > 0)
        Ce.AppendParameterElements(list, parameters2);
      if (end2 != null)
        list.Add(end2);
      if (element2 == null)
        return;
      list.Add(element2);
      foreach (Element element3 in list1)
        list.Add(element3);
      list.Add(element1);
    }

    private static void AppendParameterElements(List<Element> list, List<Element> parameters)
    {
      for (int index = 0; index < parameters.Count; ++index)
      {
        if (index > 0)
          list.Add(new Element()
          {
            Type = ElementType.Function,
            FuncType = FunctionType.Comma
          });
        list.Add(parameters[index]);
      }
    }

    private static void AppendExpressionElements(List<Element> list, XmlNode source, XmlNode parent, string uiNamespace)
    {
      foreach (XmlNode childNode in parent.ChildNodes)
      {
        switch (childNode.Name)
        {
          case "divide":
          case "add":
          case "multiply":
          case "subtract":
            bool flag = childNode.Attributes["block", uiNamespace] != null && childNode.Attributes["block", uiNamespace].Value == "true";
            if (flag)
              Ce.AppendExpressionElement(list, CalculationType.LeftParenthesis, (string) null);
            Ce.AppendExpressionElements(list, source, childNode, uiNamespace);
            if (flag)
              Ce.AppendExpressionElement(list, CalculationType.RightParenthesis, (string) null);
            if (childNode.NextSibling != null && parent.Name != "expression")
            {
              Ce.AppendExpressionElement(list, Converter.StringToCalculationType(parent.Name), (string) null);
              continue;
            }
            continue;
          case "method":
            Element field = (Element) null;
            Element end = (Element) null;
            List<Element> parameters = (List<Element>) null;
            Ce.FillFunctionElements(out field, out parameters, out end, childNode, source, false, true);
            list.Add(field);
            if (parameters != null && parameters.Count > 0)
              Ce.AppendParameterElements(list, parameters);
            list.Add(end);
            if (childNode.NextSibling != null && parent.Name != "expression")
            {
              Ce.AppendExpressionElement(list, Converter.StringToCalculationType(parent.Name), (string) null);
              continue;
            }
            continue;
          case "property":
            Ce.AppendExpressionElement(list, CalculationType.Field, childNode.Attributes["name"].Value);
            if (childNode.NextSibling != null && parent.Name != "expression")
            {
              Ce.AppendExpressionElement(list, Converter.StringToCalculationType(parent.Name), (string) null);
              continue;
            }
            continue;
          case "value":
            Ce.AppendExpressionElement(list, CalculationType.Number, childNode.InnerText);
            if (childNode.NextSibling != null && parent.Name != "expression")
            {
              Ce.AppendExpressionElement(list, Converter.StringToCalculationType(parent.Name), (string) null);
              continue;
            }
            continue;
          default:
            continue;
        }
      }
    }

    private static void AppendExpressionElement(List<Element> list, CalculationType type, string value)
    {
      Element element = new Element();
      element.Type = ElementType.Calculation;
      element.CalType = type;
      element.Oper = OperatorType.Numeric;
      if (value != null)
        element.Value = value;
      list.Add(element);
    }

    private static void SetElementType(Element el, string typeAttribute)
    {
      Ce.SetElementType(el, typeAttribute, false);
    }

    private static void SetElementType(Element el, string typeAttribute, bool setReturnProperties)
    {
      string[] strArray = typeAttribute.Split(new string[1]{ "," }, StringSplitOptions.RemoveEmptyEntries);
      if (setReturnProperties)
        el.ReturnEnumClass = strArray[0].Trim();
      else
        el.Class = el.En = strArray[0].Trim();
      if (strArray.Length <= 1)
        return;
      for (int index = 1; index < strArray.Length; ++index)
      {
        if (setReturnProperties)
        {
          Element element = el;
          string str = element.ReturnEnumAssembly + strArray[index].Trim() + ",";
          element.ReturnEnumAssembly = str;
        }
        else
        {
          Element element = el;
          string str = element.Assembly + strArray[index].Trim() + ",";
          element.Assembly = str;
        }
      }
      if (setReturnProperties)
        el.ReturnEnumAssembly.TrimEnd(',');
      else
        el.Assembly.TrimEnd(',');
    }

    private static void SetElementValues(Element el, XmlNode node, bool isParam)
    {
      switch (el.Oper)
      {
        case OperatorType.String:
          if (isParam && el.ParameterType != ParameterType.Input)
            break;
          el.Max = new Decimal?((Decimal) new int?(int.Parse(node.Attributes["maxLength"].Value)).Value);
          break;
        case OperatorType.Numeric:
          if (!isParam || el.ParameterType == ParameterType.Input)
          {
            el.Dec = node.Attributes["allowDecimal"].Value == "true";
            el.Min = new Decimal?(Decimal.Parse(node.Attributes["min"].Value));
            el.Max = new Decimal?(Decimal.Parse(node.Attributes["max"].Value));
          }
          if (isParam)
            break;
          el.Cal = node.Attributes["allowCalculation"].Value == "true";
          break;
        case OperatorType.Date:
        case OperatorType.Time:
          if (isParam && el.ParameterType != ParameterType.Input)
            break;
          el.Format = node.Attributes["format"].Value;
          break;
        case OperatorType.Enum:
          if (!isParam && node.Attributes["class"] == null)
            break;
          Ce.SetElementType(el, node.Attributes["class"].Value);
          break;
      }
    }

    private static void FillDefinition(List<Element> items, XmlDocument doc, string ruleID, string ruleName, string ruleDescription, XmlDocument sourceXml, string sourceName, RuleType mode, bool isCurrentRuleOfEvalType, bool isInitialRule, ref int index)
    {
      XmlElement element1 = doc.CreateElement("rule", CodeEffects.Rule.Common.Xml.RuleNamespace);
      element1.SetAttribute("id", ruleID);
      element1.SetAttribute("webrule", Assembly.GetExecutingAssembly().GetName().Version.ToString());
      element1.SetAttribute("utc", DateTime.Now.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.ffff"));
      XmlNode sourceNodeByToken = SourceLoader.GetSourceNodeByToken(sourceXml, sourceName);
      if (sourceNodeByToken == null)
        throw new SourceException(SourceException.ErrorIds.SourceNodeNotFound, new string[1]{ sourceName });
      if (sourceNodeByToken.Attributes["persisted"] == null || sourceNodeByToken.Attributes["persisted"].Value == "true")
        element1.SetAttribute("type", sourceNodeByToken.Attributes["type"].Value);
      element1.SetAttribute("eval", isCurrentRuleOfEvalType ? "true" : "false");
      if (!string.IsNullOrEmpty(ruleName))
      {
        XmlElement element2 = doc.CreateElement("name", CodeEffects.Rule.Common.Xml.RuleNamespace);
        element2.InnerText = Encoder.ClearXml(ruleName);
        element1.AppendChild((XmlNode) element2);
      }
      if (!string.IsNullOrEmpty(ruleDescription))
      {
        XmlElement element2 = doc.CreateElement("description", CodeEffects.Rule.Common.Xml.RuleNamespace);
        element2.InnerText = Encoder.ClearXml(ruleDescription);
        element1.AppendChild((XmlNode) element2);
      }
      XmlElement element3 = doc.CreateElement("definition", CodeEffects.Rule.Common.Xml.RuleNamespace);
      element1.AppendChild((XmlNode) element3);
      XmlElement element4 = doc.CreateElement("format", CodeEffects.Rule.Common.Xml.RuleNamespace);
      XmlElement element5 = doc.CreateElement("lines", CodeEffects.Rule.Common.Xml.RuleNamespace);
      element4.AppendChild((XmlNode) element5);
      element1.AppendChild((XmlNode) element4);
      doc.DocumentElement.AppendChild((XmlNode) element1);
      Ce.FillFormatNodes(doc, element5, items, index);
      if (isInitialRule)
        Ce.EnsureCalcOperatorPriorities(items);
      if (isCurrentRuleOfEvalType)
        Ce.FillEvaluationNodes(doc, element3, items, sourceNodeByToken, ref index);
      else
        Ce.FillExecutionNodes(doc, element3, items, sourceNodeByToken, mode, ref index);
    }

    private static void FillExecutionNodes(XmlDocument doc, XmlElement parent, List<Element> items, XmlNode source, RuleType mode, ref int index)
    {
      XmlElement xmlElement = (XmlElement) null;
      XmlElement element1 = doc.CreateElement(mode == RuleType.Loop ? "while" : "if", CodeEffects.Rule.Common.Xml.RuleNamespace);
      XmlElement element2 = doc.CreateElement("clause", CodeEffects.Rule.Common.Xml.RuleNamespace);
      element1.AppendChild((XmlNode) element2);
      parent.AppendChild((XmlNode) element1);
      Ce.FillEvaluationNodes(doc, element2, items, source, ref index);
      RuleAction ruleAction = (RuleAction) null;
      while (index < items.Count)
      {
        Element element3 = items[index];
        switch (element3.Type)
        {
          case ElementType.Flow:
            if (element3.Value == "elseIf")
            {
              if (mode == RuleType.Ruleset)
              {
                Ce.FillExecutionNodes(doc, parent, items, source, mode, ref index);
                break;
              }
              XmlElement element4 = doc.CreateElement("else", CodeEffects.Rule.Common.Xml.RuleNamespace);
              element1.AppendChild((XmlNode) element4);
              Ce.FillExecutionNodes(doc, element4, items, source, mode, ref index);
              break;
            }
            xmlElement = doc.CreateElement("else", CodeEffects.Rule.Common.Xml.RuleNamespace);
            element1.AppendChild((XmlNode) xmlElement);
            break;
          case ElementType.Action:
            switch (element3.FuncType)
            {
              case FunctionType.Name:
                ruleAction = new RuleAction()
                {
                  Action = element3
                };
                break;
              case FunctionType.Param:
                if (ruleAction != null)
                {
                  ruleAction.Parameters.Add(element3);
                  break;
                }
                break;
              case FunctionType.End:
                if (xmlElement == null)
                {
                  xmlElement = doc.CreateElement("then", CodeEffects.Rule.Common.Xml.RuleNamespace);
                  element1.AppendChild((XmlNode) xmlElement);
                }
                XmlElement element5 = doc.CreateElement("method", CodeEffects.Rule.Common.Xml.RuleNamespace);
                Ce.FillMethodNode(doc, element5, ruleAction.Action, ruleAction.Parameters, source);
                xmlElement.AppendChild((XmlNode) element5);
                break;
            }
          case ElementType.Setter:
            if (element3.Value == "set")
            {
              RuleSetter setter = new RuleSetter();
              if (xmlElement == null)
              {
                xmlElement = doc.CreateElement("then", CodeEffects.Rule.Common.Xml.RuleNamespace);
                element1.AppendChild((XmlNode) xmlElement);
              }
              XmlElement element4 = doc.CreateElement("set", CodeEffects.Rule.Common.Xml.RuleNamespace);
              Ce.FillSetterNode(doc, element4, setter, items, source, ref index);
              xmlElement.AppendChild((XmlNode) element4);
              break;
            }
            break;
        }
        ++index;
      }
    }

    private static void FillEvaluationNodes(XmlDocument doc, XmlElement parent, List<Element> items, XmlNode source, ref int index)
    {
      Element element1 = Ce.PeekLevelClause(items, index);
      XmlElement xmlElement = (XmlElement) null;
      if (element1 != null && element1.Value != "then")
        xmlElement = doc.CreateElement(element1.Value == "and" ? "and" : "or", CodeEffects.Rule.Common.Xml.RuleNamespace);
      if (xmlElement != null)
      {
        if (index > 0)
        {
          Element element2 = items[index - 1];
          if (element2.Type == ElementType.LeftParenthesis && element2.IsOrganicParenthesis)
            xmlElement.SetAttribute("block", "http://codeeffects.com/schemas/ui/4", "true");
        }
        parent.AppendChild((XmlNode) xmlElement);
      }
      RuleCondition condition = (RuleCondition) null;
      bool flag = false;
      SelectionType type = SelectionType.None;
      while (index < items.Count)
      {
        Element element2 = items[index];
        switch (element2.Type)
        {
          case ElementType.Field:
            if (condition == null)
              condition = new RuleCondition();
            condition.Field = element2;
            if (element2.Oper == OperatorType.Collection && element2.CollType == CollectionType.Value)
            {
              SourceLoader.GetFieldByPropertyName(source, element2.Value);
              break;
            }
            break;
          case ElementType.Function:
            if (condition == null)
              condition = new RuleCondition();
            switch (element2.FuncType)
            {
              case FunctionType.Name:
                if (element2.IsFuncValue)
                {
                  flag = true;
                  condition.ValueParametersCount = SourceLoader.GetParamNode(SourceLoader.GetFunctionByToken(source, element2.Token)).ChildNodes.Count;
                  condition.Value = element2;
                  break;
                }
                condition.Field = element2;
                break;
              case FunctionType.Param:
                if (flag)
                {
                  condition.ValueParameters.Add(element2);
                  break;
                }
                condition.Parameters.Add(element2);
                break;
              case FunctionType.End:
                flag = false;
                break;
            }
          case ElementType.Operator:
            if (condition == null)
              condition = new RuleCondition();
            condition.Operator = element2;
            break;
          case ElementType.Value:
            if (condition == null)
              condition = new RuleCondition();
            condition.Value = element2;
            break;
          case ElementType.Clause:
            if (element2.Value == "then")
              return;
            break;
          case ElementType.LeftParenthesis:
            ++index;
            Ce.FillEvaluationNodes(doc, xmlElement == null ? parent : xmlElement, items, source, ref index);
            break;
          case ElementType.RightParenthesis:
            return;
          case ElementType.LeftBracket:
            ++index;
            XmlElement element3 = doc.CreateElement("expression", CodeEffects.Rule.Common.Xml.RuleNamespace);
            string numericTypeName = "numeric";
            if (condition != null && condition.Field.Oper == OperatorType.Collection && condition.Field.CollType == CollectionType.Value)
            {
              XmlNode fieldByPropertyName = SourceLoader.GetFieldByPropertyName(source, condition.Field.Value);
              if (fieldByPropertyName.Attributes["generic"].Value == "false" && fieldByPropertyName.Attributes["array"].Value == "false")
                numericTypeName = fieldByPropertyName.ChildNodes[0].Attributes["class"].Value;
            }
            Ce.FillCalculationNode(doc, element3, items, source, (RuleCondition) null, numericTypeName, ref index);
            if (condition == null)
              condition = new RuleCondition();
            condition.Calculation = element3;
            break;
          case ElementType.LeftSource:
            ++index;
            string @string = Guid.NewGuid().ToString();
            XmlElement element4 = doc.CreateElement("property", CodeEffects.Rule.Common.Xml.RuleNamespace);
            XmlElement element5 = doc.CreateElement("rule", CodeEffects.Rule.Common.Xml.RuleNamespace);
            element5.SetAttribute("id", @string);
            element5.SetAttribute("operator", Converter.SelectionTypeToString(type));
            element4.SetAttribute("name", condition.Field.Value);
            element5.AppendChild((XmlNode) element4);
            (xmlElement == null ? (XmlNode) parent : (XmlNode) xmlElement).AppendChild((XmlNode) element5);
            Ce.FillDefinition(items, doc, @string, (string) null, (string) null, source.OwnerDocument, element2.Value, RuleType.Evaluation, true, false, ref index);
            break;
          case ElementType.RightSource:
            return;
          case ElementType.Exists:
            type = element2.SelType;
            break;
        }
        if (condition != null && condition.Valid)
        {
          Ce.AppendConditionNode(doc, xmlElement == null ? parent : xmlElement, condition, source);
          condition = (RuleCondition) null;
        }
        ++index;
      }
    }

    private static void FillSetterNode(XmlDocument doc, XmlElement el, RuleSetter setter, List<Element> items, XmlNode source, ref int index)
    {
      bool flag = false;
      while (index < items.Count)
      {
        Element element1 = items[index];
        switch (element1.Type)
        {
          case ElementType.Flow:
          case ElementType.Clause:
            if (element1.Type == ElementType.Flow)
              --index;
            if (!setter.Valid)
              return;
            Ce.AppendSetterNode(doc, el, setter, source);
            return;
          case ElementType.Field:
            setter.Field = element1;
            break;
          case ElementType.Function:
            switch (element1.FuncType)
            {
              case FunctionType.Name:
                if (element1.IsFuncValue)
                {
                  flag = true;
                  setter.ValueParametersCount = SourceLoader.GetParamNode(SourceLoader.GetFunctionByToken(source, element1.Token)).ChildNodes.Count;
                  setter.Value = element1;
                  break;
                }
                break;
              case FunctionType.Param:
                if (flag)
                {
                  setter.ValueParameters.Add(element1);
                  break;
                }
                break;
              case FunctionType.End:
                flag = false;
                break;
            }
          case ElementType.Value:
            setter.Value = element1;
            break;
          case ElementType.LeftBracket:
            ++index;
            XmlElement element2 = doc.CreateElement("expression", CodeEffects.Rule.Common.Xml.RuleNamespace);
            Ce.FillCalculationNode(doc, element2, items, source, (RuleCondition) null, "numeric", ref index);
            setter.Calculation = element2;
            break;
        }
        ++index;
      }
      if (!setter.Valid)
        return;
      Ce.AppendSetterNode(doc, el, setter, source);
    }

    private static void FillCalculationNode(XmlDocument doc, XmlElement parent, List<Element> items, XmlNode source, RuleCondition condition, string numericTypeName, ref int index)
    {
      Element el = Ce.PeekLevelMathOperator(items, index);
      XmlElement xmlElement = (XmlElement) null;
      if (el != null)
      {
        xmlElement = doc.CreateElement(Ce.GetCalculationNodeName(el), CodeEffects.Rule.Common.Xml.RuleNamespace);
        Element element = items[index - 1];
        if (element.CalType == CalculationType.LeftParenthesis && element.IsOrganicParenthesis)
          xmlElement.SetAttribute("block", "http://codeeffects.com/schemas/ui/4", "true");
        parent.AppendChild((XmlNode) xmlElement);
      }
      while (index < items.Count)
      {
        Element element1 = items[index];
        switch (element1.Type)
        {
          case ElementType.Function:
            if (condition == null)
              throw new InvalidRuleException(InvalidRuleException.ErrorIds.UnexpectedOrderOfCalculationNodes, new string[0]);
            if (element1.FuncType == FunctionType.Param)
            {
              condition.Parameters.Add(element1);
              break;
            }
            break;
          case ElementType.RightBracket:
            return;
          case ElementType.Calculation:
            switch (element1.CalType)
            {
              case CalculationType.Field:
                XmlElement element2 = doc.CreateElement("property", CodeEffects.Rule.Common.Xml.RuleNamespace);
                element2.SetAttribute("name", element1.Value);
                if (xmlElement == null)
                {
                  parent.AppendChild((XmlNode) element2);
                  break;
                }
                xmlElement.AppendChild((XmlNode) element2);
                break;
              case CalculationType.LeftParenthesis:
                ++index;
                Ce.FillCalculationNode(doc, xmlElement == null ? parent : xmlElement, items, source, condition, numericTypeName, ref index);
                break;
              case CalculationType.RightParenthesis:
                return;
              case CalculationType.Number:
                XmlElement element3 = doc.CreateElement("value", CodeEffects.Rule.Common.Xml.RuleNamespace);
                element3.SetAttribute("type", numericTypeName);
                element3.InnerText = element1.Value;
                if (xmlElement == null)
                {
                  parent.AppendChild((XmlNode) element3);
                  break;
                }
                xmlElement.AppendChild((XmlNode) element3);
                break;
              case CalculationType.Function:
                switch (element1.FuncType)
                {
                  case FunctionType.Name:
                    if (condition == null)
                      condition = new RuleCondition();
                    condition.Field = element1;
                    break;
                  case FunctionType.End:
                    if (condition == null)
                      throw new InvalidRuleException(InvalidRuleException.ErrorIds.UnexpectedOrderOfCalculationNodes, new string[0]);
                    XmlElement element4 = doc.CreateElement("method", CodeEffects.Rule.Common.Xml.RuleNamespace);
                    Ce.FillMethodNode(doc, element4, condition.Field, condition.Parameters, source);
                    if (xmlElement == null)
                      parent.AppendChild((XmlNode) element4);
                    else
                      xmlElement.AppendChild((XmlNode) element4);
                    condition = (RuleCondition) null;
                    break;
                }
            }
        }
        ++index;
      }
    }

    private static void FillMethodNode(XmlDocument doc, XmlElement el, Element method, List<Element> parameters, XmlNode source)
    {
      el.SetAttribute("name", method.Value);
      if (!string.IsNullOrEmpty(method.Class))
      {
        string str = method.Class;
        if (!string.IsNullOrEmpty(method.Assembly))
          str = str + ", " + method.Assembly;
        el.SetAttribute("type", str);
      }
      if (parameters == null || parameters.Count <= 0)
        return;
      for (int index = 0; index < parameters.Count; ++index)
      {
        Element element = parameters[index];
        XmlElement xmlElement = (XmlElement) null;
        switch (element.ParameterType)
        {
          case ParameterType.Source:
            xmlElement = doc.CreateElement("self", CodeEffects.Rule.Common.Xml.RuleNamespace);
            break;
          case ParameterType.Input:
            if (element.InpType == InputType.Field)
            {
              xmlElement = doc.CreateElement("property", CodeEffects.Rule.Common.Xml.RuleNamespace);
              xmlElement.SetAttribute("name", element.Value);
              break;
            }
            xmlElement = doc.CreateElement("value", CodeEffects.Rule.Common.Xml.RuleNamespace);
            Ce.SetParamType(element, xmlElement, method, source, index);
            Ce.FillNodeUiAttributes(xmlElement, element);
            xmlElement.InnerText = element.Oper == OperatorType.String ? Encoder.ClearXml(element.Value) : element.Value;
            break;
          case ParameterType.Constant:
            xmlElement = doc.CreateElement("value", CodeEffects.Rule.Common.Xml.RuleNamespace);
            Ce.SetParamType(element, xmlElement, method, source, index);
            Ce.FillNodeUiAttributes(xmlElement, element);
            xmlElement.InnerText = element.Oper == OperatorType.String ? Encoder.ClearXml(element.Value) : element.Value;
            break;
        }
        if (xmlElement != null)
          el.AppendChild((XmlNode) xmlElement);
      }
    }

    private static void SetParamType(Element parameter, XmlElement property, Element method, XmlNode source, int index)
    {
      if (parameter.Oper == OperatorType.String)
        return;
      property.SetAttribute("type", Ce.GetParamType(method, source, index));
    }

    private static void FillNodeUiAttributes(XmlElement el, Element field)
    {
      if (field.Oper != OperatorType.Enum)
        return;
      string str1;
      string str2;
      if ((field.Type == ElementType.Function || field.Type == ElementType.Calculation) && field.FuncType == FunctionType.Name)
      {
        str1 = field.ReturnEnumClass;
        str2 = field.ReturnEnumAssembly;
      }
      else
      {
        str1 = field.En;
        str2 = field.Assembly;
      }
      if (!string.IsNullOrWhiteSpace(str2))
        str1 = str1 + ", " + str2;
      el.SetAttribute("type", str1);
    }

    private static void AppendConditionNode(XmlDocument doc, XmlElement parent, RuleCondition condition, XmlNode source)
    {
      XmlElement element1 = doc.CreateElement("condition", CodeEffects.Rule.Common.Xml.RuleNamespace);
      string str1 = !RuleValidator.IsNullableOperator(condition.Operator.Value) ? condition.Operator.Value : RuleValidator.GetNullableOperatorByOperType(condition.Field.Oper, RuleValidator.IsNegativeNullableOperator(condition.Operator.Value));
      element1.SetAttribute("type", str1);
      if (condition.Operator.Oper == OperatorType.String && condition.Value != null)
      {
        StringComparison valueOption = condition.Value.InpType == InputType.Input || condition.Value.InpType == InputType.None ? condition.Field.StringComparison : condition.Value.StringComparison;
        StringComparison comparison = Ce.GetComparison(condition.Field.StringComparison, valueOption);
        element1.SetAttribute("stringComparison", comparison.ToString());
      }
      switch (condition.Field.Type)
      {
        case ElementType.Field:
          if (condition.Field.IsRule)
          {
            XmlElement element2 = doc.CreateElement("rule", CodeEffects.Rule.Common.Xml.RuleNamespace);
            element2.SetAttribute("id", condition.Field.Value);
            element1.AppendChild((XmlNode) element2);
            break;
          }
          XmlElement element3 = doc.CreateElement("property", CodeEffects.Rule.Common.Xml.RuleNamespace);
          element3.SetAttribute("name", condition.Field.Value);
          if (condition.Field.Oper == OperatorType.Collection && condition.Field.CollType == CollectionType.Value)
          {
            XmlNode fieldByPropertyName = SourceLoader.GetFieldByPropertyName(source, condition.Field.Value);
            if (fieldByPropertyName.Attributes["generic"].Value == "false" && fieldByPropertyName.Attributes["array"].Value == "false")
              element3.SetAttribute("itemType", fieldByPropertyName.ChildNodes[0].Attributes["class"].Value);
          }
          element1.AppendChild((XmlNode) element3);
          break;
        case ElementType.Function:
          XmlElement element4 = doc.CreateElement("method", CodeEffects.Rule.Common.Xml.RuleNamespace);
          if (condition.Field.IsInstance)
            element4.SetAttribute("instance", "true");
          Ce.FillMethodNode(doc, element4, condition.Field, condition.Parameters, source);
          element1.AppendChild((XmlNode) element4);
          break;
        default:
          throw new InvalidRuleException(InvalidRuleException.ErrorIds.InvalidOrderOfNodes, new string[0]);
      }
      if ((condition.Value != null || condition.Calculation != null) && !RuleValidator.IsNullableOperator(condition.Operator.Value))
      {
        if (condition.Calculation != null)
          element1.AppendChild((XmlNode) condition.Calculation);
        else if (condition.Value.Type == ElementType.Function)
        {
          XmlElement element2 = doc.CreateElement("method", CodeEffects.Rule.Common.Xml.RuleNamespace);
          if (condition.Value.IsInstance)
            element2.SetAttribute("instance", "true");
          Ce.FillMethodNode(doc, element2, condition.Value, condition.ValueParameters, source);
          element1.AppendChild((XmlNode) element2);
        }
        else
        {
          XmlElement element2;
          if (condition.Value.InpType == InputType.Field)
          {
            element2 = doc.CreateElement("property", CodeEffects.Rule.Common.Xml.RuleNamespace);
            element2.SetAttribute("name", condition.Value.Value);
          }
          else
          {
            element2 = doc.CreateElement("value", CodeEffects.Rule.Common.Xml.RuleNamespace);
            if (condition.Value.Oper != OperatorType.String)
            {
              string str2 = condition.Operator.Oper == OperatorType.Numeric ? "numeric" : Ce.GetTypeByFieldName(source, condition.Field);
              element2.SetAttribute("type", str2);
            }
            Ce.FillNodeUiAttributes(element2, condition.Field);
            element2.InnerText = condition.Field.Oper == OperatorType.String ? Encoder.ClearXml(condition.Value.Value) : condition.Value.Value;
          }
          element1.AppendChild((XmlNode) element2);
        }
      }
      parent.AppendChild((XmlNode) element1);
    }

    private static void AppendSetterNode(XmlDocument doc, XmlElement parent, RuleSetter setter, XmlNode source)
    {
      XmlElement element1 = doc.CreateElement("property", CodeEffects.Rule.Common.Xml.RuleNamespace);
      element1.SetAttribute("name", setter.Field.Value);
      parent.AppendChild((XmlNode) element1);
      if (setter.Calculation != null)
        parent.AppendChild((XmlNode) setter.Calculation);
      else if (setter.Value.Type == ElementType.Function)
      {
        XmlElement element2 = doc.CreateElement("method", CodeEffects.Rule.Common.Xml.RuleNamespace);
        if (setter.Value.IsInstance)
          element2.SetAttribute("instance", "true");
        Ce.FillMethodNode(doc, element2, setter.Value, setter.ValueParameters, source);
        parent.AppendChild((XmlNode) element2);
      }
      else
      {
        XmlElement element2;
        if (setter.Value.InpType == InputType.Field)
        {
          element2 = doc.CreateElement("property", CodeEffects.Rule.Common.Xml.RuleNamespace);
          element2.SetAttribute("name", setter.Value.Value);
        }
        else
        {
          element2 = doc.CreateElement("value", CodeEffects.Rule.Common.Xml.RuleNamespace);
          if (setter.Value.Oper != OperatorType.String)
          {
            string str = setter.Field.Oper == OperatorType.Numeric ? "numeric" : Ce.GetTypeByFieldName(source, setter.Field);
            element2.SetAttribute("type", str);
          }
          Ce.FillNodeUiAttributes(element2, setter.Field);
          element2.InnerText = setter.Field.Oper == OperatorType.String ? Encoder.ClearXml(setter.Value.Value) : setter.Value.Value;
        }
        parent.AppendChild((XmlNode) element2);
      }
    }

    private static void AppendLineNode(XmlDocument doc, XmlElement format, RuleLine line)
    {
      XmlElement element = doc.CreateElement("line", CodeEffects.Rule.Common.Xml.RuleNamespace);
      element.SetAttribute("index", line.Index.ToString());
      element.SetAttribute("tabs", line.Tabs.ToString());
      format.AppendChild((XmlNode) element);
    }

    private static string GetParamType(Element method, XmlNode source, int index)
    {
      if (method.Type == ElementType.Action)
        return SourceLoader.GetParamNode(SourceLoader.GetActionByToken(source, method.Token)).ChildNodes[index].Attributes["class"].Value;
      return SourceLoader.GetParamNode(SourceLoader.GetFunctionByToken(source, method.Token)).ChildNodes[index].Attributes["class"].Value;
    }

    private static string GetTypeByFieldName(XmlNode source, Element field)
    {
      if (field.IsRule)
        return typeof (bool).FullName;
      if (field.Type == ElementType.Function)
        return SourceLoader.GetReturnNode(SourceLoader.GetFunctionByToken(source, field.Token)).Attributes["class"].Value;
      if (field.Oper == OperatorType.Collection && field.CollType == CollectionType.Value)
        return SourceLoader.GetFieldByPropertyName(source, field.Value).ChildNodes[0].Attributes["class"].Value;
      return SourceLoader.GetFieldByPropertyName(source, field.Value).Attributes["class"].Value;
    }

    private static Element PeekLevelClause(List<Element> items, int index)
    {
      int num = 0;
      for (int index1 = index; index1 < items.Count; ++index1)
      {
        Element element = items[index1];
        if (element.Type == ElementType.LeftParenthesis || element.Type == ElementType.LeftSource)
          ++num;
        else if ((element.Type == ElementType.RightParenthesis || element.Type == ElementType.RightSource) && num > 0)
          --num;
        else if (element.Type != ElementType.RightParenthesis && element.Type != ElementType.RightSource || num != 0)
        {
          if (element.Type == ElementType.Clause && num == 0)
            return element;
        }
        else
          break;
      }
      return (Element) null;
    }

    private static Element PeekLevelMathOperator(List<Element> items, int index)
    {
      int num = 0;
      for (int index1 = index; index1 < items.Count; ++index1)
      {
        Element element = items[index1];
        if (element.Type == ElementType.RightBracket)
          return (Element) null;
        if (element.Type == ElementType.Calculation)
        {
          if (element.CalType == CalculationType.LeftParenthesis)
            ++num;
          else if (element.CalType == CalculationType.RightParenthesis && num > 0)
            --num;
          else if (element.CalType != CalculationType.RightParenthesis || num != 0)
          {
            if ((element.CalType == CalculationType.Addition || element.CalType == CalculationType.Division || (element.CalType == CalculationType.Multiplication || element.CalType == CalculationType.Subtraction)) && num == 0)
              return element;
          }
          else
            break;
        }
      }
      return (Element) null;
    }

    private static string GetCalculationNodeName(Element el)
    {
      switch (el.CalType)
      {
        case CalculationType.Multiplication:
          return "multiply";
        case CalculationType.Division:
          return "divide";
        case CalculationType.Addition:
          return "add";
        case CalculationType.Subtraction:
          return "subtract";
        default:
          throw new InvalidRuleException(InvalidRuleException.ErrorIds.RuleXMLIsInvalid, new string[0]);
      }
    }

    private static void EnsureCalcOperatorPriorities(List<Element> items)
    {
      for (int index = 0; index < items.Count; ++index)
      {
        switch (items[index].CalType)
        {
          case CalculationType.Multiplication:
          case CalculationType.Division:
            Ce.EnsureCalcParentheses(items, index);
            break;
        }
      }
      bool flag1 = true;
      bool flag2 = false;
      for (int index = 0; index < items.Count; ++index)
      {
        Element element = items[index];
        if (element.Type == ElementType.RightBracket)
        {
          flag1 = true;
        }
        else
        {
          switch (element.CalType)
          {
            case CalculationType.Field:
            case CalculationType.Number:
              if (!flag1 && !flag2)
              {
                if (!Ce.RightParenthesisExists(items, index + 1))
                {
                  Ce.InsertParenthesis(items, index + 1, CalculationType.RightParenthesis);
                  Ce.InsertParenthesis(items, Ce.GetIndexForLeftParenthesis(items, index - 1), CalculationType.LeftParenthesis);
                }
              }
              else
                flag1 = false;
              flag2 = false;
              continue;
            case CalculationType.LeftParenthesis:
              flag2 = true;
              continue;
            case CalculationType.Function:
              if (element.FuncType == FunctionType.Name && !flag1 && !flag2)
              {
                int indexForEndFunction = Ce.GetIndexForEndFunction(items, index);
                if (!Ce.RightParenthesisExists(items, indexForEndFunction + 1))
                {
                  Ce.InsertParenthesis(items, indexForEndFunction + 1, CalculationType.RightParenthesis);
                  Ce.InsertParenthesis(items, Ce.GetIndexForLeftParenthesis(items, index - 1), CalculationType.LeftParenthesis);
                  index = indexForEndFunction + 1;
                }
              }
              else
                flag1 = false;
              flag2 = false;
              continue;
            default:
              continue;
          }
        }
      }
      for (int index = 0; index < items.Count; ++index)
      {
        switch (items[index].Type)
        {
          case ElementType.LeftBracket:
            Ce.InsertParenthesis(items, index + 1, CalculationType.LeftParenthesis);
            break;
          case ElementType.RightBracket:
            Ce.InsertParenthesis(items, index - 1, CalculationType.RightParenthesis);
            ++index;
            break;
        }
      }
    }

    private static void EnsureCalcParentheses(List<Element> items, int index)
    {
      int? prevCalcOperator = Ce.GetPrevCalcOperator(items, index - 1);
      int? nextCalcOperator = Ce.GetNextCalcOperator(items, index + 1);
      if (!prevCalcOperator.HasValue || !nextCalcOperator.HasValue)
        return;
      Ce.InsertParenthesis(items, prevCalcOperator.Value + 1, CalculationType.LeftParenthesis);
      Ce.InsertParenthesis(items, nextCalcOperator.Value + 1, CalculationType.RightParenthesis);
    }

    private static int? GetPrevCalcOperator(List<Element> items, int index)
    {
      for (int index1 = index; index1 > -1; --index1)
      {
        Element element = items[index1];
        if (element.Type == ElementType.LeftBracket)
          return new int?(index1);
        switch (element.CalType)
        {
          case CalculationType.LeftParenthesis:
          case CalculationType.RightParenthesis:
            return new int?();
          case CalculationType.Multiplication:
          case CalculationType.Division:
          case CalculationType.Addition:
          case CalculationType.Subtraction:
            return new int?(index1);
          default:
            goto default;
        }
      }
      return new int?();
    }

    private static int? GetNextCalcOperator(List<Element> items, int index)
    {
      for (int index1 = index; index1 < items.Count; ++index1)
      {
        Element element = items[index1];
        if (element.Type == ElementType.RightBracket)
          return new int?(index1);
        switch (element.CalType)
        {
          case CalculationType.LeftParenthesis:
          case CalculationType.RightParenthesis:
            return new int?();
          case CalculationType.Multiplication:
          case CalculationType.Division:
          case CalculationType.Addition:
          case CalculationType.Subtraction:
            return new int?(index1);
          default:
            goto default;
        }
      }
      return new int?(items.Count);
    }

    private static void InsertParenthesis(List<Element> items, int index, CalculationType type)
    {
      items.Insert(index, new Element()
      {
        Type = ElementType.Calculation,
        CalType = type,
        IsOrganicParenthesis = false
      });
    }

    private static bool RightParenthesisExists(List<Element> items, int index)
    {
      for (int index1 = index; index1 < items.Count; ++index1)
      {
        Element element = items[index1];
        if (element.Type == ElementType.RightBracket)
          return false;
        if (element.Type == ElementType.Calculation)
          return element.CalType == CalculationType.RightParenthesis;
      }
      return false;
    }

    private static int GetIndexForEndFunction(List<Element> items, int index)
    {
      for (int index1 = index; index1 < items.Count; ++index1)
      {
        Element element = items[index1];
        if (element.Type == ElementType.RightBracket)
          throw new InvalidRuleException(InvalidRuleException.ErrorIds.UnexpectedOrderOfCalculationNodes, new string[0]);
        if (element.Type == ElementType.Calculation && element.FuncType == FunctionType.End)
          return index1;
      }
      throw new InvalidRuleException(InvalidRuleException.ErrorIds.UnexpectedOrderOfCalculationNodes, new string[0]);
    }

    private static int GetIndexForLeftParenthesis(List<Element> items, int index)
    {
      int num = 0;
      int index1;
      for (index1 = index; index1 > -1; --index1)
      {
        Element element = items[index1];
        if (element.Type == ElementType.LeftBracket)
          return index1 + 1;
        if (element.CalType == CalculationType.RightParenthesis)
          ++num;
        else if (element.CalType == CalculationType.LeftParenthesis)
        {
          if (num > 0)
            --num;
          if (num == 0)
            return index1;
        }
        else if ((element.CalType == CalculationType.Number || element.CalType == CalculationType.Field || element.CalType == CalculationType.Function && element.FuncType == FunctionType.Name) && num == 0)
          return index1;
      }
      return index1;
    }

    private static StringComparison GetComparison(StringComparison fieldOption, StringComparison valueOption)
    {
      switch (valueOption)
      {
        case StringComparison.CurrentCulture:
          switch (fieldOption)
          {
            case StringComparison.CurrentCulture:
            case StringComparison.CurrentCultureIgnoreCase:
            case StringComparison.InvariantCulture:
            case StringComparison.InvariantCultureIgnoreCase:
              return StringComparison.CurrentCulture;
            default:
              return StringComparison.Ordinal;
          }
        case StringComparison.CurrentCultureIgnoreCase:
          switch (fieldOption)
          {
            case StringComparison.CurrentCulture:
            case StringComparison.InvariantCulture:
              return StringComparison.CurrentCulture;
            case StringComparison.CurrentCultureIgnoreCase:
            case StringComparison.InvariantCultureIgnoreCase:
              return StringComparison.CurrentCultureIgnoreCase;
            case StringComparison.OrdinalIgnoreCase:
              return StringComparison.OrdinalIgnoreCase;
            default:
              return StringComparison.Ordinal;
          }
        case StringComparison.InvariantCulture:
          switch (fieldOption)
          {
            case StringComparison.CurrentCultureIgnoreCase:
              return StringComparison.CurrentCulture;
            case StringComparison.InvariantCultureIgnoreCase:
              return StringComparison.InvariantCulture;
            case StringComparison.OrdinalIgnoreCase:
              return StringComparison.Ordinal;
            default:
              return fieldOption;
          }
        case StringComparison.Ordinal:
          return StringComparison.Ordinal;
        case StringComparison.OrdinalIgnoreCase:
          switch (fieldOption)
          {
            case StringComparison.CurrentCulture:
            case StringComparison.InvariantCulture:
            case StringComparison.Ordinal:
              return StringComparison.Ordinal;
            default:
              return StringComparison.OrdinalIgnoreCase;
          }
        default:
          return fieldOption;
      }
    }

    private static void FillFormatNodes(XmlDocument doc, XmlElement parent, List<Element> items, int index)
    {
      List<Element> elementList = new List<Element>();
      int num1 = 0;
      int num2 = 0;
      for (int index1 = index; index1 < items.Count; ++index1)
      {
        Element element = items[index1];
        if (element.Type == ElementType.Function || element.Type == ElementType.Action || element.Type == ElementType.Calculation)
        {
          if (element.FuncType == FunctionType.Param && (element.ParameterType == ParameterType.Source || element.ParameterType == ParameterType.Constant))
            continue;
        }
        else if (element.Type == ElementType.LeftSource)
          ++num1;
        else if (element.Type == ElementType.RightSource)
        {
          ++num2;
          if (num2 > num1)
            break;
        }
        elementList.Add(element.Clone());
      }
      RuleLine line = (RuleLine) null;
      bool flag = false;
      int num3;
      int num4 = num3 = 0;
      int index2 = index == 0 ? -1 : 0;
      int index3 = 0;
      while (index3 < elementList.Count)
      {
        Element element = elementList[index3];
        switch (element.Type)
        {
          case ElementType.Function:
          case ElementType.Action:
          case ElementType.Calculation:
            if (element.Type != ElementType.Calculation || element.CalType == CalculationType.Function)
            {
              if (!flag)
              {
                if (line != null)
                  Ce.AppendLineNode(doc, parent, line);
                line = (RuleLine) null;
              }
              if (element.FuncType == FunctionType.Param && elementList[index3 + 1].FuncType != FunctionType.End)
              {
                ++index2;
                break;
              }
              break;
            }
            break;
          case ElementType.Tab:
            if (!flag && line != null)
            {
              ++line.Tabs;
              break;
            }
            break;
          case ElementType.NewLine:
            if (!flag)
            {
              if (line != null)
                Ce.AppendLineNode(doc, parent, line);
              line = new RuleLine(index2);
              break;
            }
            break;
          case ElementType.LeftSource:
            if (line != null)
            {
              Ce.AppendLineNode(doc, parent, line);
              line = (RuleLine) null;
            }
            ++num4;
            flag = true;
            break;
          case ElementType.RightSource:
            if (line != null)
            {
              Ce.AppendLineNode(doc, parent, line);
              line = (RuleLine) null;
            }
            ++num3;
            if (num3 >= num4)
            {
              num4 = num3 = 0;
              flag = false;
              break;
            }
            break;
          default:
            if (!flag)
            {
              if (line != null)
                Ce.AppendLineNode(doc, parent, line);
              line = (RuleLine) null;
              break;
            }
            break;
        }
        ++index3;
        ++index2;
      }
      if (line == null)
        return;
      Ce.AppendLineNode(doc, parent, line);
    }
  }
}
