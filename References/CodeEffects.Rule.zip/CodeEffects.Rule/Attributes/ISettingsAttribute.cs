﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Attributes.ISettingsAttribute
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using System;

namespace CodeEffects.Rule.Attributes
{
  public interface ISettingsAttribute
  {
    long Max { get; set; }

    long Min { get; set; }

    string DateTimeFormat { get; set; }

    Type CollectionItemType { get; set; }

    string DataSourceName { get; set; }
  }
}
