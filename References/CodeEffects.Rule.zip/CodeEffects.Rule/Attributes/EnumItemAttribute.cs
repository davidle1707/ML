﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Attributes.EnumItemAttribute
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using System;

namespace CodeEffects.Rule.Attributes
{
  [AttributeUsage(AttributeTargets.Field, AllowMultiple = false, Inherited = false)]
  public sealed class EnumItemAttribute : Attribute, IDisplayableAttribute
  {
    public string DisplayName { get; private set; }

    public EnumItemAttribute(string displayName)
    {
      this.DisplayName = displayName;
    }
  }
}
