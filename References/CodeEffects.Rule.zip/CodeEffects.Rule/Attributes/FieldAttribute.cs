﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Attributes.FieldAttribute
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using CodeEffects.Rule.Common;
using System;

namespace CodeEffects.Rule.Attributes
{
  [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = false, Inherited = true)]
  public sealed class FieldAttribute : Attribute, IDescribableAttribute, IDisplayableAttribute, ISettingsAttribute
  {
    public ValueInputType ValueInputType { get; set; }

    public string DisplayName { get; set; }

    public string CollectionItemName { get; set; }

    public Type CollectionItemType { get; set; }

    public string Description { get; set; }

    public long Min { get; set; }

    public long Max { get; set; }

    public string DateTimeFormat { get; set; }

    public bool AllowCalculations { get; set; }

    public bool IncludeInCalculations { get; set; }

    public StringComparison StringComparison { get; set; }

    public string DataSourceName { get; set; }

    public bool Settable { get; set; }

    public FieldAttribute()
    {
      this.ValueInputType = ValueInputType.All;
      this.Min = long.MinValue;
      this.Max = long.MaxValue;
      this.AllowCalculations = this.IncludeInCalculations = this.Settable = true;
      this.StringComparison = StringComparison.OrdinalIgnoreCase;
    }
  }
}
