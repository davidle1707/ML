﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Attributes.ParentAttribute
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using System;

namespace CodeEffects.Rule.Attributes
{
  [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = true, Inherited = false)]
  public sealed class ParentAttribute : Attribute, IDescribableAttribute, IDisplayableAttribute
  {
    public string ParentName { get; private set; }

    public string DisplayName { get; private set; }

    public string Description { get; private set; }

    public ParentAttribute(string parentName, string displayName)
    {
      this.ParentName = parentName;
      this.DisplayName = displayName;
    }

    public ParentAttribute(string parentName, string displayName, string description)
      : this(parentName, displayName)
    {
      this.Description = description;
    }
  }
}
