﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Attributes.DataAttribute
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using CodeEffects.Rule.Models;
using System;

namespace CodeEffects.Rule.Attributes
{
  [AttributeUsage(AttributeTargets.Class, AllowMultiple = true, Inherited = true)]
  public sealed class DataAttribute : Attribute
  {
    private Type t;
    private string a;
    private string n;
    private string m;
    private string z;

    internal FeatureLocation Location { get; private set; }

    public Type Type
    {
      get
      {
        return this.t;
      }
    }

    public string Assembly
    {
      get
      {
        return this.a;
      }
    }

    public string TypeName
    {
      get
      {
        return this.n;
      }
    }

    public string Method
    {
      get
      {
        return this.m;
      }
    }

    public string Name
    {
      get
      {
        return this.z;
      }
    }

    private DataAttribute(string name, FeatureLocation location, string methodName)
    {
      this.z = name;
      this.m = methodName;
      this.Location = location;
    }

    public DataAttribute(string name, string clientCallbackFunctionName)
      : this(name, FeatureLocation.Client, clientCallbackFunctionName)
    {
    }

    public DataAttribute(string name, Type type, string methodName)
      : this(name, FeatureLocation.Server, methodName)
    {
      this.t = type;
    }

    public DataAttribute(string name, string assemblyName, string typeFullName, string methodName)
      : this(name, FeatureLocation.Server, methodName)
    {
      this.a = assemblyName;
      this.n = typeFullName;
    }
  }
}
