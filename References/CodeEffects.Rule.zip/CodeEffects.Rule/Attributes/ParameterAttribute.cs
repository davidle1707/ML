﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Attributes.ParameterAttribute
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using CodeEffects.Rule.Common;
using System;

namespace CodeEffects.Rule.Attributes
{
  [AttributeUsage(AttributeTargets.Parameter, AllowMultiple = false, Inherited = false)]
  public sealed class ParameterAttribute : Attribute, ISettingsAttribute
  {
    public ValueInputType ValueInputType { get; set; }

    public string Description { get; set; }

    public Type CollectionItemType { get; set; }

    public long Min { get; set; }

    public long Max { get; set; }

    public string DateTimeFormat { get; set; }

    public string ConstantValue { get; set; }

    public string DataSourceName { get; set; }

    public ParameterAttribute()
      : this(ValueInputType.All)
    {
    }

    public ParameterAttribute(ValueInputType valueInputType)
    {
      this.Min = long.MinValue;
      this.Max = long.MaxValue;
      this.ValueInputType = valueInputType;
    }
  }
}
