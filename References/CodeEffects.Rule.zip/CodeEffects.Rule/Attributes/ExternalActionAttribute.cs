﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Attributes.ExternalActionAttribute
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using System;

namespace CodeEffects.Rule.Attributes
{
  [AttributeUsage(AttributeTargets.Class, AllowMultiple = true, Inherited = true)]
  public sealed class ExternalActionAttribute : Attribute, IExternalAttribute
  {
    private Type t;
    private string a;
    private string n;
    private string m;

    public Type Type
    {
      get
      {
        return this.t;
      }
    }

    public string Assembly
    {
      get
      {
        return this.a;
      }
    }

    public string TypeName
    {
      get
      {
        return this.n;
      }
    }

    public string Method
    {
      get
      {
        return this.m;
      }
    }

    public ExternalActionAttribute(Type type, string methodName)
    {
      this.t = type;
      this.m = methodName;
    }

    public ExternalActionAttribute(string assemblyName, string typeFullName, string methodName)
    {
      this.a = assemblyName;
      this.n = typeFullName;
      this.m = methodName;
    }
  }
}
