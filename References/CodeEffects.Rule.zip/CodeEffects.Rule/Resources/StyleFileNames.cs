﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Resources.StyleFileNames
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using System.Runtime.InteropServices;

namespace CodeEffects.Rule.Resources
{
  [StructLayout(LayoutKind.Sequential, Size = 1)]
  internal struct StyleFileNames
  {
    internal const string Gray = "CodeEffects.Rule.Resources.Styles.Gray.css";
    internal const string White = "CodeEffects.Rule.Resources.Styles.White.css";
    internal const string Green = "CodeEffects.Rule.Resources.Styles.Green.css";
    internal const string Red = "CodeEffects.Rule.Resources.Styles.Red.css";
    internal const string Black = "CodeEffects.Rule.Resources.Styles.Black.css";
    internal const string Navy = "CodeEffects.Rule.Resources.Styles.Navy.css";
    internal const string Blue = "CodeEffects.Rule.Resources.Styles.Blue.css";
  }
}
