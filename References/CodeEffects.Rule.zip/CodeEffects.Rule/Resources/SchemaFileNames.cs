﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Resources.SchemaFileNames
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using System.Runtime.InteropServices;

namespace CodeEffects.Rule.Resources
{
  [StructLayout(LayoutKind.Sequential, Size = 1)]
  internal struct SchemaFileNames
  {
    internal const string Rule = "CodeEffects.Rule.Resources.Schemas.Rule.xsd";
    internal const string UI = "CodeEffects.Rule.Resources.Schemas.UI.xsd";
    internal const string Source2 = "CodeEffects.Rule.Resources.Schemas.Source.2.xsd";
    internal const string Source3 = "CodeEffects.Rule.Resources.Schemas.Source.3.xsd";
    internal const string Source4 = "CodeEffects.Rule.Resources.Schemas.Source.4.xsd";
    internal const string Source42 = "CodeEffects.Rule.Resources.Schemas.Source.4.2.xsd";
  }
}
