﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Resource
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace CodeEffects.Rule
{
  [CompilerGenerated]
  [GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0")]
  [DebuggerNonUserCode]
  internal class Resource
  {
    private static ResourceManager resourceMan;
    private static CultureInfo resourceCulture;

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static ResourceManager ResourceManager
    {
      get
      {
        if (object.ReferenceEquals((object) Resource.resourceMan, (object) null))
          Resource.resourceMan = new ResourceManager("CodeEffects.Rule.Resource", typeof (Resource).Assembly);
        return Resource.resourceMan;
      }
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static CultureInfo Culture
    {
      get
      {
        return Resource.resourceCulture;
      }
      set
      {
        Resource.resourceCulture = value;
      }
    }

    internal static string Errors
    {
      get
      {
        return Resource.ResourceManager.GetString("Errors", Resource.resourceCulture);
      }
    }

    internal static string FilterHelp
    {
      get
      {
        return Resource.ResourceManager.GetString("FilterHelp", Resource.resourceCulture);
      }
    }

    internal static string RuleHelp
    {
      get
      {
        return Resource.ResourceManager.GetString("RuleHelp", Resource.resourceCulture);
      }
    }

    internal Resource()
    {
    }
  }
}
