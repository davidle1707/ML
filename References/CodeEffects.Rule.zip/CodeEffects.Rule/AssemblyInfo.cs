﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Web.UI;

[assembly: WebResource("CodeEffects.Rule.Resources.Styles.Red.css", "text/css")]
[assembly: WebResource("CodeEffects.Rule.Resources.Styles.Navy.css", "text/css")]
[assembly: WebResource("CodeEffects.Rule.Resources.Styles.Blue.css", "text/css")]
[assembly: WebResource("CodeEffects.Rule.Resources.Styles.Black.css", "text/css")]
[assembly: InternalsVisibleTo("CodeEffects.Rule.Tests, PublicKey=00240000048000009400000006020000002400005253413100040000010001009bb24e7379d8a424b89cabd473b17a024bcefb5157bb381ae341e82cfe5e34d6710c1452c72267d798411594c33cce5c05bd5780dcf338a5cc180b641db693b122a0dc5872c0e971a636dae3587c5152f19462b1f055d0de3b84aa49f975feb1e40d9a2f7b130aeac324a5f33a0475a61941e6e624c381513016517375348dec")]
[assembly: AssemblyTitle("CodeEffects.Rule")]
[assembly: AssemblyDescription(".NET business rules engine for authoring, validating and evaluating complex business rules")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Code Effects Software")]
[assembly: AssemblyProduct("CodeEffects.Rule")]
[assembly: AssemblyCopyright("Code Effects Software © 2015")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("1cb4045e-ba63-438f-b891-77d2b696b5d7")]
[assembly: AssemblyFileVersion("4.2.0.9")]
[assembly: WebResource("CodeEffects.Rule.Resources.Scripts.Control.js", "text/javascript")]
[assembly: WebResource("CodeEffects.Rule.Resources.Styles.Gray.css", "text/css")]
[assembly: WebResource("CodeEffects.Rule.Resources.Styles.White.css", "text/css")]
[assembly: WebResource("CodeEffects.Rule.Resources.Styles.Green.css", "text/css")]
[assembly: AssemblyVersion("4.2.0.9")]
