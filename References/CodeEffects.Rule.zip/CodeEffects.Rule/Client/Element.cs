﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Client.Element
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using CodeEffects.Rule.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Web.Script.Serialization;

namespace CodeEffects.Rule.Client
{
  public class Element
  {
    public string Name { get; set; }

    public string Value { get; set; }

    public ElementType Type { get; set; }

    public CalculationType CalType { get; set; }

    public FunctionType FuncType { get; set; }

    public CollectionType CollType { get; set; }

    public SelectionType SelType { get; set; }

    public bool IsFuncValue { get; set; }

    public InputType InpType { get; set; }

    [ScriptIgnore]
    public ParameterType ParameterType { get; set; }

    public OperatorType Oper { get; set; }

    public Decimal? Min { get; set; }

    public Decimal? Max { get; set; }

    public bool Dec { get; set; }

    public bool IsDs { get; set; }

    public bool Cal { get; set; }

    public List<Pair> Enums { get; set; }

    public string En { get; set; }

    public string Format { get; set; }

    public bool IsRule { get; set; }

    public bool IsInstance { get; set; }

    [ScriptIgnore]
    public bool IsOrganicParenthesis { get; set; }

    public bool NotFound { get; set; }

    [ScriptIgnore]
    public string Class { get; set; }

    [ScriptIgnore]
    public string Assembly { get; set; }

    [ScriptIgnore]
    public StringComparison StringComparison { get; set; }

    [ScriptIgnore]
    public string ReturnEnumClass { get; set; }

    [ScriptIgnore]
    public string ReturnEnumAssembly { get; set; }

    [ScriptIgnore]
    public string Token { get; set; }

    public Element()
    {
      this.Type = ElementType.Flow;
      this.CalType = CalculationType.None;
      this.FuncType = FunctionType.None;
      this.ParameterType = ParameterType.None;
      this.InpType = InputType.None;
      this.SelType = SelectionType.None;
      this.CollType = CollectionType.None;
      this.Dec = this.IsOrganicParenthesis = true;
      this.Cal = false;
      this.NotFound = this.IsDs = false;
      this.StringComparison = StringComparison.OrdinalIgnoreCase;
      this.IsRule = this.IsInstance = this.IsFuncValue = false;
      this.Enums = new List<Pair>();
      this.Oper = OperatorType.None;
    }

    public Element Clone()
    {
      Element element = new Element();
      element.Cal = this.Cal;
      element.CalType = this.CalType;
      element.Dec = this.Dec;
      element.En = this.En;
      element.Enums = this.Enums;
      element.Format = this.Format;
      element.FuncType = this.FuncType;
      element.IsFuncValue = this.IsFuncValue;
      element.InpType = this.InpType;
      element.Max = this.Max;
      element.Min = this.Min;
      element.Name = this.Name;
      element.Oper = this.Oper;
      element.Type = this.Type;
      element.Value = this.Value;
      element.Assembly = this.Assembly;
      element.StringComparison = this.StringComparison;
      element.Class = this.Class;
      element.IsInstance = this.IsInstance;
      element.IsRule = this.IsRule;
      element.IsDs = this.IsDs;
      element.NotFound = this.NotFound;
      element.Token = this.Token;
      element.IsOrganicParenthesis = element.IsOrganicParenthesis;
      element.ParameterType = this.ParameterType;
      element.ReturnEnumAssembly = this.ReturnEnumAssembly;
      element.ReturnEnumClass = this.ReturnEnumClass;
      element.SelType = this.SelType;
      element.CollType = this.CollType;
      return element;
    }

    public override string ToString()
    {
      StringBuilder sb = new StringBuilder();
      sb.Append("{");
      switch (this.Type)
      {
        case ElementType.Flow:
        case ElementType.Clause:
        case ElementType.LeftSource:
        case ElementType.RightSource:
          this.WriteString("n", CodeEffects.Rule.Core.Encoder.Sanitize(this.Name), sb);
          this.WriteString("v", CodeEffects.Rule.Core.Encoder.Sanitize(this.Value), sb);
          break;
        case ElementType.Field:
          this.WriteString("n", CodeEffects.Rule.Core.Encoder.Sanitize(this.Name), sb);
          this.WriteString("v", CodeEffects.Rule.Core.Encoder.Sanitize(this.Value), sb);
          this.WriteInteger("l", this.IsRule ? 1 : 0, sb);
          this.WriteInteger("d", this.NotFound ? 1 : 0, sb);
          this.WriteInteger("o", int.Parse(System.Enum.Format(typeof (OperatorType), (object) this.Oper, "D")), sb);
          if (this.Oper == OperatorType.Enum)
          {
            this.WriteString("e", this.En, sb);
            break;
          }
          break;
        case ElementType.Function:
        case ElementType.Action:
          this.WriteString("n", CodeEffects.Rule.Core.Encoder.Sanitize(this.Name), sb);
          this.WriteInteger("f", int.Parse(System.Enum.Format(typeof (FunctionType), (object) this.FuncType, "D")), sb);
          this.WriteInteger("d", this.NotFound ? 1 : 0, sb);
          switch (this.FuncType)
          {
            case FunctionType.Name:
            case FunctionType.End:
              this.WriteString("v", CodeEffects.Rule.Core.Encoder.Sanitize(this.Value), sb);
              this.WriteInteger("o", int.Parse(System.Enum.Format(typeof (OperatorType), (object) this.Oper, "D")), sb);
              if (this.Type == ElementType.Function)
              {
                this.WriteInteger("q", this.IsFuncValue ? 1 : 0, sb);
                break;
              }
              break;
            case FunctionType.Param:
              this.WriteString("v", CodeEffects.Rule.Core.Encoder.Sanitize(this.Value), sb);
              this.WriteInteger("i", int.Parse(System.Enum.Format(typeof (InputType), (object) this.InpType, "D")), sb);
              switch (this.InpType)
              {
                case InputType.Field:
                  this.WriteInteger("o", int.Parse(System.Enum.Format(typeof (OperatorType), (object) this.Oper, "D")), sb);
                  break;
                case InputType.Input:
                  this.WriteInteger("o", int.Parse(System.Enum.Format(typeof (OperatorType), (object) this.Oper, "D")), sb);
                  switch (this.Oper)
                  {
                    case OperatorType.Date:
                    case OperatorType.Time:
                      this.WriteString("r", this.Format, sb);
                      break;
                    case OperatorType.Enum:
                      this.WriteString("e", this.En, sb);
                      break;
                  }
                                    break;
                            }
                            break;
          }
        break;
        case ElementType.Operator:
        case ElementType.Setter:
          this.WriteString("n", CodeEffects.Rule.Core.Encoder.Sanitize(this.Name), sb);
          this.WriteString("v", CodeEffects.Rule.Core.Encoder.Sanitize(this.Value), sb);
          this.WriteInteger("o", int.Parse(System.Enum.Format(typeof (OperatorType), (object) this.Oper, "D")), sb);
          break;
        case ElementType.Value:
          this.WriteString("n", CodeEffects.Rule.Core.Encoder.Sanitize(this.Name), sb);
          this.WriteString("v", CodeEffects.Rule.Core.Encoder.Sanitize(this.Value), sb);
          this.WriteInteger("i", int.Parse(System.Enum.Format(typeof (InputType), (object) this.InpType, "D")), sb);
          this.WriteInteger("o", int.Parse(System.Enum.Format(typeof (OperatorType), (object) this.Oper, "D")), sb);
          break;
        case ElementType.LeftParenthesis:
        case ElementType.RightParenthesis:
        case ElementType.LeftBracket:
        case ElementType.RightBracket:
          this.WriteString("n", CodeEffects.Rule.Core.Encoder.Sanitize(this.Name), sb);
          break;
        case ElementType.Calculation:
          this.WriteString("n", CodeEffects.Rule.Core.Encoder.Sanitize(this.Name), sb);
          this.WriteInteger("c", int.Parse(System.Enum.Format(typeof (CalculationType), (object) this.CalType, "D")), sb);
          switch (this.CalType)
          {
            case CalculationType.Field:
              this.WriteInteger("d", this.NotFound ? 1 : 0, sb);
              this.WriteString("v", CodeEffects.Rule.Core.Encoder.Sanitize(this.Value), sb);
              break;
            case CalculationType.Number:
              this.WriteString("v", CodeEffects.Rule.Core.Encoder.Sanitize(this.Value), sb);
              break;
            case CalculationType.Function:
              this.WriteInteger("f", int.Parse(System.Enum.Format(typeof (FunctionType), (object) this.FuncType, "D")), sb);
              this.WriteInteger("d", this.NotFound ? 1 : 0, sb);
              this.WriteString("v", CodeEffects.Rule.Core.Encoder.Sanitize(this.Value), sb);
              this.WriteInteger("o", int.Parse(System.Enum.Format(typeof (OperatorType), (object) this.Oper, "D")), sb);
              break;
          }
                    break;
        case ElementType.Where:
        case ElementType.Exists:
          this.WriteString("n", CodeEffects.Rule.Core.Encoder.Sanitize(this.Name), sb);
          if (this.Value != null)
          {
            this.WriteString("v", CodeEffects.Rule.Core.Encoder.Sanitize(this.Value), sb);
            break;
          }
          this.WriteInteger("y", int.Parse(System.Enum.Format(typeof (SelectionType), (object) this.SelType, "D")), sb);
          break;
      }
      sb.Append("t:").Append(int.Parse(System.Enum.Format(typeof (ElementType), (object) this.Type, "D"))).Append("}");
      return sb.ToString();
    }

    private void WriteString(string name, string value, StringBuilder sb)
    {
      sb.Append(name).Append(":");
      if (value == null)
        sb.Append("null,");
      else
        sb.Append("\"").Append(value).Append("\",");
    }

    private void WriteInteger(string name, int value, StringBuilder sb)
    {
      sb.Append(name).Append(":");
      sb.Append(value).Append(",");
    }
  }
}
