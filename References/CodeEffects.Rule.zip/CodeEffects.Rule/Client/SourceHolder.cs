﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Client.SourceHolder
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using System.Collections.Generic;
using System.Text;

namespace CodeEffects.Rule.Client
{
  internal class SourceHolder
  {
    public string Name { get; set; }

    public List<Item> Fields { get; set; }

    public List<Function> Actions { get; set; }

    public SourceHolder()
    {
      this.Actions = new List<Function>();
      this.Fields = new List<Item>();
    }

    public override string ToString()
    {
      StringBuilder stringBuilder = new StringBuilder("{");
      stringBuilder.Append("n:\"").Append(CodeEffects.Rule.Core.Encoder.GetHashToken(this.Name)).Append("\",");
      bool flag = true;
      if (this.Actions.Count > 0)
      {
        stringBuilder.Append("acs:[");
        foreach (Function action in this.Actions)
        {
          if (!flag)
            stringBuilder.Append(",");
          else
            flag = false;
          stringBuilder.Append(action.ToString());
        }
        flag = true;
        stringBuilder.Append("],");
      }
      stringBuilder.Append("fds:[");
      foreach (Item field in this.Fields)
      {
        if (!flag)
          stringBuilder.Append(",");
        else
          flag = false;
        if (field.Type == ElementType.Function)
          stringBuilder.Append(((Function) field).ToString());
        else
          stringBuilder.Append(((Field) field).ToString());
      }
      stringBuilder.Append("]}");
      return stringBuilder.ToString();
    }
  }
}
