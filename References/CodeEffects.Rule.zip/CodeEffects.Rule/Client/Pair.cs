﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Client.Pair
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using System.Text;

namespace CodeEffects.Rule.Client
{
  public sealed class Pair
  {
    public string ID { get; set; }

    public string Name { get; set; }

    public Pair()
    {
    }

    public Pair(string id, string name)
    {
      this.ID = id;
      this.Name = name;
    }

    public override string ToString()
    {
      StringBuilder stringBuilder = new StringBuilder("{");
      stringBuilder.Append("ID:\"").Append(this.ID);
      stringBuilder.Append("\",Name:\"").Append(this.Name).Append("\"}");
      return stringBuilder.ToString();
    }
  }
}
