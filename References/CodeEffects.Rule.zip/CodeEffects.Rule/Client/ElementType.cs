﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Client.ElementType
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

namespace CodeEffects.Rule.Client
{
  public enum ElementType
  {
    Flow = 0,
    Field = 1,
    Function = 2,
    Operator = 3,
    Value = 4,
    Clause = 6,
    Action = 7,
    LeftParenthesis = 8,
    RightParenthesis = 9,
    LeftBracket = 10,
    RightBracket = 11,
    Calculation = 12,
    Tab = 13,
    NewLine = 15,
    HtmlTag = 16,
    Setter = 17,
    LeftSource = 18,
    RightSource = 19,
    Where = 20,
    Exists = 22,
  }
}
