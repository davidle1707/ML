﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Client.Returns
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using CodeEffects.Rule.Models;
using System.Text;

namespace CodeEffects.Rule.Client
{
  internal class Returns
  {
    public OperatorType DataType { get; set; }

    public bool Nullable { get; set; }

    public SettingHolder Settings { get; set; }

    public CodeEffects.Rule.Common.ValueInputType ValueInputType { get; set; }

    public Returns()
    {
      this.Nullable = false;
      this.DataType = OperatorType.None;
      this.ValueInputType = CodeEffects.Rule.Common.ValueInputType.All;
      this.Settings = new SettingHolder();
    }

    public override string ToString()
    {
      StringBuilder stringBuilder = new StringBuilder("{");
      stringBuilder.Append("o:").Append(int.Parse(System.Enum.Format(typeof (OperatorType), (object) this.DataType, "D")));
      stringBuilder.Append(",ai:").Append(int.Parse(System.Enum.Format(typeof (CodeEffects.Rule.Common.ValueInputType), (object) this.ValueInputType, "D")));
      stringBuilder.Append(",l:").Append(this.Nullable ? "true" : "false");
      stringBuilder.Append(this.Settings.ToString(SettingType.Return, this.DataType));
      stringBuilder.Append("}");
      return stringBuilder.ToString();
    }
  }
}
