﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Client.InvalidElement
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using System.Text;

namespace CodeEffects.Rule.Client
{
  public class InvalidElement
  {
    public string ClientID { get; set; }

    public string Hint { get; set; }

    public InvalidElement()
    {
    }

    public InvalidElement(string clientID, string hint)
    {
      this.ClientID = clientID;
      this.Hint = hint;
    }

    public override string ToString()
    {
      return new StringBuilder().Append("{c:\"").Append(this.ClientID).Append("\",h:\"").Append(CodeEffects.Rule.Core.Encoder.Sanitize(this.Hint)).Append("\"}").ToString();
    }
  }
}
