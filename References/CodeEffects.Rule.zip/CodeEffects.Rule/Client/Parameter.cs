﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Client.Parameter
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using CodeEffects.Rule.Models;
using System.Text;

namespace CodeEffects.Rule.Client
{
  internal class Parameter
  {
    public ParameterType Type { get; set; }

    public OperatorType DataType { get; set; }

    public CodeEffects.Rule.Common.ValueInputType ValueInputType { get; set; }

    public SettingHolder Settings { get; set; }

    public CollectionHolder Collection { get; set; }

    public string Description { get; set; }

    public bool Nullable { get; set; }

    public Parameter()
    {
      this.Type = ParameterType.None;
      this.Nullable = false;
      this.DataType = OperatorType.None;
      this.ValueInputType = CodeEffects.Rule.Common.ValueInputType.All;
      this.Collection = new CollectionHolder();
      this.Settings = new SettingHolder();
    }

    public override string ToString()
    {
      if (this.Type != ParameterType.Input)
        return string.Empty;
      StringBuilder stringBuilder = new StringBuilder("{");
      stringBuilder.Append("ai:").Append(int.Parse(System.Enum.Format(typeof (CodeEffects.Rule.Common.ValueInputType), (object) this.ValueInputType, "D")));
      stringBuilder.Append(",o:").Append(int.Parse(System.Enum.Format(typeof (OperatorType), (object) this.DataType, "D")));
      if (!string.IsNullOrWhiteSpace(this.Description))
        stringBuilder.Append(",d:\"").Append(CodeEffects.Rule.Core.Encoder.Sanitize(this.Description)).Append("\"");
      stringBuilder.Append(",l:").Append(this.Nullable ? "true" : "false");
      if (this.DataType == OperatorType.Collection)
        stringBuilder.Append(this.Collection.ToString(new ElementType?(), SettingType.Parameter));
      stringBuilder.Append(this.Settings.ToString(SettingType.Parameter, this.DataType == OperatorType.Collection ? this.Collection.DataType : this.DataType));
      stringBuilder.Append("}");
      return stringBuilder.ToString();
    }
  }
}
