﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Client.SettingHolder
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using CodeEffects.Rule.Models;
using System;
using System.Text;

namespace CodeEffects.Rule.Client
{
  internal class SettingHolder
  {
    public Decimal? Min { get; set; }

    public Decimal? Max { get; set; }

    public bool AllowDecimals { get; set; }

    public bool AllowCalculations { get; set; }

    public bool IncludeInCalculations { get; set; }

    public string DataSourceName { get; set; }

    public string Format { get; set; }

    public string TypeFullName { get; set; }

    public string Assembly { get; set; }

    public bool Nullable { get; set; }

    public SettingHolder()
    {
      this.Nullable = false;
      this.AllowDecimals = this.IncludeInCalculations = true;
      this.AllowCalculations = false;
    }

    public override string ToString()
    {
      throw new NotImplementedException("Use the other public overload");
    }

    public string ToString(SettingType elementType, OperatorType dataType)
    {
      StringBuilder stringBuilder = new StringBuilder();
      if (elementType != SettingType.Field)
        stringBuilder.Append(",pl:").Append(this.Nullable ? "true" : "false");
      switch (dataType)
      {
        case OperatorType.String:
          if (this.Max.HasValue)
          {
            stringBuilder.Append(",max:").Append((object) this.Max);
            break;
          }
          break;
        case OperatorType.Numeric:
          if (this.Max.HasValue)
            stringBuilder.Append(",max:").Append((object) this.Max);
          if (this.Min.HasValue)
            stringBuilder.Append(",min:").Append((object) this.Min);
          stringBuilder.Append(",dec:").Append(this.AllowDecimals ? "true" : "false");
          switch (elementType)
          {
            case SettingType.Field:
              stringBuilder.Append(",i:").Append(this.IncludeInCalculations ? "true" : "false");
              goto case SettingType.Return;
            case SettingType.Return:
              stringBuilder.Append(",cal:").Append(this.AllowCalculations ? "true" : "false");
              break;
          }
          if (!string.IsNullOrWhiteSpace(this.DataSourceName))
          {
            stringBuilder.Append(",mds:\"").Append(this.DataSourceName).Append("\"");
            break;
          }
          break;
        case OperatorType.Date:
        case OperatorType.Time:
          if (!string.IsNullOrEmpty(this.Format))
          {
            stringBuilder.Append(",f:\"").Append(CodeEffects.Rule.Core.Encoder.Sanitize(this.Format)).Append("\"");
            break;
          }
          break;
        case OperatorType.Enum:
          stringBuilder.Append(",e:\"").Append(this.TypeFullName).Append("\"");
          break;
      }
      return stringBuilder.ToString();
    }
  }
}
