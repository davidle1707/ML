﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Client.Function
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using CodeEffects.Rule.Models;
using System.Collections.Generic;
using System.Text;

namespace CodeEffects.Rule.Client
{
  internal class Function : Item
  {
    public List<Parameter> Parameters { get; set; }

    public Returns Returns { get; set; }

    public bool IncludeInCalculations { get; set; }

    internal bool IncludeReturnInJson { get; set; }

    public Function()
    {
      this.Parameters = new List<Parameter>();
      this.Returns = new Returns();
      this.IncludeInCalculations = true;
      this.IncludeReturnInJson = false;
    }

    public override string ToString()
    {
      StringBuilder stringBuilder = new StringBuilder("{");
      stringBuilder.Append("n:\"").Append(CodeEffects.Rule.Core.Encoder.Sanitize(this.Name)).Append("\"");
      stringBuilder.Append(",v:\"").Append(this.Value).Append("\"");
      if (!string.IsNullOrWhiteSpace(this.Description))
        stringBuilder.Append(",d:\"").Append(CodeEffects.Rule.Core.Encoder.Sanitize(this.Description)).Append("\"");
      if (this.Returns.DataType == OperatorType.Numeric)
        stringBuilder.Append(",i:").Append(this.IncludeInCalculations ? "true" : "false");
      stringBuilder.Append(",t:").Append(int.Parse(System.Enum.Format(typeof (ElementType), (object) this.Type, "D"))).Append(",ps:[");
      if (this.Parameters.Count > 0)
      {
        bool flag = true;
        foreach (Parameter parameter in this.Parameters)
        {
          if (!flag)
            stringBuilder.Append(",");
          else
            flag = false;
          stringBuilder.Append(parameter.ToString());
        }
      }
      stringBuilder.Append("]");
      if (this.IncludeReturnInJson)
        stringBuilder.Append(",rt:").Append(this.Returns.ToString());
      stringBuilder.Append("}");
      return stringBuilder.ToString();
    }
  }
}
