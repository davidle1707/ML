﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Client.CollectionHolder
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using CodeEffects.Rule.Models;
using System;
using System.Text;

namespace CodeEffects.Rule.Client
{
  internal class CollectionHolder
  {
    public CollectionType Type { get; set; }

    public bool IsArray { get; set; }

    public bool IsGeneric { get; set; }

    public string DisplayName { get; set; }

    public string ComparisonName { get; set; }

    public string UnderlyingTypeFullName { get; set; }

    public OperatorType DataType { get; set; }

    public bool IsUnderlyingTypeNullable { get; set; }

    public CollectionHolder()
    {
      this.IsUnderlyingTypeNullable = true;
      this.IsArray = this.IsGeneric = false;
      this.Type = CollectionType.None;
    }

    public override string ToString()
    {
      throw new NotImplementedException("Use the other public overload");
    }

    public string ToString(ElementType? type, SettingType settingType)
    {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.Append(",ct:").Append(int.Parse(System.Enum.Format(typeof (CollectionType), (object) this.Type, "D")));
      if (this.Type == CollectionType.Value)
        stringBuilder.Append(",co:").Append(int.Parse(System.Enum.Format(typeof (OperatorType), (object) this.DataType, "D")));
      if (type.HasValue)
      {
        ElementType? nullable = type;
        if ((nullable.GetValueOrDefault() != ElementType.Field ? 0 : (nullable.HasValue ? 1 : 0)) == 0)
          goto label_8;
      }
      stringBuilder.Append(",cg:").Append(this.IsGeneric ? "true" : "false");
      stringBuilder.Append(",cr:").Append(this.IsArray ? "true" : "false");
      stringBuilder.Append(",cc:\"").Append(CodeEffects.Rule.Core.Encoder.GetHashToken(this.ComparisonName)).Append("\"");
      if (this.Type == CollectionType.Reference && settingType == SettingType.Field)
        stringBuilder.Append(",cn:\"").Append(CodeEffects.Rule.Core.Encoder.Sanitize(this.DisplayName)).Append("\"");
      if (this.Type != CollectionType.Generic)
      {
        stringBuilder.Append(",cl:").Append(this.IsUnderlyingTypeNullable ? "true" : "false");
        stringBuilder.Append(",cv:\"").Append(CodeEffects.Rule.Core.Encoder.GetHashToken(this.UnderlyingTypeFullName)).Append("\"");
      }
label_8:
      return stringBuilder.ToString();
    }
  }
}
