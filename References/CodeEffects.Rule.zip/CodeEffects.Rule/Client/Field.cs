﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Client.Field
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using CodeEffects.Rule.Models;
using System.Text;

namespace CodeEffects.Rule.Client
{
  internal class Field : Item
  {
    public OperatorType DataType { get; set; }

    public CodeEffects.Rule.Common.ValueInputType ValueInputType { get; set; }

    public bool IsRule { get; set; }

    public bool Settable { get; set; }

    public CollectionHolder Collection { get; set; }

    public SettingHolder Settings { get; set; }

    public Field()
    {
      this.DataType = OperatorType.None;
      this.ValueInputType = CodeEffects.Rule.Common.ValueInputType.All;
      this.IsRule = false;
      this.Settable = true;
      this.Collection = new CollectionHolder();
      this.Settings = new SettingHolder();
    }

    public override string ToString()
    {
      StringBuilder stringBuilder = new StringBuilder("{");
      stringBuilder.Append("n:\"").Append(CodeEffects.Rule.Core.Encoder.Sanitize(this.Name)).Append("\"");
      stringBuilder.Append(",v:\"").Append(this.Value).Append("\"");
      if (!string.IsNullOrWhiteSpace(this.Description))
        stringBuilder.Append(",d:\"").Append(CodeEffects.Rule.Core.Encoder.Sanitize(this.Description)).Append("\"");
      stringBuilder.Append(",o:").Append(int.Parse(System.Enum.Format(typeof (OperatorType), (object) this.DataType, "D")));
      stringBuilder.Append(",t:").Append(int.Parse(System.Enum.Format(typeof (ElementType), (object) this.Type, "D")));
      stringBuilder.Append(",ai:").Append(int.Parse(System.Enum.Format(typeof (CodeEffects.Rule.Common.ValueInputType), (object) this.ValueInputType, "D")));
      if (this.IsRule)
        stringBuilder.Append(",ir:true");
      if (!this.Settable)
        stringBuilder.Append(",st:false");
      if (this.DataType == OperatorType.Collection)
        stringBuilder.Append(this.Collection.ToString(new ElementType?(this.Type), SettingType.Field));
      if (this.Type == ElementType.Field)
        stringBuilder.Append(this.Settings.ToString(SettingType.Field, this.DataType == OperatorType.Collection ? this.Collection.DataType : this.DataType));
      if (this.IncludeNullableInJson)
        stringBuilder.Append(",l:").Append(this.Nullable ? "true" : "false");
      stringBuilder.Append("}");
      return stringBuilder.ToString();
    }
  }
}
