﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Client.CalculationType
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

namespace CodeEffects.Rule.Client
{
  public enum CalculationType
  {
    Field = 0,
    LeftParenthesis = 1,
    RightParenthesis = 2,
    Multiplication = 3,
    Division = 4,
    Addition = 6,
    Subtraction = 7,
    Number = 8,
    None = 9,
    Function = 10,
  }
}
