﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Client.Item
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using System;
using System.Text;

namespace CodeEffects.Rule.Client
{
  internal class Item
  {
    public string Name { get; set; }

    public string Value { get; set; }

    public string Description { get; set; }

    public bool Nullable { get; set; }

    public ElementType Type { get; set; }

    internal bool IncludeNullableInJson { get; set; }

    public Item()
    {
      this.Nullable = true;
      this.Type = ElementType.Flow;
      this.IncludeNullableInJson = false;
    }

    public override string ToString()
    {
      StringBuilder stringBuilder = new StringBuilder("{");
      stringBuilder.Append("n:\"").Append(CodeEffects.Rule.Core.Encoder.Sanitize(this.Name)).Append("\"");
      stringBuilder.Append(",v:\"").Append(this.Value).Append("\"");
      stringBuilder.Append(",t:").Append(int.Parse(Enum.Format(typeof (ElementType), (object) this.Type, "D")));
      if (this.IncludeNullableInJson)
        stringBuilder.Append(",l:").Append(this.Nullable ? "true" : "false");
      stringBuilder.Append("}");
      return stringBuilder.ToString();
    }
  }
}
