﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Client.Labels
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using CodeEffects.Rule.Common;
using CodeEffects.Rule.Core;
using CodeEffects.Rule.Models;
using System.Collections.Generic;
using System.Text;
using System.Xml;

namespace CodeEffects.Rule.Client
{
  internal sealed class Labels
  {
    private bool includeToolBarLabels;
    private RuleType mode;
    private XmlDocument help;

    internal string Calculation { get; private set; }

    internal string Setter { get; private set; }

    internal string StringInput { get; private set; }

    internal string NumericInput { get; private set; }

    internal string BoolInput { get; private set; }

    internal string EnumInput { get; private set; }

    internal string DateInput { get; private set; }

    internal string TimeInput { get; private set; }

    internal string Name { get; private set; }

    internal string Description { get; private set; }

    internal string EmptyRuleArea { get; private set; }

    internal string MenuButton { get; private set; }

    internal string DeleteButton { get; private set; }

    internal string SaveButton { get; private set; }

    internal string NewEvaluationRule { get; private set; }

    internal string NewExecutionRule { get; private set; }

    internal string True { get; private set; }

    internal string False { get; private set; }

    internal string EvaluationIf { get; private set; }

    internal string ExecutionIf { get; private set; }

    internal string Exists { get; private set; }

    internal string DoesNotExist { get; private set; }

    internal string SectionBegin { get; private set; }

    internal string SectionEnd { get; private set; }

    internal string CalculationBegin { get; private set; }

    internal string CalculationEnd { get; private set; }

    internal string CollectionBegin { get; private set; }

    internal string CollectionEnd { get; private set; }

    public Labels(XmlDocument help, bool includeToolBarLabels, RuleType mode)
    {
      this.includeToolBarLabels = includeToolBarLabels;
      this.mode = mode;
      XmlNode xmlNode1 = help.SelectSingleNode("/codeeffects/flow");
      if (xmlNode1.SelectSingleNode("evaluationIf") == null)
      {
        this.EvaluationIf = this.ExecutionIf = CodeEffects.Rule.Core.Encoder.Sanitize(xmlNode1.SelectSingleNode("if").InnerText);
      }
      else
      {
        switch (this.mode)
        {
          case RuleType.Execution:
            this.EvaluationIf = CodeEffects.Rule.Core.Encoder.Sanitize(xmlNode1.SelectSingleNode("evaluationIf").InnerText);
            this.ExecutionIf = CodeEffects.Rule.Core.Encoder.Sanitize(xmlNode1.SelectSingleNode("executionIf").InnerText);
            break;
          case RuleType.Loop:
            this.EvaluationIf = string.Empty;
            this.ExecutionIf = this.CheckForNull(xmlNode1.SelectSingleNode("loopIf"), "While");
            break;
          case RuleType.Ruleset:
            this.EvaluationIf = string.Empty;
            this.ExecutionIf = CodeEffects.Rule.Core.Encoder.Sanitize(xmlNode1.SelectSingleNode("executionIf").InnerText);
            break;
          default:
            this.EvaluationIf = CodeEffects.Rule.Core.Encoder.Sanitize(xmlNode1.SelectSingleNode("evaluationIf").InnerText);
            this.ExecutionIf = string.Empty;
            break;
        }
      }
      XmlNode xmlNode2 = help.SelectSingleNode("/codeeffects/scopes");
      if (xmlNode2 == null)
      {
        this.CollectionBegin = this.SectionBegin = "&#40;";
        this.CollectionEnd = this.SectionEnd = "&#41;";
        this.CalculationBegin = "&#123;";
        this.CalculationEnd = "&#125;";
      }
      else
      {
        this.SectionBegin = this.CheckForNull(xmlNode2.SelectSingleNode("sectionBegin"), "&#40;");
        this.SectionEnd = this.CheckForNull(xmlNode2.SelectSingleNode("sectionEnd"), "&#41;");
        this.CalculationBegin = this.CheckForNull(xmlNode2.SelectSingleNode("calculationBegin"), "&#123;");
        this.CalculationEnd = this.CheckForNull(xmlNode2.SelectSingleNode("calculationEnd"), "&#125;");
        this.CollectionBegin = this.CheckForNull(xmlNode2.SelectSingleNode("collectionBegin"), "&#40;");
        this.CollectionEnd = this.CheckForNull(xmlNode2.SelectSingleNode("collectionEnd"), "&#41;");
      }
      XmlNode xmlNode3 = help.SelectSingleNode("/codeeffects/labels");
      this.Calculation = CodeEffects.Rule.Core.Encoder.Sanitize(xmlNode3.SelectSingleNode("calculationMenuItem").InnerText);
      this.StringInput = CodeEffects.Rule.Core.Encoder.Sanitize(xmlNode3.SelectSingleNode("stringInput").InnerText);
      this.BoolInput = CodeEffects.Rule.Core.Encoder.Sanitize(xmlNode3.SelectSingleNode("boolInput").InnerText);
      this.EnumInput = CodeEffects.Rule.Core.Encoder.Sanitize(xmlNode3.SelectSingleNode("enumInput").InnerText);
      this.NumericInput = CodeEffects.Rule.Core.Encoder.Sanitize(xmlNode3.SelectSingleNode("numericInput").InnerText);
      this.DateInput = CodeEffects.Rule.Core.Encoder.Sanitize(xmlNode3.SelectSingleNode("dateInput").InnerText);
      this.TimeInput = CodeEffects.Rule.Core.Encoder.Sanitize(xmlNode3.SelectSingleNode("timeInput").InnerText);
      this.EmptyRuleArea = CodeEffects.Rule.Core.Encoder.Sanitize(xmlNode3.SelectSingleNode("emptyRuleArea").InnerText);
      this.True = CodeEffects.Rule.Core.Encoder.Sanitize(xmlNode3.SelectSingleNode("trueValueName").InnerText);
      this.False = CodeEffects.Rule.Core.Encoder.Sanitize(xmlNode3.SelectSingleNode("falseValueName").InnerText);
      this.Exists = this.CheckForNull(xmlNode3.SelectSingleNode("existsMenuItem"), "Exists...");
      this.DoesNotExist = this.CheckForNull(xmlNode3.SelectSingleNode("doesNotExistMenuItem"), "Exists...");
      if (this.includeToolBarLabels)
      {
        this.Name = CodeEffects.Rule.Core.Encoder.Sanitize(xmlNode3.SelectSingleNode("ruleDefaultName").InnerText);
        this.Description = CodeEffects.Rule.Core.Encoder.Sanitize(xmlNode3.SelectSingleNode("ruleDefaultDescription").InnerText);
        this.MenuButton = CodeEffects.Rule.Core.Encoder.Sanitize(xmlNode3.SelectSingleNode("menuButton").InnerText);
        this.SaveButton = CodeEffects.Rule.Core.Encoder.Sanitize(xmlNode3.SelectSingleNode("saveButton").InnerText);
        this.DeleteButton = CodeEffects.Rule.Core.Encoder.Sanitize(xmlNode3.SelectSingleNode("deleteButton").InnerText);
        switch (this.mode)
        {
          case RuleType.Execution:
            this.NewEvaluationRule = CodeEffects.Rule.Core.Encoder.Sanitize(xmlNode3.SelectSingleNode("newEvaluationRule").InnerText);
            this.NewExecutionRule = CodeEffects.Rule.Core.Encoder.Sanitize(xmlNode3.SelectSingleNode("newExecutionRule").InnerText);
            break;
          case RuleType.Loop:
          case RuleType.Ruleset:
            this.NewExecutionRule = CodeEffects.Rule.Core.Encoder.Sanitize(xmlNode3.SelectSingleNode("newRule").InnerText);
            break;
          default:
            this.NewEvaluationRule = CodeEffects.Rule.Core.Encoder.Sanitize(xmlNode3.SelectSingleNode("newRule").InnerText);
            break;
        }
      }
      switch (this.mode)
      {
        case RuleType.Execution:
        case RuleType.Loop:
        case RuleType.Ruleset:
          this.Setter = this.CheckForNull(xmlNode3.SelectSingleNode("setMenuItem"), "Set...");
          break;
      }
      this.help = help;
    }

    public List<Pair> GetErrorMessages()
    {
      List<Pair> pairList = new List<Pair>();
      foreach (XmlNode childNode in this.help.SelectSingleNode("/codeeffects/errors").ChildNodes)
      {
        if (childNode.NodeType != XmlNodeType.Comment && (childNode.Attributes["toolbar"] == null || this.includeToolBarLabels && childNode.Attributes["toolbar"].Value == "true"))
          pairList.Add(new Pair(childNode.Name, childNode.InnerText));
      }
      return pairList;
    }

    public List<Pair> GetUiMessages()
    {
      List<Pair> pairList = new List<Pair>();
      foreach (XmlNode childNode in this.help.SelectSingleNode("/codeeffects/help").ChildNodes)
      {
        if (childNode.NodeType != XmlNodeType.Comment)
          pairList.Add(new Pair(childNode.Name, childNode.InnerText));
      }
      return pairList;
    }

    internal string GetFlowLabel(string value, bool isEvaluationRule)
    {
      string str = value;
      if (str == "if" || this.mode == RuleType.Ruleset && str == "elseIf")
      {
        switch (this.mode)
        {
          case RuleType.Execution:
          case RuleType.Ruleset:
            str = isEvaluationRule ? "evaluationIf" : "executionIf";
            break;
          case RuleType.Loop:
            str = "loopIf";
            break;
          default:
            str = "evaluationIf";
            break;
        }
      }
      return this.help.SelectSingleNode(string.Format("{0}/{1}", (object) "/codeeffects/flow", (object) str)).InnerText;
    }

    internal string GetExistsLabel(SelectionType type)
    {
      return this.help.SelectSingleNode(string.Format("{0}/{1}", (object) "/codeeffects/collections", type == SelectionType.DoesNotExist ? (object) "doesNotExist" : (object) "exists")).InnerText;
    }

    internal string GetWhereLabel()
    {
      return this.help.SelectSingleNode(string.Format("{0}/{1}", (object) "/codeeffects/collections", (object) "where")).InnerText;
    }

    internal string GetClauseLabel(string value)
    {
      return this.help.SelectSingleNode(string.Format("{0}/{1}", (object) "/codeeffects/clauses", (object) value)).InnerText;
    }

    internal string GetSetterLabel(string value)
    {
      return this.help.SelectSingleNode(string.Format("{0}/{1}", (object) "/codeeffects/setters", (object) value)).InnerText;
    }

    internal string GetScopeLabel(Labels.Scope scope)
    {
      string str = "collectionBegin";
      switch (scope)
      {
        case Labels.Scope.SectionBegin:
          str = "sectionBegin";
          break;
        case Labels.Scope.SectionEnd:
          str = "sectionEnd";
          break;
        case Labels.Scope.CalculationBegin:
          str = "calculationBegin";
          break;
        case Labels.Scope.CalculationEnd:
          str = "calculationEnd";
          break;
        case Labels.Scope.CollectionEnd:
          str = "collectionEnd";
          break;
      }
      return this.help.SelectSingleNode(string.Format("{0}/{1}", (object) "/codeeffects/scopes", (object) str)).InnerText;
    }

    internal string GetOperatorLabel(string value, OperatorType type)
    {
      return this.help.SelectSingleNode(string.Format("{0}/{1}/{2}", (object) "/codeeffects/operators", (object) Converter.ClientTypeToClientString(type), (object) value)).InnerText;
    }

    public override string ToString()
    {
      StringBuilder stringBuilder = new StringBuilder("{");
      stringBuilder.Append("c:\"").Append(this.Calculation);
      stringBuilder.Append("\",s:\"").Append(this.StringInput);
      stringBuilder.Append("\",b:\"").Append(this.BoolInput);
      stringBuilder.Append("\",e:\"").Append(this.EnumInput);
      stringBuilder.Append("\",m:\"").Append(this.NumericInput);
      stringBuilder.Append("\",v:\"").Append(this.DateInput);
      stringBuilder.Append("\",j:\"").Append(this.TimeInput);
      stringBuilder.Append("\",g:\"").Append(this.EmptyRuleArea);
      stringBuilder.Append("\",h:\"").Append(this.Exists);
      stringBuilder.Append("\",l:\"").Append(this.DoesNotExist);
      stringBuilder.Append("\",pb:\"").Append(this.SectionBegin);
      stringBuilder.Append("\",pe:\"").Append(this.SectionEnd);
      stringBuilder.Append("\",cb:\"").Append(this.CalculationBegin);
      stringBuilder.Append("\",ce:\"").Append(this.CalculationEnd);
      stringBuilder.Append("\",ub:\"").Append(this.CollectionBegin);
      stringBuilder.Append("\",ue:\"").Append(this.CollectionEnd);
      if (this.includeToolBarLabels)
      {
        stringBuilder.Append("\",n:\"").Append(this.Name);
        stringBuilder.Append("\",d:\"").Append(this.Description);
        stringBuilder.Append("\",a:\"").Append(this.SaveButton);
        stringBuilder.Append("\",u:\"").Append(this.DeleteButton);
        stringBuilder.Append("\",r:\"").Append(this.MenuButton);
        if (this.mode == RuleType.Loop || this.mode == RuleType.Ruleset)
          stringBuilder.Append("\",x:\"").Append(this.NewExecutionRule);
        else if (this.mode == RuleType.Execution)
        {
          stringBuilder.Append("\",y:\"").Append(this.NewEvaluationRule);
          stringBuilder.Append("\",x:\"").Append(this.NewExecutionRule);
        }
        else
          stringBuilder.Append("\",y:\"").Append(this.NewEvaluationRule);
      }
      if (this.mode != RuleType.Evaluation && this.mode != RuleType.Filter)
        stringBuilder.Append("\",w:\"").Append(this.Setter);
      stringBuilder.Append("\",t:\"").Append(this.True);
      stringBuilder.Append("\",f:\"").Append(this.False).Append("\"}");
      return stringBuilder.ToString();
    }

    private string CheckForNull(XmlNode node, string defaultValue)
    {
      if (node != null)
        return CodeEffects.Rule.Core.Encoder.Sanitize(node.InnerText);
      return defaultValue;
    }

    internal enum Scope
    {
      SectionBegin,
      SectionEnd,
      CalculationBegin,
      CalculationEnd,
      CollectionBegin,
      CollectionEnd,
    }
  }
}
