﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Client.Settings
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using CodeEffects.Rule.Attributes;
using CodeEffects.Rule.Common;
using CodeEffects.Rule.Core;
using CodeEffects.Rule.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Xml;

namespace CodeEffects.Rule.Client
{
  internal sealed class Settings
  {
    private bool includeToolBarSettings { get; set; }

    private XmlDocument help { get; set; }

    public Labels Labels { get; set; }

    public List<EnumHolder> Enums { get; set; }

    public List<DataSourceDescriber> DataSources { get; set; }

    public List<Item> Clauses { get; set; }

    public List<Item> Collections { get; set; }

    public List<Item> Setters { get; set; }

    public List<Field> Operators { get; set; }

    public List<Item> Flows { get; set; }

    public ICollection<MenuItem> ToolBarRules { get; set; }

    public List<SourceHolder> Sources { get; set; }

    public Settings(XmlDocument help, ICollection<MenuItem> toolBarRules, bool includeToolBarSettings, RuleType mode)
    {
      this.help = help;
      this.includeToolBarSettings = includeToolBarSettings;
      this.Flows = new List<Item>();
      this.Clauses = new List<Item>();
      this.Collections = new List<Item>();
      this.Setters = new List<Item>();
      this.Sources = new List<SourceHolder>();
      this.Operators = new List<Field>();
      this.Labels = new Labels(help, includeToolBarSettings, mode);
      this.Enums = new List<EnumHolder>();
      this.DataSources = new List<DataSourceDescriber>();
      this.ToolBarRules = toolBarRules;
    }

    internal void Load(IControl control, ICollection<MenuItem> contextMenuRules, XmlDocument sourceXml, ICollection<DataSourceHolder> dataSourceHolders)
    {
      SourceValidator.Validate(sourceXml);
      List<string> registeredNamespaces = new List<string>();
      foreach (DataSource dataSource in SourceLoader.GetDataSources(sourceXml))
        this.DataSources.Add(this.LoadDataSource(dataSource));
      if (dataSourceHolders != null && dataSourceHolders.Count > 0)
      {
        using (IEnumerator<DataSourceHolder> enumerator = dataSourceHolders.GetEnumerator())
        {
          while (enumerator.MoveNext())
          {
            DataSourceHolder dh = enumerator.Current;
            if (this.DataSources.Any<DataSourceDescriber>((Func<DataSourceDescriber, bool>) (s => s.Name == dh.Name)))
              throw new SourceException(SourceException.ErrorIds.MultipleDynamicMenuDataSources, new string[0]);
            this.DataSources.Add(this.LoadDataSource(dh));
          }
        }
      }
      this.Flows.Add(new Item() { Value = "if" });
      if (control.Mode == RuleType.Execution)
      {
        this.Flows.Add(new Item()
        {
          Name = this.GetHelpValue("/codeeffects/flow/elseIf"),
          Value = "elseIf"
        });
        this.Flows.Add(new Item()
        {
          Name = this.GetHelpValue("/codeeffects/flow/else"),
          Value = "else"
        });
      }
      else if (control.Mode == RuleType.Ruleset)
        this.Flows.Add(new Item()
        {
          Name = this.GetHelpValue("/codeeffects/flow/executionIf"),
          Value = "elseIf"
        });
      this.Clauses.Add(new Item()
      {
        Name = this.GetHelpValue("/codeeffects/clauses/and"),
        Value = "and",
        Type = ElementType.Clause
      });
      this.Clauses.Add(new Item()
      {
        Name = this.GetHelpValue("/codeeffects/clauses/or"),
        Value = "or",
        Type = ElementType.Clause
      });
      if (control.Mode != RuleType.Evaluation && control.Mode != RuleType.Filter)
      {
        this.Clauses.Add(new Item()
        {
          Name = this.GetHelpValue("/codeeffects/clauses/" + (control.Mode == RuleType.Loop ? "do" : "then"), "do"),
          Value = "then",
          Type = ElementType.Clause
        });
        this.Setters.Add(new Item()
        {
          Name = this.GetHelpValue("/codeeffects/setters/set", "set"),
          Value = "set",
          Type = ElementType.Setter
        });
        this.Setters.Add(new Item()
        {
          Name = this.GetHelpValue("/codeeffects/setters/to", "to"),
          Value = "to",
          Type = ElementType.Setter
        });
      }
      string prefix = "s";
      XmlNamespaceManager nsmgr = new XmlNamespaceManager(sourceXml.NameTable);
      nsmgr.AddNamespace(prefix, sourceXml.DocumentElement.NamespaceURI);
      for (int index = 0; index < sourceXml.DocumentElement.ChildNodes.Count; ++index)
      {
        XmlNode source = sourceXml.DocumentElement.ChildNodes[index];
        SourceHolder sourceHolder = new SourceHolder();
        sourceHolder.Name = source.Attributes["name"] == null ? "Default.Source.Name" : source.Attributes["name"].Value;
        XmlNodeList childNodes = source.SelectSingleNode(string.Format("{0}:fields", (object) prefix), nsmgr).ChildNodes;
        List<Item> objList = new List<Item>();
        this.AutodetectOperators(control, childNodes);
        foreach (XmlNode xmlNode in childNodes)
        {
          if (xmlNode.NodeType != XmlNodeType.Comment)
          {
            SourceValidator.ValidateField(xmlNode);
            switch (xmlNode.Name)
            {
              case "collection":
                Field field1 = new Field();
                field1.Name = xmlNode.Attributes["displayName"].Value;
                field1.Value = xmlNode.Attributes["propertyName"].Value;
                field1.Nullable = true;
                field1.Description = xmlNode.Attributes["description"] == null ? (string) null : xmlNode.Attributes["description"].Value;
                field1.DataType = OperatorType.Collection;
                field1.Type = ElementType.Field;
                field1.IncludeNullableInJson = true;
                Field field2 = field1;
                field2.Collection = this.GetCollection(xmlNode, SettingType.Field);
                if (field2.Collection.Type == CollectionType.Value)
                {
                  OperatorType clientType = Converter.ClientStringToClientType(xmlNode.ChildNodes[0].Attributes["type"].Value);
                  field2.ValueInputType = Converter.StringToValueInputType(xmlNode.Attributes["valueInputType"].Value);
                  field2.Settings = this.GetSettings(xmlNode.ChildNodes[0], clientType, SettingType.Field, registeredNamespaces);
                  if (clientType == OperatorType.Numeric)
                  {
                    field2.ValueInputType = CodeEffects.Rule.Common.ValueInputType.User;
                    field2.Settings.AllowCalculations = field2.Settings.IncludeInCalculations = false;
                  }
                }
                else
                  field2.ValueInputType = CodeEffects.Rule.Common.ValueInputType.Fields;
                objList.Add((Item) field2);
                continue;
              case "function":
                Function function1 = new Function();
                function1.Name = xmlNode.Attributes["displayName"].Value;
                function1.Value = SourceLoader.GetTokenBySourceMethodNode(source, xmlNode);
                function1.Type = ElementType.Function;
                function1.IncludeReturnInJson = true;
                Function function2 = function1;
                if (xmlNode.Attributes["description"] != null)
                  function2.Description = xmlNode.Attributes["description"].Value;
                if (xmlNode.Attributes["includeInCalculations"] != null)
                  function2.IncludeInCalculations = xmlNode.Attributes["includeInCalculations"].Value == "true";
                foreach (XmlNode childNode1 in xmlNode.ChildNodes)
                {
                  if (childNode1.NodeType != XmlNodeType.Comment)
                  {
                    if (childNode1.Name == "returns")
                    {
                      function2.Returns.DataType = Converter.ClientStringToClientType(childNode1.Attributes["type"].Value);
                      function2.Returns.Nullable = childNode1.Attributes["nullable"].Value == "true";
                      function2.Returns.ValueInputType = Converter.StringToValueInputType(childNode1.Attributes["valueInputType"].Value);
                      function2.Returns.Settings = this.GetSettings(childNode1, function2.Returns.DataType, SettingType.Return, registeredNamespaces);
                    }
                    else
                    {
                      foreach (XmlNode childNode2 in childNode1.ChildNodes)
                      {
                        if (childNode2.NodeType != XmlNodeType.Comment)
                        {
                          switch (Converter.StringToParameterType(childNode2.Name))
                          {
                            case ParameterType.Input:
                            case ParameterType.Collection:
                              function2.Parameters.Add(this.GetParameter(childNode2, registeredNamespaces));
                              continue;
                            default:
                              continue;
                          }
                        }
                      }
                    }
                  }
                }
                objList.Add((Item) function2);
                continue;
              default:
                Field field3 = new Field();
                field3.Name = xmlNode.Attributes["displayName"].Value;
                field3.Value = xmlNode.Attributes["propertyName"].Value;
                field3.Nullable = xmlNode.Attributes["nullable"].Value == "true";
                field3.Description = xmlNode.Attributes["description"] == null ? (string) null : xmlNode.Attributes["description"].Value;
                field3.DataType = Converter.ClientStringToClientType(xmlNode.Name);
                field3.Type = ElementType.Field;
                field3.ValueInputType = Converter.StringToValueInputType(xmlNode.Attributes["valueInputType"].Value);
                field3.IncludeNullableInJson = true;
                Field field4 = field3;
                if (xmlNode.Attributes["settable"] != null && xmlNode.Attributes["settable"].Value == "false")
                  field4.Settable = false;
                field4.Settings = this.GetSettings(xmlNode, field4.DataType, SettingType.Field, registeredNamespaces);
                objList.Add((Item) field4);
                continue;
            }
          }
        }
        XmlNode actions = source.SelectSingleNode(string.Format("{0}:actions", (object) prefix), nsmgr);
        SourceValidator.ValidateActions(actions);
        List<Function> functionList = new List<Function>();
        if (actions != null && control.Mode != RuleType.Evaluation && control.Mode != RuleType.Filter)
        {
          foreach (XmlNode childNode1 in actions.ChildNodes)
          {
            if (childNode1.NodeType != XmlNodeType.Comment)
            {
              Function function1 = new Function();
              function1.Name = childNode1.Attributes["displayName"].Value;
              function1.Value = SourceLoader.GetTokenBySourceMethodNode(source, childNode1);
              function1.Type = ElementType.Action;
              Function function2 = function1;
              if (childNode1.Attributes["description"] != null)
                function2.Description = childNode1.Attributes["description"].Value;
              if (childNode1.HasChildNodes)
              {
                foreach (XmlNode childNode2 in childNode1.ChildNodes[0].ChildNodes)
                {
                  if (childNode2.NodeType != XmlNodeType.Comment)
                  {
                    switch (Converter.StringToParameterType(childNode2.Name))
                    {
                      case ParameterType.Input:
                      case ParameterType.Collection:
                        function2.Parameters.Add(this.GetParameter(childNode2, registeredNamespaces));
                        continue;
                      default:
                        continue;
                    }
                  }
                }
              }
              functionList.Add(function2);
            }
          }
        }
        bool references = false;
        List<CollectionHolder> collections = new List<CollectionHolder>();
        foreach (Item obj in objList)
        {
          if (obj.Type == ElementType.Field)
          {
            Field field = (Field) obj;
            if (field.DataType == OperatorType.Collection)
            {
              if (field.Collection.Type == CollectionType.Reference)
                references = true;
              collections.Add(field.Collection);
            }
          }
        }
        foreach (Item obj in objList)
        {
          if (obj.Type == ElementType.Function)
          {
            Function function = (Function) obj;
            if (function.Parameters.Count == 0)
              sourceHolder.Fields.Add(obj);
            else if (this.ValidateParameters(function.Parameters, collections, references))
              sourceHolder.Fields.Add(obj);
          }
          else
            sourceHolder.Fields.Add(obj);
        }
        foreach (Function function in functionList)
        {
          if (function.Parameters.Count == 0)
            sourceHolder.Actions.Add(function);
          else if (this.ValidateParameters(function.Parameters, collections, references))
            sourceHolder.Actions.Add(function);
        }
        if (contextMenuRules != null && contextMenuRules.Count > 0)
        {
          foreach (MenuItem contextMenuRule in (IEnumerable<MenuItem>) contextMenuRules)
          {
            if (string.IsNullOrWhiteSpace(contextMenuRule.SourceName) && index == 0 || contextMenuRule.SourceName == sourceHolder.Name)
            {
              Field field1 = new Field();
              field1.Name = contextMenuRule.DisplayName;
              field1.Value = contextMenuRule.ID.ToString();
              field1.Description = string.IsNullOrWhiteSpace(contextMenuRule.Description) ? (string) null : contextMenuRule.Description;
              field1.Nullable = false;
              field1.DataType = OperatorType.Bool;
              field1.Type = ElementType.Field;
              field1.IsRule = true;
              field1.ValueInputType = CodeEffects.Rule.Common.ValueInputType.User;
              field1.IncludeNullableInJson = true;
              Field field2 = field1;
              sourceHolder.Fields.Add((Item) field2);
            }
          }
        }
        if (references)
        {
          this.Collections.Add(new Item()
          {
            Name = this.GetHelpValue("/codeeffects/collections/exists", "exists"),
            Value = "exists",
            Type = ElementType.Exists
          });
          this.Collections.Add(new Item()
          {
            Name = this.GetHelpValue("/codeeffects/collections/doesNotExist", "doesNotExist"),
            Value = "doesNotExist",
            Type = ElementType.Exists
          });
          this.Collections.Add(new Item()
          {
            Name = this.GetHelpValue("/codeeffects/collections/where", "where"),
            Value = "where",
            Type = ElementType.Where
          });
        }
        if (sourceHolder.Fields.Count > 0 && !control.KeepDeclaredOrder)
          sourceHolder.Fields.Sort((Comparison<Item>) ((f1, f2) => f1.Name.CompareTo(f2.Name)));
        if (sourceHolder.Actions.Count > 0 && !control.KeepDeclaredOrder)
          sourceHolder.Actions.Sort((Comparison<Function>) ((f1, f2) => f1.Name.CompareTo(f2.Name)));
        this.Sources.Add(sourceHolder);
      }
    }

    public override string ToString()
    {
      StringBuilder sb = new StringBuilder();
      sb.Append("{lbl:");
      sb.Append(this.Labels.ToString());
      sb.Append(",");
      this.GetJson<Item>("fls", (ICollection<Item>) this.Flows, sb);
      this.GetJson<Item>("cls", (ICollection<Item>) this.Clauses, sb);
      this.GetJson<Item>("dsc", (ICollection<Item>) this.Collections, sb);
      this.GetJson<Item>("str", (ICollection<Item>) this.Setters, sb);
      if (this.includeToolBarSettings && this.ToolBarRules != null && this.ToolBarRules.Count > 0)
        this.GetJson<MenuItem>("rls", this.ToolBarRules, sb);
      if (this.Enums.Count > 0)
        this.GetJson<EnumHolder>("ens", (ICollection<EnumHolder>) this.Enums, sb);
      if (this.DataSources.Count > 0)
        this.GetJson<DataSourceDescriber>("mds", (ICollection<DataSourceDescriber>) this.DataSources, sb);
      this.GetJson<Field>("ops", (ICollection<Field>) this.Operators, sb);
      this.GetJson<SourceHolder>("src", (ICollection<SourceHolder>) this.Sources, sb);
      sb.Remove(sb.Length - 1, 1).Append("}");
      return sb.ToString();
    }

    private bool IsOperatorExcluded(IControl control, OperatorType type, ExcludedOperator ex)
    {
      return control.ExcludedOperators.Any<Operator>((Func<Operator, bool>) (o =>
      {
        if (o.Type == type)
          return (o.ExcludedOperator & ex) == ex;
        return false;
      }));
    }

    private void AutodetectOperators(IControl control, XmlNodeList fields)
    {
      bool isNullable1 = false;
      if (SourceValidator.IsOperatorTypeUsed(fields, OperatorType.Bool, out isNullable1))
      {
        if (!this.IsOperatorExcluded(control, OperatorType.Bool, ExcludedOperator.Equal))
          this.AddOperator(OperatorType.Bool, "equal");
        if (isNullable1)
        {
          this.AddOperator(OperatorType.Bool, "isNull");
          this.AddOperator(OperatorType.Bool, "isNotNull");
        }
      }
      bool isNullable2 = false;
      if (SourceValidator.IsOperatorTypeUsed(fields, OperatorType.Date, out isNullable2))
      {
        if (!this.IsOperatorExcluded(control, OperatorType.Date, ExcludedOperator.Equal))
          this.AddOperator(OperatorType.Date, "equal");
        if (!this.IsOperatorExcluded(control, OperatorType.Date, ExcludedOperator.NotEqual))
          this.AddOperator(OperatorType.Date, "notEqual");
        if (!this.IsOperatorExcluded(control, OperatorType.Date, ExcludedOperator.Greater))
          this.AddOperator(OperatorType.Date, "greater");
        if (!this.IsOperatorExcluded(control, OperatorType.Date, ExcludedOperator.GreaterOrEqual))
          this.AddOperator(OperatorType.Date, "greaterOrEqual");
        if (!this.IsOperatorExcluded(control, OperatorType.Date, ExcludedOperator.Less))
          this.AddOperator(OperatorType.Date, "less");
        if (!this.IsOperatorExcluded(control, OperatorType.Date, ExcludedOperator.LessOrEqual))
          this.AddOperator(OperatorType.Date, "lessOrEqual");
        if (isNullable2)
        {
          this.AddOperator(OperatorType.Date, "isNull");
          this.AddOperator(OperatorType.Date, "isNotNull");
        }
      }
      bool isNullable3 = false;
      if (SourceValidator.IsOperatorTypeUsed(fields, OperatorType.Time, out isNullable3))
      {
        if (!this.IsOperatorExcluded(control, OperatorType.Time, ExcludedOperator.Equal))
          this.AddOperator(OperatorType.Time, "equal");
        if (!this.IsOperatorExcluded(control, OperatorType.Time, ExcludedOperator.NotEqual))
          this.AddOperator(OperatorType.Time, "notEqual");
        if (!this.IsOperatorExcluded(control, OperatorType.Time, ExcludedOperator.Greater))
          this.AddOperator(OperatorType.Time, "greater");
        if (!this.IsOperatorExcluded(control, OperatorType.Time, ExcludedOperator.GreaterOrEqual))
          this.AddOperator(OperatorType.Time, "greaterOrEqual");
        if (!this.IsOperatorExcluded(control, OperatorType.Time, ExcludedOperator.Less))
          this.AddOperator(OperatorType.Time, "less");
        if (!this.IsOperatorExcluded(control, OperatorType.Time, ExcludedOperator.LessOrEqual))
          this.AddOperator(OperatorType.Time, "lessOrEqual");
        if (isNullable3)
        {
          this.AddOperator(OperatorType.Time, "isNull");
          this.AddOperator(OperatorType.Time, "isNotNull");
        }
      }
      bool isNullable4 = false;
      if (SourceValidator.IsOperatorTypeUsed(fields, OperatorType.Numeric, out isNullable4))
      {
        if (!this.IsOperatorExcluded(control, OperatorType.Numeric, ExcludedOperator.Equal))
          this.AddOperator(OperatorType.Numeric, "equal");
        if (!this.IsOperatorExcluded(control, OperatorType.Numeric, ExcludedOperator.NotEqual))
          this.AddOperator(OperatorType.Numeric, "notEqual");
        if (!this.IsOperatorExcluded(control, OperatorType.Numeric, ExcludedOperator.Greater))
          this.AddOperator(OperatorType.Numeric, "greater");
        if (!this.IsOperatorExcluded(control, OperatorType.Numeric, ExcludedOperator.GreaterOrEqual))
          this.AddOperator(OperatorType.Numeric, "greaterOrEqual");
        if (!this.IsOperatorExcluded(control, OperatorType.Numeric, ExcludedOperator.Less))
          this.AddOperator(OperatorType.Numeric, "less");
        if (!this.IsOperatorExcluded(control, OperatorType.Numeric, ExcludedOperator.LessOrEqual))
          this.AddOperator(OperatorType.Numeric, "lessOrEqual");
        if (isNullable4)
        {
          this.AddOperator(OperatorType.Numeric, "isNull");
          this.AddOperator(OperatorType.Numeric, "isNotNull");
        }
      }
      if (SourceValidator.IsOperatorTypeUsed(fields, OperatorType.Enum, out isNullable4))
      {
        if (!this.IsOperatorExcluded(control, OperatorType.Enum, ExcludedOperator.Equal))
          this.AddOperator(OperatorType.Enum, "equal");
        if (!this.IsOperatorExcluded(control, OperatorType.Enum, ExcludedOperator.NotEqual))
          this.AddOperator(OperatorType.Enum, "notEqual");
      }
      if (SourceValidator.IsOperatorTypeUsed(fields, OperatorType.String, out isNullable4))
      {
        if (!this.IsOperatorExcluded(control, OperatorType.String, ExcludedOperator.Equal))
          this.AddOperator(OperatorType.String, "equal");
        if (!this.IsOperatorExcluded(control, OperatorType.String, ExcludedOperator.NotEqual))
          this.AddOperator(OperatorType.String, "notEqual");
        if (!this.IsOperatorExcluded(control, OperatorType.String, ExcludedOperator.Contains))
          this.AddOperator(OperatorType.String, "contains");
        if (!this.IsOperatorExcluded(control, OperatorType.String, ExcludedOperator.DoesNotContain))
          this.AddOperator(OperatorType.String, "doesNotContain");
        if (!this.IsOperatorExcluded(control, OperatorType.String, ExcludedOperator.StartsWith))
          this.AddOperator(OperatorType.String, "startsWith");
        if (!this.IsOperatorExcluded(control, OperatorType.String, ExcludedOperator.DoesNotStartWith))
          this.AddOperator(OperatorType.String, "doesNotStartWith");
        if (!this.IsOperatorExcluded(control, OperatorType.String, ExcludedOperator.EndsWith))
          this.AddOperator(OperatorType.String, "endsWith");
        if (!this.IsOperatorExcluded(control, OperatorType.String, ExcludedOperator.DoesNotEndWith))
          this.AddOperator(OperatorType.String, "doesNotEndWith");
        this.AddOperator(OperatorType.String, "isNull");
        this.AddOperator(OperatorType.String, "isNotNull");
      }
      if (!SourceValidator.IsOperatorTypeUsed(fields, OperatorType.Collection, out isNullable4))
        return;
      if (!this.IsOperatorExcluded(control, OperatorType.Collection, ExcludedOperator.Contains))
        this.AddOperator(OperatorType.Collection, "contains", "contains");
      if (!this.IsOperatorExcluded(control, OperatorType.Collection, ExcludedOperator.DoesNotContain))
        this.AddOperator(OperatorType.Collection, "doesNotContain", "doesNotContain");
      if (!this.IsOperatorExcluded(control, OperatorType.Collection, ExcludedOperator.StartsWith))
        this.AddOperator(OperatorType.Collection, "startsWith", "startsWith");
      if (!this.IsOperatorExcluded(control, OperatorType.Collection, ExcludedOperator.DoesNotStartWith))
        this.AddOperator(OperatorType.Collection, "doesNotStartWith", "doesNotStartWith");
      if (!this.IsOperatorExcluded(control, OperatorType.Collection, ExcludedOperator.EndsWith))
        this.AddOperator(OperatorType.Collection, "endsWith", "endsWith");
      if (!this.IsOperatorExcluded(control, OperatorType.Collection, ExcludedOperator.DoesNotEndWith))
        this.AddOperator(OperatorType.Collection, "doesNotEndWith", "doesNotEndWith");
      this.AddOperator(OperatorType.Collection, "isNull", "isNull");
      this.AddOperator(OperatorType.Collection, "isNotNull", "isNotNull");
    }

    private void AddOperator(OperatorType type, string value)
    {
      this.AddOperator(type, value, "-default-");
    }

    private void AddOperator(OperatorType type, string value, string defaultValue)
    {
      if (this.Operators.Any<Field>((Func<Field, bool>) (o =>
      {
        if (o.Value == value)
          return o.DataType == type;
        return false;
      })))
        return;
      List<Field> operators = this.Operators;
      Field field1 = new Field();
      field1.Name = this.GetHelpValue(string.Format("{0}/{1}/{2}", (object) "/codeeffects/operators", (object) Converter.ClientTypeToClientString(type), (object) value), defaultValue);
      field1.Value = value;
      field1.DataType = type;
      field1.Type = ElementType.Operator;
      Field field2 = field1;
      operators.Add(field2);
    }

    private void GetJson<T>(string name, ICollection<T> list, StringBuilder sb)
    {
      bool flag = true;
      sb.Append(name).Append(":[");
      foreach (T obj in (IEnumerable<T>) list)
      {
        if (!flag)
          sb.Append(",");
        else
          flag = false;
        sb.Append(obj.ToString());
      }
      sb.Append("],");
    }

    private EnumHolder LoadEnum(XmlNode node, List<string> registered)
    {
      return this.LoadEnum(node.Attributes["assembly"].Value, node.Attributes["class"].Value, registered);
    }

    private EnumHolder LoadEnum(string assembly, string type, List<string> registered)
    {
      if (registered.Contains(type))
        return (EnumHolder) null;
      registered.Add(type);
      Type type1;
      try
      {
        type1 = Assembly.Load(assembly).GetType(type);
      }
      catch (Exception ex)
      {
        throw new SourceException(SourceException.ErrorIds.FailedToLoadAssemblyOrType, new string[3]{ assembly, type, ex.Message });
      }
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.Append("[");
      EnumHolder enumHolder = new EnumHolder();
      if (type1.MemberType == MemberTypes.NestedType)
      {
        string[] strArray = type.Split('.');
        enumHolder.Name = strArray[strArray.Length - 1];
      }
      else
        enumHolder.Name = type1.Name;
      enumHolder.Ns = type1.Namespace;
      Array values = System.Enum.GetValues(type1);
      bool flag = true;
      foreach (object obj in values)
      {
        string name = System.Enum.GetName(type1, obj);
        string str = name;
        FieldInfo field = type1.GetField(name);
        if (field.GetCustomAttributes(typeof (ExcludeFromEvaluationAttribute), false).Length == 0)
        {
          object[] customAttributes = field.GetCustomAttributes(typeof (EnumItemAttribute), false);
          if (customAttributes.Length > 0)
            str = CodeEffects.Rule.Core.Encoder.Sanitize(((EnumItemAttribute) customAttributes[0]).DisplayName);
          if (!flag)
            stringBuilder.Append(",");
          else
            flag = false;
          stringBuilder.Append("{ID:").Append(int.Parse(System.Enum.Format(type1, obj, "D"))).Append(",Name:\\\"").Append(str).Append("\\\"}");
        }
      }
      stringBuilder.Append("]");
      enumHolder.Data = stringBuilder.ToString();
      return enumHolder;
    }

    private CollectionHolder GetCollection(XmlNode fieldNode, SettingType type)
    {
      CollectionHolder collectionHolder = new CollectionHolder();
      collectionHolder.Type = Converter.StringToCollectionType(fieldNode.ChildNodes[0].Name);
      collectionHolder.IsArray = fieldNode.Attributes["array"].Value == "true";
      collectionHolder.IsGeneric = fieldNode.Attributes["generic"].Value == "true";
      collectionHolder.ComparisonName = fieldNode.Attributes["comparisonName"].Value;
      switch (collectionHolder.Type)
      {
        case CollectionType.Value:
          collectionHolder.UnderlyingTypeFullName = fieldNode.ChildNodes[0].Attributes["class"].Value;
          collectionHolder.DataType = Converter.ClientStringToClientType(fieldNode.ChildNodes[0].Attributes["type"].Value);
          collectionHolder.IsUnderlyingTypeNullable = fieldNode.ChildNodes[0].Attributes["nullable"].Value == "true";
          break;
        case CollectionType.Reference:
          if (type == SettingType.Field)
            collectionHolder.DisplayName = fieldNode.ChildNodes[0].Attributes["displayName"].Value;
          collectionHolder.UnderlyingTypeFullName = fieldNode.ChildNodes[0].Attributes["class"].Value;
          break;
        default:
          if (type == SettingType.Field)
            throw new SourceException(SourceException.ErrorIds.GenericCollectionsAndPropertiesNotSupported, new string[0]);
          break;
      }
      return collectionHolder;
    }

    private SettingHolder GetSettings(XmlNode node, OperatorType dataType, SettingType elementType, List<string> registeredNamespaces)
    {
      SettingHolder settingHolder = new SettingHolder();
      if (elementType != SettingType.Field)
        settingHolder.Nullable = node.Attributes["nullable"].Value == "true";
      switch (dataType)
      {
        case OperatorType.String:
          if (node.Attributes["maxLength"] != null)
          {
            settingHolder.Max = new Decimal?((Decimal) new int?(int.Parse(node.Attributes["maxLength"].Value)).Value);
            break;
          }
          break;
        case OperatorType.Numeric:
          switch (elementType)
          {
            case SettingType.Field:
              settingHolder.IncludeInCalculations = node.Attributes["includeInCalculations"].Value == "true";
              goto case SettingType.Return;
            case SettingType.Return:
              settingHolder.AllowCalculations = node.Attributes["allowCalculation"].Value == "true";
              break;
          }
          settingHolder.AllowDecimals = node.Attributes["allowDecimal"].Value == "true";
          settingHolder.Min = new Decimal?(Decimal.Parse(node.Attributes["min"].Value));
          settingHolder.Max = new Decimal?(Decimal.Parse(node.Attributes["max"].Value));
          if (node.Attributes["dataSourceName"] != null)
          {
            settingHolder.DataSourceName = node.Attributes["dataSourceName"].Value;
            break;
          }
          break;
        case OperatorType.Date:
        case OperatorType.Time:
          settingHolder.Format = node.Attributes["format"].Value;
          break;
        case OperatorType.Enum:
          settingHolder.TypeFullName = node.Attributes["class"].Value;
          EnumHolder holder = this.LoadEnum(node, registeredNamespaces);
          if (holder != null && !this.Enums.Any<EnumHolder>((Func<EnumHolder, bool>) (e =>
          {
            if (e.Name == holder.Name)
              return e.Ns == holder.Ns;
            return false;
          })))
          {
            this.Enums.Add(holder);
            break;
          }
          break;
      }
      return settingHolder;
    }

    private DataSourceDescriber LoadDataSource(DataSourceHolder source)
    {
      DataSourceDescriber h = new DataSourceDescriber();
      h.Client = false;
      h.Name = source.Name;
      try
      {
        List<DataSourceItem> dataSourceItemList = source.Delegate();
        this.HandleDataSourceItems(h, (ICollection<DataSourceItem>) dataSourceItemList);
      }
      catch (Exception ex)
      {
        throw new SourceException(SourceException.ErrorIds.DelegateInvokeOrConversionError, new string[2]{ source.Name, ex.Message });
      }
      return h;
    }

    private DataSourceDescriber LoadDataSource(DataSource source)
    {
      DataSourceDescriber h = new DataSourceDescriber();
      h.Client = source.Location == FeatureLocation.Client;
      h.Name = source.Name;
      if (h.Client)
      {
        h.Data = "[\\\"" + source.Method + "\\\"]";
      }
      else
      {
        Type type;
        try
        {
          type = Assembly.Load(source.Assembly).GetType(source.Class);
        }
        catch (Exception ex)
        {
          throw new SourceException(SourceException.ErrorIds.FailedToLoadAssemblyOrType, new string[3]{ source.Assembly, source.Class, ex.Message });
        }
        MethodInfo method;
        try
        {
          method = type.GetMethod(source.Method, BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.InvokeMethod, (Binder) null, new Type[0], new ParameterModifier[0]);
          if (method == (MethodInfo) null)
            throw new Exception();
        }
        catch (Exception ex)
        {
          throw new SourceException(SourceException.ErrorIds.MissingOrInaccessibleMethod, new string[1]{ source.Method });
        }
        if (!SourceValidator.IsDataSourceMethodValid(method))
          throw new SourceException(SourceException.ErrorIds.MethodIsNotDataSource, new string[1]{ source.Method });
        ICollection<DataSourceItem> items;
        try
        {
          items = (ICollection<DataSourceItem>) method.Invoke(method.IsStatic ? (object) type : Activator.CreateInstance(type), (object[]) null);
        }
        catch (Exception ex)
        {
          throw new SourceException(SourceException.ErrorIds.MethodInvokeOrConversionError, new string[2]{ source.Method, ex.Message });
        }
        this.HandleDataSourceItems(h, items);
      }
      return h;
    }

    private void HandleDataSourceItems(DataSourceDescriber h, ICollection<DataSourceItem> items)
    {
      if (items != null && items.Count > 0)
      {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.Append("[");
        bool flag = true;
        foreach (DataSourceItem dataSourceItem in (IEnumerable<DataSourceItem>) items)
        {
          if (!flag)
            stringBuilder.Append(",");
          else
            flag = false;
          stringBuilder.Append("{ID:").Append(dataSourceItem.ID).Append(",Name:\\\"").Append(CodeEffects.Rule.Core.Encoder.Sanitize(dataSourceItem.Name)).Append("\\\"}");
        }
        stringBuilder.Append("]");
        h.Data = stringBuilder.ToString();
      }
      else
        h.Data = "[null]";
    }

    private string GetHelpValue(string path)
    {
      return this.GetHelpValue(path, "-default-");
    }

    private string GetHelpValue(string path, string defaultValue)
    {
      XmlNode xmlNode = this.help.SelectSingleNode(path);
      if (xmlNode != null)
        return CodeEffects.Rule.Core.Encoder.Desanitize(xmlNode.InnerText);
      return defaultValue;
    }

    private Parameter GetParameter(XmlNode p, List<string> registeredNamespaces)
    {
      Parameter parameter = new Parameter();
      parameter.Type = ParameterType.Input;
      if (p.Attributes["description"] != null)
        parameter.Description = p.Attributes["description"].Value;
      if (p.Name == "collection")
      {
        parameter.ValueInputType = CodeEffects.Rule.Common.ValueInputType.Fields;
        parameter.DataType = OperatorType.Collection;
        parameter.Collection = this.GetCollection(p, SettingType.Parameter);
        if (parameter.Collection.Type == CollectionType.Value)
        {
          parameter.Nullable = p.ChildNodes[0].Attributes["nullable"].Value == "true";
          parameter.Settings = this.GetSettings(p.ChildNodes[0], Converter.ClientStringToClientType(p.ChildNodes[0].Attributes["type"].Value), SettingType.Parameter, registeredNamespaces);
        }
      }
      else
      {
        parameter.DataType = Converter.ClientStringToClientType(p.Attributes["type"].Value);
        parameter.ValueInputType = Converter.StringToValueInputType(p.Attributes["valueInputType"].Value);
        parameter.Nullable = p.Attributes["nullable"].Value == "true";
        parameter.Settings = this.GetSettings(p, parameter.DataType, SettingType.Parameter, registeredNamespaces);
      }
      return parameter;
    }

    private bool ValidateParameters(List<Parameter> parameters, List<CollectionHolder> collections, bool references)
    {
      using (List<Parameter>.Enumerator enumerator = parameters.GetEnumerator())
      {
        while (enumerator.MoveNext())
        {
          Parameter param = enumerator.Current;
          if (param.DataType == OperatorType.Collection)
          {
            if (collections.Count == 0 || param.Collection.Type == CollectionType.Reference && !references)
              return false;
            if (param.Collection.Type == CollectionType.Generic)
            {
              if (!collections.Any<CollectionHolder>((Func<CollectionHolder, bool>) (c => c.ComparisonName == param.Collection.ComparisonName)))
                return false;
            }
            else if (!collections.Any<CollectionHolder>((Func<CollectionHolder, bool>) (c =>
            {
              if (c.Type == param.Collection.Type && c.IsArray == param.Collection.IsArray && (c.IsGeneric == param.Collection.IsGeneric && c.ComparisonName == param.Collection.ComparisonName) && c.UnderlyingTypeFullName == param.Collection.UnderlyingTypeFullName)
                return c.IsUnderlyingTypeNullable == param.Collection.IsUnderlyingTypeNullable;
              return false;
            })))
              return false;
          }
        }
      }
      return true;
    }
  }
}
