﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Mvc.HtmlHelperExtension
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using System.Web.Mvc;

namespace CodeEffects.Rule.Mvc
{
  public static class HtmlHelperExtension
  {
    public static ComponentFactory CodeEffects(this HtmlHelper helper)
    {
      return new ComponentFactory(helper);
    }
  }
}
