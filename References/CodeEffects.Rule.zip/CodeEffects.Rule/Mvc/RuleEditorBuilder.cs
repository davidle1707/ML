﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Mvc.RuleEditorBuilder
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using CodeEffects.Rule.Common;
using CodeEffects.Rule.Models;
using System.Collections.Generic;
using System.Web.Mvc;
using System.Xml;

namespace CodeEffects.Rule.Mvc
{
  public class RuleEditorBuilder
  {
    private ViewContext viewContext;

    public RuleEditor Editor { get; set; }

    public RuleEditorBuilder(ViewContext viewContext)
    {
      this.viewContext = viewContext;
      this.Editor = new RuleEditor(viewContext);
    }

    public RuleEditorBuilder Id(string id)
    {
      this.Editor.Id = id;
      return this;
    }

    public RuleEditorBuilder SaveAction(string saveAction, string saveController)
    {
      this.Editor.SaveController = saveController;
      this.Editor.SaveAction = saveAction;
      return this;
    }

    public RuleEditorBuilder DeleteAction(string deleteAction, string deleteController)
    {
      this.Editor.DeleteController = deleteController;
      this.Editor.DeleteAction = deleteAction;
      return this;
    }

    public RuleEditorBuilder LoadAction(string loadAction, string loadController)
    {
      this.Editor.LoadController = loadController;
      this.Editor.LoadAction = loadAction;
      return this;
    }

    public RuleEditorBuilder ToolBarRules(List<MenuItem> toolBarRules)
    {
      this.Editor.ToolBarRules = (ICollection<MenuItem>) toolBarRules;
      return this;
    }

    public RuleEditorBuilder ContextMenuRules(List<MenuItem> contextMenuRules)
    {
      this.Editor.ContextMenuRules = (ICollection<MenuItem>) contextMenuRules;
      return this;
    }

    public RuleEditorBuilder Help(string helpXmlFilePath)
    {
      this.Editor.HelpXmlFile = helpXmlFilePath;
      return this;
    }

    public RuleEditorBuilder Help(XmlDocument helpXml)
    {
      this.Editor.HelpXml = helpXml;
      return this;
    }

    public RuleEditorBuilder Rule(RuleModel rule)
    {
      this.Editor.Rule = rule;
      return this;
    }

    public RuleEditorBuilder ExcludedOperators(ICollection<Operator> excludedOperators)
    {
      this.Editor.ExcludedOperators = excludedOperators;
      return this;
    }

    public RuleEditorBuilder DataSources(ICollection<DataSourceHolder> dataSources)
    {
      this.Editor.DataSources = dataSources;
      return this;
    }

    public RuleEditorBuilder Theme(ThemeType theme)
    {
      this.Editor.Theme = theme;
      return this;
    }

    public RuleEditorBuilder Mode(RuleType mode)
    {
      this.Editor.Mode = mode;
      return this;
    }

    public RuleEditorBuilder ShowHelpString(bool showHelpString)
    {
      this.Editor.ShowHelpString = showHelpString;
      return this;
    }

    public RuleEditorBuilder ShowLineDots(bool showLineDots)
    {
      this.Editor.ShowLineDots = showLineDots;
      return this;
    }

    public RuleEditorBuilder ShowMenuOnRightArrowKey(bool showMenuOnRightArrowKey)
    {
      this.Editor.ShowMenuOnRightArrowKey = showMenuOnRightArrowKey;
      return this;
    }

    public RuleEditorBuilder ShowMenuOnElementClicked(bool showMenuOnElementClicked)
    {
      this.Editor.ShowMenuOnElementClicked = showMenuOnElementClicked;
      return this;
    }

    public RuleEditorBuilder ShowDescriptionsOnMouseHover(bool showDescriptionsOnMouseHover)
    {
      this.Editor.ShowDescriptionsOnMouseHover = showDescriptionsOnMouseHover;
      return this;
    }

    public RuleEditorBuilder ShowToolBar(bool showToolBar)
    {
      this.Editor.ShowToolBar = showToolBar;
      return this;
    }

    public RuleEditorBuilder ClientOnly(bool clientOnly)
    {
      this.Editor.ClientOnly = clientOnly;
      return this;
    }

    public RuleEditorBuilder KeepDeclaredOrder(bool keepDeclaredOrder)
    {
      this.Editor.KeepDeclaredOrder = keepDeclaredOrder;
      return this;
    }

    public void Render()
    {
      this.Editor.Render();
    }
  }
}
