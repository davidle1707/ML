﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Mvc.RuleEditor
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using CodeEffects.Rule.Client;
using CodeEffects.Rule.Common;
using CodeEffects.Rule.Core;
using CodeEffects.Rule.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Web.Mvc;
using System.Web.UI;
using System.Xml;

namespace CodeEffects.Rule.Mvc
{
  public class RuleEditor : CodeEffects.Rule.Models.IControl
  {
    private bool showToolBar = true;
    private RuleType mode;
    private ViewContext viewContext;
    private RuleModel rule;

    private string dataFieldID
    {
      get
      {
        return this.Id + "Data";
      }
    }

    private bool valid
    {
      get
      {
        if (this.Rule.InvalidElements.Count == 0)
          return !this.Rule.NameIsInvalid;
        return false;
      }
    }

    public string Id { get; set; }

    public string SaveController { get; set; }

    public string SaveAction { get; set; }

    public string DeleteController { get; set; }

    public string DeleteAction { get; set; }

    public string LoadController { get; set; }

    public string LoadAction { get; set; }

    public XmlDocument HelpXml { get; set; }

    public string HelpXmlFile { get; set; }

    public bool ShowHelpString { get; set; }

    public bool ShowLineDots { get; set; }

    public bool ShowMenuOnRightArrowKey { get; set; }

    public bool ShowMenuOnElementClicked { get; set; }

    public bool ShowDescriptionsOnMouseHover { get; set; }

    public bool ShowToolBar
    {
      get
      {
        return this.showToolBar;
      }
      set
      {
        if (!value)
          this.Rule.SkipNameValidation = true;
        this.showToolBar = value;
      }
    }

    public bool KeepDeclaredOrder { get; set; }

    public RuleType Mode
    {
      get
      {
        return this.mode;
      }
      set
      {
        if (value == RuleType.Filter)
          this.showToolBar = false;
        this.mode = value;
      }
    }

    public ThemeType Theme { get; set; }

    public bool ClientOnly { get; set; }

    public ICollection<MenuItem> ToolBarRules { get; set; }

    public ICollection<MenuItem> ContextMenuRules { get; set; }

    public ICollection<Operator> ExcludedOperators { get; set; }

    public ICollection<DataSourceHolder> DataSources { get; set; }

    public RuleModel Rule
    {
      get
      {
        return this.rule;
      }
      set
      {
        this.rule = value;
        if (this.showToolBar)
          return;
        this.rule.SkipNameValidation = true;
      }
    }

    public RuleEditor(string id)
    {
      this.Id = string.IsNullOrWhiteSpace(id) ? (string) null : id;
      this.Mode = RuleType.Evaluation;
      this.ClientOnly = this.ShowLineDots = this.KeepDeclaredOrder = false;
      this.rule = new RuleModel();
      this.showToolBar = this.Mode != RuleType.Filter;
      this.ShowMenuOnRightArrowKey = this.ShowMenuOnElementClicked = this.ShowDescriptionsOnMouseHover = this.ShowHelpString = true;
      this.Theme = ThemeType.Gray;
      this.ExcludedOperators = (ICollection<Operator>) new List<Operator>();
    }

    public RuleEditor(ViewContext viewContext)
      : this(string.Empty)
    {
      this.viewContext = viewContext;
    }

    internal void RenderScript(HtmlTextWriter writer)
    {
      MarkupData conditions = this.GetConditions();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.Append(MarkupManager.RenderControlInstance(this.Id, this.Id, this.ClientOnly ? (string) null : this.dataFieldID, this.viewContext.HttpContext.Request.Browser.Platform.ToLower() == "winxp", false));
      if (!this.ClientOnly)
      {
        stringBuilder.Append(MarkupManager.RenderSettings((CodeEffects.Rule.Models.IControl) this, conditions, true));
        RuleValidator.ForceTokens(this.Rule.Elements);
        stringBuilder.Append(MarkupManager.RenderRuleDataForLoading(this.Rule, this.Id));
        if (!this.valid)
        {
          if (this.Rule.InvalidElements != null && this.Rule.InvalidElements.Count > 0)
          {
            foreach (InvalidElement invalidElement in this.Rule.InvalidElements)
            {
              foreach (XmlNode childNode in this.GetHelpXml().SelectSingleNode("/codeeffects/validation").ChildNodes)
              {
                if (childNode.NodeType != XmlNodeType.Comment && childNode.Name == invalidElement.Hint)
                {
                  invalidElement.Hint = childNode.InnerText;
                  break;
                }
              }
            }
          }
          stringBuilder.Append(MarkupManager.RenderInvalidDataForLoading(this.Rule, this.Id));
        }
      }
      writer.Write(stringBuilder.ToString());
    }

    public void Render()
    {
      if (!this.Rule.IsLoadedRuleOfEvalType.HasValue)
        this.Rule.IsLoadedRuleOfEvalType = new bool?(this.Mode == RuleType.Evaluation || this.mode == RuleType.Filter);
      if (this.Rule.InvalidElements.Count == 0 && !this.Rule.NameIsInvalid)
        RuleValidator.EnsureValues(this.Rule.Elements);
      if (string.IsNullOrWhiteSpace(this.Id))
        throw new RuleEditorMVCException(RuleEditorMVCException.ErrorIds.RuleEditorIdIsNull, new string[0]);
      using (HtmlTextWriter htmlTextWriter = new HtmlTextWriter(this.viewContext.Writer))
      {
        ++htmlTextWriter.Indent;
        htmlTextWriter.WriteLine();
        htmlTextWriter.AddAttribute(HtmlTextWriterAttribute.Id, this.Id);
        htmlTextWriter.AddAttribute(HtmlTextWriterAttribute.Name, this.Id);
        htmlTextWriter.RenderBeginTag(HtmlTextWriterTag.Div);
        if (!this.ClientOnly)
        {
          htmlTextWriter.AddAttribute(HtmlTextWriterAttribute.Type, "hidden");
          htmlTextWriter.AddAttribute(HtmlTextWriterAttribute.Id, this.dataFieldID);
          htmlTextWriter.AddAttribute(HtmlTextWriterAttribute.Name, this.Id);
          htmlTextWriter.RenderBeginTag(HtmlTextWriterTag.Input);
        }
        htmlTextWriter.WriteLine();
        htmlTextWriter.AddAttribute(HtmlTextWriterAttribute.Href, "http://codeeffects.com");
        htmlTextWriter.AddAttribute("ce002", this.IsDemo() ? "true" : "false");
        htmlTextWriter.RenderBeginTag(HtmlTextWriterTag.A);
        htmlTextWriter.WriteEncodedText(".");
        htmlTextWriter.RenderEndTag();
        if (!this.ClientOnly)
          htmlTextWriter.RenderEndTag();
        htmlTextWriter.RenderEndTag();
        htmlTextWriter.WriteLine();
      }
    }

    public string GetClientSettings()
    {
      return MarkupManager.RenderSettings((CodeEffects.Rule.Models.IControl) this, this.GetConditions(), false);
    }

    public string GetClientRuleData()
    {
      if (this.Rule.IsEmpty() || !this.Rule.IsValid())
        return (string) null;
      return MarkupManager.RenderRuleClientData(this.Rule);
    }

    public void LoadClientData(string ruleClientData)
    {
      this.Rule = new RuleDataTypeConverter().GetRuleModel(ruleClientData, this.Rule.SourceAssembly, this.Rule.SourceType, this.Rule.SourceXml);
      if (this.Rule.Elements != null && this.Rule.Elements.Count > 0)
        RuleValidator.EnsureTokens(this.Rule.Elements, this.GetSourceXml());
      if (!string.IsNullOrWhiteSpace(this.Rule.Id))
        return;
      this.Rule.Id = Guid.NewGuid().ToString();
    }

    public string GetClientInvalidData()
    {
      XmlDocument helpXml = this.GetHelpXml();
      foreach (InvalidElement invalidElement in this.Rule.InvalidElements)
        invalidElement.Hint = RuleValidator.GetValidationMessage(helpXml, invalidElement.Hint);
      return MarkupManager.RenderRuleInvalidClientData(this.Rule);
    }

    public XmlDocument GetSourceXml()
    {
      if (this.Rule.SourceXml != null)
        return this.Rule.SourceXml;
      this.Rule.SourceXml = SourceLoader.LoadSourceXml(this.Rule.SourceAssembly, this.Rule.SourceType, this.Rule.SourceXmlFile, new List<Type>());
      return this.Rule.SourceXml;
    }

    public XmlDocument GetHelpXml()
    {
      if (this.HelpXml != null)
        return this.HelpXml;
      if (string.IsNullOrEmpty(this.HelpXmlFile))
      {
        string xml = this.Mode == RuleType.Filter ? Resource.FilterHelp : Resource.RuleHelp;
        this.HelpXml = new XmlDocument();
        this.HelpXml.LoadXml(xml);
        return this.HelpXml;
      }
      try
      {
        this.HelpXml = new XmlDocument();
        this.HelpXml.Load(this.HelpXmlFile);
        return this.HelpXml;
      }
      catch (Exception ex)
      {
        throw new MalformedXmlException(MalformedXmlException.ErrorIds.MalformedOrMissingHelpXML, new string[1]{ ex.Message });
      }
    }

    public override string ToString()
    {
      return this.ToString((GetRuleDelegate) null, (Dictionary<string, GetDataSourceDelegate>) null);
    }

    public string ToString(GetRuleDelegate ruleDelegate)
    {
      return this.ToString(ruleDelegate, (Dictionary<string, GetDataSourceDelegate>) null);
    }

    public string ToString(Dictionary<string, GetDataSourceDelegate> dataSources)
    {
      return this.ToString((GetRuleDelegate) null, dataSources);
    }

    public string ToString(GetRuleDelegate ruleDelegate, Dictionary<string, GetDataSourceDelegate> dataSources)
    {
      if (this.Rule.IsEmpty())
        return base.ToString();
      return RuleLoader.GetString(this.Rule.Elements, this.GetSourceXml(), new Labels(this.GetHelpXml(), this.ShowToolBar, this.Mode), ruleDelegate, dataSources);
    }

    private bool IsDemo()
    {
      return Vector.IsDemo(this.viewContext.HttpContext.Request.Url.Host, this.viewContext.HttpContext.Request.ServerVariables["SERVER_NAME"], this.viewContext.HttpContext.Request.IsLocal);
    }

    private MarkupData GetConditions()
    {
      MarkupData markupData1 = new MarkupData();
      markupData1.Pattern = Pattern.Mvc;
      if (this.ShowToolBar && !this.ClientOnly)
      {
        markupData1.MvcActions = new ActionUrls();
        UrlHelper urlHelper = new UrlHelper(this.viewContext.RequestContext);
        if (!string.IsNullOrWhiteSpace(this.SaveAction) && !string.IsNullOrWhiteSpace(this.SaveController))
          markupData1.MvcActions.SaveAction = urlHelper.Action(this.SaveAction, this.SaveController);
        if (!string.IsNullOrWhiteSpace(this.DeleteAction) && !string.IsNullOrWhiteSpace(this.DeleteController))
          markupData1.MvcActions.DeleteAction = urlHelper.Action(this.DeleteAction, this.DeleteController, (object) new{ id = "_ce_" });
        if (!string.IsNullOrWhiteSpace(this.LoadAction) && !string.IsNullOrWhiteSpace(this.LoadController))
          markupData1.MvcActions.LoadAction = urlHelper.Action(this.LoadAction, this.LoadController, (object) new{ id = "_ce_" });
      }
      if (this.Theme != ThemeType.None)
        markupData1.ThemeFactory = new ThemeManager(this.Theme);
      Settings settings = new Settings(this.GetHelpXml(), this.ToolBarRules, this.ShowToolBar, this.Mode);
      settings.Load((CodeEffects.Rule.Models.IControl) this, this.ContextMenuRules, this.GetSourceXml(), this.DataSources);
      markupData1.Settings = settings;
      markupData1.ControlServerID = this.Id;
      if (this.Mode == RuleType.Loop || this.Mode == RuleType.Ruleset)
      {
        markupData1.IsLoadedRuleOfEvalType = false;
        this.Rule.IsLoadedRuleOfEvalType = new bool?(false);
      }
      else if (!this.Rule.IsLoadedRuleOfEvalType.HasValue)
      {
        markupData1.IsLoadedRuleOfEvalType = this.Mode == RuleType.Evaluation || this.Mode == RuleType.Filter;
      }
      else
      {
        MarkupData markupData2 = markupData1;
        bool? loadedRuleOfEvalType = this.Rule.IsLoadedRuleOfEvalType;
        int num = !loadedRuleOfEvalType.GetValueOrDefault() ? 0 : (loadedRuleOfEvalType.HasValue ? 1 : 0);
        markupData2.IsLoadedRuleOfEvalType = num != 0;
      }
      markupData1.Mode = this.Mode;
      return markupData1;
    }
  }
}
