﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Mvc.ScriptManager
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using CodeEffects.Rule.Client;
using CodeEffects.Rule.Common;
using CodeEffects.Rule.Core;
using System.Collections.Generic;
using System.Web.Mvc;
using System.Web.UI;

namespace CodeEffects.Rule.Mvc
{
  public class ScriptManager
  {
    private List<RuleEditor> ruleEditors = new List<RuleEditor>();
    private ViewContext viewContext;

    public static object Key
    {
      get
      {
        return (object) typeof (ScriptManager).AssemblyQualifiedName;
      }
    }

    public ScriptManager(ViewContext viewContext)
    {
      this.viewContext = viewContext;
      if (this.viewContext.HttpContext.Items[ScriptManager.Key] != null)
        throw new RuleEditorMVCException(RuleEditorMVCException.ErrorIds.OnlyOneScriptManagerIsAllowed, new string[0]);
      this.viewContext.HttpContext.Items[ScriptManager.Key] = (object) this;
    }

    public void Register(RuleEditor editor)
    {
      if (this.ruleEditors.Contains(editor))
        return;
      this.ruleEditors.Add(editor);
    }

    public void Render()
    {
      if (this.ruleEditors.Count == 0)
        return;
      using (HtmlTextWriter writer = new HtmlTextWriter(this.viewContext.Writer))
      {
        ++writer.Indent;
        writer.WriteLine();
        string webResourceUrl = new Page().ClientScript.GetWebResourceUrl(typeof (CodeEffects.Rule.Asp.RuleEditor), "CodeEffects.Rule.Resources.Scripts.Control.js");
        writer.AddAttribute(HtmlTextWriterAttribute.Type, "text/javascript");
        writer.AddAttribute(HtmlTextWriterAttribute.Src, webResourceUrl);
        writer.RenderBeginTag(HtmlTextWriterTag.Script);
        writer.RenderEndTag();
        writer.WriteLine();
        writer.AddAttribute(HtmlTextWriterAttribute.Type, "text/javascript");
        writer.RenderBeginTag(HtmlTextWriterTag.Script);
        writer.Write("//<![CDATA[");
        writer.Write(MarkupManager.RenderInitials());
        bool flag = false;
        bool includeToolBarLabels = false;
        foreach (RuleEditor ruleEditor in this.ruleEditors)
        {
          if (!flag && ruleEditor.ShowHelpString)
            flag = true;
          if (!includeToolBarLabels && ruleEditor.ShowToolBar)
            includeToolBarLabels = true;
        }
        this.ruleEditors[0].GetHelpXml();
        Labels labels = new Labels(this.ruleEditors[0].GetHelpXml(), includeToolBarLabels, RuleType.Evaluation);
        if (flag)
          writer.Write(MarkupManager.RenderHelp(labels.GetUiMessages()));
        writer.Write(MarkupManager.RenderErrors(labels.GetErrorMessages()));
        foreach (RuleEditor ruleEditor in this.ruleEditors)
          ruleEditor.RenderScript(writer);
        writer.Write("//]]>");
        writer.RenderEndTag();
        writer.WriteLine();
      }
    }
  }
}
