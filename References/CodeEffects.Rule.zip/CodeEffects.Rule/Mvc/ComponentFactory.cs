﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Mvc.ComponentFactory
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using System.ComponentModel;
using System.Web.Mvc;

namespace CodeEffects.Rule.Mvc
{
  public class ComponentFactory
  {
    private ScriptManager scriptManager;
    private StyleManager styleManager;

    [EditorBrowsable(EditorBrowsableState.Never)]
    public HtmlHelper HtmlHelper { get; set; }

    public ComponentFactory(HtmlHelper helper)
    {
      this.HtmlHelper = helper;
      this.scriptManager = this.HtmlHelper.ViewContext.HttpContext.Items[ScriptManager.Key] as ScriptManager ?? new ScriptManager(this.HtmlHelper.ViewContext);
      this.styleManager = this.HtmlHelper.ViewContext.HttpContext.Items[StyleManager.Key] as StyleManager ?? new StyleManager(this.HtmlHelper.ViewContext);
    }

    public RuleEditorBuilder RuleEditor()
    {
      RuleEditorBuilder ruleEditorBuilder = new RuleEditorBuilder(this.HtmlHelper.ViewContext);
      ruleEditorBuilder.Theme(this.styleManager.Theme);
      this.scriptManager.Register(ruleEditorBuilder.Editor);
      return ruleEditorBuilder;
    }

    public StyleManager Styles()
    {
      return this.styleManager;
    }

    public ScriptManager Scripts()
    {
      return this.scriptManager;
    }
  }
}
