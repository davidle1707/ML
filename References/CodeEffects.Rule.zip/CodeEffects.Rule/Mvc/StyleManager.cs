﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Mvc.StyleManager
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using CodeEffects.Rule.Common;
using CodeEffects.Rule.Core;
using System.Web.Mvc;
using System.Web.UI;

namespace CodeEffects.Rule.Mvc
{
  public class StyleManager
  {
    private ViewContext viewContext;

    public static object Key
    {
      get
      {
        return (object) typeof (StyleManager).AssemblyQualifiedName;
      }
    }

    public ThemeType Theme { get; set; }

    public StyleManager(ViewContext viewContext)
    {
      this.viewContext = viewContext;
      if (this.viewContext.HttpContext.Items[StyleManager.Key] != null)
        throw new RuleEditorMVCException(RuleEditorMVCException.ErrorIds.OnlyOneStyleManagerIsAllowed, new string[0]);
      this.viewContext.HttpContext.Items[StyleManager.Key] = (object) this;
      this.Theme = ThemeType.Gray;
    }

    public StyleManager SetTheme(ThemeType theme)
    {
      this.Theme = theme;
      return this;
    }

    public void Render()
    {
      if (this.Theme == ThemeType.None)
        return;
      ThemeManager themeManager = new ThemeManager(this.Theme);
      using (HtmlTextWriter htmlTextWriter = new HtmlTextWriter(this.viewContext.Writer))
      {
        ++htmlTextWriter.Indent;
        htmlTextWriter.WriteLine();
        htmlTextWriter.AddAttribute(HtmlTextWriterAttribute.Rel, "stylesheet");
        htmlTextWriter.AddAttribute(HtmlTextWriterAttribute.Type, "text/css");
        htmlTextWriter.AddAttribute(themeManager.StyleTagAttribute, "true");
        htmlTextWriter.AddAttribute(HtmlTextWriterAttribute.Href, themeManager.GetLinkUrl());
        htmlTextWriter.RenderBeginTag(HtmlTextWriterTag.Link);
        htmlTextWriter.RenderEndTag();
        htmlTextWriter.WriteLine();
      }
    }
  }
}
