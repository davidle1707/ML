﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Common.Xml
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using System;
using System.IO;
using System.Reflection;
using System.Xml;
using System.Xml.Schema;

namespace CodeEffects.Rule.Common
{
  public static class Xml
  {
    internal const string SourceNamespaceTag = "s";
    private const string currentRuleNamespace = "http://codeeffects.com/schemas/rule/41";
    public const string UiNamespace = "http://codeeffects.com/schemas/ui/4";
    public const string SourceNamespace = "http://codeeffects.com/schemas/source/42";

    internal static string RuleNamespaceTag
    {
      get
      {
        return "x";
      }
    }

    internal static string UiNamespaceTag
    {
      get
      {
        return "y";
      }
    }

    public static string RuleNamespace
    {
      get
      {
        return "http://codeeffects.com/schemas/rule/41";
      }
    }

    public static XmlDocument GetEmptyRuleDocument()
    {
      return CodeEffects.Rule.Common.Xml.GetEmptyRuleDocument(RuleFormatType.CodeEffects);
    }

    public static XmlDocument GetEmptyRuleDocument(RuleFormatType format)
    {
      if (format != RuleFormatType.CodeEffects)
        throw new NotSupportedException("This XML format is not supported by this version of Code Effects.");
      XmlDocument xmlDocument = new XmlDocument();
      xmlDocument.InnerXml = string.Format("<codeeffects xmlns=\"{0}\" xmlns:ui=\"{1}\"></codeeffects>", (object) CodeEffects.Rule.Common.Xml.RuleNamespace, (object) "http://codeeffects.com/schemas/ui/4");
      xmlDocument.InsertBefore((XmlNode) xmlDocument.CreateXmlDeclaration("1.0", "utf-8", (string) null), (XmlNode) xmlDocument.DocumentElement);
      return xmlDocument;
    }

    public static bool IsRuleValid(XmlDocument ruleXml)
    {
      return new RuleXmlValidator().Validate(ruleXml.OuterXml);
    }

    internal static bool IsVersion2XmlNamespace(string namespaceUri)
    {
      switch (namespaceUri.ToLower())
      {
        case "http://codeeffects.com/schemas/rule":
        case "http://rule.codeeffects.com/schemas/rule":
        case "http://codeeffects.com/schemas/rule/3":
        case "http://rule.codeeffects.com/schemas/rule/3":
        case "http://codeeffects.com/schemas/rule/4":
        case "http://rule.codeeffects.com/schemas/rule/4":
        case "http://rule.codeeffects.com/schemas/rule/41":
        case "http://codeeffects.com/schemas/rule/41":
          return true;
        default:
          return false;
      }
    }

    internal static string GetUiNamespaceByRuleNamespace(string ruleNamespaceUri)
    {
      switch (ruleNamespaceUri.ToLower())
      {
        case "http://codeeffects.com/schemas/rule":
        case "http://rule.codeeffects.com/schemas/rule":
          return "http://codeeffects.com/schemas/ui";
        case "http://codeeffects.com/schemas/rule/3":
        case "http://rule.codeeffects.com/schemas/rule/3":
          return "http://codeeffects.com/schemas/ui/3";
        case "http://codeeffects.com/schemas/rule/4":
        case "http://rule.codeeffects.com/schemas/rule/4":
        case "http://rule.codeeffects.com/schemas/rule/41":
        case "http://codeeffects.com/schemas/rule/41":
          return "http://codeeffects.com/schemas/ui/4";
        default:
          throw new InvalidRuleException(InvalidRuleException.ErrorIds.UnknownNameSpace, new string[1]{ ruleNamespaceUri });
      }
    }

    public static string GetSourceNameByNamespace(string sourceNamespaceUri)
    {
      switch (sourceNamespaceUri.ToLower())
      {
        case "http://codeeffects.com/schemas/source/3":
        case "http://rule.codeeffects.com/schemas/source/3":
          return "CodeEffects.Rule.Resources.Schemas.Source.3.xsd";
        case "http://rule.codeeffects.com/schemas/source/4":
        case "http://codeeffects.com/schemas/source/4":
          return "CodeEffects.Rule.Resources.Schemas.Source.4.xsd";
        case "http://rule.codeeffects.com/schemas/source/42":
        case "http://codeeffects.com/schemas/source/42":
          return "CodeEffects.Rule.Resources.Schemas.Source.4.2.xsd";
        default:
          return "CodeEffects.Rule.Resources.Schemas.Source.2.xsd";
      }
    }

    internal static XmlDocument GetEmptySourceDocument()
    {
      XmlDocument xmlDocument = new XmlDocument();
      xmlDocument.InnerXml = string.Format("<codeeffects xmlns=\"{0}\"></codeeffects>", (object) "http://codeeffects.com/schemas/source/42");
      xmlDocument.InsertBefore((XmlNode) xmlDocument.CreateXmlDeclaration("1.0", "utf-8", "yes"), (XmlNode) xmlDocument.DocumentElement);
      return xmlDocument;
    }

    public static void ValidateSchema(XmlDocument doc, string schemaResource)
    {
      Assembly executingAssembly = Assembly.GetExecutingAssembly();
      XmlReaderSettings settings = new XmlReaderSettings();
      settings.CloseInput = true;
      settings.ConformanceLevel = ConformanceLevel.Document;
      settings.ValidationType = ValidationType.Schema;
      using (Stream manifestResourceStream = executingAssembly.GetManifestResourceStream(schemaResource))
      {
        string targetNamespace = string.Empty;
        XmlReader schemaDocument = XmlReader.Create(manifestResourceStream);
        int num = (int) schemaDocument.MoveToContent();
        if (schemaDocument.MoveToAttribute("targetNamespace"))
          targetNamespace = schemaDocument.Value;
        if (!doc.Schemas.Contains(targetNamespace))
        {
          manifestResourceStream.Position = 0L;
          schemaDocument = XmlReader.Create(manifestResourceStream, settings);
          doc.Schemas.Add((string) null, schemaDocument);
        }
        doc.Validate(new ValidationEventHandler(CodeEffects.Rule.Common.Xml.ValidationFailed));
        schemaDocument.Close();
      }
    }

    internal static XmlNamespaceManager GetSourceNamespaceManager(XmlNode node)
    {
      return CodeEffects.Rule.Common.Xml.GetSourceNamespaceManager(node.GetType() == typeof (XmlDocument) ? (XmlDocument) node : node.OwnerDocument);
    }

    internal static XmlNamespaceManager GetSourceNamespaceManager(XmlDocument xml)
    {
      XmlNamespaceManager namespaceManager = new XmlNamespaceManager(xml.NameTable);
      namespaceManager.AddNamespace("s", xml.DocumentElement.NamespaceURI);
      return namespaceManager;
    }

    private static void ValidationFailed(object sender, ValidationEventArgs e)
    {
      throw new SourceException(SourceException.ErrorIds.SchemaValidationFailed, new string[1]{ e.Message });
    }
  }
}
