﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Common.SourceException
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

namespace CodeEffects.Rule.Common
{
  public class SourceException : RuleException
  {
    internal SourceException(SourceException.ErrorIds error, params string[] parameters)
      : base("s" + (object) error, parameters)
    {
    }

    public enum ErrorIds
    {
      FailureToLoadSourceXML = 100,
      AssemblyNameIsEmpty = 101,
      AssemlbyDoesNotDeclareSourceType = 102,
      FailedToFindOrLoadAssembly = 103,
      AssemblyDoesNotContainType = 104,
      FailedToLoadAssemblyOrType = 105,
      ExternalMethodHasOverloads = 106,
      MissingPublicValueTypeFields = 107,
      MethodHasOverloads = 108,
      MethodIsDecoratedButInvalid = 111,
      NoMethodForTheToken = 112,
      DuplicateDataAttributes = 113,
      MethodIsNotDataSource = 114,
      MissingOrInaccessibleMethod = 115,
      MethodInvokeOrConversionError = 116,
      InvalidMethodParameters = 117,
      InvalidDataSourceMethod = 118,
      DelegateInvokeOrConversionError = 119,
      EnumMethodParamNotSupported = 120,
      GenericCollectionsAndPropertiesNotSupported = 121,
      NullableReturnNotSupported = 122,
      ReturnTypeNotSupported = 123,
      MethodNotFound = 124,
      MultipleDynamicMenuDataSources = 125,
      InvalidCollectionParameterXML = 126,
      InvalidSourceXML = 127,
      SchemaValidationFailed = 128,
      SourceNodeNotFound = 130,
    }
  }
}
