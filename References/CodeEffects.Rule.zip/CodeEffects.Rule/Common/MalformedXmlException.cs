﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Common.MalformedXmlException
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

namespace CodeEffects.Rule.Common
{
  public class MalformedXmlException : RuleException
  {
    internal MalformedXmlException(MalformedXmlException.ErrorIds error, params string[] parameters)
      : base("m" + (object) error, parameters)
    {
    }

    public enum ErrorIds
    {
      UnknownConditionType = 102,
      UnknownNodeName = 103,
      MissingActionsNode = 104,
      ReferenceTypedCollectionNotAllowed = 105,
      MissingFieldsNode = 106,
      MissingFieldsWithPropertyName = 107,
      RuleDelegateIsNull = 108,
      GetRuleDelegateInvokeError = 109,
      UnknownDataSourceLocationType = 110,
      UnknownDataSourceLocationString = 111,
      MissingEnumMember = 112,
      InvalidSelectionType = 113,
      UnknownDataType = 114,
      MalformedOrMissingSourceXML = 129,
      MalformedOrMissingHelpXML = 130,
      CouldNotLoadRuleXML = 131,
      InvalidFieldName = 138,
      MissingMinAttribute = 148,
      MissingMaxAttribute = 149,
      InvalidMinValue = 152,
      MissingMaxlengthAttribute = 155,
      CollectionsAsConstantParams = 200,
      InvalidBoolParamValue = 204,
      InvalidDateParamValue = 205,
      InvalidTimeParamValue = 206,
      InvalidStringParamLength = 207,
      InvalidNumericParamFormat = 208,
      TooManyOrMissingReturn = 211,
      MissingReturnClassAttribute = 212,
      UnknownParameterType = 215,
      UnknownCollectionType = 218,
      UnknownInputType = 225,
    }
  }
}
