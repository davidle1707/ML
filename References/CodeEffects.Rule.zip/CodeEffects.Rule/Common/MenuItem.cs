﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Common.MenuItem
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using System;
using System.Text;

namespace CodeEffects.Rule.Common
{
  public class MenuItem
  {
    public string ID { get; set; }

    public string DisplayName { get; set; }

    public string SourceName { get; set; }

    public string Description { get; set; }

    public MenuItem()
    {
      this.ID = Guid.Empty.ToString();
    }

    public MenuItem(string id, string displayName)
    {
      this.ID = id;
      this.DisplayName = displayName;
    }

    public MenuItem(string id, string displayName, string description)
      : this(id, displayName)
    {
      this.Description = description;
    }

    public MenuItem(string id, string displayName, string description, string sourceName)
      : this(id, displayName)
    {
      this.SourceName = sourceName;
      this.Description = description;
    }

    public override string ToString()
    {
      StringBuilder stringBuilder = new StringBuilder("{");
      stringBuilder.Append("\"v\":\"").Append(CodeEffects.Rule.Core.Encoder.Sanitize(this.ID));
      stringBuilder.Append("\",\"n\":\"").Append(CodeEffects.Rule.Core.Encoder.Sanitize(this.DisplayName)).Append("\"}");
      return stringBuilder.ToString();
    }
  }
}
