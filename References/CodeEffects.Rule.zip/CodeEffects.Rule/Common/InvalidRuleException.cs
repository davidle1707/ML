﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Common.InvalidRuleException
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

namespace CodeEffects.Rule.Common
{
  public class InvalidRuleException : RuleException
  {
    internal InvalidRuleException(InvalidRuleException.ErrorIds error, params string[] parameters)
      : base("i" + (object) error, parameters)
    {
    }

    public enum ErrorIds
    {
      FlowTypeElementExcpected = 100,
      RuleXMLIsInvalid = 101,
      ReferencedRuleNotFound = 102,
      RuleNotFound = 103,
      InvalidOrderOfNodes = 105,
      UnexpectedOrderOfCalculationNodes = 107,
      UnecpectedCalculationType = 108,
      MissingControl = 114,
      RuleIsInvalid = 115,
      FailtureToValidate = 116,
      XMLFileNotFound = 117,
      XMLFileIsMalformed = 118,
      ParameterIsNull = 119,
      RuleXMLNotFound = 120,
      InvalidNumberOfChildNodes = 124,
      RuleXMLIsInvalid2 = 125,
      InvalidNumberOfConditionChildNodes = 126,
      UnexpectedChildNodeInCondition = 127,
      UnknownNameSpace = 128,
      UnexpectedNumberOfParameters = 129,
      UnexpectedValueSetters = 130,
      InvalidDefinitionStructure = 131,
      InvalidNumberOfIfElements = 132,
    }
  }
}
