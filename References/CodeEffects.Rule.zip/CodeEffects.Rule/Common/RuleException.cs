﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Common.RuleException
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using System;
using System.Text.RegularExpressions;
using System.Xml;

namespace CodeEffects.Rule.Common
{
  public class RuleException : Exception
  {
    private string number;
    private string message;

    public override string Message
    {
      get
      {
        if (this.message == null)
          return base.Message;
        return this.message;
      }
    }

    public string Number
    {
      get
      {
        return this.number;
      }
    }

    protected internal RuleException(string errorId, params string[] parameters)
      : base(errorId)
    {
      if (!this.IsMessageId(errorId))
        return;
      this.number = errorId.ToUpper();
      this.message = this.LoadMessage(errorId, parameters);
    }

    private bool IsMessageId(string text)
    {
      if (string.IsNullOrWhiteSpace(text))
        return false;
      return new Regex("^[a-z]+\\d+$", RegexOptions.IgnoreCase).IsMatch(text);
    }

    private string LoadMessage(string messageId, string[] parameters)
    {
      XmlDocument xmlDocument = new XmlDocument();
      xmlDocument.LoadXml(Resource.Errors);
      XmlNode xmlNode = xmlDocument.DocumentElement.SelectSingleNode("/codeeffects/values/" + messageId);
      if (xmlNode == null)
        return "Generic error: " + messageId.ToUpper();
      string str = string.Format("{0} (Error {1})", (object) xmlNode.InnerText, (object) messageId.ToUpper());
      if (parameters != null && parameters.Length > 0)
      {
        for (int index = 0; index < parameters.Length; ++index)
          str = str.Replace("{" + (object) index + "}", parameters[index] == null ? "[NULL]" : parameters[index]);
      }
      return str;
    }
  }
}
