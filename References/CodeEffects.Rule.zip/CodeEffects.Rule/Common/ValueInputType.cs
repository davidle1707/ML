﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Common.ValueInputType
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

namespace CodeEffects.Rule.Common
{
  public enum ValueInputType
  {
    Fields = 0,
    User = 2,
    All = 4,
  }
}
