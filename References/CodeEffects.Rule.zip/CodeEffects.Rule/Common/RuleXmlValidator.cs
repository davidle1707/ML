﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Common.RuleXmlValidator
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using CodeEffects.Rule.Core;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Web.Script.Serialization;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Schema;
using System.Xml.Serialization;

namespace CodeEffects.Rule.Common
{
  internal class RuleXmlValidator
  {
    private bool ruleIsValid;
    private XmlSchemaSet schemas;
    private List<string> errors;

    public List<string> Errors
    {
      get
      {
        return this.errors;
      }
    }

    public RuleXmlValidator()
    {
      Assembly executingAssembly = Assembly.GetExecutingAssembly();
      this.schemas = new XmlSchemaSet();
      RuleXmlValidator.AddSchema(this.schemas, "Rule", executingAssembly);
      RuleXmlValidator.AddSchema(this.schemas, "UI", executingAssembly);
      this.errors = new List<string>();
    }

    private static void AddSchema(XmlSchemaSet schemas, string schemaName, Assembly assembly)
    {
      using (Stream manifestResourceStream = assembly.GetManifestResourceStream(string.Format("CodeEffects.Rule.Resources.Schemas.{0}.xsd", (object) schemaName)))
      {
        using (XmlReader schemaDocument = XmlReader.Create(manifestResourceStream, new XmlReaderSettings() { CloseInput = true, ConformanceLevel = ConformanceLevel.Document, ValidationType = ValidationType.Schema }))
          schemas.Add((string) null, schemaDocument);
      }
    }

    public bool Validate(string xmlString)
    {
      XDocument source = XDocument.Parse(xmlString);
      this.ruleIsValid = true;
      source.Validate(this.schemas, (ValidationEventHandler) ((o, e) =>
      {
        this.ruleIsValid = false;
        this.errors.Add(string.Format("{0}", (object) e.Message));
      }), true);
      if (!this.ruleIsValid)
        return this.ruleIsValid;
      XNamespace defaultNamespace = source.Root.GetDefaultNamespace();
      foreach (XElement descendant in source.Descendants(defaultNamespace + "value"))
      {
        this.ruleIsValid = this.ValidateValue(descendant);
        if (!this.ruleIsValid)
          break;
      }
      foreach (XElement descendant in source.Descendants(defaultNamespace + "condition"))
      {
        this.ruleIsValid = RuleXmlValidator.ValidateCondition(descendant);
        if (!this.ruleIsValid)
          break;
      }
      foreach (XElement descendant in source.Descendants(defaultNamespace + "method"))
      {
        this.ruleIsValid = RuleXmlValidator.ValidateMethod(descendant);
        if (!this.ruleIsValid)
          break;
      }
      return this.ruleIsValid;
    }

    private static bool ValidateCondition(XElement condition)
    {
      bool flag = false;
      switch ((string) condition.Attribute((XName) "type"))
      {
        case "equal":
        case "notEqual":
        case "less":
        case "lessOrEqual":
        case "greater":
        case "greaterOrEqual":
          flag = condition.Elements().Count<XElement>() == 2;
          break;
        case "isNull":
        case "isNotNull":
          flag = condition.Elements().Count<XElement>() == 1;
          break;
        case "between":
          flag = condition.Elements().Count<XElement>() == 3;
          break;
      }
      return flag;
    }

    private bool ValidateValue(XElement value)
    {
      bool flag = false;
      string lower = ((string) value.Attribute((XName) "type") ?? "string").ToLower();
      if (lower == "string" || value.IsEmpty)
        return true;
      if (string.IsNullOrWhiteSpace(value.Value))
      {
        flag = false;
      }
      else
      {
        switch (lower)
        {
          case "bool":
            bool result1;
            flag = bool.TryParse(value.Value, out result1);
            break;
          case "integer":
            int result2;
            flag = int.TryParse(value.Value, NumberStyles.Float, (IFormatProvider) CultureInfo.InvariantCulture, out result2);
            break;
          case "time":
            TimeSpan result3;
            flag = TimeSpan.TryParse(value.Value, (IFormatProvider) CultureInfo.InvariantCulture, out result3);
            break;
          case "date":
          case "datetime":
            DateTime result4;
            flag = DateTime.TryParse(value.Value, (IFormatProvider) CultureInfo.InvariantCulture, DateTimeStyles.None, out result4);
            break;
          case "numeric":
            double result5;
            flag = double.TryParse(value.Value, NumberStyles.Float, (IFormatProvider) CultureInfo.InvariantCulture, out result5);
            break;
          case "double":
            double result6;
            flag = double.TryParse(value.Value, NumberStyles.Float, (IFormatProvider) CultureInfo.InvariantCulture, out result6);
            break;
          default:
            Type type = Type.GetType((string) value.Attribute((XName) "type"), true, true);
            if (type.IsEnum)
            {
              try
              {
                Enum.Parse(type, value.Value, true);
                flag = true;
                break;
              }
              catch
              {
                break;
              }
            }
            else
            {
              if (ExpressionBuilderBase.IsGenericNullable(type))
                type = Nullable.GetUnderlyingType(type);
              MethodInfo method1 = type.GetMethod("Parse", BindingFlags.Static | BindingFlags.Public, (Binder) null, new Type[2]{ typeof (string), typeof (IFormatProvider) }, (ParameterModifier[]) null);
              if (method1 != (MethodInfo) null)
              {
                try
                {
                  method1.Invoke((object) null, new object[2]
                  {
                    (object) value.Value,
                    (object) CultureInfo.InvariantCulture
                  });
                  flag = true;
                }
                catch
                {
                }
              }
              MethodInfo method2 = type.GetMethod("Parse", BindingFlags.Static | BindingFlags.Public, (Binder) null, new Type[1]{ typeof (string) }, (ParameterModifier[]) null);
              if (method2 != (MethodInfo) null)
              {
                try
                {
                  method2.Invoke((object) null, new object[1]
                  {
                    (object) value.Value
                  });
                  flag = true;
                }
                catch
                {
                }
              }
              if (!flag)
              {
                XmlSerializer xmlSerializer = new XmlSerializer(type, value.GetDefaultNamespace().NamespaceName);
                using (StringReader stringReader = new StringReader(value.FirstNode.ToString(SaveOptions.DisableFormatting)))
                {
                  try
                  {
                    xmlSerializer.Deserialize((TextReader) stringReader);
                    flag = true;
                  }
                  catch
                  {
                  }
                }
              }
              if (!flag)
              {
                try
                {
                  new JavaScriptSerializer().Deserialize(value.Value, type);
                  flag = true;
                  break;
                }
                catch
                {
                  break;
                }
              }
              else
                break;
            }
        }
      }
      if (!flag)
        this.errors.Add(string.Format("Value of type '{0}', cannot parse '{1}'", (object) value.Attribute((XName) "type"), (object) value.Value));
      return flag;
    }

    private static bool ValidateMethod(XElement method)
    {
      if (!(((string) method.Attribute((XName) "instance") ?? "").ToLower() != "true"))
        return method.Elements().Count<XElement>() > 0;
      return true;
    }

    private void Schemas_ValidationEventHandler(object sender, ValidationEventArgs e)
    {
      this.ruleIsValid = false;
    }

    public void DumpInvalidNodes(XElement el)
    {
      if (el.GetSchemaInfo().Validity != XmlSchemaValidity.Valid)
        this.errors.Add(string.Format("Invalid Element {0}", (object) el.AncestorsAndSelf().InDocumentOrder<XElement>().Aggregate<XElement, string>("", (Func<string, XElement, string>) ((s, i) => s + "/" + i.Name.ToString()))));
      foreach (XAttribute attribute in el.Attributes())
      {
        if (attribute.GetSchemaInfo().Validity != XmlSchemaValidity.Valid)
          this.errors.Add(string.Format("Invalid Attribute {0}", (object) (attribute.Parent.AncestorsAndSelf().InDocumentOrder<XElement>().Aggregate<XElement, string>("", (Func<string, XElement, string>) ((s, i) => s + "/" + i.Name.ToString())) + "/@" + attribute.Name.ToString())));
      }
      foreach (XElement element in el.Elements())
        this.DumpInvalidNodes(element);
    }
  }
}
