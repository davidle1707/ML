﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Asp.SaveEventArgs
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using System;
using System.Collections.Generic;

namespace CodeEffects.Rule.Asp
{
  public class SaveEventArgs : EventArgs
  {
    public string RuleID { get; set; }

    public string RuleName { get; set; }

    public string RuleDescription { get; set; }

    public string RuleXmlAsDocument { get; set; }

    public string RuleXmlAsNode { get; set; }

    public bool IsEvaluationTypeRule { get; set; }

    public List<string> ReferencedRules { get; set; }

    public SaveEventArgs()
    {
      this.IsEvaluationTypeRule = false;
      this.ReferencedRules = new List<string>();
    }
  }
}
