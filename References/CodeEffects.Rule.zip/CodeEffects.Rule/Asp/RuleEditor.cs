﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Asp.RuleEditor
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using CodeEffects.Rule.Client;
using CodeEffects.Rule.Common;
using CodeEffects.Rule.Core;
using CodeEffects.Rule.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Permissions;
using System.Text;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

namespace CodeEffects.Rule.Asp
{
  [ToolboxData("<{0}:RuleEditor runat=\"server\"></{0}:RuleEditor>")]
  [DefaultProperty("SourceType")]
  [Designer(typeof (RuleEditorDesigner))]
  [DesignTimeVisible(true)]
  [AspNetHostingPermission(SecurityAction.Demand, Level = AspNetHostingPermissionLevel.Minimal)]
  [AspNetHostingPermission(SecurityAction.InheritanceDemand, Level = AspNetHostingPermissionLevel.Minimal)]
  public class RuleEditor : Panel, CodeEffects.Rule.Models.IControl
  {
    private const string HiddenFieldIdPrefix = "ce004_";
    private const string CacheSourceKeyPrefix = "appCodeEffectsRuleSourceXmlPath";
    private const string CacheHelpKeyPrefix = "appCodeEffectsRuleHelpXmlPath";
    private const string AnchorIdPrefix = "ce002";
    private HiddenField hiddenField;
    private RuleModel rule;

    [EditorBrowsable(EditorBrowsableState.Always)]
    [Browsable(false)]
    public ICollection<CodeEffects.Rule.Common.MenuItem> ToolBarRules { get; set; }

    [EditorBrowsable(EditorBrowsableState.Always)]
    [Browsable(false)]
    public ICollection<CodeEffects.Rule.Common.MenuItem> ContextMenuRules { get; set; }

    [EditorBrowsable(EditorBrowsableState.Always)]
    [Browsable(false)]
    public bool IsEmpty
    {
      get
      {
        return this.rule.Elements.Count == 0;
      }
    }

    [EditorBrowsable(EditorBrowsableState.Always)]
    [Browsable(false)]
    public bool IsValid
    {
      get
      {
        if (this.rule.InvalidElements.Count == 0)
          return !this.rule.NameIsInvalid;
        return false;
      }
    }

    [EditorBrowsable(EditorBrowsableState.Always)]
    [Browsable(false)]
    public ICollection<DataSourceHolder> DataSources { get; set; }

    [EditorBrowsable(EditorBrowsableState.Always)]
    [Browsable(false)]
    public GetRuleDelegate GetRuleDelegate { get; set; }

    [Browsable(false)]
    [EditorBrowsable(EditorBrowsableState.Always)]
    public XmlDocument HelpXml { get; set; }

    public ICollection<Operator> ExcludedOperators { get; set; }

    [Browsable(false)]
    [EditorBrowsable(EditorBrowsableState.Always)]
    public XmlDocument SourceXml { get; set; }

    [EditorBrowsable(EditorBrowsableState.Always)]
    [Browsable(false)]
    public Type Source { get; set; }

    [Localizable(true)]
    [Bindable(true)]
    [Category("Source")]
    public string SourceXmlFile
    {
      get
      {
        return (string) this.ViewState["ce701"];
      }
      set
      {
        this.ViewState["ce701"] = (object) value;
      }
    }

    [Bindable(true)]
    [Localizable(true)]
    [Category("Source")]
    public string SourceType
    {
      get
      {
        return (string) this.ViewState["ce702"];
      }
      set
      {
        this.ViewState["ce702"] = (object) value;
      }
    }

    [Bindable(true)]
    [Category("Source")]
    [Localizable(true)]
    public string SourceAssembly
    {
      get
      {
        return (string) this.ViewState["ce703"];
      }
      set
      {
        this.ViewState["ce703"] = (object) value;
      }
    }

    [DefaultValue(false)]
    [Category("Source")]
    [Localizable(true)]
    [Bindable(true)]
    public bool CacheSource
    {
      get
      {
        return ((bool?) this.ViewState["ce704"]).GetValueOrDefault();
      }
      set
      {
        this.ViewState["ce704"] = (object) value;
      }
    }

    [Localizable(true)]
    [Bindable(true)]
    [Category("Behavior")]
    [DefaultValue(false)]
    public bool ClientOnly
    {
      get
      {
        return ((bool?) this.ViewState["ce705"]).GetValueOrDefault();
      }
      set
      {
        this.ViewState["ce705"] = (object) value;
      }
    }

    [Localizable(true)]
    [Bindable(true)]
    [Category("Behavior")]
    [DefaultValue(false)]
    public bool ShowLineDots
    {
      get
      {
        return ((bool?) this.ViewState["ce706"]).GetValueOrDefault();
      }
      set
      {
        this.ViewState["ce706"] = (object) value;
      }
    }

    [Category("Behavior")]
    [Bindable(true)]
    [Localizable(true)]
    [DefaultValue(true)]
    public bool ShowMenuOnRightArrowKey
    {
      get
      {
        return ((bool?) this.ViewState["ce707"]).GetValueOrDefault();
      }
      set
      {
        this.ViewState["ce707"] = (object) value;
      }
    }

    [Bindable(true)]
    [Localizable(true)]
    [Category("Behavior")]
    [DefaultValue(true)]
    public bool ShowMenuOnElementClicked
    {
      get
      {
        return ((bool?) this.ViewState["ce708"]).GetValueOrDefault();
      }
      set
      {
        this.ViewState["ce708"] = (object) value;
      }
    }

    [Bindable(true)]
    [DefaultValue(true)]
    [Localizable(true)]
    [Category("Behavior")]
    public bool ShowDescriptionsOnMouseHover
    {
      get
      {
        return ((bool?) this.ViewState["ce711"]).GetValueOrDefault();
      }
      set
      {
        this.ViewState["ce711"] = (object) value;
      }
    }

    [Bindable(true)]
    [Localizable(true)]
    [Category("Behavior")]
    [DefaultValue(true)]
    public bool RuleNameIsRequired
    {
      get
      {
        return ((bool?) this.ViewState["ce712"]).GetValueOrDefault();
      }
      set
      {
        this.ViewState["ce712"] = (object) value;
      }
    }

    [Localizable(true)]
    [Bindable(true)]
    [Category("Behavior")]
    [DefaultValue(true)]
    public bool ShowToolBar
    {
      get
      {
        return ((bool?) this.ViewState["ce709"]).GetValueOrDefault();
      }
      set
      {
        if (!value)
        {
          this.rule.SkipNameValidation = true;
          this.RuleNameIsRequired = false;
        }
        this.ViewState["ce709"] = (object) value;
      }
    }

    [DefaultValue(true)]
    [Category("Behavior")]
    [Localizable(true)]
    [Bindable(true)]
    public bool KeepDeclaredOrder
    {
      get
      {
        return ((bool?) this.ViewState["ce713"]).GetValueOrDefault();
      }
      set
      {
        this.ViewState["ce713"] = (object) value;
      }
    }

    [Localizable(true)]
    [Bindable(true)]
    [Category("Behavior")]
    [DefaultValue(RuleType.Evaluation)]
    public RuleType Mode
    {
      get
      {
        if (this.ViewState["ce710"] != null)
          return (RuleType) this.ViewState["ce710"];
        return RuleType.Evaluation;
      }
      set
      {
        if (value == RuleType.Filter)
          this.ShowToolBar = false;
        this.ViewState["ce710"] = (object) value;
      }
    }

    [Category("Style")]
    [Bindable(true)]
    [DefaultValue(ThemeType.Gray)]
    [Localizable(true)]
    public ThemeType Theme
    {
      get
      {
        if (this.ViewState["ce824"] != null)
          return (ThemeType) this.ViewState["ce824"];
        return ThemeType.Gray;
      }
      set
      {
        this.ViewState["ce824"] = (object) value;
      }
    }

    [Bindable(true)]
    [Localizable(true)]
    [Category("Help")]
    public string HelpXmlFile
    {
      get
      {
        return (string) this.ViewState["ce601"];
      }
      set
      {
        this.ViewState["ce601"] = (object) value;
      }
    }

    [Bindable(true)]
    [Localizable(true)]
    [Category("Help")]
    [DefaultValue(true)]
    public bool ShowHelpString
    {
      get
      {
        return ((bool?) this.ViewState["ce604"]).GetValueOrDefault();
      }
      set
      {
        this.ViewState["ce604"] = (object) value;
      }
    }

    [Localizable(true)]
    [Bindable(true)]
    [Category("Help")]
    [DefaultValue(false)]
    public bool CacheHelp
    {
      get
      {
        return ((bool?) this.ViewState["ce603"]).GetValueOrDefault();
      }
      set
      {
        this.ViewState["ce603"] = (object) value;
      }
    }

    [Browsable(false)]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public override string AccessKey
    {
      get
      {
        return base.AccessKey;
      }
    }

    [EditorBrowsable(EditorBrowsableState.Never)]
    [Browsable(false)]
    public override string BackImageUrl
    {
      get
      {
        return base.BackImageUrl;
      }
    }

    [EditorBrowsable(EditorBrowsableState.Never)]
    [Browsable(false)]
    public override BorderStyle BorderStyle
    {
      get
      {
        return base.BorderStyle;
      }
    }

    [Browsable(false)]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public override Unit BorderWidth
    {
      get
      {
        return base.BorderWidth;
      }
    }

    [Browsable(false)]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public override short TabIndex
    {
      get
      {
        return base.TabIndex;
      }
    }

    [Browsable(false)]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public override Unit Height
    {
      get
      {
        return base.Height;
      }
    }

    [EditorBrowsable(EditorBrowsableState.Never)]
    [Browsable(false)]
    public override string DefaultButton
    {
      get
      {
        return base.DefaultButton;
      }
    }

    [EditorBrowsable(EditorBrowsableState.Never)]
    [Browsable(false)]
    public override string GroupingText
    {
      get
      {
        return base.GroupingText;
      }
    }

    [EditorBrowsable(EditorBrowsableState.Never)]
    [Browsable(false)]
    public override string ToolTip
    {
      get
      {
        return base.ToolTip;
      }
    }

    [EditorBrowsable(EditorBrowsableState.Never)]
    [Browsable(false)]
    public override string CssClass
    {
      get
      {
        return "ceRule";
      }
    }

    [EditorBrowsable(EditorBrowsableState.Never)]
    [Browsable(false)]
    public override ControlCollection Controls
    {
      get
      {
        return base.Controls;
      }
    }

    [EditorBrowsable(EditorBrowsableState.Never)]
    [Browsable(false)]
    public override FontInfo Font
    {
      get
      {
        return base.Font;
      }
    }

    [Browsable(false)]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public override ContentDirection Direction
    {
      get
      {
        return ContentDirection.NotSet;
      }
    }

    [Browsable(false)]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public override HorizontalAlign HorizontalAlign
    {
      get
      {
        return HorizontalAlign.NotSet;
      }
    }

    [Browsable(false)]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public override ScrollBars ScrollBars
    {
      get
      {
        return ScrollBars.None;
      }
    }

    [EditorBrowsable(EditorBrowsableState.Never)]
    [Browsable(false)]
    public override bool Enabled
    {
      get
      {
        return true;
      }
    }

    [EditorBrowsable(EditorBrowsableState.Never)]
    [Browsable(false)]
    public override bool Wrap
    {
      get
      {
        return true;
      }
    }

    [Browsable(false)]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public override bool EnableViewState
    {
      get
      {
        return false;
      }
    }

    [Browsable(false)]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public override bool EnableTheming
    {
      get
      {
        return false;
      }
    }

    public event SaveEventHandler SaveRule;

    public event RuleEventHandler DeleteRule;

    public event RuleEventHandler LoadRule;

    public RuleEditor()
    {
      this.rule = new RuleModel();
      this.Mode = RuleType.Evaluation;
      this.ClientOnly = false;
      this.CacheHelp = this.CacheSource = this.ShowLineDots = false;
      this.RuleNameIsRequired = true;
      this.ShowToolBar = this.Mode != RuleType.Filter;
      this.ShowMenuOnRightArrowKey = this.ShowMenuOnElementClicked = this.ShowDescriptionsOnMouseHover = this.ShowHelpString = true;
      this.Theme = ThemeType.Gray;
      this.ExcludedOperators = (ICollection<Operator>) new List<Operator>();
    }

    [EditorBrowsable(EditorBrowsableState.Never)]
    public override void DataBind()
    {
      throw new NotSupportedException("DataBind method is not supported in Code Effects control.");
    }

    [EditorBrowsable(EditorBrowsableState.Never)]
    public override void Focus()
    {
    }

    [EditorBrowsable(EditorBrowsableState.Never)]
    public override Control FindControl(string id)
    {
      return (Control) null;
    }

    public override void Dispose()
    {
      this.ClearCache();
      this.Clear();
      base.Dispose();
    }

    public override string ToString()
    {
      return this.ToString(this.GetRuleDelegate, (Dictionary<string, GetDataSourceDelegate>) null);
    }

    public string ToString(GetRuleDelegate ruleDelegate)
    {
      return this.ToString(ruleDelegate, (Dictionary<string, GetDataSourceDelegate>) null);
    }

    public string ToString(Dictionary<string, GetDataSourceDelegate> dataSources)
    {
      return this.ToString(this.GetRuleDelegate, dataSources);
    }

    public string ToString(GetRuleDelegate ruleDelegate, Dictionary<string, GetDataSourceDelegate> dataSources)
    {
      if (this.IsEmpty)
        return base.ToString();
      return RuleLoader.GetString(this.rule.Elements, this.GetSourceXmlDocument(), new Labels(this.LoadHelpXml(), this.ShowToolBar, this.Mode), ruleDelegate, dataSources);
    }

    protected override void OnInit(EventArgs e)
    {
      if (this.DesignMode)
        return;
      base.OnInit(e);
      Literal literal = new Literal();
      literal.ID = "ce002" + this.ID;
      literal.EnableViewState = false;
      literal.Text = string.Format("<a href=\"http://codeeffects.com\" {0}=\"{1}\">*</a>", (object) "ce002", (object) this.IsDemo().ToString().ToLower());
      this.Controls.AddAt(0, (Control) literal);
      if (this.ClientOnly)
        return;
      this.hiddenField = new HiddenField();
      this.hiddenField.ID = "ce004_" + this.ID;
      this.hiddenField.EnableViewState = false;
      this.Controls.AddAt(0, (Control) this.hiddenField);
    }

    protected override void OnLoad(EventArgs e)
    {
      if (this.DesignMode)
        return;
      base.OnLoad(e);
      Type type = this.GetType();
      ScriptManager current = ScriptManager.GetCurrent(this.Page);
      if (current != null)
      {
        try
        {
          if (current.CompositeScript != null)
          {
            if (!current.CompositeScript.Scripts.Any<ScriptReference>((Func<ScriptReference, bool>) (script => script.Name == "CodeEffects.Rule.Resources.Scripts.Control.js")))
              current.CompositeScript.Scripts.Add(new ScriptReference("CodeEffects.Rule.Resources.Scripts.Control.js", Assembly.GetExecutingAssembly().FullName));
          }
          else
            current.Scripts.Add(new ScriptReference("CodeEffects.Rule.Resources.Scripts.Control.js", Assembly.GetExecutingAssembly().FullName));
        }
        catch
        {
          this.Page.ClientScript.RegisterClientScriptResource(type, "CodeEffects.Rule.Resources.Scripts.Control.js");
        }
      }
      else
        this.Page.ClientScript.RegisterClientScriptResource(type, "CodeEffects.Rule.Resources.Scripts.Control.js");
      if (!this.ClientOnly && !this.Page.ClientScript.IsOnSubmitStatementRegistered(type, "scrCodeEffectsControlOnSubmit" + this.ClientID))
        this.Page.ClientScript.RegisterOnSubmitStatement(type, "scrCodeEffectsControlOnSubmit" + this.ClientID, string.Format("var ce{0} = $ce('{0}');if(ce{0})ce{0}.post();", (object) this.ID));
      if (!this.Page.IsPostBack)
        return;
      if (this.hiddenField == null)
        throw new InvalidRuleException(InvalidRuleException.ErrorIds.MissingControl, new string[0]);
      this.LoadClientData(this.hiddenField.Value);
      this.hiddenField.Value = string.Empty;
      if (this.Page.Request.Form["__EVENTTARGET"] == this.ClientID)
      {
        if (!this.IsValid)
          return;
        switch (this.rule.Command)
        {
          case "ceSave":
            if (this.IsEmpty)
              break;
            if (string.IsNullOrWhiteSpace(this.rule.Id))
              this.rule.Id = Guid.NewGuid().ToString();
            if (this.SaveRule == null)
              break;
            this.SaveRule((object) this, this.GetSaveEventArgs());
            break;
          case "ceDelete":
            if (string.IsNullOrWhiteSpace(this.rule.Id))
              throw new EvaluationException(EvaluationException.ErrorIds.InvalidPostbackArgument, new string[0]);
            if (this.DeleteRule == null)
              break;
            this.DeleteRule((object) this, new RuleEventArgs(this.rule.Id, this.rule.IsLoadedRuleOfEvalType));
            break;
          default:
            try
            {
              this.rule.Id = this.rule.Command;
            }
            catch
            {
              throw new EvaluationException(EvaluationException.ErrorIds.InvalidPostbackArgument, new string[0]);
            }
            if (this.LoadRule == null)
              break;
            this.LoadRule((object) this, new RuleEventArgs(this.rule.Id, this.rule.IsLoadedRuleOfEvalType));
            break;
        }
      }
      else
      {
        if (!this.ShowToolBar)
          return;
        this.rule.NameIsInvalid = false;
      }
    }

    protected override void OnPreRender(EventArgs e)
    {
      if (this.DesignMode)
        return;
      base.OnPreRender(e);
      if (this.Theme != ThemeType.None)
        this.AddStyleLink(new ThemeManager(this.Theme));
      Type type = this.Page.GetType();
      if (!this.Page.ClientScript.IsStartupScriptRegistered(typeof (Element).FullName))
        this.Page.ClientScript.RegisterStartupScript(type, typeof (Element).FullName, MarkupManager.RenderInitials(), true);
      Labels labels = (Labels) null;
      if (this.ShowHelpString && !this.Page.ClientScript.IsStartupScriptRegistered(type, "ceStartupHelpMessages"))
      {
        labels = new Labels(this.LoadHelpXml(), this.ShowToolBar, this.Mode);
        this.Page.ClientScript.RegisterStartupScript(type, "ceStartupHelpMessages", MarkupManager.RenderHelp(labels.GetUiMessages()), true);
      }
      if (!this.Page.ClientScript.IsStartupScriptRegistered(type, "ceStartupErrorMessages"))
      {
        if (labels == null)
          labels = new Labels(this.LoadHelpXml(), this.ShowToolBar, this.Mode);
        this.Page.ClientScript.RegisterStartupScript(type, "ceStartupErrorMessages", MarkupManager.RenderErrors(labels.GetErrorMessages()), true);
      }
      if (!this.Page.ClientScript.IsStartupScriptRegistered(type, "scrCodeEffectsControlStartUp" + this.ClientID))
      {
        string script = MarkupManager.RenderControlInstance(this.ID, this.ClientID, this.ClientOnly ? (string) null : this.hiddenField.ClientID, this.Page.Request.Browser.Platform.ToLower() == "winxp", true);
        if (!this.ClientOnly)
          script += MarkupManager.RenderSettings((CodeEffects.Rule.Models.IControl) this, this.GetConditions(), true);
        this.Page.ClientScript.RegisterStartupScript(type, "scrCodeEffectsControlStartUp" + this.ClientID, script, true);
      }
      StringBuilder stringBuilder = new StringBuilder();
      if (!this.ClientOnly && !this.IsEmpty)
      {
        RuleValidator.ForceTokens(this.rule.Elements);
        stringBuilder.Append(MarkupManager.RenderRuleDataForLoading(this.rule, this.ID));
        if (!this.IsValid)
          stringBuilder.Append(MarkupManager.RenderInvalidDataForLoading(this.rule, this.ID));
      }
      if (stringBuilder.Length > 0)
        this.Page.ClientScript.RegisterStartupScript(type, "scrCodeEffectsControlLoadInvalidStartUp" + this.ClientID, stringBuilder.ToString(), true);
      this.Clear();
    }

    public string GetSourceXml()
    {
      return this.GetSourceXmlDocument().OuterXml;
    }

    public string GetHelpXml()
    {
      return this.LoadHelpXml().OuterXml;
    }

    public string GetRuleXml()
    {
      return this.GetRuleXml(RuleFormatType.CodeEffects);
    }

    public string GetClientSettings()
    {
      return MarkupManager.RenderSettings((CodeEffects.Rule.Models.IControl) this, this.GetConditions(), false);
    }

    public string GetClientRuleData()
    {
      if (this.IsEmpty || !this.IsValid)
        return (string) null;
      return MarkupManager.RenderRuleClientData(this.rule);
    }

    public string GetClientInvalidData()
    {
      if (this.IsValid)
        return (string) null;
      return MarkupManager.RenderRuleInvalidClientData(this.rule);
    }

    public SaveEventArgs GetSaveArguments()
    {
      if (string.IsNullOrWhiteSpace(this.rule.Id))
        this.rule.Id = Guid.NewGuid().ToString();
      return this.GetSaveEventArgs();
    }

    public void LoadRuleFile(string ruleXmlFileFullPath)
    {
      this.LoadRuleFile(ruleXmlFileFullPath, this.GetRuleDelegate);
    }

    public void LoadRuleFile(string ruleXmlFileFullPath, GetRuleDelegate ruleDelegate)
    {
      if (!File.Exists(ruleXmlFileFullPath))
        throw new InvalidRuleException(InvalidRuleException.ErrorIds.XMLFileNotFound, new string[0]);
      XmlDocument xmlDocument = new XmlDocument();
      try
      {
        xmlDocument.Load(ruleXmlFileFullPath);
      }
      catch
      {
        throw new InvalidRuleException(InvalidRuleException.ErrorIds.XMLFileIsMalformed, new string[0]);
      }
      this.LoadRuleXml(xmlDocument.OuterXml, ruleDelegate);
    }

    public void LoadRuleXml(string ruleXml)
    {
      this.LoadRuleXml(ruleXml, this.GetRuleDelegate);
    }

    public void LoadRuleXml(string ruleXml, GetRuleDelegate ruleDelegate)
    {
      XmlDocument sourceXmlDocument = this.GetSourceXmlDocument();
      this.rule = RuleLoader.LoadXml(ruleXml, sourceXmlDocument, ruleDelegate);
      if (this.rule.Format != RuleFormatType.CodeEffects)
        throw new NotSupportedException("Old XML formats are not supported by this version of Code Effects control.");
      this.rule.IsLoadedRuleOfEvalType = new bool?(!RuleValidator.HasActions(this.rule.Elements));
      this.ValidateRule(this.rule.Elements);
    }

    public void LoadClientData(string ruleClientData)
    {
      if (string.IsNullOrEmpty(ruleClientData))
        return;
      this.rule = new JavaScriptSerializer().Deserialize<RuleModel>(ruleClientData);
      if (this.ShowToolBar)
      {
        if (this.rule.Name != null)
          this.rule.Name = CodeEffects.Rule.Core.Encoder.Desanitize(this.rule.Name);
        if (this.rule.Desc != null)
          this.rule.Desc = CodeEffects.Rule.Core.Encoder.Desanitize(this.rule.Desc);
      }
      if (this.rule.Elements.Count == 0)
        return;
      RuleValidator.EnsureTokens(this.rule.Elements, this.GetSourceXmlDocument());
      if (!string.IsNullOrWhiteSpace(this.rule.Command) && !(this.rule.Command == "ceExtract") && !(this.rule.Command == "ceSave"))
        return;
      this.ValidateRule(this.rule.Elements);
      if (!this.IsValid)
        return;
      RuleValidator.EnsureValues(this.rule.Elements);
    }

    public void ClearCache()
    {
      if (HttpContext.Current == null)
        return;
      string index1 = "appCodeEffectsRuleSourceXmlPath" + this.ID;
      string index2 = "appCodeEffectsRuleHelpXmlPath" + this.ID;
      HttpContext.Current.Application[index1] = (object) null;
      HttpContext.Current.Application[index2] = (object) null;
    }

    public void Clear()
    {
      this.rule = new RuleModel();
    }

    private string GetRuleXml(RuleFormatType format)
    {
      if (this.IsEmpty)
        return (string) null;
      if (!this.IsValid)
        throw new InvalidRuleException(InvalidRuleException.ErrorIds.RuleIsInvalid, new string[0]);
      List<Element> items = this.CopyElements(this.rule.Elements);
      XmlDocument sourceXmlDocument = this.GetSourceXmlDocument();
      string ruleName = this.ShowToolBar ? this.rule.Name : (string) null;
      string ruleDescription = this.ShowToolBar ? this.rule.Desc : (string) null;
      RuleValidator.EnsureIgnoredProperties(items, sourceXmlDocument);
      RuleValidator.EnsureValues(items);
      return RuleLoader.GetXml(items, string.IsNullOrWhiteSpace(this.rule.Id) ? Guid.NewGuid().ToString() : this.rule.Id, ruleName, ruleDescription, sourceXmlDocument, format, this.Mode, !this.rule.IsLoadedRuleOfEvalType.HasValue ? this.Mode == RuleType.Evaluation || this.Mode == RuleType.Filter : this.rule.IsLoadedRuleOfEvalType.Value);
    }

    private bool IsDemo()
    {
      return Vector.IsDemo(this.Page.Request.Url.Host, this.Page.Request.ServerVariables["SERVER_NAME"], this.Page.Request.IsLocal);
    }

    private List<Element> CopyElements(List<Element> elements)
    {
      return elements.Where<Element>((Func<Element, bool>) (el => el.FuncType != FunctionType.Comma)).Select<Element, Element>((Func<Element, Element>) (el => el.Clone())).ToList<Element>();
    }

    private MarkupData GetConditions()
    {
      MarkupData markupData1 = new MarkupData();
      markupData1.Pattern = Pattern.Asp;
      markupData1.ControlServerID = this.ID;
      if (!this.ClientOnly)
        markupData1.PostBackFunctionName = this.Page.ClientScript.GetPostBackEventReference((Control) this, string.Empty);
      if (!this.rule.IsLoadedRuleOfEvalType.HasValue)
      {
        markupData1.IsLoadedRuleOfEvalType = this.Mode == RuleType.Evaluation || this.Mode == RuleType.Filter;
      }
      else
      {
        MarkupData markupData2 = markupData1;
        bool? loadedRuleOfEvalType = this.rule.IsLoadedRuleOfEvalType;
        int num = !loadedRuleOfEvalType.GetValueOrDefault() ? 0 : (loadedRuleOfEvalType.HasValue ? 1 : 0);
        markupData2.IsLoadedRuleOfEvalType = num != 0;
      }
      markupData1.Mode = this.Mode;
      if (this.Theme != ThemeType.None)
        markupData1.ThemeFactory = new ThemeManager(this.Theme);
      Settings settings = new Settings(this.LoadHelpXml(), this.ToolBarRules, this.ShowToolBar, this.Mode);
      settings.Load((CodeEffects.Rule.Models.IControl) this, this.ContextMenuRules, this.GetSourceXmlDocument(), this.DataSources);
      markupData1.Settings = settings;
      return markupData1;
    }

    private XmlDocument GetSourceXmlDocument()
    {
      if (this.SourceXml != null)
        return this.SourceXml;
      if (this.Source != (Type) null || !string.IsNullOrEmpty(this.SourceType))
      {
        string index = "appCodeEffectsRuleSourceXmlPath" + (this.Source == (Type) null ? this.SourceType : this.Source.FullName);
        if (HttpContext.Current != null && HttpContext.Current.Application[index] != null)
          return (XmlDocument) HttpContext.Current.Application[index];
        List<Type> processedTypes = new List<Type>();
        XmlDocument xmlDocument = !(this.Source != (Type) null) ? SourceLoader.GetXml(this.SourceAssembly, this.SourceType, processedTypes) : SourceLoader.GetXml(this.Source, processedTypes);
        if (HttpContext.Current != null && this.CacheSource)
          HttpContext.Current.Application[index] = (object) xmlDocument;
        return xmlDocument;
      }
      if (string.IsNullOrEmpty(this.SourceXmlFile))
        throw new SourceException(SourceException.ErrorIds.FailureToLoadSourceXML, new string[0]);
      string cacheKey = "appCodeEffectsRuleSourceXmlPath" + this.SourceXmlFile;
      try
      {
        return this.GetCachedXmlFile(cacheKey, this.SourceXmlFile, this.CacheSource);
      }
      catch
      {
        throw new MalformedXmlException(MalformedXmlException.ErrorIds.MalformedOrMissingSourceXML, new string[0]);
      }
    }

    private XmlDocument LoadHelpXml()
    {
      if (this.HelpXml != null)
        return this.HelpXml;
      if (string.IsNullOrEmpty(this.HelpXmlFile))
      {
        XmlDocument xmlDocument = new XmlDocument();
        string xml = this.Mode == RuleType.Filter ? Resource.FilterHelp : Resource.RuleHelp;
        xmlDocument.LoadXml(xml);
        return xmlDocument;
      }
      try
      {
        return this.GetCachedXmlFile("appCodeEffectsRuleHelpXmlPath" + this.ID, this.HelpXmlFile, this.CacheHelp);
      }
      catch (Exception ex)
      {
        throw new MalformedXmlException(MalformedXmlException.ErrorIds.MalformedOrMissingHelpXML, new string[1]{ ex.Message });
      }
    }

    private SaveEventArgs GetSaveEventArgs()
    {
      XmlDocument xmlDocument = new XmlDocument();
      xmlDocument.LoadXml(this.GetRuleXml());
      XmlNode firstChild = xmlDocument.DocumentElement.FirstChild;
      List<string> list = this.rule.Elements.Where<Element>((Func<Element, bool>) (el =>
      {
        if (el.Type == ElementType.Field)
          return el.IsRule;
        return false;
      })).Select<Element, string>((Func<Element, string>) (el => el.Value)).Distinct<string>().ToList<string>();
      return new SaveEventArgs()
      {
        IsEvaluationTypeRule = this.rule.IsLoadedRuleOfEvalType.Value,
        RuleID = this.rule.Id,
        RuleXmlAsDocument = xmlDocument.OuterXml,
        RuleXmlAsNode = firstChild.OuterXml,
        RuleDescription = this.rule.Desc,
        RuleName = this.rule.Name,
        ReferencedRules = list.Count > 0 ? list : (List<string>) null
      };
    }

    private XmlDocument GetCachedXmlFile(string cacheKey, string xmlPath, bool storeInCache)
    {
      if (HttpContext.Current != null && HttpContext.Current.Application[cacheKey] != null)
        return (XmlDocument) HttpContext.Current.Application[cacheKey];
      XmlDocument xmlDocument = new XmlDocument();
      xmlDocument.Load(xmlPath);
      if (storeInCache && HttpContext.Current != null)
        HttpContext.Current.Application[cacheKey] = (object) xmlDocument;
      return xmlDocument;
    }

    private void AddStyleLink(ThemeManager themeManager)
    {
      string styleTagId = themeManager.StyleTagID;
      Literal literal = new Literal();
      literal.ID = styleTagId;
      literal.EnableViewState = false;
      literal.Text = string.Format("<link {0}=\"true\" rel=\"stylesheet\" type=\"text/css\"{1}></link>", (object) themeManager.StyleTagAttribute, this.ClientOnly ? (object) string.Empty : (object) (" href=\"" + themeManager.GetLinkUrl() + "\""));
      if (this.Page.Header != null)
      {
        if (this.Page.Header.FindControl(styleTagId) != null)
          return;
        this.Page.Header.Controls.Add((Control) literal);
      }
      else
      {
        if (this.Page.FindControl(styleTagId) != null)
          return;
        this.Controls.Add((Control) literal);
      }
    }

    private void ResetValidation()
    {
      this.rule.InvalidElements = new List<InvalidElement>();
      this.rule.NameIsInvalid = false;
    }

    private void ValidateRule(List<Element> elements)
    {
      XmlDocument help = this.LoadHelpXml();
      List<InvalidElement> invalidElementList = RuleValidator.Validate(help, elements, this.GetSourceXmlDocument(), this.rule.IsLoadedRuleOfEvalType.GetValueOrDefault());
      if (invalidElementList.Count > 0)
        this.rule.InvalidElements = invalidElementList;
      else if (this.GetRuleDelegate != null)
        invalidElementList = RuleValidator.CheckRecursion(elements, this.GetRuleXml(), help, this.GetRuleDelegate);
      if (invalidElementList.Count > 0)
        this.rule.InvalidElements = invalidElementList;
      else if (this.ShowToolBar && this.RuleNameIsRequired && string.IsNullOrWhiteSpace(this.rule.Name))
      {
        this.rule.NameIsInvalid = true;
      }
      else
      {
        this.rule.InvalidElements = new List<InvalidElement>();
        this.rule.NameIsInvalid = false;
      }
      if (!string.IsNullOrWhiteSpace(this.rule.Desc))
        return;
      this.rule.Desc = (string) null;
    }
  }
}
