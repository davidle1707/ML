﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Asp.RuleEventArgs
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using System;

namespace CodeEffects.Rule.Asp
{
  public class RuleEventArgs : EventArgs
  {
    public string RuleID { get; set; }

    public bool? IsEvaluationTypeRule { get; set; }

    public RuleEventArgs(string id, bool? isEval)
    {
      this.RuleID = id;
      this.IsEvaluationTypeRule = isEval;
    }
  }
}
