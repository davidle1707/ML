﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Asp.RuleEditorDesigner
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using System;
using System.Web.UI.Design;

namespace CodeEffects.Rule.Asp
{
  internal class RuleEditorDesigner : ControlDesigner
  {
    private string html = "<div><span style=\"color: Gray\">Rule authoring is not available at design-time.<span></div>";

    public override string GetDesignTimeHtml()
    {
      return this.html;
    }

    protected override string GetErrorDesignTimeHtml(Exception e)
    {
      return this.html;
    }

    protected override string GetEmptyDesignTimeHtml()
    {
      return this.html;
    }
  }
}
