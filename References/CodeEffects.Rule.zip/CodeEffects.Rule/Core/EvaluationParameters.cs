﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Core.EvaluationParameters
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

namespace CodeEffects.Rule.Core
{
  public class EvaluationParameters
  {
    public bool PerformNullChecks = true;
    public int MaxIterations = -1;
    public bool ShortCircuit = true;
    public string RuleId;
    public GetRuleDelegate RuleGetter;
    public LinqProviderType LINQProviderType;
    public EvaluationScope Scope;
  }
}
