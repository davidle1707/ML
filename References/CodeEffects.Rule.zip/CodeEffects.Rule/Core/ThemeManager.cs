﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Core.ThemeManager
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using CodeEffects.Rule.Asp;
using CodeEffects.Rule.Common;
using System.Web.UI;

namespace CodeEffects.Rule.Core
{
  internal sealed class ThemeManager
  {
    private ThemeType theme;

    internal string StyleTagAttribute
    {
      get
      {
        return "ce008";
      }
    }

    internal string StyleTagID
    {
      get
      {
        return "ce003" + this.theme.ToString();
      }
    }

    public ThemeManager(ThemeType theme)
    {
      this.theme = theme;
    }

    internal string GetLinkUrl()
    {
      return new Page().ClientScript.GetWebResourceUrl(typeof (RuleEditor), Converter.ThemeTypeToResourceName(this.theme));
    }
  }
}
