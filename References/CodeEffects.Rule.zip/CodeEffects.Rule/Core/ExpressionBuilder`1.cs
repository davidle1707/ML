﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Core.ExpressionBuilder`1
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using System;
using System.Linq.Expressions;
using System.Xml.Linq;

namespace CodeEffects.Rule.Core
{
  internal class ExpressionBuilder<TSource> : ExpressionBuilderBase
  {
    public ExpressionBuilder(GetRuleInternalDelegate getRule)
      : base(typeof (TSource), getRule)
    {
    }

    internal Expression<Func<TSource, bool>> GetPredicateExpression(XElement rule)
    {
      return Expression.Lambda<Func<TSource, bool>>(this.GetSafeExpressionBody(rule, false), new ParameterExpression[1]{ this.source });
    }

    internal Func<TSource, bool> CompileRule(XElement rule)
    {
      return this.GetPredicateExpression(rule).Compile();
    }

    internal Func<TSource, bool> CompileRule(Expression<Func<TSource, bool>> ruleExpression)
    {
      return ruleExpression.Compile();
    }
  }
}
