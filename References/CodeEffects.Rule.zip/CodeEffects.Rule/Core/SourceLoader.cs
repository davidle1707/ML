﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Core.SourceLoader
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using CodeEffects.Rule.Attributes;
using CodeEffects.Rule.Common;
using CodeEffects.Rule.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Xml;

namespace CodeEffects.Rule.Core
{
  internal sealed class SourceLoader
  {
    private SourceLoader()
    {
    }

    internal static XmlDocument GetXml(string assembly, string type, List<Type> processedTypes)
    {
      return SourceLoader.GetXml(SourceLoader.LoadType(assembly, type, SourceException.ErrorIds.FailureToLoadSourceXML, SourceException.ErrorIds.AssemlbyDoesNotDeclareSourceType), processedTypes);
    }

    internal static XmlDocument GetXml(Type type, List<Type> processedTypes)
    {
      XmlDocument emptySourceDocument = CodeEffects.Rule.Common.Xml.GetEmptySourceDocument();
      SourceLoader.Extract(emptySourceDocument, type, processedTypes);
      return emptySourceDocument;
    }

    internal static string GetTokenByRuleMethodNode(XmlNode source, XmlNode method, bool isMethod)
    {
      string methodName = method.Attributes["name"].Value;
      Type sourceObject = SourceLoader.GetSourceObject(source);
      Type type = method.Attributes["type"] == null ? sourceObject : Type.GetType(method.Attributes["type"].Value);
      return SourceLoader.GetTokenByMethod(source, type, sourceObject, methodName, method.ChildNodes, isMethod);
    }

    internal static string GetTokenBySourceMethodNode(XmlNode source, XmlNode method)
    {
      string methodName = method.Attributes["methodName"].Value;
      Type sourceObject = SourceLoader.GetSourceObject(source);
      Type type = method.Attributes["class"] == null ? sourceObject : (method.Attributes["assembly"] == null ? Type.GetType(method.Attributes["class"].Value) : Type.GetType(method.Attributes["class"].Value + ", " + method.Attributes["assembly"].Value));
      return SourceLoader.GetTokenByMethod(source, type, sourceObject, methodName, SourceLoader.GetParamNode(method).ChildNodes, method.ChildNodes.Count > 1);
    }

    internal static XmlNode GetActionByToken(XmlNode source, string token)
    {
      return SourceLoader.GetMethodByToken(source, token, false, MalformedXmlException.ErrorIds.MissingActionsNode);
    }

    internal static XmlNode GetFunctionByToken(XmlNode source, string token)
    {
      return SourceLoader.GetMethodByToken(source, token, true, MalformedXmlException.ErrorIds.MissingFieldsNode);
    }

    internal static XmlNode GetFieldByPropertyName(XmlNode source, string propertyName)
    {
      XmlNode xmlNode = source.SelectSingleNode(string.Format("{0}:fields", (object) "s"), CodeEffects.Rule.Common.Xml.GetSourceNamespaceManager(source));
      if (xmlNode == null || xmlNode.ChildNodes.Count == 0)
        throw new MalformedXmlException(MalformedXmlException.ErrorIds.MissingFieldsNode, new string[0]);
      foreach (XmlNode childNode in xmlNode.ChildNodes)
      {
        if (childNode.Attributes["propertyName"] != null && childNode.Attributes["propertyName"].Value == propertyName)
          return childNode;
      }
      throw new MalformedXmlException(MalformedXmlException.ErrorIds.MissingFieldsWithPropertyName, new string[1]{ propertyName });
    }

    internal static XmlNode GetParamNode(XmlNode function)
    {
      if (function == null)
        return (XmlNode) null;
      foreach (XmlNode childNode in function.ChildNodes)
      {
        if (childNode.Name == "parameters")
          return childNode;
      }
      return (XmlNode) null;
    }

    internal static XmlNode GetReturnNode(XmlNode function)
    {
      foreach (XmlNode childNode in function.ChildNodes)
      {
        if (childNode.Name == "returns")
          return childNode;
      }
      throw new MalformedXmlException(MalformedXmlException.ErrorIds.TooManyOrMissingReturn, new string[0]);
    }

    internal static XmlDocument LoadSourceXml(string sourceAssembly, string sourceType, string sourceXmlFile, List<Type> processedTypes)
    {
      if (!string.IsNullOrEmpty(sourceType))
        return SourceLoader.GetXml(sourceAssembly, sourceType, processedTypes);
      if (string.IsNullOrEmpty(sourceXmlFile))
        throw new SourceException(SourceException.ErrorIds.FailureToLoadSourceXML, new string[0]);
      try
      {
        XmlDocument xmlDocument = new XmlDocument();
        xmlDocument.Load(sourceXmlFile);
        return xmlDocument;
      }
      catch
      {
        throw new MalformedXmlException(MalformedXmlException.ErrorIds.MalformedOrMissingSourceXML, new string[0]);
      }
    }

    internal static List<DataSource> GetDataSources(XmlDocument sourceXml)
    {
      List<DataSource> source = new List<DataSource>();
      foreach (XmlNode childNode1 in sourceXml.DocumentElement.ChildNodes)
      {
        XmlNode xmlNode = childNode1.SelectSingleNode(string.Format("{0}:dataSources", (object) "s"), CodeEffects.Rule.Common.Xml.GetSourceNamespaceManager(sourceXml));
        if (xmlNode != null && xmlNode.ChildNodes.Count > 0)
        {
          foreach (XmlNode childNode2 in xmlNode.ChildNodes)
          {
            DataSource d = new DataSource();
            d.Name = childNode2.Attributes["name"].Value;
            if (source.Any<DataSource>((Func<DataSource, bool>) (s => s.Name == d.Name)))
              throw new SourceException(SourceException.ErrorIds.MultipleDynamicMenuDataSources, new string[0]);
            d.Location = Converter.StringToFeatureLocation(childNode2.Attributes["location"].Value);
            d.Method = childNode2.Attributes["methodName"].Value;
            if (d.Location != FeatureLocation.Client)
            {
              d.Assembly = childNode2.Attributes["assembly"].Value;
              d.Class = childNode2.Attributes["class"].Value;
            }
            source.Add(d);
          }
        }
      }
      return source;
    }

    internal static XmlNode GetSourceNode(XmlDocument sourceXml, string sourceName)
    {
      foreach (XmlNode childNode in sourceXml.DocumentElement.ChildNodes)
      {
        if (sourceName == null || childNode.Attributes["name"] == null || childNode.Attributes["name"].Value == sourceName)
          return childNode;
      }
      return (XmlNode) null;
    }

    internal static XmlNode GetSourceNodeByToken(XmlDocument sourceXml, string token)
    {
      foreach (XmlNode childNode in sourceXml.DocumentElement.ChildNodes)
      {
        if (token == null || childNode.Attributes["name"] == null || Encoder.GetHashToken(childNode.Attributes["name"].Value) == token)
          return childNode;
      }
      return (XmlNode) null;
    }

    private static void Extract(XmlDocument source, Type type, List<Type> processedTypes)
    {
      if (processedTypes.Contains(type))
        return;
      processedTypes.Add(type);
      foreach (XmlNode childNode in source.DocumentElement.ChildNodes)
      {
        if (childNode.Attributes["name"] != null && childNode.Attributes["name"].Value == type.FullName)
          return;
      }
      XmlElement element1 = source.CreateElement("source", "http://codeeffects.com/schemas/source/42");
      XmlElement element2 = source.CreateElement("fields", "http://codeeffects.com/schemas/source/42");
      XmlElement element3 = source.CreateElement("actions", "http://codeeffects.com/schemas/source/42");
      XmlElement element4 = source.CreateElement("dataSources", "http://codeeffects.com/schemas/source/42");
      element1.SetAttribute("name", type.FullName);
      element1.SetAttribute("webrule", Assembly.GetExecutingAssembly().GetName().Version.ToString());
      element1.SetAttribute("utc", DateTime.Now.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.ffff"));
      element1.SetAttribute("type", type.AssemblyQualifiedName);
      object[] customAttributes = type.GetCustomAttributes(true);
      SourceState state = SourceLoader.ManageSourceAttribute(customAttributes);
      element1.SetAttribute("persisted", state.Persisted ? "true" : "false");
      Dictionary<string, XmlElement> dictionary1 = new Dictionary<string, XmlElement>();
      Dictionary<string, XmlElement> dictionary2 = new Dictionary<string, XmlElement>();
      Dictionary<string, XmlElement> parent = new Dictionary<string, XmlElement>();
      foreach (object obj in customAttributes)
      {
        if (obj is ExternalMethodAttribute)
          SourceLoader.ManageExternalMethodAttribute((IExternalAttribute) obj, source, (IDictionary<string, XmlElement>) dictionary1, type, processedTypes);
        else if (obj is ExternalActionAttribute)
          SourceLoader.ManageExternalMethodAttribute((IExternalAttribute) obj, source, (IDictionary<string, XmlElement>) dictionary2, type, processedTypes);
        else if (obj is DataAttribute)
          SourceLoader.ManageDataAttribute((DataAttribute) obj, source, parent);
      }
      SourceLoader.ManageProperties(type, (string) null, (string) null, source, (IDictionary<string, XmlElement>) dictionary1, 1, state, processedTypes);
      SourceLoader.ManageMethods(type, source, (IDictionary<string, XmlElement>) dictionary1, (IDictionary<string, XmlElement>) dictionary2, state, processedTypes);
      if (dictionary1.Count == 0)
        throw new SourceException(SourceException.ErrorIds.MissingPublicValueTypeFields, new string[1]{ type.FullName });
      foreach (string key in dictionary1.Keys)
        element2.AppendChild((XmlNode) dictionary1[key]);
      dictionary1.Clear();
      element1.AppendChild((XmlNode) element2);
      if (dictionary2.Count > 0)
      {
        foreach (string key in dictionary2.Keys)
          element3.AppendChild((XmlNode) dictionary2[key]);
        dictionary2.Clear();
        element1.AppendChild((XmlNode) element3);
      }
      if (parent.Count > 0)
      {
        foreach (string key in parent.Keys)
          element4.AppendChild((XmlNode) parent[key]);
        parent.Clear();
        element1.AppendChild((XmlNode) element4);
      }
      source.DocumentElement.PrependChild((XmlNode) element1);
    }

    private static SourceState ManageSourceAttribute(object[] attributes)
    {
      SourceState sourceState = new SourceState();
      object attribute = SourceLoader.GetAttribute<SourceAttribute>(attributes);
      SourceAttribute sourceAttribute = attribute != null ? (SourceAttribute) attribute : new SourceAttribute();
      sourceState.MaxLevel = sourceAttribute.MaxTypeNestingLevel;
      sourceState.DeclaredMembersOnly = sourceAttribute.DeclaredMembersOnly;
      sourceState.Persisted = sourceAttribute.PersistTypeNameInRuleXml;
      return sourceState;
    }

    private static void ManageMethods(Type type, XmlDocument doc, IDictionary<string, XmlElement> fields, IDictionary<string, XmlElement> actions, SourceState state, List<Type> processedTypes)
    {
      Type[] interfaces = type.GetInterfaces();
      foreach (MethodInfo method in SourceLoader.GetMethods(type, state))
      {
        if (!method.IsSpecialName)
        {
          Type[] methodParameterTypes = SourceLoader.GetMethodParameterTypes(method);
          if (method.GetCustomAttributes(typeof (ExcludeFromEvaluationAttribute), true).Length == 0 && !SourceLoader.IsMethodExcludedInInterface(interfaces, method.Name, methodParameterTypes))
          {
            object[] customAttributes = method.GetCustomAttributes(false);
            IDescribableAttribute attr = (IDescribableAttribute) null;
            foreach (object obj in customAttributes)
            {
              if (obj is MethodAttribute || obj is ActionAttribute)
              {
                attr = (IDescribableAttribute) obj;
                break;
              }
            }
            if (attr == null)
              attr = SourceLoader.GetInterfaceDescribableAttribute(interfaces, method.Name, methodParameterTypes);
            if (attr == null)
            {
              bool flag = method.ReturnType == typeof (void);
              if (SourceValidator.IsMethodValid(method, !flag))
              {
                if (flag)
                  SourceLoader.ManageMethod(method, (IDescribableAttribute) null, doc, actions, type, false, processedTypes);
                else if (method.ReturnType.IsValueType || method.ReturnType == typeof (string))
                  SourceLoader.ManageMethod(method, (IDescribableAttribute) null, doc, fields, type, true, processedTypes);
              }
            }
            else
            {
              bool checkReturn = attr is MethodAttribute;
              if (!SourceValidator.IsMethodValid(method, checkReturn))
                throw new SourceException(SourceException.ErrorIds.MethodIsDecoratedButInvalid, new string[1]{ method.Name });
              if (checkReturn)
                SourceLoader.ManageMethod(method, attr, doc, fields, type, true, processedTypes);
              else
                SourceLoader.ManageMethod(method, attr, doc, actions, type, false, processedTypes);
            }
          }
        }
      }
    }

    private static void ManageMethod(MethodInfo m, IDescribableAttribute attr, XmlDocument doc, IDictionary<string, XmlElement> parent, Type sourceType, bool isMethod, List<Type> processedTypes)
    {
      XmlElement element1 = doc.CreateElement(isMethod ? "function" : "action", "http://codeeffects.com/schemas/source/42");
      element1.SetAttribute("methodName", m.Name);
      element1.SetAttribute("displayName", attr == null || string.IsNullOrEmpty(attr.DisplayName) ? m.Name : Encoder.Sanitize(attr.DisplayName));
      if (attr != null && !string.IsNullOrWhiteSpace(attr.Description))
        element1.SetAttribute("description", Encoder.Sanitize(attr.Description));
      if (isMethod)
      {
        if (attr != null)
        {
          bool nullable = false;
          bool sourceable = false;
          if (SourceLoader.GetClientType(m.ReturnType, out nullable, out sourceable) == SourceLoader.ClientType.Numeric)
            element1.SetAttribute("includeInCalculations", ((MethodAttribute) attr).IncludeInCalculations ? "true" : "false");
        }
        else
          element1.SetAttribute("includeInCalculations", "true");
      }
      XmlElement element2 = doc.CreateElement("parameters", "http://codeeffects.com/schemas/source/42");
      element1.AppendChild((XmlNode) element2);
      if (!SourceLoader.ManageParameters(m.GetParameters(), doc, element2, m, sourceType, attr != null, processedTypes))
        return;
      if (isMethod)
      {
        XmlElement element3 = doc.CreateElement("returns", "http://codeeffects.com/schemas/source/42");
        element1.AppendChild((XmlNode) element3);
        try
        {
          SourceLoader.ManageReturn(m, element3);
        }
        catch (SourceException ex)
        {
          if (attr == null)
            return;
          throw;
        }
      }
      try
      {
        parent.Add(attr == null || string.IsNullOrEmpty(attr.DisplayName) ? m.Name : Encoder.Sanitize(attr.DisplayName), element1);
      }
      catch (ArgumentException ex)
      {
        if (attr != null)
          throw new SourceException(SourceException.ErrorIds.MethodHasOverloads, new string[1]{ m.Name });
      }
    }

    private static void ManageExternalMethodAttribute(IExternalAttribute attr, XmlDocument doc, IDictionary<string, XmlElement> parent, Type sourceType, List<Type> processedTypes)
    {
      bool checkReturn = attr is ExternalMethodAttribute;
      Type type = !(attr.Type == (Type) null) ? attr.Type : SourceLoader.LoadType(attr.Assembly, attr.TypeName, SourceException.ErrorIds.AssemblyNameIsEmpty, SourceException.ErrorIds.AssemblyDoesNotContainType);
      Type[] interfaces = type.GetInterfaces();
      foreach (MethodInfo method in SourceLoader.GetMethods(type))
      {
        if (!(method.Name != attr.Method) && method.GetCustomAttributes(typeof (ExcludeFromEvaluationAttribute), true).Length == 0 && (!SourceLoader.IsMethodExcludedInInterface(interfaces, method.Name, SourceLoader.GetMethodParameterTypes(method)) && SourceValidator.IsMethodValid(method, checkReturn)))
        {
          IDescribableAttribute describableAttribute = (IDescribableAttribute) null;
          string str1 = (string) null;
          object[] objArray = !checkReturn ? method.GetCustomAttributes(typeof (ActionAttribute), false) : method.GetCustomAttributes(typeof (MethodAttribute), false);
          string str2;
          if (objArray.Length > 0)
          {
            describableAttribute = (IDescribableAttribute) objArray[0];
            str2 = describableAttribute.DisplayName;
            str1 = describableAttribute.Description;
          }
          else
            str2 = attr.Method;
          XmlElement element1 = doc.CreateElement(checkReturn ? "function" : "action", "http://codeeffects.com/schemas/source/42");
          element1.SetAttribute("methodName", attr.Method);
          element1.SetAttribute("displayName", Encoder.Sanitize(str2));
          if (!string.IsNullOrWhiteSpace(str1))
            element1.SetAttribute("description", Encoder.Sanitize(str1));
          if (attr.Type == (Type) null)
          {
            element1.SetAttribute("class", attr.TypeName);
            element1.SetAttribute("assembly", attr.Assembly);
          }
          else
          {
            element1.SetAttribute("class", attr.Type.FullName);
            element1.SetAttribute("assembly", Assembly.GetAssembly(attr.Type).FullName);
          }
          XmlElement element2 = doc.CreateElement("parameters", "http://codeeffects.com/schemas/source/42");
          element1.AppendChild((XmlNode) element2);
          if (!SourceLoader.ManageParameters(method.GetParameters(), doc, element2, method, sourceType, describableAttribute != null, processedTypes))
            break;
          if (checkReturn)
          {
            XmlElement element3 = doc.CreateElement("returns", "http://codeeffects.com/schemas/source/42");
            element1.AppendChild((XmlNode) element3);
            try
            {
              SourceLoader.ManageReturn(method, element3);
            }
            catch (SourceException ex)
            {
              if (describableAttribute == null)
                break;
              throw;
            }
          }
          try
          {
            parent.Add(str2, element1);
          }
          catch (ArgumentException ex)
          {
            if (describableAttribute != null)
              throw new SourceException(SourceException.ErrorIds.ExternalMethodHasOverloads, new string[1]{ method.Name });
          }
        }
      }
    }

    private static void ManageDataAttribute(DataAttribute attr, XmlDocument doc, Dictionary<string, XmlElement> parent)
    {
      XmlElement element = doc.CreateElement("dataSource", "http://codeeffects.com/schemas/source/42");
      element.SetAttribute("name", attr.Name);
      element.SetAttribute("methodName", attr.Method);
      element.SetAttribute("location", Converter.FeatureLocationToString(attr.Location));
      if (attr.Location != FeatureLocation.Client)
      {
        Type type = !(attr.Type == (Type) null) ? attr.Type : SourceLoader.LoadType(attr.Assembly, attr.TypeName, SourceException.ErrorIds.AssemblyNameIsEmpty, SourceException.ErrorIds.AssemblyDoesNotContainType);
        Type[] interfaces = type.GetInterfaces();
        List<MethodInfo> methods = SourceLoader.GetMethods(type);
        bool flag = false;
        foreach (MethodInfo m in methods)
        {
          if (!(m.Name != attr.Method) && m.GetCustomAttributes(typeof (ExcludeFromEvaluationAttribute), true).Length == 0 && (!SourceLoader.IsMethodExcludedInInterface(interfaces, m.Name, SourceLoader.GetMethodParameterTypes(m)) && SourceValidator.IsDataSourceMethodValid(m)))
          {
            element.SetAttribute("class", type.FullName);
            element.SetAttribute("assembly", Assembly.GetAssembly(type).FullName);
            flag = true;
          }
        }
        if (!flag)
          throw new SourceException(SourceException.ErrorIds.InvalidDataSourceMethod, new string[2]{ type.FullName, attr.Method });
      }
      try
      {
        parent.Add(attr.Name, element);
      }
      catch (ArgumentException ex)
      {
        throw new SourceException(SourceException.ErrorIds.DuplicateDataAttributes, new string[1]{ attr.Name });
      }
    }

    private static void ManageProperties(Type type, string name, string parent, XmlDocument doc, IDictionary<string, XmlElement> fields, int level, SourceState state, List<Type> processedTypes)
    {
      Type[] interfaces1 = type.GetInterfaces();
      BindingFlags bindingAttr = state.DeclaredMembersOnly ? BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Public : BindingFlags.Instance | BindingFlags.Public;
      FieldInfo[] fields1 = type.GetFields(bindingAttr);
      PropertyInfo[] properties = type.GetProperties(bindingAttr);
      Dictionary<string, SourceLoader.Member> dictionary = new Dictionary<string, SourceLoader.Member>(fields1.Length + properties.Length);
      int num = 0;
      foreach (FieldInfo fieldInfo in fields1)
        dictionary.Add((++num).ToString(), new SourceLoader.Member((MemberInfo) fieldInfo, fieldInfo.FieldType, !fieldInfo.IsLiteral && !fieldInfo.IsInitOnly && !SourceLoader.IsReadOnly((MemberInfo) fieldInfo)));
      foreach (PropertyInfo propertyInfo in properties)
      {
        if (propertyInfo.GetGetMethod() != (MethodInfo) null)
          dictionary.Add((++num).ToString(), new SourceLoader.Member((MemberInfo) propertyInfo, propertyInfo.PropertyType, propertyInfo.GetSetMethod() != (MethodInfo) null && !SourceLoader.IsReadOnly((MemberInfo) propertyInfo)));
      }
      foreach (string key in dictionary.Keys)
      {
        Type type1 = dictionary[key].Type;
        Type[] interfaces2 = type1.GetInterfaces();
        if (!((IEnumerable<Type>) interfaces2).Contains<Type>(typeof (IDictionary)))
        {
          bool flag = ((IEnumerable<Type>) interfaces2).Contains<Type>(typeof (IEnumerable));
          if (!(type1 == typeof (object)) && !(type1 == typeof (Guid)) && (type1.IsValueType || !type1.IsGenericType || flag) && (!type1.IsGenericTypeDefinition && !type1.IsImport && (!type1.IsAbstract || flag) && ((!type1.IsInterface || flag) && (!type1.IsMarshalByRef && !type1.IsSpecialName))))
          {
            MemberInfo info = dictionary[key].Info;
            XmlElement el = (XmlElement) null;
            if ((info.MemberType == MemberTypes.Property || info.MemberType == MemberTypes.Field) && (info.GetCustomAttributes(typeof (ExcludeFromEvaluationAttribute), true).Length == 0 && !SourceLoader.IsPropertyExcludedInInterface(interfaces1, info.Name)))
            {
              if (flag && type1 != typeof (string))
              {
                el = doc.CreateElement("collection", "http://codeeffects.com/schemas/source/42");
                el.SetAttribute("propertyName", SourceLoader.BuildName(info, name));
                FieldAttribute fieldAttribute = SourceLoader.GetFieldAttribute(info, interfaces1);
                SourceLoader.SetDisplayName(info, el, fieldAttribute, (string) null, name, (string) null);
                string str = el.Attributes["displayName"].Value;
                XmlElement xmlElement = SourceLoader.BuildItemElement(doc, type1, (ISettingsAttribute) fieldAttribute, str, false, processedTypes);
                if (xmlElement != null)
                {
                  el.SetAttribute("generic", type1.IsGenericType ? "true" : "false");
                  el.SetAttribute("array", type1.IsArray ? "true" : "false");
                  el.SetAttribute("class", type1.FullName);
                  if (xmlElement.Name == "value")
                  {
                    if (fieldAttribute != null)
                      el.SetAttribute("valueInputType", Converter.ValueInputTypeToString(fieldAttribute.ValueInputType));
                    else
                      el.SetAttribute("valueInputType", Converter.ValueInputTypeToString(CodeEffects.Rule.Common.ValueInputType.All));
                  }
                  if (!type1.IsArray && type1.IsGenericType)
                    el.SetAttribute("comparisonName", SourceLoader.GetComparisonName(type1));
                  else
                    el.SetAttribute("comparisonName", type1.FullName);
                  el.AppendChild((XmlNode) xmlElement);
                  try
                  {
                    fields.Add(str, el);
                  }
                  catch (ArgumentException ex)
                  {
                  }
                }
                else
                  continue;
              }
              else
              {
                bool nullable = false;
                bool sourceable = false;
                bool settable = dictionary[key].Settable;
                FieldAttribute fieldAttribute = SourceLoader.GetFieldAttribute(info, interfaces1);
                if (settable && fieldAttribute != null && !fieldAttribute.Settable)
                  settable = false;
                SourceLoader.ClientType clientType = SourceLoader.GetClientType(type1, out nullable, out sourceable);
                if (clientType != SourceLoader.ClientType.Other)
                {
                  string parentName = (string) null;
                  string parentDescription = (string) null;
                  if (parent != null)
                  {
                    object[] objArray = info.GetCustomAttributes(typeof (ParentAttribute), true);
                    if (objArray == null || objArray.Length == 0)
                      objArray = SourceLoader.GetInterfaceParentAttributes(interfaces1, info.Name);
                    if (objArray != null && objArray.Length > 0)
                    {
                      foreach (ParentAttribute parentAttribute in objArray)
                      {
                        if (parentAttribute.ParentName.Contains(parent))
                        {
                          parentName = parentAttribute.DisplayName;
                          if (!string.IsNullOrWhiteSpace(parentAttribute.Description))
                          {
                            parentDescription = parentAttribute.Description;
                            break;
                          }
                          break;
                        }
                      }
                    }
                  }
                  switch (clientType)
                  {
                    case SourceLoader.ClientType.Enum:
                      el = SourceLoader.GetPropertyElement(doc, "enum", type1, fieldAttribute, SourceLoader.BuildName(info, name), false, settable);
                      SourceLoader.SetDisplayName(info, el, fieldAttribute, parentName, name, parentDescription);
                      el.SetAttribute("assembly", Assembly.GetAssembly(type1).FullName);
                      break;
                    case SourceLoader.ClientType.Numeric:
                      el = SourceLoader.GetPropertyElement(doc, "numeric", type1, fieldAttribute, SourceLoader.BuildName(info, name), nullable, settable);
                      SourceLoader.SetDisplayName(info, el, fieldAttribute, parentName, name, parentDescription);
                      if (fieldAttribute != null)
                        el.SetAttribute("allowCalculation", fieldAttribute.AllowCalculations ? "true" : "false");
                      else
                        el.SetAttribute("allowCalculation", "true");
                      if (fieldAttribute != null)
                        el.SetAttribute("includeInCalculations", fieldAttribute.IncludeInCalculations ? "true" : "false");
                      else
                        el.SetAttribute("includeInCalculations", "true");
                      el.SetAttribute("allowDecimal", nullable ? SourceLoader.GetNullableDecimalByNumeric(type1) : SourceLoader.GetDecimalByNumeric(type1.Name.ToLower()));
                      if (fieldAttribute != null && fieldAttribute.Min != long.MinValue)
                        el.SetAttribute("min", fieldAttribute.Min.ToString());
                      else
                        el.SetAttribute("min", nullable ? SourceLoader.GetNullableMinByNumeric(type1) : SourceLoader.GetMinByNumeric(type1.Name.ToLower()));
                      if (fieldAttribute != null && fieldAttribute.Max != long.MaxValue)
                        el.SetAttribute("max", fieldAttribute.Max.ToString());
                      else
                        el.SetAttribute("max", nullable ? SourceLoader.GetNullableMaxByNumeric(type1) : SourceLoader.GetMaxByNumeric(type1.Name.ToLower()));
                      if (fieldAttribute != null && !string.IsNullOrWhiteSpace(fieldAttribute.DataSourceName) && sourceable)
                      {
                        el.SetAttribute("dataSourceName", fieldAttribute.DataSourceName);
                        break;
                      }
                      break;
                    case SourceLoader.ClientType.String:
                      el = SourceLoader.GetPropertyElement(doc, "string", type1, fieldAttribute, SourceLoader.BuildName(info, name), true, settable);
                      SourceLoader.SetDisplayName(info, el, fieldAttribute, parentName, name, parentDescription);
                      if (fieldAttribute != null && fieldAttribute.Max != long.MaxValue && fieldAttribute.Max <= 256L)
                        el.SetAttribute("maxLength", fieldAttribute.Max.ToString());
                      else
                        el.SetAttribute("maxLength", 256L.ToString());
                      if (fieldAttribute != null && fieldAttribute.StringComparison != StringComparison.OrdinalIgnoreCase)
                      {
                        el.SetAttribute("stringComparison", fieldAttribute.StringComparison.ToString());
                        break;
                      }
                      break;
                    case SourceLoader.ClientType.Date:
                      el = SourceLoader.GetPropertyElement(doc, "date", type1, fieldAttribute, SourceLoader.BuildName(info, name), nullable, settable);
                      SourceLoader.SetDisplayName(info, el, fieldAttribute, parentName, name, parentDescription);
                      if (fieldAttribute != null && !string.IsNullOrEmpty(fieldAttribute.DateTimeFormat))
                      {
                        el.SetAttribute("format", Encoder.Sanitize(fieldAttribute.DateTimeFormat));
                        break;
                      }
                      el.SetAttribute("format", "MMM dd, yyyy");
                      break;
                    case SourceLoader.ClientType.Time:
                      el = SourceLoader.GetPropertyElement(doc, "time", type1, fieldAttribute, SourceLoader.BuildName(info, name), nullable, settable);
                      SourceLoader.SetDisplayName(info, el, fieldAttribute, parentName, name, parentDescription);
                      if (fieldAttribute != null && !string.IsNullOrEmpty(fieldAttribute.DateTimeFormat))
                      {
                        el.SetAttribute("format", Encoder.Sanitize(fieldAttribute.DateTimeFormat));
                        break;
                      }
                      el.SetAttribute("format", "hh:mm tt");
                      break;
                    case SourceLoader.ClientType.Bool:
                      el = SourceLoader.GetPropertyElement(doc, "bool", type1, fieldAttribute, SourceLoader.BuildName(info, name), nullable, settable);
                      SourceLoader.SetDisplayName(info, el, fieldAttribute, parentName, name, parentDescription);
                      break;
                  }
                }
              }
              if (el != null)
              {
                try
                {
                  if (!fields.ContainsKey(el.Attributes["displayName"].Value))
                    fields.Add(el.Attributes["displayName"].Value, el);
                }
                catch (ArgumentException ex)
                {
                }
              }
              else if (level < state.MaxLevel && !flag)
              {
                string parent1 = parent == null ? info.Name : parent;
                SourceLoader.ManageProperties(type1, SourceLoader.BuildName(info, name), parent1, doc, fields, level + 1, state, processedTypes);
              }
            }
          }
        }
      }
    }

    private static bool ManageParameters(ParameterInfo[] pars, XmlDocument doc, XmlElement elParams, MethodInfo m, Type sourceType, bool attrExists, List<Type> processedTypes)
    {
      List<XmlElement> xmlElementList = new List<XmlElement>();
      foreach (ParameterInfo par in pars)
      {
        if (!SourceValidator.IsParameterValid(par, sourceType))
        {
          if (attrExists)
            throw new SourceException(SourceException.ErrorIds.InvalidMethodParameters, new string[1]{ m.Name });
          break;
        }
        Type parameterType = par.ParameterType;
        object[] customAttributes = par.GetCustomAttributes(typeof (ParameterAttribute), true);
        ParameterAttribute attr = (ParameterAttribute) null;
        if (customAttributes.Length > 0)
          attr = (ParameterAttribute) customAttributes[0];
        if (attr == null)
          attr = SourceLoader.GetInterfaceParameterAttribute(m, par.Name, parameterType);
        XmlElement element;
        if (TypeUtils.AreEquivalent(parameterType, typeof (object)) || TypeUtils.IsSameOrSubclass(parameterType, sourceType))
          element = doc.CreateElement("source", "http://codeeffects.com/schemas/source/42");
        else if (((IEnumerable<Type>) parameterType.GetInterfaces()).Contains<Type>(typeof (IEnumerable)) && parameterType != typeof (string))
        {
          element = doc.CreateElement("collection", "http://codeeffects.com/schemas/source/42");
          element.SetAttribute("generic", parameterType.IsGenericType ? "true" : "false");
          element.SetAttribute("array", parameterType.IsArray ? "true" : "false");
          if (attr != null && !string.IsNullOrEmpty(attr.Description))
            element.SetAttribute("description", Encoder.Sanitize(attr.Description));
          XmlElement xmlElement = SourceLoader.BuildItemElement(doc, parameterType, (ISettingsAttribute) attr, (string) null, true, processedTypes);
          if (xmlElement == null)
          {
            if (attrExists)
              throw new SourceException(SourceException.ErrorIds.InvalidMethodParameters, new string[1]{ m.Name });
            break;
          }
          element.SetAttribute("class", xmlElement.Name == "generic" ? parameterType.Name : parameterType.FullName);
          if (!parameterType.IsArray && parameterType.IsGenericType || xmlElement.Name == "generic")
            element.SetAttribute("comparisonName", SourceLoader.GetComparisonName(parameterType));
          else
            element.SetAttribute("comparisonName", parameterType.FullName);
          element.AppendChild((XmlNode) xmlElement);
        }
        else
        {
          bool nullable = false;
          bool sourceable = false;
          SourceLoader.ClientType clientType = SourceLoader.GetClientType(parameterType, out nullable, out sourceable);
          if (clientType == SourceLoader.ClientType.Enum)
          {
            if (attr != null && attr.ConstantValue != null)
              throw new SourceException(SourceException.ErrorIds.EnumMethodParamNotSupported, new string[0]);
            element = doc.CreateElement("input", "http://codeeffects.com/schemas/source/42");
            SourceLoader.SetElement(element, "enum", attr, false);
            element.SetAttribute("class", parameterType.FullName);
            element.SetAttribute("assembly", Assembly.GetAssembly(parameterType).FullName);
            if (attr != null)
            {
              element.SetAttribute("valueInputType", Converter.ValueInputTypeToString(attr.ValueInputType));
              if (!string.IsNullOrWhiteSpace(attr.Description))
                element.SetAttribute("description", Encoder.Sanitize(attr.Description));
            }
            else
              element.SetAttribute("valueInputType", Converter.ValueInputTypeToString(CodeEffects.Rule.Common.ValueInputType.All));
          }
          else
          {
            bool flag = false;
            if (attr != null && attr.ConstantValue != null)
            {
              element = doc.CreateElement("constant", "http://codeeffects.com/schemas/source/42");
              element.SetAttribute("value", Encoder.Sanitize(attr.ConstantValue));
              flag = true;
            }
            else
            {
              element = doc.CreateElement("input", "http://codeeffects.com/schemas/source/42");
              if (attr != null)
              {
                element.SetAttribute("valueInputType", Converter.ValueInputTypeToString(attr.ValueInputType));
                if (!string.IsNullOrWhiteSpace(attr.Description))
                  element.SetAttribute("description", Encoder.Sanitize(attr.Description));
              }
              else
                element.SetAttribute("valueInputType", Converter.ValueInputTypeToString(CodeEffects.Rule.Common.ValueInputType.All));
            }
            element.SetAttribute("class", parameterType.FullName);
            switch (clientType)
            {
              case SourceLoader.ClientType.Numeric:
                SourceLoader.SetElement(element, "numeric", attr, nullable);
                if (!flag)
                {
                  if (attr != null && attr.Min != long.MinValue)
                    element.SetAttribute("min", attr.Min.ToString());
                  else
                    element.SetAttribute("min", nullable ? SourceLoader.GetNullableMinByNumeric(parameterType) : SourceLoader.GetMinByNumeric(parameterType.Name.ToLower()));
                  if (attr != null && attr.Max != long.MaxValue)
                    element.SetAttribute("max", attr.Max.ToString());
                  else
                    element.SetAttribute("max", nullable ? SourceLoader.GetNullableMaxByNumeric(parameterType) : SourceLoader.GetMaxByNumeric(parameterType.Name.ToLower()));
                  element.SetAttribute("allowDecimal", nullable ? SourceLoader.GetNullableDecimalByNumeric(parameterType) : SourceLoader.GetDecimalByNumeric(parameterType.Name.ToLower()));
                  if (attr != null && !string.IsNullOrWhiteSpace(attr.DataSourceName) && sourceable)
                  {
                    element.SetAttribute("dataSourceName", attr.DataSourceName);
                    break;
                  }
                  break;
                }
                break;
              case SourceLoader.ClientType.String:
                SourceLoader.SetElement(element, "string", attr, true);
                if (!flag)
                {
                  if (attr != null)
                  {
                    if (attr.ValueInputType != CodeEffects.Rule.Common.ValueInputType.Fields)
                    {
                      element.SetAttribute("maxLength", attr.Max == long.MaxValue || attr.Max > 256L ? 256L.ToString() : attr.Max.ToString());
                      break;
                    }
                    break;
                  }
                  element.SetAttribute("maxLength", 256L.ToString());
                  break;
                }
                break;
              case SourceLoader.ClientType.Date:
                SourceLoader.SetElement(element, "date", attr, nullable);
                if (!flag)
                {
                  if (attr != null && !string.IsNullOrEmpty(attr.DateTimeFormat))
                  {
                    element.SetAttribute("format", Encoder.Sanitize(attr.DateTimeFormat));
                    break;
                  }
                  element.SetAttribute("format", "MMM dd, yyyy");
                  break;
                }
                break;
              case SourceLoader.ClientType.Time:
                SourceLoader.SetElement(element, "time", attr, nullable);
                if (!flag)
                {
                  if (attr != null && !string.IsNullOrEmpty(attr.DateTimeFormat))
                  {
                    element.SetAttribute("format", Encoder.Sanitize(attr.DateTimeFormat));
                    break;
                  }
                  element.SetAttribute("format", "hh:mm tt");
                  break;
                }
                break;
              case SourceLoader.ClientType.Bool:
                SourceLoader.SetElement(element, "bool", attr, nullable);
                break;
            }
          }
        }
        if (element != null)
        {
          xmlElementList.Add(element);
        }
        else
        {
          if (attrExists)
            throw new SourceException(SourceException.ErrorIds.InvalidMethodParameters, new string[1]{ m.Name });
          break;
        }
      }
      if (xmlElementList.Count != pars.Length)
        return false;
      foreach (XmlElement xmlElement in xmlElementList)
        elParams.AppendChild((XmlNode) xmlElement);
      return true;
    }

    private static void ManageReturn(MethodInfo m, XmlElement elReturn)
    {
      object[] customAttributes = m.ReturnParameter.GetCustomAttributes(typeof (ReturnAttribute), true);
      ReturnAttribute returnAttribute = customAttributes.Length <= 0 ? SourceLoader.GetInterfaceReturnAttribute(m) : (ReturnAttribute) customAttributes[0];
      if (returnAttribute != null)
        elReturn.SetAttribute("valueInputType", Converter.ValueInputTypeToString(returnAttribute.ValueInputType));
      else
        elReturn.SetAttribute("valueInputType", Converter.ValueInputTypeToString(CodeEffects.Rule.Common.ValueInputType.All));
      Type returnType = m.ReturnType;
      elReturn.SetAttribute("class", returnType.FullName);
      bool nullable = false;
      bool sourceable = false;
      switch (SourceLoader.GetClientType(returnType, out nullable, out sourceable))
      {
        case SourceLoader.ClientType.Enum:
          SourceLoader.SetElement(elReturn, "enum", (ParameterAttribute) null, false);
          elReturn.SetAttribute("assembly", Assembly.GetAssembly(returnType).FullName);
          break;
        case SourceLoader.ClientType.Numeric:
          SourceLoader.SetElement(elReturn, "numeric", (ParameterAttribute) null, nullable);
          if (returnAttribute != null && returnAttribute.Min != long.MinValue)
            elReturn.SetAttribute("min", returnAttribute.Min.ToString());
          else
            elReturn.SetAttribute("min", nullable ? SourceLoader.GetNullableMinByNumeric(returnType) : SourceLoader.GetMinByNumeric(returnType.Name.ToLower()));
          if (returnAttribute != null && returnAttribute.Max != long.MaxValue)
            elReturn.SetAttribute("max", returnAttribute.Max.ToString());
          else
            elReturn.SetAttribute("max", nullable ? SourceLoader.GetNullableMaxByNumeric(returnType) : SourceLoader.GetMaxByNumeric(returnType.Name.ToLower()));
          elReturn.SetAttribute("allowDecimal", nullable ? SourceLoader.GetNullableDecimalByNumeric(returnType) : SourceLoader.GetDecimalByNumeric(returnType.Name.ToLower()));
          if (returnAttribute != null)
            elReturn.SetAttribute("allowCalculation", returnAttribute.AllowCalculations ? "true" : "false");
          else
            elReturn.SetAttribute("allowCalculation", "true");
          if (returnAttribute == null || string.IsNullOrWhiteSpace(returnAttribute.DataSourceName) || !sourceable)
            break;
          elReturn.SetAttribute("dataSourceName", returnAttribute.DataSourceName);
          break;
        case SourceLoader.ClientType.String:
          SourceLoader.SetElement(elReturn, "string", (ParameterAttribute) null, true);
          elReturn.SetAttribute("type", "string");
          if (returnAttribute != null && returnAttribute.Max != long.MaxValue && returnAttribute.Max <= 256L)
            elReturn.SetAttribute("maxLength", returnAttribute.Max.ToString());
          else
            elReturn.SetAttribute("maxLength", 256L.ToString());
          if (returnAttribute == null || returnAttribute.StringComparison == StringComparison.OrdinalIgnoreCase)
            break;
          elReturn.SetAttribute("stringComparison", returnAttribute.StringComparison.ToString());
          break;
        case SourceLoader.ClientType.Date:
          SourceLoader.SetElement(elReturn, "date", (ParameterAttribute) null, nullable);
          if (returnAttribute != null && !string.IsNullOrEmpty(returnAttribute.DateTimeFormat))
          {
            elReturn.SetAttribute("format", Encoder.Sanitize(returnAttribute.DateTimeFormat));
            break;
          }
          elReturn.SetAttribute("format", "MMM dd, yyyy");
          break;
        case SourceLoader.ClientType.Time:
          SourceLoader.SetElement(elReturn, "time", (ParameterAttribute) null, nullable);
          if (returnAttribute != null && !string.IsNullOrEmpty(returnAttribute.DateTimeFormat))
          {
            elReturn.SetAttribute("format", Encoder.Sanitize(returnAttribute.DateTimeFormat));
            break;
          }
          elReturn.SetAttribute("format", "hh:mm tt");
          break;
        case SourceLoader.ClientType.Bool:
          SourceLoader.SetElement(elReturn, "bool", (ParameterAttribute) null, nullable);
          break;
        default:
          throw new SourceException((SourceException.ErrorIds) (nullable ? 122 : 123), new string[1]{ m.Name });
      }
    }

    private static string GetTokenByMethod(XmlNode source, Type type, Type sourceObject, string methodName, XmlNodeList parameters, bool isMethod)
    {
      foreach (MethodInfo method in SourceLoader.GetMethods(type))
      {
        if (!(method.Name != methodName) && method.GetCustomAttributes(typeof (ExcludeFromEvaluationAttribute), true).Length == 0 && SourceValidator.IsMethodValid(method, isMethod))
        {
          ParameterInfo[] parameters1 = method.GetParameters();
          if (parameters1.Length == parameters.Count && (parameters1.Length == 0 || SourceLoader.ParamsMatch(source, sourceObject, parameters1, parameters)))
            return Encoder.GetHashToken(method);
        }
      }
      throw new SourceException(SourceException.ErrorIds.MethodNotFound, new string[1]{ methodName });
    }

    private static XmlNode GetMethodByToken(XmlNode sourceXml, string token, bool isMethod, MalformedXmlException.ErrorIds errorTag)
    {
      XmlNode xmlNode = sourceXml.SelectSingleNode(string.Format(isMethod ? "{0}:fields" : "{0}:actions", (object) "s"), CodeEffects.Rule.Common.Xml.GetSourceNamespaceManager(sourceXml));
      if (xmlNode == null || xmlNode.ChildNodes.Count == 0)
        throw new MalformedXmlException(errorTag, new string[0]);
      Type sourceObject = SourceLoader.GetSourceObject(sourceXml);
      foreach (XmlNode childNode in xmlNode.ChildNodes)
      {
        if (childNode.NodeType != XmlNodeType.Comment && (!isMethod || !(childNode.Name != "function")))
        {
          MethodInfo matchingMethod = SourceLoader.GetMatchingMethod(childNode.Attributes["methodName"].Value, childNode.Attributes["class"] == null ? sourceObject : SourceLoader.LoadType(childNode.Attributes["assembly"].Value, childNode.Attributes["class"].Value, SourceException.ErrorIds.AssemblyNameIsEmpty, SourceException.ErrorIds.AssemblyDoesNotContainType), token, isMethod);
          if (!(matchingMethod == (MethodInfo) null))
          {
            ParameterInfo[] parameters = matchingMethod.GetParameters();
            XmlNode paramNode = SourceLoader.GetParamNode(childNode);
            if (parameters.Length == paramNode.ChildNodes.Count && (parameters.Length == 0 || SourceLoader.ParamsMatch(sourceXml, sourceObject, parameters, paramNode.ChildNodes)))
              return childNode;
          }
        }
      }
      throw new SourceException(SourceException.ErrorIds.NoMethodForTheToken, new string[1]{ token });
    }

    private static MethodInfo GetMatchingMethod(string methodName, Type type, string token, bool isMethod)
    {
      foreach (MethodInfo method in SourceLoader.GetMethods(type))
      {
        if (!(method.Name != methodName) && method.GetCustomAttributes(typeof (ExcludeFromEvaluationAttribute), true).Length == 0 && (SourceValidator.IsMethodValid(method, isMethod) && Encoder.GetHashToken(method) == token))
          return method;
      }
      return (MethodInfo) null;
    }

    private static bool ParamsMatch(XmlNode source, Type sourceObject, ParameterInfo[] pis, XmlNodeList paramNodes)
    {
      bool flag = true;
      for (int index = 0; index < pis.Length; ++index)
      {
        XmlNode xmlNode = paramNodes[index];
        switch (xmlNode.Name)
        {
          case "source":
          case "self":
            flag = TypeUtils.AreEquivalent(pis[index].ParameterType, typeof (object)) || TypeUtils.IsSameOrSubclass(pis[index].ParameterType, sourceObject);
            break;
          case "collection":
            if (xmlNode.ChildNodes[0].Name == "generic")
            {
              flag = string.IsNullOrEmpty(pis[index].ParameterType.FullName) && pis[index].ParameterType.Name == xmlNode.Attributes["class"].Value;
              break;
            }
            Type underlyingType1 = SourceLoader.GetUnderlyingType(pis[index].ParameterType, (Type) null);
            if (xmlNode.Attributes["array"].Value == "true")
            {
              flag = pis[index].ParameterType.IsArray && xmlNode.ChildNodes[0].Attributes["class"].Value == pis[index].ParameterType.GetElementType().FullName;
              break;
            }
            Type type1 = Type.GetType(xmlNode.Attributes["class"].Value);
            Type underlyingType2 = SourceLoader.GetUnderlyingType(type1, Type.GetType(xmlNode.ChildNodes[0].Attributes["class"].Value));
            flag = TypeUtils.IsSameOrSubclass(type1, pis[index].ParameterType) && TypeUtils.IsSameOrSubclass(underlyingType2, underlyingType1);
            break;
          case "input":
          case "constant":
            Type type2;
            if (xmlNode.Attributes["assembly"] != null)
            {
              type2 = Type.GetType(xmlNode.Attributes["class"].Value + ", " + xmlNode.Attributes["assembly"].Value);
              if (type2 == (Type) null)
                type2 = Type.GetType(xmlNode.Attributes["class"].Value);
            }
            else
              type2 = Type.GetType(xmlNode.Attributes["class"].Value);
            flag = TypeUtils.AreEquivalent(type2, pis[index].ParameterType) || TypeUtils.IsImplicitlyConvertible(type2, pis[index].ParameterType);
            break;
          case "property":
            XmlNode fieldByPropertyName = SourceLoader.GetFieldByPropertyName(source, xmlNode.Attributes["name"].Value);
            Type type3;
            if (fieldByPropertyName.Attributes["assembly"] != null)
            {
              type3 = Type.GetType(fieldByPropertyName.Attributes["class"].Value + ", " + fieldByPropertyName.Attributes["assembly"].Value);
              if (type3 == (Type) null)
                type3 = Type.GetType(fieldByPropertyName.Attributes["class"].Value);
            }
            else
              type3 = Type.GetType(fieldByPropertyName.Attributes["class"].Value);
            Type[] interfaces = type3.GetInterfaces();
            flag = !((IEnumerable<Type>) interfaces).Contains<Type>(typeof (IDictionary)) && (!((IEnumerable<Type>) interfaces).Contains<Type>(typeof (IEnumerable)) || !(type3 != typeof (string)) ? TypeUtils.AreEquivalent(type3, pis[index].ParameterType) || TypeUtils.IsImplicitlyConvertible(type3, pis[index].ParameterType) : TypeUtils.IsSameOrSubclass(type3.GetGenericTypeDefinition(), pis[index].ParameterType.GetGenericTypeDefinition()));
            break;
          case "value":
            flag = (xmlNode.Attributes["type"] == null ? typeof (string).FullName : Type.GetType(xmlNode.Attributes["type"].Value).FullName) == pis[index].ParameterType.FullName;
            break;
          default:
            throw new MalformedXmlException(MalformedXmlException.ErrorIds.UnknownNodeName, new string[1]{ paramNodes[index].Name });
        }
        if (!flag)
          break;
      }
      return flag;
    }

    private static List<MethodInfo> GetMethods(Type type)
    {
      return SourceLoader.GetMethods(type, (SourceState) null);
    }

    private static List<MethodInfo> GetMethods(Type type, SourceState state)
    {
      BindingFlags bindingAttr = state == null || !state.DeclaredMembersOnly ? BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public : BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public;
      MethodInfo[] methods = type.GetMethods(bindingAttr);
      List<MethodInfo> methodInfoList = new List<MethodInfo>();
      foreach (MethodInfo methodInfo in methods)
      {
        if (!(methodInfo.DeclaringType == typeof (object)))
          methodInfoList.Add(methodInfo);
      }
      return methodInfoList;
    }

    private static Type GetSourceObject(XmlNode source)
    {
      return Type.GetType(source.Attributes["type"].Value);
    }

    private static object GetAttribute<T>(object[] attributes)
    {
      for (int index = 0; index < attributes.Length; ++index)
      {
        if (attributes[index] is T)
          return attributes[index];
      }
      return (object) null;
    }

    private static XmlElement GetPropertyElement(XmlDocument doc, string node, Type t, FieldAttribute attr, string name, bool nullable, bool settable)
    {
      XmlElement element = doc.CreateElement(node, "http://codeeffects.com/schemas/source/42");
      element.SetAttribute("propertyName", name);
      element.SetAttribute("class", t.FullName);
      element.SetAttribute("nullable", nullable ? "true" : "false");
      if (!settable)
        element.SetAttribute("settable", "false");
      if (attr != null)
        element.SetAttribute("valueInputType", Converter.ValueInputTypeToString(attr.ValueInputType));
      else
        element.SetAttribute("valueInputType", Converter.ValueInputTypeToString(CodeEffects.Rule.Common.ValueInputType.All));
      return element;
    }

    private static bool IsReadOnly(MemberInfo mi)
    {
      ReadOnlyAttribute readOnlyAttribute = Attribute.GetCustomAttribute(mi, typeof (ReadOnlyAttribute)) as ReadOnlyAttribute;
      if (readOnlyAttribute != null)
        return readOnlyAttribute.IsReadOnly;
      return false;
    }

    private static void SetElement(XmlElement el, string type, ParameterAttribute attr, bool nullable)
    {
      el.SetAttribute("type", type);
      if (attr != null && !string.IsNullOrEmpty(attr.Description))
        el.SetAttribute("description", Encoder.Sanitize(attr.Description));
      el.SetAttribute("nullable", nullable ? "true" : "false");
    }

    private static SourceLoader.ClientType GetClientType(Type t, out bool nullable, out bool sourceable)
    {
      // ISSUE: explicit reference operation
      // ISSUE: cast to a reference type
      // ISSUE: explicit reference operation
      nullable =sourceable = false;
      if (!t.IsValueType && t != typeof (string))
        return SourceLoader.ClientType.Other;
      if (t.IsEnum)
        return SourceLoader.ClientType.Enum;
      if (t.IsGenericType)
      {
        nullable = true;
        if (t == typeof (byte?) || t == typeof (sbyte?) || (t == typeof (short?) || t == typeof (ushort?)) || (t == typeof (int?) || t == typeof (uint?) || (t == typeof (long?) || t == typeof (ulong?))))
        {
          sourceable = true;
          return SourceLoader.ClientType.Numeric;
        }
        if (t == typeof (float?) || t == typeof (double?) || t == typeof (Decimal?))
          return SourceLoader.ClientType.Numeric;
        if (t == typeof (DateTime?))
          return SourceLoader.ClientType.Date;
        if (t == typeof (TimeSpan?))
          return SourceLoader.ClientType.Time;
        if (t == typeof (bool?))
          return SourceLoader.ClientType.Bool;
      }
      else
      {
        switch (t.Name.ToLower())
        {
          case "byte":
          case "sbyte":
          case "int16":
          case "uint16":
          case "int32":
          case "uint32":
          case "int64":
          case "uint64":
            sourceable = true;
            return SourceLoader.ClientType.Numeric;
          case "single":
          case "double":
          case "decimal":
            return SourceLoader.ClientType.Numeric;
          case "datetime":
            return SourceLoader.ClientType.Date;
          case "timespan":
            return SourceLoader.ClientType.Time;
          case "boolean":
            return SourceLoader.ClientType.Bool;
          case "string":
            nullable = true;
            return SourceLoader.ClientType.String;
        }
      }
      return SourceLoader.ClientType.Other;
    }

    private static Type GetUnderlyingType(Type collectionType, Type userDefinedType)
    {
      Type type = (Type) null;
      if (collectionType.IsArray)
        type = collectionType.GetElementType();
      else if (collectionType.IsGenericType)
        type = collectionType.GetGenericArguments()[0];
      else if (userDefinedType == (Type) null)
      {
        if (collectionType == typeof (BitArray) || collectionType == typeof (BitVector32))
          type = typeof (bool);
        else if (collectionType == typeof (StringCollection))
          type = typeof (string);
      }
      else
        type = userDefinedType;
      return type;
    }

    private static XmlElement BuildItemElement(XmlDocument sourceXml, Type collectionType, ISettingsAttribute attr, string displayName, bool isParameter, List<Type> processedTypes)
    {
      FieldAttribute fieldAttribute = isParameter ? (FieldAttribute) null : (FieldAttribute) attr;
      Type underlyingType = SourceLoader.GetUnderlyingType(collectionType, attr == null || attr.CollectionItemType == (Type) null ? (Type) null : attr.CollectionItemType);
      if (underlyingType == (Type) null || underlyingType != typeof (string) && ((IEnumerable<Type>) underlyingType.GetInterfaces()).Contains<Type>(typeof (IEnumerable)))
        return (XmlElement) null;
      XmlElement element;
      if (underlyingType.IsValueType || underlyingType == typeof (string))
      {
        if (underlyingType.IsEnum && underlyingType.GetCustomAttributes(typeof (ExcludeFromEvaluationAttribute), true).Length != 0)
          return (XmlElement) null;
        element = sourceXml.CreateElement("value", "http://codeeffects.com/schemas/source/42");
        element.SetAttribute("class", underlyingType.FullName);
        bool nullable = false;
        bool sourceable = false;
        switch (SourceLoader.GetClientType(underlyingType, out nullable, out sourceable))
        {
          case SourceLoader.ClientType.Enum:
            element.SetAttribute("type", "enum");
            element.SetAttribute("assembly", Assembly.GetAssembly(underlyingType).FullName);
            element.SetAttribute("nullable", "false");
            break;
          case SourceLoader.ClientType.Numeric:
            element.SetAttribute("type", "numeric");
            if (!isParameter)
            {
              if (attr != null)
                element.SetAttribute("allowCalculation", fieldAttribute.AllowCalculations ? "true" : "false");
              else
                element.SetAttribute("allowCalculation", "true");
              if (attr != null)
                element.SetAttribute("includeInCalculations", fieldAttribute.IncludeInCalculations ? "true" : "false");
              else
                element.SetAttribute("includeInCalculations", "true");
              if (attr != null && !string.IsNullOrWhiteSpace(attr.DataSourceName) && sourceable)
                element.SetAttribute("dataSourceName", attr.DataSourceName);
            }
            element.SetAttribute("allowDecimal", nullable ? SourceLoader.GetNullableDecimalByNumeric(underlyingType) : SourceLoader.GetDecimalByNumeric(underlyingType.Name.ToLower()));
            if (attr != null && attr.Min != long.MinValue)
              element.SetAttribute("min", attr.Min.ToString());
            else
              element.SetAttribute("min", nullable ? SourceLoader.GetNullableMinByNumeric(underlyingType) : SourceLoader.GetMinByNumeric(underlyingType.Name.ToLower()));
            if (attr != null && attr.Max != long.MaxValue)
              element.SetAttribute("max", attr.Max.ToString());
            else
              element.SetAttribute("max", nullable ? SourceLoader.GetNullableMaxByNumeric(underlyingType) : SourceLoader.GetMaxByNumeric(underlyingType.Name.ToLower()));
            element.SetAttribute("nullable", nullable ? "true" : "false");
            break;
          case SourceLoader.ClientType.String:
            element.SetAttribute("type", "string");
            if (!isParameter)
            {
              if (attr != null && attr.Max != long.MaxValue && attr.Max <= 256L)
                element.SetAttribute("maxLength", attr.Max.ToString());
              else
                element.SetAttribute("maxLength", 256L.ToString());
              if (attr != null && fieldAttribute.StringComparison != StringComparison.OrdinalIgnoreCase)
                element.SetAttribute("stringComparison", fieldAttribute.StringComparison.ToString());
            }
            element.SetAttribute("nullable", "true");
            break;
          case SourceLoader.ClientType.Date:
            element.SetAttribute("type", "date");
            if (attr != null && !string.IsNullOrEmpty(attr.DateTimeFormat))
              element.SetAttribute("format", Encoder.Sanitize(attr.DateTimeFormat));
            else
              element.SetAttribute("format", "MMM dd, yyyy");
            element.SetAttribute("nullable", nullable ? "true" : "false");
            break;
          case SourceLoader.ClientType.Time:
            element.SetAttribute("type", "time");
            if (attr != null && !string.IsNullOrEmpty(attr.DateTimeFormat))
              element.SetAttribute("format", Encoder.Sanitize(attr.DateTimeFormat));
            else
              element.SetAttribute("format", "hh:mm tt");
            element.SetAttribute("nullable", nullable ? "true" : "false");
            break;
          case SourceLoader.ClientType.Bool:
            element.SetAttribute("type", "bool");
            element.SetAttribute("nullable", nullable ? "true" : "false");
            break;
          default:
            return (XmlElement) null;
        }
      }
      else if (string.IsNullOrEmpty(collectionType.FullName) || underlyingType.GUID == Guid.Empty || string.IsNullOrEmpty(underlyingType.FullName))
      {
        if (!isParameter)
          return (XmlElement) null;
        element = sourceXml.CreateElement("generic", "http://codeeffects.com/schemas/source/42");
      }
      else
      {
        if (underlyingType.GetCustomAttributes(typeof (ExcludeFromEvaluationAttribute), true).Length != 0)
          return (XmlElement) null;
        element = sourceXml.CreateElement("reference", "http://codeeffects.com/schemas/source/42");
        element.SetAttribute("class", underlyingType.FullName);
        if (!isParameter)
          element.SetAttribute("displayName", fieldAttribute == null || string.IsNullOrWhiteSpace(fieldAttribute.CollectionItemName) ? displayName : fieldAttribute.CollectionItemName);
        SourceLoader.Extract(sourceXml, underlyingType, processedTypes);
      }
      return element;
    }

    private static bool IsPropertyExcludedInInterface(Type[] interfaces, string name)
    {
      if (interfaces == null || interfaces.Length == 0)
        return false;
      foreach (Type @interface in interfaces)
      {
        MemberInfo memberInfo = SourceLoader.GetMemberInfo(@interface, name);
        if (memberInfo != (MemberInfo) null && memberInfo.GetCustomAttributes(typeof (ExcludeFromEvaluationAttribute), true).Length > 0)
          return true;
      }
      return false;
    }

    private static bool IsMethodExcludedInInterface(Type[] interfaces, string name, Type[] pars)
    {
      if (interfaces == null || interfaces.Length == 0)
        return false;
      foreach (Type @interface in interfaces)
      {
        MethodInfo method = @interface.GetMethod(name, pars);
        if (method != (MethodInfo) null && method.GetCustomAttributes(typeof (ExcludeFromEvaluationAttribute), true).Length > 0)
          return true;
      }
      return false;
    }

    private static IDescribableAttribute GetInterfaceDescribableAttribute(Type[] interfaces, string name, Type[] pars)
    {
      if (interfaces == null || interfaces.Length == 0)
        return (IDescribableAttribute) null;
      foreach (Type @interface in interfaces)
      {
        MethodInfo method = @interface.GetMethod(name, pars);
        if (method != (MethodInfo) null)
        {
          object[] customAttributes = method.GetCustomAttributes(false);
          if (customAttributes != null && customAttributes.Length > 0)
          {
            foreach (object obj in customAttributes)
            {
              if (obj is MethodAttribute || obj is ActionAttribute)
                return (IDescribableAttribute) obj;
            }
          }
        }
      }
      return (IDescribableAttribute) null;
    }

    private static ParameterAttribute GetInterfaceParameterAttribute(MethodInfo m, string name, Type t)
    {
      Type[] interfaces = m.DeclaringType.GetInterfaces();
      Type[] methodParameterTypes = SourceLoader.GetMethodParameterTypes(m);
      if (methodParameterTypes.Length == 0 || interfaces == null || interfaces.Length == 0)
        return (ParameterAttribute) null;
      foreach (Type type in interfaces)
      {
        MethodInfo method = type.GetMethod(m.Name, methodParameterTypes);
        if (method != (MethodInfo) null)
        {
          ParameterInfo[] parameters = method.GetParameters();
          if (parameters.Length > 0)
          {
            foreach (ParameterInfo parameterInfo in parameters)
            {
              if (parameterInfo.Name == name && parameterInfo.ParameterType == t)
              {
                object[] customAttributes = parameterInfo.GetCustomAttributes(typeof (ParameterAttribute), true);
                if (customAttributes.Length > 0)
                  return (ParameterAttribute) customAttributes[0];
              }
            }
          }
        }
      }
      return (ParameterAttribute) null;
    }

    private static ReturnAttribute GetInterfaceReturnAttribute(MethodInfo m)
    {
      Type[] interfaces = m.DeclaringType.GetInterfaces();
      Type[] methodParameterTypes = SourceLoader.GetMethodParameterTypes(m);
      if (interfaces == null || interfaces.Length == 0)
        return (ReturnAttribute) null;
      foreach (Type type in interfaces)
      {
        if (type.GetMethod(m.Name, methodParameterTypes) != (MethodInfo) null)
        {
          object[] customAttributes = m.ReturnParameter.GetCustomAttributes(typeof (ReturnAttribute), true);
          if (customAttributes.Length > 0)
            return (ReturnAttribute) customAttributes[0];
        }
      }
      return (ReturnAttribute) null;
    }

    private static FieldAttribute GetInterfaceFieldAttribute(Type[] interfaces, string name)
    {
      if (interfaces == null || interfaces.Length == 0)
        return (FieldAttribute) null;
      foreach (Type @interface in interfaces)
      {
        MemberInfo memberInfo = SourceLoader.GetMemberInfo(@interface, name);
        if (memberInfo != (MemberInfo) null)
        {
          object[] customAttributes = memberInfo.GetCustomAttributes(typeof (FieldAttribute), true);
          if (customAttributes.Length > 0)
            return (FieldAttribute) customAttributes[0];
        }
      }
      return (FieldAttribute) null;
    }

    private static object[] GetInterfaceParentAttributes(Type[] interfaces, string name)
    {
      if (interfaces == null || interfaces.Length == 0)
        return (object[]) null;
      foreach (Type @interface in interfaces)
      {
        MemberInfo memberInfo = SourceLoader.GetMemberInfo(@interface, name);
        if (memberInfo != (MemberInfo) null)
        {
          object[] customAttributes = memberInfo.GetCustomAttributes(typeof (ParentAttribute), true);
          if (customAttributes.Length > 0)
            return customAttributes;
        }
      }
      return (object[]) null;
    }

    private static MemberInfo GetMemberInfo(Type type, string name)
    {
      PropertyInfo property = type.GetProperty(name, BindingFlags.Instance | BindingFlags.Public);
      if (property != (PropertyInfo) null)
        return (MemberInfo) property;
      FieldInfo field = type.GetField(name, BindingFlags.Instance | BindingFlags.Public);
      if (field != (FieldInfo) null)
        return (MemberInfo) field;
      return (MemberInfo) null;
    }

    private static Type[] GetMethodParameterTypes(MethodInfo m)
    {
      ParameterInfo[] parameters = m.GetParameters();
      List<Type> typeList = new List<Type>(parameters.Length);
      foreach (ParameterInfo parameterInfo in parameters)
        typeList.Add(parameterInfo.ParameterType);
      return typeList.ToArray();
    }

    private static Type LoadType(string assembly, string type, SourceException.ErrorIds nullError, SourceException.ErrorIds typeError)
    {
      if (string.IsNullOrEmpty(type) || string.IsNullOrEmpty(assembly))
        throw new SourceException(nullError, new string[0]);
      Assembly assembly1;
      try
      {
        assembly1 = Assembly.Load(assembly);
      }
      catch (Exception ex)
      {
        throw new SourceException(SourceException.ErrorIds.FailedToFindOrLoadAssembly, new string[2]{ assembly, ex.Message });
      }
      foreach (Type type1 in assembly1.GetTypes())
      {
        if (type1.FullName == type)
          return type1;
      }
      throw new SourceException(typeError, new string[2]{ assembly, type });
    }

    private static string GetMinByNumeric(string type)
    {
      switch (type)
      {
        case "byte":
        case "uint16":
        case "uint32":
        case "uint64":
          return "0";
        case "sbyte":
          return "-128";
        case "int16":
          return "-32768";
        case "int32":
          return "-2147483648";
        default:
          return "-9007199254740992";
      }
    }

    private static string GetMaxByNumeric(string type)
    {
      switch (type)
      {
        case "byte":
          return "255";
        case "sbyte":
          return "127";
        case "int16":
          return "32767";
        case "uint16":
          return "65535";
        case "int32":
          return "2147483647";
        case "uint32":
          return "4294967295";
        default:
          return "9007199254740992";
      }
    }

    private static string GetDecimalByNumeric(string type)
    {
      switch (type)
      {
        case "byte":
        case "sbyte":
        case "int16":
        case "uint16":
        case "int32":
        case "uint32":
        case "int64":
        case "uint64":
          return "false";
        default:
          return "true";
      }
    }

    private static string GetNullableMinByNumeric(Type type)
    {
      if (type == typeof (byte?) || type == typeof (ushort?) || (type == typeof (uint?) || type == typeof (ulong?)))
        return "0";
      if (type == typeof (sbyte?))
        return "-128";
      if (type == typeof (short?))
        return "-32768";
      return type == typeof (int?) ? "-2147483648" : "-9007199254740992";
    }

    private static string GetNullableMaxByNumeric(Type type)
    {
      if (type == typeof (byte?))
        return "255";
      if (type == typeof (sbyte?))
        return "127";
      if (type == typeof (short?))
        return "32767";
      if (type == typeof (ushort?))
        return "65535";
      if (type == typeof (int?))
        return "2147483647";
      return type == typeof (uint?) ? "4294967295" : "9007199254740992";
    }

    private static string GetNullableDecimalByNumeric(Type t)
    {
      return t == typeof (byte?) || t == typeof (ushort?) || (t == typeof (uint?) || t == typeof (ulong?)) || (t == typeof (sbyte?) || t == typeof (short?) || (t == typeof (int?) || t == typeof (long?))) ? "false" : "true";
    }

    private static void SetDisplayName(MemberInfo pi, XmlElement el, FieldAttribute attr, string parentName, string name, string parentDescription)
    {
      if (parentName != null)
      {
        el.SetAttribute("displayName", Encoder.Sanitize(parentName));
        if (parentDescription != null)
          el.SetAttribute("description", Encoder.Sanitize(parentDescription));
        else if (attr != null && !string.IsNullOrEmpty(attr.Description))
          el.SetAttribute("description", Encoder.Sanitize(attr.Description));
      }
      else if (attr != null)
      {
        if (!string.IsNullOrEmpty(attr.DisplayName))
          el.SetAttribute("displayName", Encoder.Sanitize(attr.DisplayName));
        if (!string.IsNullOrEmpty(attr.Description))
          el.SetAttribute("description", Encoder.Sanitize(attr.Description));
      }
      if (el.Attributes["displayName"] != null)
        return;
      el.SetAttribute("displayName", SourceLoader.BuildName(pi, name));
    }

    private static FieldAttribute GetFieldAttribute(MemberInfo mi, Type[] interfaces)
    {
      object[] customAttributes = mi.GetCustomAttributes(typeof (FieldAttribute), true);
      return customAttributes.Length <= 0 ? SourceLoader.GetInterfaceFieldAttribute(interfaces, mi.Name) : (FieldAttribute) customAttributes[0];
    }

    private static string BuildName(MemberInfo pi, string name)
    {
      if (name != null)
        return name + "." + pi.Name;
      return pi.Name;
    }

    private static string GetComparisonName(Type type)
    {
      return type.Namespace + "." + type.Name;
    }

    private class Member
    {
      public MemberInfo Info { get; set; }

      public Type Type { get; set; }

      public bool Settable { get; set; }

      public Member(MemberInfo mi, Type t, bool setable)
      {
        this.Type = t;
        this.Info = mi;
        this.Settable = setable;
      }
    }

    private enum ClientType
    {
      Enum,
      Numeric,
      String,
      Date,
      Time,
      Bool,
      Other,
    }
  }
}
