﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Core.RuleLoader
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using CodeEffects.Rule.Attributes;
using CodeEffects.Rule.Client;
using CodeEffects.Rule.Common;
using CodeEffects.Rule.Formats;
using CodeEffects.Rule.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Xml;

namespace CodeEffects.Rule.Core
{
  internal sealed class RuleLoader
  {
    private RuleLoader()
    {
    }

    internal static string GetXml(List<Element> items, string ruleID, string ruleName, string ruleDescription, XmlDocument sourceXml, RuleFormatType format, RuleType mode, bool isEvaluationType)
    {
      if (format == RuleFormatType.CodeEffects)
        return Ce.GetXml(items, sourceXml, ruleID, ruleName, ruleDescription, mode, isEvaluationType);
      throw new FormatException("Unknown value of CodeEffects.Rule.Common.RuleFormatType enumeration.");
    }

    internal static RuleModel LoadXml(string xmlRule, XmlDocument sourceXml, GetRuleDelegate ruleDelegate)
    {
      if (xmlRule == null || xmlRule.Trim().Length == 0)
        throw new InvalidRuleException(InvalidRuleException.ErrorIds.ParameterIsNull, new string[0]);
      RuleModel ruleModel = new RuleModel();
      ruleModel.SourceXml = sourceXml;
      XmlDocument rule = new XmlDocument();
      rule.LoadXml(xmlRule);
      if (!CodeEffects.Rule.Common.Xml.IsVersion2XmlNamespace(rule.DocumentElement.NamespaceURI))
        throw new NotSupportedException("Old XML formats are not supported by this version of Code Effects control.");
      XmlNamespaceManager nsmgr = new XmlNamespaceManager(rule.NameTable);
      nsmgr.AddNamespace("x", rule.DocumentElement.NamespaceURI);
      XmlNode xmlNode1 = rule.SelectSingleNode("/x:codeeffects/x:rule", nsmgr) ?? rule.SelectSingleNode("/x:rule", nsmgr);
      if (xmlNode1 == null)
        throw new MalformedXmlException(MalformedXmlException.ErrorIds.CouldNotLoadRuleXML, new string[0]);
      ruleModel.Id = xmlNode1.Attributes["id"].Value;
      XmlNode xmlNode2 = xmlNode1.SelectSingleNode("x:name", nsmgr);
      if (xmlNode2 != null)
        ruleModel.Name = Encoder.Desanitize(xmlNode2.InnerText);
      XmlNode xmlNode3 = xmlNode1.SelectSingleNode("x:description", nsmgr);
      if (xmlNode3 != null)
        ruleModel.Desc = Encoder.Desanitize(xmlNode3.InnerText);
      ruleModel.Elements = RuleLoader.LoadXml(rule, sourceXml, RuleFormatType.CodeEffects, ruleDelegate);
      ruleModel.Format = RuleFormatType.CodeEffects;
      return ruleModel;
    }

    internal static List<Element> LoadXml(XmlDocument rule, XmlDocument source, RuleFormatType format, GetRuleDelegate getRuleDelegate)
    {
      if (format == RuleFormatType.CodeEffects)
        return Ce.LoadXml(rule, source, getRuleDelegate);
      throw new FormatException("Unknown value of CodeEffects.Rule.Common.RuleFormatType enumeration.");
    }

    internal static string GetString(List<Element> items, XmlDocument source, Labels labels, GetRuleDelegate ruleDelegate, Dictionary<string, GetDataSourceDelegate> dataSources)
    {
      int i = 0;
      StringBuilder sb = new StringBuilder();
      RuleLoader.DoGetString(items, source, source.DocumentElement.ChildNodes[0].Attributes["name"] == null ? (string) null : source.DocumentElement.ChildNodes[0].Attributes["name"].Value, labels, ruleDelegate, dataSources, sb, ref i);
      return sb.ToString().Trim();
    }

    private static void DoGetString(List<Element> items, XmlDocument sourceXml, string sourceName, Labels labels, GetRuleDelegate ruleDelegate, Dictionary<string, GetDataSourceDelegate> dataSources, StringBuilder sb, ref int i)
    {
      XmlNode source = SourceLoader.GetSourceNode(sourceXml, sourceName) ?? SourceLoader.GetSourceNodeByToken(sourceXml, sourceName);
      if (source == null)
        throw new SourceException(SourceException.ErrorIds.SourceNodeNotFound, new string[1]{ sourceName });
      string format = (string) null;
      string propertyName = (string) null;
      string name1 = (string) null;
      string token = (string) null;
      string name2 = (string) null;
      string assemblyString = (string) null;
      string globalValue1 = (string) null;
      Dictionary<string, List<DataSourceItem>> dataSourceItems = new Dictionary<string, List<DataSourceItem>>();
      int num1 = 0;
      int index = -1;
      XmlNode function = (XmlNode) null;
      while (i < items.Count)
      {
        Element el = items[i];
        int num2;
        switch (el.Type)
        {
          case ElementType.Flow:
            bool isEvaluationRule = true;
            foreach (Element element in items)
            {
              if (element.Type == ElementType.Clause && element.Value == "then")
              {
                isEvaluationRule = false;
                break;
              }
            }
            sb.Append(" ").Append(labels.GetFlowLabel(el.Value, isEvaluationRule)).Append(" ");
            break;
          case ElementType.Field:
            // ISSUE: variable of the null type
            __Null local1;
            globalValue1 = (string) (local1 = null);
            assemblyString = (string) local1;
            name2 = (string) local1;
            token = (string) local1;
            name1 = (string) local1;
            format = (string) local1;
            if (el.IsRule)
            {
              if (ruleDelegate == null)
                throw new MalformedXmlException(MalformedXmlException.ErrorIds.RuleDelegateIsNull, new string[0]);
              propertyName = (string) null;
              XmlDocument xmlDocument = new XmlDocument();
              string xml = ruleDelegate(el.Value);
              try
              {
                xmlDocument.LoadXml(xml);
                XmlNamespaceManager nsmgr = new XmlNamespaceManager(xmlDocument.NameTable);
                nsmgr.AddNamespace("x", xmlDocument.DocumentElement.NamespaceURI);
                XmlNode xmlNode = xmlDocument.SelectSingleNode(string.Format("/x:codeeffects/x:{0}/x:{1}", (object) "rule", (object) "name"), nsmgr);
                if (xmlNode == null)
                {
                  XmlDocument emptyRuleDocument = CodeEffects.Rule.Common.Xml.GetEmptyRuleDocument();
                  emptyRuleDocument.DocumentElement.InnerXml = xml;
                  xmlNode = emptyRuleDocument.SelectSingleNode(string.Format("/x:codeeffects/x:{0}/x:{1}", (object) "rule", (object) "name"), nsmgr);
                }
                if (xmlNode == null)
                  throw new Exception("The XML of the reusable rule does not contain the name node. Without the name, Code Effects control cannot display this reusable rule in the resulting string. Either use Toolbar when saving the rule or insert its name node into the Rule XML manually before saving it.");
                sb.Append(xmlNode.InnerText);
                break;
              }
              catch (Exception ex)
              {
                throw new MalformedXmlException(MalformedXmlException.ErrorIds.GetRuleDelegateInvokeError, new string[1]{ ex.Message });
              }
            }
            else
            {
              function = SourceLoader.GetFieldByPropertyName(source, el.Value);
              propertyName = el.Value;
              string str = function.Attributes["displayName"].Value;
              if (function.Name == "collection")
              {
                function = function.ChildNodes[0];
                if (function.Attributes["displayName"] != null)
                  str = function.Attributes["displayName"].Value;
              }
              if (function.Name == "enum" && function.Attributes["class"] != null)
              {
                name2 = function.Attributes["class"].Value;
                assemblyString = function.Attributes["assembly"].Value;
              }
              else if (function.Name == "numeric" && function.Attributes["dataSourceName"] != null)
                globalValue1 = RuleLoader.HandleDataSources(dataSources, dataSourceItems, function.Attributes["dataSourceName"].Value);
              else if (function.Attributes["format"] != null)
                format = Encoder.Desanitize(function.Attributes["format"].Value);
              sb.Append(str);
              break;
            }
          case ElementType.Function:
          case ElementType.Action:
            switch (el.FuncType)
            {
              case FunctionType.Name:
                // ISSUE: variable of the null type
                __Null local2;
                globalValue1 = (string) (local2 = null);
                assemblyString = (string) local2;
                name2 = (string) local2;
                format = (string) local2;
                propertyName = (string) local2;
                num2 = 0;
                index = -1;
                name1 = el.Value;
                token = el.Token;
                function = el.Type != ElementType.Function ? SourceLoader.GetActionByToken(source, token) : SourceLoader.GetFunctionByToken(source, token);
                sb.Append(function.Attributes["displayName"].Value);
                XmlNode paramNode1 = SourceLoader.GetParamNode(function);
                num1 = paramNode1 == null || paramNode1.ChildNodes.Count <= 0 ? 0 : RuleLoader.CountInputParams(paramNode1.ChildNodes);
                if (num1 > 0)
                  sb.Append(" (");
                if (el.Type == ElementType.Function)
                {
                  XmlNode returnNode = SourceLoader.GetReturnNode(function);
                  switch (Converter.ClientStringToClientType(returnNode.Attributes["type"].Value))
                  {
                    case OperatorType.Date:
                    case OperatorType.Time:
                      format = Encoder.Desanitize(returnNode.Attributes["format"].Value);
                      break;
                    case OperatorType.Enum:
                      name2 = returnNode.Attributes["class"].Value;
                      assemblyString = returnNode.Attributes["assembly"].Value;
                      break;
                    case OperatorType.Numeric:
                      if (returnNode.Attributes["dataSourceName"] != null)
                      {
                        globalValue1 = RuleLoader.HandleDataSources(dataSources, dataSourceItems, returnNode.Attributes["dataSourceName"].Value);
                        break;
                      }
                      break;
                  }
                }
                else
                  break;
              case FunctionType.Param:
                ++index;
                if (el.InpType == InputType.Field)
                {
                  function = SourceLoader.GetFieldByPropertyName(source, el.Value);
                  sb.Append(function.Attributes["displayName"].Value);
                }
                else
                {
                  switch (el.Oper)
                  {
                    case OperatorType.String:
                      sb.Append("\"").Append(el.Value).Append("\"");
                      break;
                    case OperatorType.Numeric:
                      CodeEffects.Rule.Client.Parameter paramByIndex1 = RuleLoader.GetParamByIndex(source, el.Type, name1, token, index);
                      if (string.IsNullOrWhiteSpace(paramByIndex1.Settings.DataSourceName))
                      {
                        sb.Append(el.Value);
                        break;
                      }
                      string globalValue2 = RuleLoader.HandleDataSources(dataSources, dataSourceItems, paramByIndex1.Settings.DataSourceName);
                      RuleLoader.HandleNumericValue(dataSourceItems, sb, globalValue2, el.Value);
                      break;
                    case OperatorType.Date:
                      sb.Append(DateTime.Parse(el.Value).ToString(Encoder.Desanitize(RuleLoader.GetParamByIndex(source, el.Type, name1, token, index).Settings.Format), (IFormatProvider) Thread.CurrentThread.CurrentCulture));
                      break;
                    case OperatorType.Time:
                      sb.Append(DateTime.Parse("1/1/2010 " + el.Value).ToString(Encoder.Desanitize(RuleLoader.GetParamByIndex(source, el.Type, name1, token, index).Settings.Format)));
                      break;
                    case OperatorType.Bool:
                      sb.Append(el.Value == "true" ? labels.True : labels.False);
                      break;
                    case OperatorType.Enum:
                      CodeEffects.Rule.Client.Parameter paramByIndex2 = RuleLoader.GetParamByIndex(source, el.Type, name1, token, index);
                      Type type1 = Assembly.Load(paramByIndex2.Settings.Assembly).GetType(paramByIndex2.Settings.TypeFullName);
                      sb.Append(RuleLoader.GetEnumItemDisplayName(type1, el.Value));
                      break;
                    default:
                      throw new InvalidRuleException(InvalidRuleException.ErrorIds.InvalidOrderOfNodes, new string[0]);
                  }
                }
                sb.Append(", ");
                break;
              case FunctionType.End:
                if (num1 > 0)
                {
                  sb.Remove(sb.Length - 2, 2);
                  sb.Append(")");
                }
                num1 = 0;
                index = -1;
                break;
            }
          case ElementType.Operator:
            sb.Append(" ").Append(labels.GetOperatorLabel(el.Value, el.Oper)).Append(" ");
            break;
          case ElementType.Value:
            if (el.InpType == InputType.Field)
            {
              function = SourceLoader.GetFieldByPropertyName(source, el.Value);
              sb.Append(function.Attributes["displayName"].Value);
              break;
            }
            switch (el.Oper)
            {
              case OperatorType.String:
                sb.Append("\"").Append(Encoder.Sanitize(el.Value)).Append("\"");
                break;
              case OperatorType.Numeric:
                RuleLoader.HandleNumericValue(dataSourceItems, sb, globalValue1, el.Value);
                globalValue1 = (string) null;
                break;
              case OperatorType.Date:
                sb.Append(DateTime.Parse(el.Value).ToString(format, (IFormatProvider) Thread.CurrentThread.CurrentCulture));
                break;
              case OperatorType.Time:
                sb.Append(DateTime.Parse("1/1/2010 " + el.Value).ToString(format));
                break;
              case OperatorType.Bool:
                sb.Append(el.Value == "true" ? labels.True : labels.False);
                break;
              case OperatorType.Enum:
                if (name2 != null)
                {
                  Type type2 = Assembly.Load(assemblyString).GetType(name2);
                  sb.Append(RuleLoader.GetEnumItemDisplayName(type2, el.Value));
                  break;
                }
                if (function == null)
                  function = SourceLoader.GetFieldByPropertyName(source, propertyName);
                IEnumerator enumerator = function.ChildNodes.GetEnumerator();
                try
                {
                  while (enumerator.MoveNext())
                  {
                    XmlNode xmlNode = (XmlNode) enumerator.Current;
                    if (xmlNode.Attributes["value"].Value == el.Value)
                    {
                      sb.Append(xmlNode.Attributes["displayName"].Value);
                      break;
                    }
                  }
                  break;
                }
                finally
                {
                  IDisposable disposable = enumerator as IDisposable;
                  if (disposable != null)
                    disposable.Dispose();
                }
              default:
                throw new InvalidRuleException(InvalidRuleException.ErrorIds.InvalidOrderOfNodes, new string[0]);
            }
          case ElementType.Clause:
            sb.Append(" ").Append(labels.GetClauseLabel(el.Value)).Append(" ");
            break;
          case ElementType.LeftParenthesis:
            sb.Append(labels.GetScopeLabel(Labels.Scope.SectionBegin));
            break;
          case ElementType.RightParenthesis:
            sb.Append(labels.GetScopeLabel(Labels.Scope.SectionEnd));
            break;
          case ElementType.LeftBracket:
            sb.Append(labels.GetScopeLabel(Labels.Scope.SectionBegin));
            break;
          case ElementType.RightBracket:
            sb.Append(labels.GetScopeLabel(Labels.Scope.SectionEnd));
            break;
          case ElementType.Calculation:
            if (el.CalType == CalculationType.Function)
            {
              switch (el.FuncType)
              {
                case FunctionType.Name:
                  // ISSUE: variable of the null type
                  __Null local3;
                  globalValue1 = (string) (local3 = null);
                  assemblyString = (string) local3;
                  name2 = (string) local3;
                  format = (string) local3;
                  propertyName = (string) local3;
                  num2 = 0;
                  index = -1;
                  name1 = el.Value;
                  token = el.Token;
                  function = SourceLoader.GetFunctionByToken(source, token);
                  sb.Append(function.Attributes["displayName"].Value);
                  XmlNode paramNode2 = SourceLoader.GetParamNode(function);
                  num1 = paramNode2 == null || paramNode2.ChildNodes.Count <= 0 ? 0 : RuleLoader.CountInputParams(paramNode2.ChildNodes);
                  if (num1 > 0)
                    sb.Append(" (");
                  XmlNode returnNode1 = SourceLoader.GetReturnNode(function);
                  switch (Converter.ClientStringToClientType(returnNode1.Attributes["type"].Value))
                  {
                    case OperatorType.Date:
                    case OperatorType.Time:
                      format = Encoder.Desanitize(returnNode1.Attributes["format"].Value);
                      break;
                    case OperatorType.Enum:
                      name2 = returnNode1.Attributes["class"].Value;
                      assemblyString = returnNode1.Attributes["assembly"].Value;
                      break;
                    case OperatorType.Numeric:
                      if (returnNode1.Attributes["dataSourceName"] != null)
                      {
                        globalValue1 = RuleLoader.HandleDataSources(dataSources, dataSourceItems, returnNode1.Attributes["dataSourceName"].Value);
                        break;
                      }
                      break;
                  }
                case FunctionType.End:
                  if (num1 > 0)
                  {
                    sb.Remove(sb.Length - 2, 2);
                    sb.Append(")");
                  }
                  num1 = 0;
                  index = -1;
                  break;
              }
            }
            else
            {
              RuleLoader.GetCalculationString(el, sb, source, labels);
              break;
            }
          case ElementType.Setter:
            sb.Append(" ").Append(labels.GetSetterLabel(el.Value)).Append(" ");
            break;
          case ElementType.LeftSource:
            sb.Append(labels.GetScopeLabel(Labels.Scope.CollectionBegin));
            ++i;
            RuleLoader.DoGetString(items, sourceXml, el.Value, labels, ruleDelegate, dataSources, sb, ref i);
            break;
          case ElementType.RightSource:
            sb.Append(labels.GetScopeLabel(Labels.Scope.CollectionEnd));
            return;
          case ElementType.Where:
            sb.Append(" ").Append(labels.GetWhereLabel()).Append(" ");
            break;
          case ElementType.Exists:
            sb.Append(" ").Append(labels.GetExistsLabel(el.SelType)).Append(" ");
            break;
        }
        ++i;
      }
    }

    private static string HandleDataSources(Dictionary<string, GetDataSourceDelegate> dataSources, Dictionary<string, List<DataSourceItem>> dataSourceItems, string dataSourceName)
    {
      if (dataSources == null || dataSources.Count <= 0)
        return (string) null;
      if (!dataSources.ContainsKey(dataSourceName))
        return (string) null;
      if (!dataSourceItems.ContainsKey(dataSourceName))
      {
        List<DataSourceItem> dataSourceItemList = dataSources[dataSourceName]();
        dataSourceItems.Add(dataSourceName, dataSourceItemList);
      }
      return dataSourceName;
    }

    private static void HandleNumericValue(Dictionary<string, List<DataSourceItem>> dataSourceItems, StringBuilder sb, string globalValue, string value)
    {
      if (!string.IsNullOrWhiteSpace(globalValue))
      {
        List<DataSourceItem> dataSourceItemList = dataSourceItems[globalValue];
        if (dataSourceItemList != null && dataSourceItemList.Count > 0)
        {
          bool flag = false;
          foreach (DataSourceItem dataSourceItem in dataSourceItemList)
          {
            if (dataSourceItem.ID.ToString() == value)
            {
              sb.Append(Encoder.Sanitize(dataSourceItem.Name));
              flag = true;
              break;
            }
          }
          if (flag)
            return;
          sb.Append(value);
        }
        else
          sb.Append(value);
      }
      else
        sb.Append(value);
    }

    private static CodeEffects.Rule.Client.Parameter GetParamByIndex(XmlNode source, ElementType type, string name, string token, int index)
    {
      XmlNode function = type != ElementType.Function ? SourceLoader.GetActionByToken(source, token) : SourceLoader.GetFunctionByToken(source, token);
      int num = 0;
      XmlNode paramNode = SourceLoader.GetParamNode(function);
      for (int index1 = 0; index1 < paramNode.ChildNodes.Count; ++index1)
      {
        if (paramNode.ChildNodes[index1].Name == "input")
        {
          if (num == index)
          {
            CodeEffects.Rule.Client.Parameter parameter = new CodeEffects.Rule.Client.Parameter();
            if (paramNode.ChildNodes[index1].Attributes["format"] != null)
              parameter.Settings.Format = paramNode.ChildNodes[index1].Attributes["format"].Value;
            if (paramNode.ChildNodes[index1].Attributes["class"] != null)
              parameter.Settings.TypeFullName = paramNode.ChildNodes[index1].Attributes["class"].Value;
            if (paramNode.ChildNodes[index1].Attributes["assembly"] != null)
              parameter.Settings.Assembly = paramNode.ChildNodes[index1].Attributes["assembly"].Value;
            if (paramNode.ChildNodes[index1].Attributes["dataSourceName"] != null)
              parameter.Settings.DataSourceName = paramNode.ChildNodes[index1].Attributes["dataSourceName"].Value;
            return parameter;
          }
          ++num;
        }
      }
      return (CodeEffects.Rule.Client.Parameter) null;
    }

    private static void GetCalculationString(Element el, StringBuilder sb, XmlNode source, Labels labels)
    {
      switch (el.CalType)
      {
        case CalculationType.Field:
          sb.Append(SourceLoader.GetFieldByPropertyName(source, el.Value).Attributes["displayName"].Value);
          break;
        case CalculationType.LeftParenthesis:
          sb.Append(labels.GetScopeLabel(Labels.Scope.SectionBegin));
          break;
        case CalculationType.RightParenthesis:
          sb.Append(labels.GetScopeLabel(Labels.Scope.SectionEnd));
          break;
        case CalculationType.Multiplication:
          sb.Append(" * ");
          break;
        case CalculationType.Division:
          sb.Append(" / ");
          break;
        case CalculationType.Addition:
          sb.Append(" + ");
          break;
        case CalculationType.Subtraction:
          sb.Append(" - ");
          break;
        case CalculationType.Number:
          sb.Append(el.Value);
          break;
      }
    }

    private static string GetEnumItemDisplayName(Type t, string value)
    {
      foreach (object obj in System.Enum.GetValues(t))
      {
        if (int.Parse(System.Enum.Format(t, obj, "D")).ToString() == value)
        {
          string name = System.Enum.GetName(t, obj);
          string str = name;
          object[] customAttributes = t.GetField(name).GetCustomAttributes(typeof (EnumItemAttribute), false);
          if (customAttributes.Length > 0)
            str = Encoder.Sanitize(((EnumItemAttribute) customAttributes[0]).DisplayName);
          return str;
        }
      }
      throw new MalformedXmlException(MalformedXmlException.ErrorIds.MissingEnumMember, new string[1]{ value });
    }

    private static int CountInputParams(XmlNodeList pars)
    {
      int num = 0;
      foreach (XmlNode par in pars)
      {
        if (par.Name == "input" || par.Name == "collection")
          ++num;
      }
      return num;
    }
  }
}
