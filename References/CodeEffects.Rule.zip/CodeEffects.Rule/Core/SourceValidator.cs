﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Core.SourceValidator
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using CodeEffects.Rule.Client;
using CodeEffects.Rule.Common;
using CodeEffects.Rule.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Xml;

namespace CodeEffects.Rule.Core
{
  internal sealed class SourceValidator
  {
    private SourceValidator()
    {
    }

    public static void Validate(XmlDocument source)
    {
      CodeEffects.Rule.Common.Xml.ValidateSchema(source, CodeEffects.Rule.Common.Xml.GetSourceNameByNamespace(source.DocumentElement.NamespaceURI));
    }

    internal static void ValidateField(XmlNode field)
    {
      switch (field.Name)
      {
        case "function":
          IEnumerator enumerator = field.ChildNodes.GetEnumerator();
          try
          {
            while (enumerator.MoveNext())
            {
              XmlNode field1 = (XmlNode) enumerator.Current;
              if (field1.Name == "parameters")
              {
                foreach (XmlNode childNode in field1.ChildNodes)
                {
                  switch (childNode.Name)
                  {
                    case "constant":
                      SourceValidator.ValidateConstantParam(childNode);
                      continue;
                    case "input":
                      switch (Converter.ClientStringToClientType(childNode.Attributes["type"].Value))
                      {
                        case OperatorType.String:
                        case OperatorType.Numeric:
                          SourceValidator.ValidateFieldDataType(childNode, Converter.ClientStringToClientType(childNode.Attributes["type"].Value));
                          continue;
                        default:
                          continue;
                      }
                    case "collection":
                      if (childNode.ChildNodes.Count != 1)
                        throw new SourceException(SourceException.ErrorIds.InvalidCollectionParameterXML, new string[0]);
                      if (Converter.StringToCollectionType(childNode.ChildNodes[0].Name) == CollectionType.Value)
                      {
                        SourceValidator.ValidateFieldDataType(childNode.ChildNodes[0], Converter.ClientStringToClientType(childNode.ChildNodes[0].Attributes["type"].Value));
                        continue;
                      }
                      continue;
                    default:
                      continue;
                  }
                }
              }
              else if (field1.Name == "returns")
                SourceValidator.ValidateFieldDataType(field1, Converter.ClientStringToClientType(field1.Attributes["type"].Value));
            }
            break;
          }
          finally
          {
            IDisposable disposable = enumerator as IDisposable;
            if (disposable != null)
              disposable.Dispose();
          }
        case "collection":
          if (field.ChildNodes.Count != 1)
            throw new SourceException(SourceException.ErrorIds.InvalidCollectionParameterXML, new string[0]);
          if (Converter.StringToCollectionType(field.ChildNodes[0].Name) != CollectionType.Value)
            break;
          SourceValidator.ValidateFieldDataType(field.ChildNodes[0], Converter.ClientStringToClientType(field.ChildNodes[0].Attributes["type"].Value));
          break;
        case "bool":
        case "date":
        case "enum":
        case "numeric":
        case "string":
        case "time":
          SourceValidator.ValidateFieldDataType(field, Converter.ClientStringToClientType(field.Name));
          break;
        default:
          throw new MalformedXmlException(MalformedXmlException.ErrorIds.InvalidFieldName, new string[1]{ field.Name });
      }
    }

    internal static void ValidateActions(XmlNode actions)
    {
      if (actions == null)
        return;
      foreach (XmlNode childNode in actions.ChildNodes)
        SourceValidator.ValidateAction(childNode);
    }

    internal static bool IsMethodValid(MethodInfo m, bool checkReturn)
    {
      if (m == (MethodInfo) null || m.IsPrivate || (m.IsSpecialName || m.IsAbstract) || m.IsConstructor)
        return false;
      if (checkReturn)
      {
        if (m.ReturnType == typeof (void) || !SourceValidator.IsAcceptedValueType(m.ReturnType))
          return false;
      }
      else if (m.ReturnType != typeof (void))
        return false;
      return true;
    }

    internal static bool IsDataSourceMethodValid(MethodInfo m)
    {
      return !(m == (MethodInfo) null) && !m.IsPrivate && (!m.IsSpecialName && m.GetParameters().Length <= 0) && (!m.ContainsGenericParameters && !m.IsAbstract && (!m.IsConstructor && !m.IsGenericMethod)) && (!m.IsGenericMethodDefinition && TypeUtils.AreReferenceAssignable(typeof (ICollection<DataSourceItem>), m.ReturnType));
    }

    internal static bool IsParameterValid(ParameterInfo pi)
    {
      return SourceValidator.IsParameterValid(pi, (Type) null);
    }

    internal static bool IsParameterValid(ParameterInfo pi, Type sourceType)
    {
      Type[] interfaces = pi.ParameterType.GetInterfaces();
      if (((IEnumerable<Type>) interfaces).Contains<Type>(typeof (IDictionary)))
        return false;
      if (((IEnumerable<Type>) interfaces).Contains<Type>(typeof (IEnumerable)))
        return true;
      bool flag = TypeUtils.AreEquivalent(pi.ParameterType, typeof (object)) || TypeUtils.IsSameOrSubclass(pi.ParameterType, sourceType);
      return (pi.ParameterType.IsValueType || !(sourceType != (Type) null) || flag) && ((flag || SourceValidator.IsAcceptedValueType(pi.ParameterType)) && (!pi.IsOptional && !pi.IsOut));
    }

    internal static bool IsAcceptedValueType(Type type)
    {
      if (type == typeof (Guid))
        return false;
      if (type == typeof (string))
        return true;
      if (!type.IsValueType)
        return false;
      if (!type.IsEnum && !(type == typeof (DateTime)) && (!(type == typeof (TimeSpan)) && !(type == typeof (Decimal))) && !type.IsPrimitive)
        return type.IsGenericType;
      return true;
    }

    internal static bool IsOperatorTypeUsed(XmlNodeList fields, OperatorType type, out bool isNullable)
    {
      bool flag1 = false;
      bool flag2 = false;
      foreach (XmlNode field in fields)
      {
        if (field.NodeType != XmlNodeType.Comment)
        {
          switch (field.Name)
          {
            case "function":
              IEnumerator enumerator = field.ChildNodes.GetEnumerator();
              try
              {
                while (enumerator.MoveNext())
                {
                  XmlNode xmlNode = (XmlNode) enumerator.Current;
                  if (xmlNode.NodeType != XmlNodeType.Comment && xmlNode.Name == "returns" && (type == OperatorType.Bool || type == Converter.ClientStringToClientType(xmlNode.Attributes["type"].Value)))
                  {
                    if (!flag2 && xmlNode.Attributes["nullable"].Value == "true")
                      flag2 = true;
                    flag1 = true;
                  }
                }
                continue;
              }
              finally
              {
                IDisposable disposable = enumerator as IDisposable;
                if (disposable != null)
                  disposable.Dispose();
              }
            default:
              OperatorType clientType = Converter.ClientStringToClientType(field.Name);
              if (type == OperatorType.Bool || type == clientType)
              {
                if (clientType == OperatorType.Collection)
                  flag2 = true;
                else if (!flag2 && field.Attributes["nullable"].Value == "true")
                  flag2 = true;
                flag1 = true;
                continue;
              }
              continue;
          }
        }
      }
      isNullable = flag2;
      return flag1;
    }

    private static void ValidateAction(XmlNode action)
    {
      if (action.ChildNodes.Count <= 0)
        return;
      foreach (XmlNode childNode in action.ChildNodes[0].ChildNodes)
      {
        switch (childNode.Name)
        {
          case "constant":
            SourceValidator.ValidateConstantParam(childNode);
            continue;
          case "input":
            switch (Converter.ClientStringToClientType(childNode.Attributes["type"].Value))
            {
              case OperatorType.String:
              case OperatorType.Numeric:
                SourceValidator.ValidateFieldDataType(childNode, Converter.ClientStringToClientType(childNode.Attributes["type"].Value));
                continue;
              default:
                continue;
            }
          case "collection":
            if (childNode.ChildNodes.Count != 1)
              throw new SourceException(SourceException.ErrorIds.InvalidCollectionParameterXML, new string[0]);
            if (Converter.StringToCollectionType(childNode.ChildNodes[0].Name) == CollectionType.Value)
            {
              SourceValidator.ValidateFieldDataType(childNode.ChildNodes[0], Converter.ClientStringToClientType(childNode.ChildNodes[0].Attributes["type"].Value));
              continue;
            }
            continue;
          default:
            continue;
        }
      }
    }

    private static void ValidateConstantParam(XmlNode param)
    {
      switch (param.Attributes["type"].Value)
      {
        case "string":
          if ((long) param.Attributes["value"].Value.Trim().Length <= 256L)
            break;
          throw new MalformedXmlException(MalformedXmlException.ErrorIds.InvalidStringParamLength, new string[0]);
        case "bool":
          if (!(param.Attributes["value"].Value != "true") || !(param.Attributes["value"].Value != "false"))
            break;
          throw new MalformedXmlException(MalformedXmlException.ErrorIds.InvalidBoolParamValue, new string[0]);
        case "date":
          DateTime result1 = DateTime.MinValue;
          if (DateTime.TryParse(param.Attributes["value"].Value, (IFormatProvider) Thread.CurrentThread.CurrentCulture, DateTimeStyles.None, out result1))
            break;
          throw new MalformedXmlException(MalformedXmlException.ErrorIds.InvalidDateParamValue, new string[0]);
        case "time":
          DateTime result2 = DateTime.MinValue;
          if (DateTime.TryParse("01/01/2010 " + param.Attributes["value"].Value, out result2))
            break;
          throw new MalformedXmlException(MalformedXmlException.ErrorIds.InvalidTimeParamValue, new string[0]);
        case "numeric":
          Decimal result3 = new Decimal(0);
          if (Decimal.TryParse(param.Attributes["value"].Value, out result3))
            break;
          throw new MalformedXmlException(MalformedXmlException.ErrorIds.InvalidNumericParamFormat, new string[0]);
        case "collection":
          throw new MalformedXmlException(MalformedXmlException.ErrorIds.CollectionsAsConstantParams, new string[0]);
      }
    }

    private static void ValidateFieldDataType(XmlNode field, OperatorType type)
    {
      switch (Converter.ClientStringToClientType(field.Attributes["type"] == null ? field.Name : field.Attributes["type"].Value))
      {
        case OperatorType.String:
          if (field.Attributes["valueInputType"] == null || !(field.Attributes["valueInputType"].Value != "fields"))
            break;
          int result1 = 0;
          if (!int.TryParse(field.Attributes["maxLength"].Value, out result1))
            throw new MalformedXmlException(MalformedXmlException.ErrorIds.MissingMaxlengthAttribute, new string[0]);
          if ((long) result1 <= 256L)
            break;
          throw new MalformedXmlException(MalformedXmlException.ErrorIds.MissingMaxlengthAttribute, new string[0]);
        case OperatorType.Numeric:
          Decimal result2 = new Decimal(0);
          Decimal result3 = new Decimal(0);
          if (!Decimal.TryParse(field.Attributes["min"].Value, out result2))
            throw new MalformedXmlException(MalformedXmlException.ErrorIds.MissingMinAttribute, new string[0]);
          if (!Decimal.TryParse(field.Attributes["max"].Value, out result3))
            throw new MalformedXmlException(MalformedXmlException.ErrorIds.MissingMaxAttribute, new string[0]);
          if (!(result2 >= result3))
            break;
          throw new MalformedXmlException(MalformedXmlException.ErrorIds.InvalidMinValue, new string[0]);
      }
    }
  }
}
