﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Core.Evaluator
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Xml.Linq;

namespace CodeEffects.Rule.Core
{
  public class Evaluator : EvaluatorBase
  {
    private Dictionary<string, Predicate> predicates = new Dictionary<string, Predicate>();

    public Evaluator(Type sourceType, string rulesetXml, GetRuleDelegate getRule = null, int maxIterations = -1)
      : base(sourceType, rulesetXml, maxIterations, getRule)
    {
    }

    public Evaluator(Type sourceType, string rulesetXml, EvaluationParameters parameters)
      : base(sourceType, rulesetXml, parameters)
    {
    }

    protected override void CompileRule(XElement rule)
    {
      ExpressionBuilder expressionBuilder = new ExpressionBuilder(this.sourceType, new GetRuleInternalDelegate(((EvaluatorBase) this).GetRule));
      expressionBuilder.MaxIterations = this.parameters.MaxIterations;
      expressionBuilder.PerformNullChecks = this.parameters.PerformNullChecks;
      expressionBuilder.EvaluationScope = this.parameters.Scope;
      expressionBuilder.ShortCircuit = this.parameters.ShortCircuit;
      LambdaExpression predicateExpression = expressionBuilder.GetPredicateExpression(rule);
      this.LogExpression((Expression) predicateExpression);
      Delegate @delegate = expressionBuilder.CompileRule(predicateExpression);
      this.predicates[(string) rule.Attribute((XName) "id")] = new Predicate()
      {
        Delegate = @delegate,
        Expression = predicateExpression
      };
    }

    public bool Evaluate(object source, string ruleId = null)
    {
      this.DelayIfDemo();
      if (ruleId == null)
        return (bool) this.predicates.First<KeyValuePair<string, Predicate>>().Value.Delegate.DynamicInvoke(source);
      return (bool) this.predicates[ruleId].Delegate.DynamicInvoke(source);
    }

    public bool Evaluate(object source, int ruleIndex)
    {
      this.DelayIfDemo();
      return (bool) this.predicates.ElementAt<KeyValuePair<string, Predicate>>(ruleIndex).Value.Delegate.DynamicInvoke(source);
    }

    public bool Evaluate(object source, EvaluationScope scope, bool shortCircuit = true)
    {
      this.DelayIfDemo();
      bool flag = scope == EvaluationScope.All;
      for (int index = 0; index < this.predicates.Count; ++index)
      {
        if (scope == EvaluationScope.All)
        {
          flag = ((flag ? 1 : 0) & ((bool) this.predicates.ElementAt<KeyValuePair<string, Predicate>>(index).Value.Delegate.DynamicInvoke(source) ? 1 : 0)) != 0;
          if (shortCircuit && !flag)
            break;
        }
        else
        {
          flag = ((flag ? 1 : 0) | ((bool) this.predicates.ElementAt<KeyValuePair<string, Predicate>>(index).Value.Delegate.DynamicInvoke(source) ? 1 : 0)) != 0;
          if (shortCircuit && flag)
            break;
        }
      }
      return flag;
    }

    internal Delegate GetPredicate(string ruleId)
    {
      if (ruleId == null)
        return this.predicates.First<KeyValuePair<string, Predicate>>().Value.Delegate;
      return this.predicates[ruleId].Delegate;
    }

    internal Delegate GetPredicate(int ruleIndex)
    {
      return this.predicates.ElementAt<KeyValuePair<string, Predicate>>(ruleIndex).Value.Delegate;
    }

    internal LambdaExpression GetPredicateExpression(string ruleId)
    {
      if (ruleId == null)
        return this.predicates.First<KeyValuePair<string, Predicate>>().Value.Expression;
      return this.predicates[ruleId].Expression;
    }

    internal LambdaExpression GetPredicateExpression(int ruleIndex)
    {
      return this.predicates.ElementAt<KeyValuePair<string, Predicate>>(ruleIndex).Value.Expression;
    }
  }
}
