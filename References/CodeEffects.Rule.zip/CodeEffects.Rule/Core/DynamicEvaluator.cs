﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Core.DynamicEvaluator
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using System;
using System.Collections.Generic;

namespace CodeEffects.Rule.Core
{
  public class DynamicEvaluator
  {
    protected string rulesetXml;
    protected GetRuleDelegate getRule;
    private Dictionary<Type, Evaluator> evaluators;

    internal bool SuspendDemoDelay { get; set; }

    public DynamicEvaluator(string rulesetXml, GetRuleDelegate getRule = null)
    {
      this.rulesetXml = rulesetXml;
      this.getRule = getRule;
      this.evaluators = new Dictionary<Type, Evaluator>();
    }

    protected void DelayIfDemo()
    {
      if (this.SuspendDemoDelay)
        return;
      Vector.DelayIfDemo();
    }

    public bool Evaluate(object source, string ruleId = null)
    {
      this.DelayIfDemo();
      Type type = source.GetType();
      Evaluator evaluator;
      if (this.evaluators.ContainsKey(type))
      {
        evaluator = this.evaluators[type];
      }
      else
      {
        evaluator = new Evaluator(source.GetType(), this.rulesetXml, this.getRule, -1);
        this.evaluators.Add(source.GetType(), evaluator);
      }
      return evaluator.Evaluate(source, ruleId);
    }

    [Obsolete("Consider using a Evaluate overload with the ruleId parameter instead.")]
    public bool Evaluate(object source, int ruleIndex)
    {
      this.DelayIfDemo();
      Type type = source.GetType();
      Evaluator evaluator;
      if (this.evaluators.ContainsKey(type))
      {
        evaluator = this.evaluators[type];
      }
      else
      {
        evaluator = new Evaluator(source.GetType(), this.rulesetXml, this.getRule, -1);
        this.evaluators.Add(source.GetType(), evaluator);
      }
      return evaluator.Evaluate(source, ruleIndex);
    }

    public bool Evaluate(object source, EvaluationScope scope, bool shortCircuit = true)
    {
      this.DelayIfDemo();
      Type type = source.GetType();
      Evaluator evaluator;
      if (this.evaluators.ContainsKey(type))
      {
        evaluator = this.evaluators[type];
      }
      else
      {
        evaluator = new Evaluator(source.GetType(), this.rulesetXml, this.getRule, -1);
        this.evaluators.Add(source.GetType(), evaluator);
      }
      return evaluator.Evaluate(source, scope, shortCircuit);
    }
  }
}
