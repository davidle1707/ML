﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Core.RecursionVisitor
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using CodeEffects.Rule.Common;
using System.Collections.Generic;
using System.Xml.Linq;

namespace CodeEffects.Rule.Core
{
  internal class RecursionVisitor
  {
    private Dictionary<string, XElement> ruleCache;
    private GetRuleDelegate getRule;
    private XNamespace ns;
    private XElement root;
    private Stack<string> recursionStack;

    public Stack<string> RecursionStack
    {
      get
      {
        return this.recursionStack;
      }
    }

    public RecursionVisitor(string ruleXml, GetRuleDelegate getRule = null)
    {
      this.getRule = getRule;
      this.ruleCache = new Dictionary<string, XElement>();
      this.root = this.LoadRuleset(ruleXml);
      this.recursionStack = new Stack<string>();
    }

    private XElement LoadRuleset(string ruleXml)
    {
      XElement xelement1 = XElement.Parse(ruleXml);
      this.ns = xelement1.GetDefaultNamespace();
      XElement xelement2 = (XElement) null;
      if (xelement1.Name == this.ns + "codeeffects")
      {
        foreach (XElement element in xelement1.Elements(this.ns + "rule"))
        {
          if (xelement2 == null)
            xelement2 = element;
          if (!this.ruleCache.ContainsKey((string) element.Attribute((XName) "id")))
            this.ruleCache.Add((string) element.Attribute((XName) "id"), element);
        }
      }
      else
      {
        if (!(xelement1.Name == this.ns + "rule"))
          throw new InvalidRuleException(InvalidRuleException.ErrorIds.RuleXMLIsInvalid, new string[0]);
        xelement2 = xelement1;
        if (!this.ruleCache.ContainsKey((string) xelement2.Attribute((XName) "id")))
          this.ruleCache.Add((string) xelement2.Attribute((XName) "id"), xelement2);
      }
      return xelement2;
    }

    public bool HasRecursion()
    {
      this.recursionStack.Clear();
      return this.HasRecursion(this.root);
    }

    private bool HasRecursion(XElement root)
    {
      if (root == null)
        return false;
      if (this.recursionStack.Contains((string) root.Attribute((XName) "id")))
        return true;
      this.recursionStack.Push((string) root.Attribute((XName) "id"));
      XNamespace defaultNamespace = root.GetDefaultNamespace();
      foreach (XElement descendant in root.Descendants(defaultNamespace + "rule"))
      {
        XElement rule = this.GetRule((string) descendant.Attribute((XName) "id"));
        if (rule == null)
          throw new InvalidRuleException(InvalidRuleException.ErrorIds.ReferencedRuleNotFound, new string[1]{ (string) descendant.Attribute((XName) "id") });
        if (this.HasRecursion(rule))
          return true;
      }
      this.recursionStack.Pop();
      return false;
    }

    protected XElement GetRule(string ruleId)
    {
      XElement xelement = (XElement) null;
      if (this.ruleCache.ContainsKey(ruleId))
        return this.ruleCache[ruleId];
      if (this.getRule != null)
      {
        string ruleXml = this.getRule(ruleId);
        if (!string.IsNullOrEmpty(ruleXml))
          xelement = this.LoadRuleset(ruleXml);
      }
      return xelement;
    }
  }
}
