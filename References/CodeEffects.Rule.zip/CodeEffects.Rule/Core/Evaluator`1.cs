﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Core.Evaluator`1
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Xml.Linq;

namespace CodeEffects.Rule.Core
{
  public class Evaluator<TSource> : EvaluatorBase
  {
    private Dictionary<string, Predicate<TSource>> predicates = new Dictionary<string, Predicate<TSource>>();

    public Evaluator(string rulesetXml, GetRuleDelegate getRule = null, int maxIterations = -1)
      : base(typeof (TSource), rulesetXml, maxIterations, getRule)
    {
    }

    public Evaluator(string rulesetXml, EvaluationParameters parameters)
      : base(typeof (TSource), rulesetXml, parameters)
    {
    }

    protected override void CompileRule(XElement rule)
    {
      ExpressionBuilder<TSource> expressionBuilder = new ExpressionBuilder<TSource>(new GetRuleInternalDelegate(((EvaluatorBase) this).GetRule));
      expressionBuilder.MaxIterations = this.parameters.MaxIterations;
      expressionBuilder.PerformNullChecks = this.parameters.PerformNullChecks;
      expressionBuilder.EvaluationScope = this.parameters.Scope;
      expressionBuilder.ShortCircuit = this.parameters.ShortCircuit;
      Expression<Func<TSource, bool>> predicateExpression = expressionBuilder.GetPredicateExpression(rule);
      this.LogExpression((Expression) predicateExpression);
      Func<TSource, bool> func = expressionBuilder.CompileRule(predicateExpression);
      this.predicates[(string) rule.Attribute((XName) "id")] = new Predicate<TSource>()
      {
        Delegate = func,
        Expression = predicateExpression
      };
    }

    public bool Evaluate(TSource source, string ruleId = null)
    {
      this.DelayIfDemo();
      if (ruleId == null)
        return this.predicates.First<KeyValuePair<string, Predicate<TSource>>>().Value.Delegate(source);
      return this.predicates[ruleId].Delegate(source);
    }

    public bool Evaluate(TSource source, int ruleIndex)
    {
      this.DelayIfDemo();
      return this.predicates.ElementAt<KeyValuePair<string, Predicate<TSource>>>(ruleIndex).Value.Delegate(source);
    }

    public bool Evaluate(TSource source, EvaluationScope scope, bool shortCircuit = true)
    {
      this.DelayIfDemo();
      bool flag = scope == EvaluationScope.All;
      for (int index = 0; index < this.predicates.Count; ++index)
      {
        if (scope == EvaluationScope.All)
        {
          flag &= this.predicates.ElementAt<KeyValuePair<string, Predicate<TSource>>>(index).Value.Delegate(source);
          if (shortCircuit && !flag)
            break;
        }
        else
        {
          flag |= this.predicates.ElementAt<KeyValuePair<string, Predicate<TSource>>>(index).Value.Delegate(source);
          if (shortCircuit && flag)
            break;
        }
      }
      return flag;
    }

    internal Func<TSource, bool> GetPredicate(string ruleId)
    {
      if (ruleId == null)
        return this.predicates.First<KeyValuePair<string, Predicate<TSource>>>().Value.Delegate;
      return this.predicates[ruleId].Delegate;
    }

    internal Func<TSource, bool> GetPredicate(int ruleIndex)
    {
      return this.predicates.ElementAt<KeyValuePair<string, Predicate<TSource>>>(ruleIndex).Value.Delegate;
    }

    internal Expression<Func<TSource, bool>> GetPredicateExpression(string ruleId)
    {
      if (ruleId == null)
        return this.predicates.First<KeyValuePair<string, Predicate<TSource>>>().Value.Expression;
      return this.predicates[ruleId].Expression;
    }

    internal Expression<Func<TSource, bool>> GetPredicateExpression(int ruleIndex)
    {
      return this.predicates.ElementAt<KeyValuePair<string, Predicate<TSource>>>(ruleIndex).Value.Expression;
    }
  }
}
