﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Core.Visitor
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using System;
using System.Linq.Expressions;

namespace CodeEffects.Rule.Core
{
  internal class Visitor : ExpressionVisitor
  {
    private int indent;

    public override Expression Visit(Expression node)
    {
      Console.Write(new string('\t', this.indent));
      if (node == null)
        Console.WriteLine("NULL");
      else
        Console.WriteLine("{1} : {0}", (object) node.ToString(), (object) node.NodeType.ToString());
      ++this.indent;
      Expression expression = base.Visit(node);
      --this.indent;
      return expression;
    }
  }
}
