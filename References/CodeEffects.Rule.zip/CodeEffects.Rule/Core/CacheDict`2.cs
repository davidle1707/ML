﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Core.CacheDict`2
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using System.Collections.Generic;

namespace CodeEffects.Rule.Core
{
  internal class CacheDict<TKey, TValue>
  {
    private readonly Dictionary<TKey, CacheDict<TKey, TValue>.KeyInfo<TKey, TValue>> _dict;
    private readonly LinkedList<TKey> _list;
    private readonly int _maxSize;

    internal TValue this[TKey key]
    {
      get
      {
        TValue obj;
        if (!this.TryGetValue(key, out obj))
          throw new KeyNotFoundException();
        return obj;
      }
      set
      {
        this.Add(key, value);
      }
    }

    internal CacheDict(int maxSize)
    {
      this._dict = new Dictionary<TKey, CacheDict<TKey, TValue>.KeyInfo<TKey, TValue>>();
      this._list = new LinkedList<TKey>();
      this._maxSize = maxSize;
    }

    internal void Add(TKey key, TValue value)
    {
      CacheDict<TKey, TValue>.KeyInfo<TKey, TValue> keyInfo;
      if (this._dict.TryGetValue(key, out keyInfo))
        this._list.Remove(keyInfo.List);
      else if (this._list.Count == this._maxSize)
      {
        LinkedListNode<TKey> last = this._list.Last;
        this._list.RemoveLast();
        this._dict.Remove(last.Value);
      }
      LinkedListNode<TKey> linkedListNode = new LinkedListNode<TKey>(key);
      this._list.AddFirst(linkedListNode);
      this._dict[key] = new CacheDict<TKey, TValue>.KeyInfo<TKey, TValue>(value, linkedListNode);
    }

    internal bool TryGetValue(TKey key, out TValue value)
    {
      CacheDict<TKey, TValue>.KeyInfo<TKey, TValue> keyInfo;
      if (this._dict.TryGetValue(key, out keyInfo))
      {
        LinkedListNode<TKey> node = keyInfo.List;
        if (node.Previous != null)
        {
          this._list.Remove(node);
          this._list.AddFirst(node);
        }
        value = keyInfo.Value;
        return true;
      }
      value = default (TValue);
      return false;
    }

    private struct KeyInfo<TKey_internal, TValue_internal>
    {
      internal readonly TValue_internal Value;
      internal readonly LinkedListNode<TKey_internal> List;

      internal KeyInfo(TValue_internal value, LinkedListNode<TKey_internal> list)
      {
        this.Value = value;
        this.List = list;
      }
    }
  }
}
