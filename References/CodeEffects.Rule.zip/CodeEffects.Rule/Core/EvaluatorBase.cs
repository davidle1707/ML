﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Core.EvaluatorBase
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using CodeEffects.Rule.Common;
using System;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Xml.Linq;

namespace CodeEffects.Rule.Core
{
  public class EvaluatorBase
  {
    protected EvaluationParameters parameters = new EvaluationParameters();
    protected Type sourceType;
    protected XElement ruleSet;

    public static TextWriter Log { get; set; }

    internal bool SuspendDemoDelay { get; set; }

    internal EvaluatorBase(Type sourceType, string rulesetXml, EvaluationParameters parameters)
    {
      this.sourceType = sourceType;
      this.ruleSet = XElement.Parse(rulesetXml);
      this.parameters = parameters;
      XNamespace defaultNamespace = this.ruleSet.GetDefaultNamespace();
      int num = 0;
      foreach (XElement element in this.ruleSet.Elements(defaultNamespace + "rule"))
      {
        string str1 = (string) element.Attribute((XName) "id");
        string typeName = (string) element.Attribute((XName) "type");
        if (string.IsNullOrWhiteSpace(str1))
          num.ToString();
        if (!string.IsNullOrWhiteSpace(typeName) && typeName != sourceType.AssemblyQualifiedName)
        {
          string[] strArray = typeName.Split(new char[1]{ ',' }, 2);
          string name = strArray[0];
          string str2 = strArray.Length > 1 ? new AssemblyName(strArray[1]).FullName : "";
          Type type = (Type) null;
          if (str2 == sourceType.Assembly.FullName)
            type = sourceType.Assembly.GetType(name, false, true);
          if (type == (Type) null)
            type = Type.GetType(typeName, false, true);
          if (type == (Type) null || !type.IsAssignableFrom(sourceType))
            continue;
        }
        this.CompileRule(element);
        ++num;
      }
      if (num == 0)
        throw new EvaluationException(EvaluationException.ErrorIds.NoRulesWithGivenType, new string[1]{ sourceType.AssemblyQualifiedName });
    }

    internal EvaluatorBase(Type sourceType, string rulesetXml, int maxIterations, GetRuleDelegate getRule = null)
      : this(sourceType, rulesetXml, new EvaluationParameters() { RuleGetter = getRule, MaxIterations = maxIterations })
    {
    }

    protected void DelayIfDemo()
    {
      if (this.SuspendDemoDelay)
        return;
      Vector.DelayIfDemo();
    }

    protected void LogExpression(Expression expression)
    {
      if (EvaluatorBase.Log == null)
        return;
      EvaluatorBase.Log.WriteLine("EXPRESSION:");
      EvaluatorBase.Log.WriteLine((object) expression);
      EvaluatorBase.Log.WriteLine();
      EvaluatorBase.Log.WriteLine("DEBUG EXPRESSION:");
      EvaluatorBase.Log.WriteLine(typeof (Expression).GetProperty("DebugView", BindingFlags.Instance | BindingFlags.NonPublic).GetValue((object) expression, (object[]) null));
      EvaluatorBase.Log.WriteLine();
    }

    protected virtual void CompileRule(XElement rule)
    {
    }

    protected XElement GetRule(string ruleId)
    {
      if (this.parameters.RuleGetter != null)
        return XElement.Parse(this.parameters.RuleGetter(ruleId));
      return this.ruleSet.Elements(this.ruleSet.GetDefaultNamespace() + "rule").Where<XElement>((Func<XElement, bool>) (x => (string) x.Attribute((XName) "id") == ruleId)).FirstOrDefault<XElement>();
    }
  }
}
