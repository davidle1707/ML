﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Core.ConversionVisitor
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;

namespace CodeEffects.Rule.Core
{
  internal class ConversionVisitor : ExpressionVisitor
  {
    protected override Expression VisitBinary(BinaryExpression node)
    {
      if (node.NodeType == ExpressionType.NotEqual && node.Left.NodeType == ExpressionType.Call)
      {
        MethodCallExpression methodCallExpression = node.Left as MethodCallExpression;
        if (methodCallExpression.Method.Name == "IndexOf" && methodCallExpression.Arguments.Count == 2 && (methodCallExpression.Arguments[1].NodeType == ExpressionType.Constant && (methodCallExpression.Arguments[1] as ConstantExpression).Type == typeof (StringComparison)) && (node.Right.NodeType == ExpressionType.Constant && (int) (node.Right as ConstantExpression).Value == -1))
        {
          MethodInfo method = ((IEnumerable<MethodInfo>) typeof (string).GetMethods()).Where<MethodInfo>((Func<MethodInfo, bool>) (x => x.Name == "Contains")).First<MethodInfo>();
          return this.Visit((Expression) Expression.Call(methodCallExpression.Object, method, new Expression[1]{ methodCallExpression.Arguments[0] }));
        }
      }
      return base.VisitBinary(node);
    }

    protected override Expression VisitMethodCall(MethodCallExpression method)
    {
      if (method.Method.Name == "Equals" && method.Arguments.Count == 3 && (method.Arguments[2].NodeType == ExpressionType.Constant && (method.Arguments[2] as ConstantExpression).Type == typeof (StringComparison)))
        return this.Visit((Expression) Expression.Call(typeof (string).GetMethod("Equals", new Type[2]{ typeof (string), typeof (string) }), method.Arguments[0], method.Arguments[1]));
      if (!(method.Method.Name == "StartsWith") && !(method.Method.Name == "EndsWith") || (method.Arguments.Count != 2 || method.Arguments[1].NodeType != ExpressionType.Constant) || !((method.Arguments[1] as ConstantExpression).Type == typeof (StringComparison)))
        return base.VisitMethodCall(method);
      MethodInfo method1 = ((IEnumerable<MethodInfo>) typeof (string).GetMethods()).Where<MethodInfo>((Func<MethodInfo, bool>) (x => x.Name == method.Method.Name)).First<MethodInfo>();
      return this.Visit((Expression) Expression.Call(method.Object, method1, new Expression[1]{ method.Arguments[0] }));
    }
  }
}
