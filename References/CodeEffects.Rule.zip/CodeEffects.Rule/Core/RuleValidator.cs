﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Core.RuleValidator
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using CodeEffects.Rule.Client;
using CodeEffects.Rule.Common;
using CodeEffects.Rule.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Threading;
using System.Xml;

namespace CodeEffects.Rule.Core
{
  internal sealed class RuleValidator
  {
    private static NumberStyles defaultNumericStyles
    {
      get
      {
        return NumberStyles.AllowLeadingSign | NumberStyles.AllowDecimalPoint;
      }
    }

    private RuleValidator()
    {
    }

    internal static List<InvalidElement> Validate(List<Element> items, XmlDocument source, bool noActionsAllowed)
    {
      return RuleValidator.DoValidate((XmlDocument) null, items, source, noActionsAllowed);
    }

    internal static List<InvalidElement> Validate(XmlDocument help, List<Element> items, XmlDocument source, bool noActionsAllowed)
    {
      return RuleValidator.DoValidate(help, items, source, noActionsAllowed);
    }

    internal static void EnsureTokens(List<Element> items, XmlDocument sourceXml)
    {
      XmlNode source = SourceLoader.GetSourceNode(sourceXml, sourceXml.DocumentElement.ChildNodes[0].Attributes["name"] == null ? (string) null : sourceXml.DocumentElement.ChildNodes[0].Attributes["name"].Value);
      foreach (Element element in items)
      {
        if (element.Type == ElementType.LeftSource || element.Type == ElementType.RightSource)
          source = SourceLoader.GetSourceNodeByToken(sourceXml, element.Value);
        else if (element.Type == ElementType.Function || element.Type == ElementType.Action || element.Type == ElementType.Calculation && element.CalType == CalculationType.Function)
        {
          if (element.FuncType != FunctionType.Name)
          {
            if (element.FuncType != FunctionType.End)
              continue;
          }
          try
          {
            XmlNode xmlNode = element.Type != ElementType.Action ? SourceLoader.GetFunctionByToken(source, element.Value) : SourceLoader.GetActionByToken(source, element.Value);
            element.Token = element.Value;
            element.Value = xmlNode.Attributes["methodName"].Value;
          }
          catch (SourceException ex)
          {
            if (string.IsNullOrWhiteSpace(element.Value))
              element.Value = "Unknown method";
            element.NotFound = true;
          }
        }
      }
    }

    internal static void ForceTokens(List<Element> items)
    {
      foreach (Element element in items)
      {
        if ((element.Type == ElementType.Function || element.Type == ElementType.Action || element.Type == ElementType.Calculation && element.CalType == CalculationType.Function) && ((element.FuncType == FunctionType.Name || element.FuncType == FunctionType.End) && !string.IsNullOrWhiteSpace(element.Token)))
          element.Value = element.Token;
      }
    }

    internal static void EnsureIgnoredProperties(List<Element> items, XmlDocument source)
    {
      RuleValidator.DoEnsureIgnoredProperties(items, source);
    }

    internal static void EnsureValues(List<Element> items)
    {
      RuleValidator.DoEnsureValues(items);
    }

    internal static void EnsureValuesForClient(List<Element> items)
    {
      for (int index = 0; index < items.Count; ++index)
      {
        Element element = items[index];
        switch (element.Type)
        {
          case ElementType.Function:
          case ElementType.Action:
            if (element.FuncType == FunctionType.Param && element.InpType != InputType.Field)
            {
              switch (element.Oper)
              {
                case OperatorType.Numeric:
                  element.Value = RuleValidator.GetNumericDisplayString(element.Value);
                  continue;
                case OperatorType.Date:
                  element.Value = RuleValidator.GetDateValueString(element.Value);
                  continue;
                default:
                  continue;
              }
            }
            else
              break;
          case ElementType.Value:
            if (element.InpType != InputType.Field)
            {
              switch (element.Oper)
              {
                case OperatorType.Numeric:
                  element.Value = RuleValidator.GetNumericDisplayString(element.Value);
                  continue;
                case OperatorType.Date:
                  element.Value = RuleValidator.GetDateValueString(element.Value);
                  continue;
                default:
                  continue;
              }
            }
            else
              break;
          case ElementType.Calculation:
            if (element.CalType == CalculationType.Number)
            {
              element.Value = RuleValidator.GetNumericDisplayString(element.Value);
              break;
            }
            break;
        }
      }
    }

    internal static List<InvalidElement> CheckRecursion(List<Element> items, string ruleXml, XmlDocument help, GetRuleDelegate getRule)
    {
      List<InvalidElement> list = new List<InvalidElement>();
      if (string.IsNullOrWhiteSpace(ruleXml) || items.Count == 0)
        return list;
      Stack<string> stringStack = new Stack<string>();
      bool flag = false;
      RecursionVisitor recursionVisitor = new RecursionVisitor(ruleXml, getRule);
      if (recursionVisitor.HasRecursion())
      {
        stringStack = recursionVisitor.RecursionStack;
        flag = true;
      }
      if (!flag)
        return list;
      foreach (Element element in items)
      {
        if (element.IsRule)
        {
          foreach (string str in stringStack)
          {
            if (element.Value.ToLower() == str.ToLower())
            {
              RuleValidator.AddInvalidElement(list, help, element.Name, "v135");
              break;
            }
          }
        }
      }
      return list;
    }

    public static bool HasActions(List<Element> items)
    {
      foreach (Element element in items)
      {
        if (element.Type == ElementType.Action || element.Type == ElementType.Setter || element.Type == ElementType.Clause && element.Value == "then" || element.Type == ElementType.Flow && (element.Value == "else" || element.Value == "elseIf"))
          return true;
      }
      return false;
    }

    internal static string GetValidationMessage(XmlDocument help, string tag)
    {
      if (help == null)
        return tag;
      foreach (XmlNode childNode in help.SelectSingleNode("/codeeffects/validation").ChildNodes)
      {
        if (childNode.NodeType != XmlNodeType.Comment && childNode.Name == tag)
          return childNode.InnerText;
      }
      return "- unknown help tag (" + tag + ") -";
    }

    public static bool IsNullableOperator(string val)
    {
      if (!(val == "isNotNull"))
        return val == "isNull";
      return true;
    }

    public static bool IsNegativeNullableOperator(string val)
    {
      return val == "isNotNull";
    }

    public static bool IsNegativeOperator(string val)
    {
      if (!(val == "notEqual") && !(val == "doesNotContain") && !(val == "doesNotEndWith"))
        return val == "doesNotStartWith";
      return true;
    }

    public static string GetNullableOperatorByOperType(OperatorType type, bool negative)
    {
      switch (type)
      {
        case OperatorType.String:
          return !negative ? "isNull" : "isNotNull";
        case OperatorType.Numeric:
          return !negative ? "isNull" : "isNotNull";
        case OperatorType.Date:
          return !negative ? "isNull" : "isNotNull";
        case OperatorType.Time:
          return !negative ? "isNull" : "isNotNull";
        case OperatorType.Bool:
          return !negative ? "isNull" : "isNotNull";
        case OperatorType.Collection:
          return !negative ? "isNull" : "isNotNull";
        default:
          throw new MalformedXmlException(MalformedXmlException.ErrorIds.UnknownConditionType, new string[0]);
      }
    }

    private static List<InvalidElement> DoValidate(XmlDocument help, List<Element> items, XmlDocument source, bool noActionsAllowed)
    {
      List<InvalidElement> list = new List<InvalidElement>();
      if (items.Count == 0)
        return list;
      Element nextElement1 = RuleValidator.GetNextElement(items, -1);
      if (nextElement1 == null || nextElement1.Type != ElementType.Flow || nextElement1.Value != "if")
        throw new InvalidRuleException(InvalidRuleException.ErrorIds.FlowTypeElementExcpected, new string[0]);
      Element nextElement2 = RuleValidator.GetNextElement(items, 0);
      if (nextElement2 == null)
        RuleValidator.AddInvalidElement(list, help, nextElement1.Name, "v101");
      else if (nextElement2.Type == ElementType.Flow)
        RuleValidator.AddInvalidElement(list, help, nextElement1.Name, "v110");
      else if (nextElement2.Type != ElementType.LeftParenthesis && nextElement2.Type != ElementType.Field && (nextElement2.Type != ElementType.Function || nextElement2.IsFuncValue) && nextElement2.Type != ElementType.Exists)
        RuleValidator.AddInvalidElement(list, help, nextElement1.Name, "v105");
      int i = 1;
      RuleValidator.ValidateSourceSection(items, source, source.DocumentElement.ChildNodes[0].Attributes["name"] == null ? (string) null : Encoder.GetHashToken(source.DocumentElement.ChildNodes[0].Attributes["name"].Value), help, noActionsAllowed, list, ref i);
      int index = 0;
      RuleValidator.ValidateLevelClauses(items, list, help, ref index);
      return list;
    }

    private static void ValidateSourceSection(List<Element> items, XmlDocument sourceXml, string sourceName, XmlDocument help, bool noActionsAllowed, List<InvalidElement> list, ref int i)
    {
      XmlNode sourceNodeByToken = SourceLoader.GetSourceNodeByToken(sourceXml, sourceName);
      if (sourceNodeByToken == null)
        throw new SourceException(SourceException.ErrorIds.SourceNodeNotFound, new string[1]{ sourceName });
      int num1 = 0;
      int num2 = 0;
      int count = 0;
      int index = -1;
      int paramCount = 0;
      Element element1 = (Element) null;
      Element element2 = (Element) null;
      Element element3 = (Element) null;
      Decimal result1 = new Decimal(-1, -1, -1, true, (byte) 0);
      Decimal num3 = new Decimal(-1, -1, -1, true, (byte) 0);
      Decimal num4 = new Decimal(-1, -1, -1, true, (byte) 0);
      DateTime result2 = DateTime.MinValue;
      bool flag1 = false;
      bool flag2 = false;
      bool flag3 = false;
      XmlNode pars = (XmlNode) null;
      string lastFunctionId = (string) null;
      string lastPropertyName = (string) null;
      string lastToken = (string) null;
      while (i < items.Count)
      {
        Element element4 = items[i];
        if (element4.Type != ElementType.HtmlTag && element4.Type != ElementType.NewLine && element4.Type != ElementType.Tab)
        {
          Element nextElement = RuleValidator.GetNextElement(items, i);
          switch (element4.Type)
          {
            case ElementType.Flow:
              if (element4.Value == "if")
                RuleValidator.AddInvalidElement(list, help, element4.Name, "v123");
              else if (element4.Value == "else")
              {
                if (noActionsAllowed)
                  RuleValidator.AddInvalidElement(list, help, element4.Name, "v144");
                else if (flag1)
                {
                  RuleValidator.AddInvalidElement(list, help, element4.Name, "v124");
                }
                else
                {
                  flag1 = true;
                  if (nextElement == null)
                    RuleValidator.AddInvalidElement(list, help, element4.Name, "v101");
                  else if (nextElement.Type == element4.Type)
                    RuleValidator.AddInvalidElement(list, help, element4.Name, "v110");
                  else if (nextElement.Type != ElementType.Action && (nextElement.Type != ElementType.Setter || nextElement.Value != "set"))
                    RuleValidator.AddInvalidElement(list, help, element4.Name, "v106");
                }
              }
              else if (noActionsAllowed)
                RuleValidator.AddInvalidElement(list, help, element4.Name, "v144");
              else if (nextElement == null)
                RuleValidator.AddInvalidElement(list, help, element4.Name, "v101");
              else if (nextElement.Type == element4.Type)
                RuleValidator.AddInvalidElement(list, help, element4.Name, "v110");
              else if (nextElement.Type != ElementType.LeftParenthesis && nextElement.Type != ElementType.Field && (nextElement.Type != ElementType.Function && nextElement.Type != ElementType.Exists))
                RuleValidator.AddInvalidElement(list, help, element4.Name, "v105");
              if (num1 != num2)
                RuleValidator.AddInvalidElement(list, help, num1 > num2 ? element1.Name : element2.Name, "v109");
              element1 = element2 = (Element) null;
              num1 = 0;
              num2 = 0;
              break;
            case ElementType.Field:
              lastFunctionId = lastToken = (string) null;
              lastPropertyName = element4.Value;
              flag3 = element4.IsRule;
              try
              {
                if (!element4.IsRule)
                  SourceLoader.GetFieldByPropertyName(sourceNodeByToken, element4.Value);
                if (nextElement == null)
                {
                  RuleValidator.AddInvalidElement(list, help, element4.Name, "v101");
                  break;
                }
                if (nextElement.Type == element4.Type)
                {
                  RuleValidator.AddInvalidElement(list, help, element4.Name, "v110");
                  break;
                }
                if (RuleValidator.IsInActionSection(items, i))
                {
                  if (nextElement.Type == ElementType.Setter)
                  {
                    if (!(nextElement.Value != "to"))
                      break;
                  }
                  RuleValidator.AddInvalidElement(list, help, element4.Name, "v136");
                  break;
                }
                if (element4.Oper == OperatorType.Collection && element4.CollType == CollectionType.Reference)
                {
                  if (nextElement.Type != ElementType.Where)
                  {
                    RuleValidator.AddInvalidElement(list, help, element4.Name, "v143");
                    break;
                  }
                  break;
                }
                if (nextElement.Type != ElementType.Operator)
                {
                  RuleValidator.AddInvalidElement(list, help, element4.Name, "v102");
                  break;
                }
                if (element4.Oper != nextElement.Oper)
                {
                  RuleValidator.AddInvalidElement(list, help, element4.Name, "v107");
                  break;
                }
                break;
              }
              catch (SourceException ex)
              {
                RuleValidator.AddInvalidElement(list, help, element4.Name, "v133");
                break;
              }
            case ElementType.Function:
              flag3 = false;
              RuleValidator.ValidateFunction(element4, nextElement, list, sourceNodeByToken, help, ref lastPropertyName, ref lastToken, ref lastFunctionId, false, RuleValidator.IsInActionSection(items, i), noActionsAllowed, ref index, ref count, ref paramCount);
              break;
            case ElementType.Operator:
              element3 = (Element) null;
              if (RuleValidator.IsNullableOperator(element4.Value))
              {
                if (!noActionsAllowed)
                {
                  if (nextElement == null)
                  {
                    RuleValidator.AddInvalidElement(list, help, element4.Name, "v101");
                    break;
                  }
                  if (nextElement.Type == element4.Type)
                  {
                    RuleValidator.AddInvalidElement(list, help, element4.Name, "v110");
                    break;
                  }
                  if (nextElement.Type != ElementType.Clause && nextElement.Type != ElementType.RightParenthesis && nextElement.Type != ElementType.RightSource)
                  {
                    RuleValidator.AddInvalidElement(list, help, element4.Name, "v104");
                    break;
                  }
                  break;
                }
                if (nextElement != null)
                {
                  if (nextElement.Type == element4.Type)
                  {
                    RuleValidator.AddInvalidElement(list, help, element4.Name, "v110");
                    break;
                  }
                  if (nextElement.Type != ElementType.Clause && nextElement.Type != ElementType.RightParenthesis && nextElement.Type != ElementType.RightSource)
                  {
                    RuleValidator.AddInvalidElement(list, help, element4.Name, "v104");
                    break;
                  }
                  break;
                }
                break;
              }
              if (nextElement == null)
              {
                RuleValidator.AddInvalidElement(list, help, element4.Name, "v101");
                break;
              }
              if (nextElement.Type == element4.Type)
              {
                RuleValidator.AddInvalidElement(list, help, element4.Name, "v110");
                break;
              }
              if (nextElement.Type != ElementType.Value && nextElement.Type != ElementType.LeftBracket && (nextElement.Type != ElementType.Function || nextElement.FuncType != FunctionType.Name || !nextElement.IsFuncValue))
              {
                RuleValidator.AddInvalidElement(list, help, element4.Name, "v103");
                break;
              }
              XmlNode xmlNode = !string.IsNullOrEmpty(lastFunctionId) || string.IsNullOrEmpty(lastPropertyName) || flag3 ? (XmlNode) null : SourceLoader.GetFieldByPropertyName(sourceNodeByToken, lastPropertyName);
              if (nextElement.Type != ElementType.LeftBracket && xmlNode != null && xmlNode.Name == "collection")
              {
                if (!(xmlNode.ChildNodes[0].Name == "value"))
                  throw new MalformedXmlException(MalformedXmlException.ErrorIds.ReferenceTypedCollectionNotAllowed, new string[1]{ lastPropertyName });
                break;
              }
              if (nextElement.Type != ElementType.LeftBracket && element4.Oper != nextElement.Oper)
              {
                RuleValidator.AddInvalidElement(list, help, element4.Name, "v108");
                break;
              }
              element3 = element4;
              break;
            case ElementType.Value:
              bool flag4 = RuleValidator.IsInActionSection(items, i);
              if (element4.InpType != InputType.Field)
              {
                switch (element4.Oper)
                {
                  case OperatorType.String:
                    if (string.IsNullOrEmpty(element4.Value) && element3 != null && (element3.Value != "is" && element3.Value != "isNot") && (element3.Value != "equal" && element3.Value != "notEqual"))
                      RuleValidator.AddInvalidElement(list, help, element3.Name, "v120");
                    Decimal num5 = (Decimal) element4.Value.Length;
                    Decimal? max1 = element4.Max;
                    if ((!(num5 > max1.GetValueOrDefault()) ? 0 : (max1.HasValue ? 1 : 0)) != 0)
                    {
                      RuleValidator.AddInvalidElement(list, help, element4.Name, "v122");
                      break;
                    }
                    break;
                  case OperatorType.Numeric:
                    if (!Decimal.TryParse(element4.Value, RuleValidator.defaultNumericStyles, (IFormatProvider) Thread.CurrentThread.CurrentCulture, out result1))
                    {
                      RuleValidator.AddInvalidElement(list, help, element4.Name, "v119");
                      break;
                    }
                    if (sourceNodeByToken != null)
                    {
                      if (lastFunctionId != null)
                      {
                        try
                        {
                          pars = SourceLoader.GetReturnNode(SourceLoader.GetFunctionByToken(sourceNodeByToken, lastToken));
                          num3 = Decimal.Parse(pars.Attributes["min"].Value);
                          num4 = Decimal.Parse(pars.Attributes["max"].Value);
                        }
                        catch (SourceException ex)
                        {
                          RuleValidator.AddInvalidElement(list, help, element4.Name, "v134");
                        }
                        catch
                        {
                          RuleValidator.AddInvalidElement(list, help, element4.Name, "v131");
                        }
                      }
                      else
                      {
                        try
                        {
                          XmlNode fieldByPropertyName = SourceLoader.GetFieldByPropertyName(sourceNodeByToken, lastPropertyName);
                          if (fieldByPropertyName.Name == "collection")
                          {
                            if (fieldByPropertyName.ChildNodes[0].Name == "value")
                            {
                              num3 = Decimal.Parse(fieldByPropertyName.ChildNodes[0].Attributes["min"].Value);
                              num4 = Decimal.Parse(fieldByPropertyName.ChildNodes[0].Attributes["max"].Value);
                            }
                            else
                              throw new MalformedXmlException(MalformedXmlException.ErrorIds.ReferenceTypedCollectionNotAllowed, new string[1]{ lastPropertyName });
                          }
                          else
                          {
                            num3 = Decimal.Parse(fieldByPropertyName.Attributes["min"].Value);
                            num4 = Decimal.Parse(fieldByPropertyName.Attributes["max"].Value);
                          }
                        }
                        catch (InvalidRuleException ex)
                        {
                          throw;
                        }
                        catch (SourceException ex)
                        {
                          RuleValidator.AddInvalidElement(list, help, element4.Name, "v134");
                        }
                        catch (Exception ex)
                        {
                          RuleValidator.AddInvalidElement(list, help, element4.Name, "v131");
                        }
                      }
                      if (result1 > num4 || result1 < num3)
                      {
                        RuleValidator.AddInvalidElement(list, help, element4.Name, "v121");
                        break;
                      }
                      break;
                    }
                    break;
                  case OperatorType.Date:
                    if (!DateTime.TryParse(element4.Value, (IFormatProvider) CultureInfo.CreateSpecificCulture("en-US"), DateTimeStyles.None, out result2))
                    {
                      RuleValidator.AddInvalidElement(list, help, element4.Name, "v117");
                      break;
                    }
                    break;
                  case OperatorType.Time:
                    if (!DateTime.TryParse("1/1/2010 " + element4.Value, (IFormatProvider) CultureInfo.CreateSpecificCulture("en-US"), DateTimeStyles.None, out result2))
                    {
                      RuleValidator.AddInvalidElement(list, help, element4.Name, "v118");
                      break;
                    }
                    break;
                  case OperatorType.Enum:
                    Type enumType1 = (Type) null;
                    try
                    {
                      XmlNode fieldByPropertyName = SourceLoader.GetFieldByPropertyName(sourceNodeByToken, lastPropertyName);
                      string str = fieldByPropertyName.Attributes["assembly"] == null ? string.Empty : ", " + fieldByPropertyName.Attributes["assembly"].Value;
                      enumType1 = Type.GetType(fieldByPropertyName.Attributes["class"].Value + str, false);
                    }
                    catch (SourceException ex)
                    {
                      if (lastFunctionId != null)
                      {
                        XmlNode returnNode = SourceLoader.GetReturnNode(SourceLoader.GetFunctionByToken(sourceNodeByToken, lastToken));
                        string str = returnNode.Attributes["assembly"] == null ? string.Empty : ", " + returnNode.Attributes["assembly"].Value;
                        enumType1 = Type.GetType(returnNode.Attributes["class"].Value + str, false);
                      }
                      else
                        RuleValidator.AddInvalidElement(list, help, element4.Name, "v145");
                    }
                    if (enumType1 == (Type) null || !System.Enum.IsDefined(enumType1, System.Enum.Parse(enumType1, element4.Value)))
                    {
                      RuleValidator.AddInvalidElement(list, help, element4.Name, "v145");
                      break;
                    }
                    break;
                }
              }
              else
              {
                try
                {
                  SourceLoader.GetFieldByPropertyName(sourceNodeByToken, element4.Value);
                }
                catch (SourceException ex)
                {
                  RuleValidator.AddInvalidElement(list, help, element4.Name, "v134");
                }
              }
              if (noActionsAllowed)
              {
                if (flag4)
                  throw new InvalidRuleException(InvalidRuleException.ErrorIds.UnexpectedValueSetters, new string[0]);
                if (nextElement != null)
                {
                  if (nextElement.Type == element4.Type)
                  {
                    RuleValidator.AddInvalidElement(list, help, element4.Name, "v110");
                    break;
                  }
                  if (nextElement.Type != ElementType.Clause && nextElement.Type != ElementType.RightParenthesis && nextElement.Type != ElementType.RightSource)
                  {
                    RuleValidator.AddInvalidElement(list, help, element4.Name, "v104");
                    break;
                  }
                  break;
                }
                break;
              }
              if (flag4)
              {
                if (nextElement != null)
                {
                  if (nextElement.Type == element4.Type)
                  {
                    RuleValidator.AddInvalidElement(list, help, element4.Name, "v110");
                    break;
                  }
                  if (nextElement.Type != ElementType.Clause && nextElement.Type != ElementType.Flow)
                  {
                    RuleValidator.AddInvalidElement(list, help, element4.Name, "v137");
                    break;
                  }
                  if (nextElement.Type == ElementType.Clause && nextElement.Value != "and")
                  {
                    RuleValidator.AddInvalidElement(list, help, element4.Name, "v111");
                    break;
                  }
                  if (nextElement.Type == ElementType.Flow && nextElement.Value != "elseIf" & nextElement.Value != "else")
                  {
                    RuleValidator.AddInvalidElement(list, help, element4.Name, "v138");
                    break;
                  }
                  break;
                }
                break;
              }
              if (nextElement == null)
              {
                RuleValidator.AddInvalidElement(list, help, element4.Name, "v101");
                break;
              }
              if (nextElement.Type == element4.Type)
              {
                RuleValidator.AddInvalidElement(list, help, element4.Name, "v110");
                break;
              }
              if (nextElement.Type != ElementType.Clause && nextElement.Type != ElementType.RightParenthesis && nextElement.Type != ElementType.RightSource)
              {
                RuleValidator.AddInvalidElement(list, help, element4.Name, "v104");
                break;
              }
              break;
            case ElementType.Clause:
              if (nextElement == null)
              {
                RuleValidator.AddInvalidElement(list, help, element4.Name, "v101");
                break;
              }
              if (nextElement.Type == element4.Type)
              {
                RuleValidator.AddInvalidElement(list, help, element4.Name, "v110");
                break;
              }
              if (element4.Value == "then" || RuleValidator.IsInActionSection(items, i))
              {
                if (noActionsAllowed)
                {
                  RuleValidator.AddInvalidElement(list, help, element4.Name, "v144");
                  break;
                }
                if (nextElement.Type != ElementType.Action && (nextElement.Type != ElementType.Setter || nextElement.Value != "set"))
                {
                  RuleValidator.AddInvalidElement(list, help, element4.Name, "v106");
                  break;
                }
                break;
              }
              if (nextElement.Type != ElementType.LeftParenthesis && nextElement.Type != ElementType.Field && (nextElement.Type != ElementType.Function && nextElement.Type != ElementType.Exists))
              {
                RuleValidator.AddInvalidElement(list, help, element4.Name, "v105");
                break;
              }
              break;
            case ElementType.Action:
              flag3 = false;
              if (noActionsAllowed)
              {
                RuleValidator.AddInvalidElement(list, help, element4.Name, "v144");
                break;
              }
              switch (element4.FuncType)
              {
                case FunctionType.Name:
                  index = -1;
                  paramCount = 0;
                  pars = (XmlNode) null;
                  lastPropertyName = element4.Value;
                  lastToken = element4.Token;
                  flag2 = true;
                  lastFunctionId = string.IsNullOrEmpty(element4.Name) ? element4.Value : element4.Name;
                  if (nextElement == null)
                  {
                    RuleValidator.AddInvalidElement(list, help, element4.Name, "v101");
                    break;
                  }
                  if (nextElement.FuncType == element4.FuncType)
                  {
                    RuleValidator.AddInvalidElement(list, help, element4.Name, "v110");
                    break;
                  }
                  if (nextElement.FuncType != FunctionType.Param && nextElement.FuncType != FunctionType.End)
                  {
                    RuleValidator.AddInvalidElement(list, help, element4.Name, "v125");
                    break;
                  }
                  break;
                case FunctionType.Param:
                  ++index;
                  ++paramCount;
                  if (nextElement == null)
                  {
                    RuleValidator.AddInvalidElement(list, help, element4.Name, "v101");
                    break;
                  }
                  if (nextElement.FuncType == element4.FuncType)
                  {
                    RuleValidator.AddInvalidElement(list, help, element4.Name, "v110");
                    break;
                  }
                  if (nextElement.FuncType != FunctionType.Comma && nextElement.FuncType != FunctionType.End)
                    RuleValidator.AddInvalidElement(list, help, element4.Name, "v127");
                  if (sourceNodeByToken != null)
                  {
                    pars = SourceLoader.GetParamNode(SourceLoader.GetActionByToken(sourceNodeByToken, lastToken));
                    if (RuleValidator.GetInputParamDataType(pars.ChildNodes, index) != element4.Oper)
                      RuleValidator.AddInvalidElement(list, help, element4.Name, "v129");
                  }
                  if (element4.InpType == InputType.Input)
                  {
                    switch (element4.Oper)
                    {
                      case OperatorType.String:
                        Decimal num6 = (Decimal) element4.Value.Length;
                        Decimal? max2 = element4.Max;
                        if ((!(num6 > max2.GetValueOrDefault()) ? 0 : (max2.HasValue ? 1 : 0)) != 0)
                        {
                          RuleValidator.AddInvalidElement(list, help, element4.Name, "v122");
                          break;
                        }
                        break;
                      case OperatorType.Numeric:
                        if (!Decimal.TryParse(element4.Value, RuleValidator.defaultNumericStyles, (IFormatProvider) Thread.CurrentThread.CurrentCulture, out result1))
                        {
                          RuleValidator.AddInvalidElement(list, help, element4.Name, "v119");
                          break;
                        }
                        Decimal num7 = result1;
                        Decimal? max3 = element4.Max;
                        if ((!(num7 > max3.GetValueOrDefault()) ? 0 : (max3.HasValue ? 1 : 0)) == 0)
                        {
                          Decimal num8 = result1;
                          Decimal? min = element4.Min;
                          if ((!(num8 < min.GetValueOrDefault()) ? 0 : (min.HasValue ? 1 : 0)) == 0)
                            break;
                        }
                        RuleValidator.AddInvalidElement(list, help, element4.Name, "v121");
                        break;
                      case OperatorType.Date:
                        if (!DateTime.TryParse(element4.Value, (IFormatProvider) CultureInfo.CreateSpecificCulture("en-US"), DateTimeStyles.None, out result2))
                        {
                          RuleValidator.AddInvalidElement(list, help, element4.Name, "v117");
                          break;
                        }
                        break;
                      case OperatorType.Time:
                        if (!DateTime.TryParse("1/1/2010 " + element4.Value, (IFormatProvider) CultureInfo.CreateSpecificCulture("en-US"), DateTimeStyles.None, out result2))
                        {
                          RuleValidator.AddInvalidElement(list, help, element4.Name, "v118");
                          break;
                        }
                        break;
                      case OperatorType.Enum:
                        Type enumType2 = (Type) null;
                        if (lastFunctionId != null)
                        {
                          if (pars == null)
                            pars = SourceLoader.GetParamNode(SourceLoader.GetActionByToken(sourceNodeByToken, lastToken));
                          XmlNode paramByIndex = RuleValidator.GetParamByIndex(pars, paramCount);
                          string str = paramByIndex.Attributes["assembly"] == null ? string.Empty : ", " + paramByIndex.Attributes["assembly"].Value;
                          enumType2 = Type.GetType(paramByIndex.Attributes["class"].Value + str, false);
                        }
                        else
                          RuleValidator.AddInvalidElement(list, help, element4.Name, "v145");
                        if (enumType2 == (Type) null || !System.Enum.IsDefined(enumType2, System.Enum.Parse(enumType2, element4.Value)))
                        {
                          RuleValidator.AddInvalidElement(list, help, element4.Name, "v145");
                          break;
                        }
                        break;
                    }
                  }
                  else
                    break;
                case FunctionType.Comma:
                  if (nextElement == null)
                  {
                    RuleValidator.AddInvalidElement(list, help, element4.Name, "v101");
                    break;
                  }
                  if (nextElement.FuncType == element4.FuncType)
                  {
                    RuleValidator.AddInvalidElement(list, help, element4.Name, "v110");
                    break;
                  }
                  if (nextElement.FuncType != FunctionType.Param)
                  {
                    RuleValidator.AddInvalidElement(list, help, element4.Name, "v128");
                    break;
                  }
                  break;
                case FunctionType.End:
                  count = paramCount = 0;
                  pars = (XmlNode) null;
                  if (sourceNodeByToken != null)
                  {
                    pars = SourceLoader.GetParamNode(SourceLoader.GetActionByToken(sourceNodeByToken, lastToken));
                    count = pars == null ? 0 : RuleValidator.GetInputParamCount(pars.ChildNodes);
                    if (count != index + 1)
                    {
                      RuleValidator.AddInvalidElement(list, help, lastFunctionId, "v128");
                      RuleValidator.AddInvalidElement(list, help, element4.Name, "v128");
                    }
                  }
                  if (nextElement != null)
                  {
                    if (nextElement.Type == element4.Type)
                    {
                      RuleValidator.AddInvalidElement(list, help, lastFunctionId, "v110");
                      RuleValidator.AddInvalidElement(list, help, element4.Name, "v110");
                    }
                    else if (RuleValidator.IsInActionSection(items, i))
                    {
                      if ((nextElement.Type != ElementType.Clause || nextElement.Value != "and") && (nextElement.Type != ElementType.Flow || nextElement.Value == "if"))
                      {
                        RuleValidator.AddInvalidElement(list, help, lastFunctionId, "v137");
                        RuleValidator.AddInvalidElement(list, help, element4.Name, "v137");
                      }
                    }
                    else if (nextElement.Type != ElementType.Clause || nextElement.Value != "and")
                    {
                      RuleValidator.AddInvalidElement(list, help, lastFunctionId, "v111");
                      RuleValidator.AddInvalidElement(list, help, element4.Name, "v111");
                    }
                    else if (nextElement.Type == ElementType.Flow && nextElement.Value == "if")
                    {
                      RuleValidator.AddInvalidElement(list, help, lastFunctionId, "v123");
                      RuleValidator.AddInvalidElement(list, help, element4.Name, "v123");
                    }
                  }
                  index = -1;
                  break;
                default:
                  throw new MalformedXmlException(MalformedXmlException.ErrorIds.UnknownDataType, new string[0]);
              }
            case ElementType.LeftParenthesis:
              if (nextElement == null)
                RuleValidator.AddInvalidElement(list, help, element4.Name, "v101");
              else if (nextElement.Type != ElementType.LeftParenthesis && nextElement.Type != ElementType.Field && (nextElement.Type != ElementType.Function && nextElement.Type != ElementType.Exists))
                RuleValidator.AddInvalidElement(list, help, element4.Name, "v105");
              ++num1;
              if (element1 == null)
              {
                element1 = element4;
                break;
              }
              break;
            case ElementType.RightParenthesis:
            case ElementType.RightSource:
              if (!noActionsAllowed)
              {
                if (nextElement == null)
                  RuleValidator.AddInvalidElement(list, help, element4.Name, "v101");
                else if (nextElement.Type != ElementType.RightParenthesis && nextElement.Type != ElementType.Clause && nextElement.Type != ElementType.RightSource)
                  RuleValidator.AddInvalidElement(list, help, element4.Name, "v104");
              }
              else if (nextElement != null && nextElement.Type != ElementType.RightParenthesis && (nextElement.Type != ElementType.Clause && nextElement.Type != ElementType.RightSource))
                RuleValidator.AddInvalidElement(list, help, element4.Name, "v104");
              if (element4.Type == ElementType.RightSource)
                return;
              ++num2;
              element2 = element4;
              break;
            case ElementType.LeftBracket:
              if (nextElement == null || nextElement.Type == element4.Type)
                throw new InvalidRuleException(InvalidRuleException.ErrorIds.UnexpectedOrderOfCalculationNodes, new string[0]);
              if (nextElement.Type == ElementType.RightBracket)
              {
                RuleValidator.AddInvalidElement(list, help, element4.Name, "v112");
                break;
              }
              if (nextElement.Type != ElementType.Calculation)
                throw new InvalidRuleException(InvalidRuleException.ErrorIds.UnexpectedOrderOfCalculationNodes, new string[0]);
              ++i;
              RuleValidator.ValidateCalculation(items, list, sourceNodeByToken, help, ref i);
              break;
            case ElementType.RightBracket:
              if (RuleValidator.IsInActionSection(items, i))
              {
                if (nextElement != null)
                {
                  if (nextElement.Type == element4.Type)
                    throw new InvalidRuleException(InvalidRuleException.ErrorIds.UnexpectedOrderOfCalculationNodes, new string[0]);
                  if (nextElement.Type != ElementType.Clause && nextElement.Type != ElementType.Flow)
                  {
                    RuleValidator.AddInvalidElement(list, help, element4.Name, "v137");
                    break;
                  }
                  if (nextElement.Type == ElementType.Clause && nextElement.Value != "and")
                  {
                    RuleValidator.AddInvalidElement(list, help, element4.Name, "v111");
                    break;
                  }
                  if (nextElement.Type == ElementType.Flow && nextElement.Value != "elseIf" & nextElement.Value != "else")
                  {
                    RuleValidator.AddInvalidElement(list, help, element4.Name, "v138");
                    break;
                  }
                  break;
                }
                break;
              }
              if (!noActionsAllowed)
              {
                if (nextElement == null)
                {
                  RuleValidator.AddInvalidElement(list, help, element4.Name, "v101");
                  break;
                }
                if (nextElement.Type == element4.Type)
                  throw new InvalidRuleException(InvalidRuleException.ErrorIds.UnexpectedOrderOfCalculationNodes, new string[0]);
                if (nextElement.Type != ElementType.Clause && nextElement.Type != ElementType.RightParenthesis && nextElement.Type != ElementType.RightSource)
                {
                  RuleValidator.AddInvalidElement(list, help, element4.Name, "v104");
                  break;
                }
                break;
              }
              if (nextElement != null)
              {
                if (nextElement.Type == element4.Type)
                  throw new InvalidRuleException(InvalidRuleException.ErrorIds.UnexpectedOrderOfCalculationNodes, new string[0]);
                if (nextElement.Type != ElementType.Clause && nextElement.Type != ElementType.RightParenthesis && nextElement.Type != ElementType.RightSource)
                {
                  RuleValidator.AddInvalidElement(list, help, element4.Name, "v104");
                  break;
                }
                break;
              }
              break;
            case ElementType.Setter:
              flag2 = true;
              if (noActionsAllowed)
              {
                RuleValidator.AddInvalidElement(list, help, element4.Name, "v144");
                break;
              }
              if (nextElement == null)
              {
                RuleValidator.AddInvalidElement(list, help, element4.Name, "v101");
                break;
              }
              if (nextElement.Type == element4.Type)
              {
                RuleValidator.AddInvalidElement(list, help, element4.Name, "v110");
                break;
              }
              if (element4.Value == "set" && nextElement.Type != ElementType.Field)
              {
                RuleValidator.AddInvalidElement(list, help, element4.Name, "v139");
                break;
              }
              if (element4.Value == "to" && nextElement.Type != ElementType.Value && nextElement.Type != ElementType.LeftBracket && (nextElement.Type != ElementType.Function || nextElement.FuncType != FunctionType.Name))
              {
                RuleValidator.AddInvalidElement(list, help, element4.Name, "v140");
                break;
              }
              break;
            case ElementType.LeftSource:
              if (nextElement == null)
                RuleValidator.AddInvalidElement(list, help, element4.Name, "v101");
              else if (nextElement.Type != ElementType.LeftParenthesis && nextElement.Type != ElementType.Field && (nextElement.Type != ElementType.Function && nextElement.Type != ElementType.Exists))
                RuleValidator.AddInvalidElement(list, help, element4.Name, "v105");
              ++i;
              RuleValidator.ValidateSourceSection(items, sourceXml, element4.Value, help, true, list, ref i);
              break;
            case ElementType.Where:
              if (nextElement == null)
              {
                RuleValidator.AddInvalidElement(list, help, element4.Name, "v101");
                break;
              }
              if (nextElement.Type == element4.Type)
              {
                RuleValidator.AddInvalidElement(list, help, element4.Name, "v110");
                break;
              }
              if (nextElement.Type != ElementType.LeftSource)
              {
                RuleValidator.AddInvalidElement(list, help, element4.Name, "v142");
                break;
              }
              break;
            case ElementType.Exists:
              if (nextElement == null)
              {
                RuleValidator.AddInvalidElement(list, help, element4.Name, "v101");
                break;
              }
              if (nextElement.Type == element4.Type)
              {
                RuleValidator.AddInvalidElement(list, help, element4.Name, "v110");
                break;
              }
              if (nextElement.Type != ElementType.Field || nextElement.Oper != OperatorType.Collection || nextElement.CollType != CollectionType.Reference)
              {
                RuleValidator.AddInvalidElement(list, help, element4.Name, "v141");
                break;
              }
              break;
          }
        }
        ++i;
      }
      if (!noActionsAllowed && !flag2)
        RuleValidator.AddInvalidElement(list, help, items[items.Count - 1].Name, "v101");
      if (num1 == num2)
        return;
      RuleValidator.AddInvalidElement(list, help, num1 > num2 ? element1.Name : element2.Name, "v109");
    }

    private static void ValidateCalculation(List<Element> items, List<InvalidElement> invalids, XmlNode source, XmlDocument help, ref int i)
    {
      bool flag = false;
      int num1 = 0;
      int num2 = 0;
      int index1 = i - 1;
      int index2 = -1;
      int paramCount = 0;
      int count = 0;
      Element nextElement1 = RuleValidator.GetNextElement(items, index1);
      if (nextElement1.Type != ElementType.Calculation || nextElement1.CalType != CalculationType.LeftParenthesis && (nextElement1.CalType != CalculationType.Function || nextElement1.FuncType != FunctionType.Name) && (nextElement1.CalType != CalculationType.Field && nextElement1.CalType != CalculationType.Number))
        RuleValidator.AddInvalidElement(invalids, help, nextElement1.Name, "v116");
      Element element1 = (Element) null;
      Element element2 = (Element) null;
      string lastFunctionId = (string) null;
      string lastPropertyName = (string) null;
      string lastToken = (string) null;
      while (i < items.Count)
      {
        Element element3 = items[i];
        if (element3.Type == ElementType.RightBracket)
        {
          flag = true;
          break;
        }
        if (element3.Type == ElementType.HtmlTag || element3.Type == ElementType.NewLine || (element3.Type == ElementType.Tab || element3.Type == ElementType.Flow))
        {
          ++i;
        }
        else
        {
          Element nextElement2 = RuleValidator.GetNextElement(items, i);
          if (nextElement2 == null)
            throw new InvalidRuleException(InvalidRuleException.ErrorIds.UnexpectedOrderOfCalculationNodes, new string[0]);
          if (element3.FuncType == FunctionType.Param || element3.FuncType == FunctionType.Comma)
          {
            RuleValidator.ValidateFunction(element3, nextElement2, invalids, source, help, ref lastPropertyName, ref lastToken, ref lastFunctionId, true, false, true, ref index2, ref count, ref paramCount);
            ++i;
          }
          else
          {
            switch (element3.CalType)
            {
              case CalculationType.Field:
                try
                {
                  SourceLoader.GetFieldByPropertyName(source, element3.Value);
                  if (nextElement2.Type != ElementType.RightBracket)
                  {
                    if (nextElement2.CalType != CalculationType.RightParenthesis)
                    {
                      if (nextElement2.CalType != CalculationType.Addition)
                      {
                        if (nextElement2.CalType != CalculationType.Multiplication)
                        {
                          if (nextElement2.CalType != CalculationType.Division)
                          {
                            if (nextElement2.CalType != CalculationType.Subtraction)
                            {
                              RuleValidator.AddInvalidElement(invalids, help, element3.Name, "v114");
                              break;
                            }
                            break;
                          }
                          break;
                        }
                        break;
                      }
                      break;
                    }
                    break;
                  }
                  break;
                }
                catch (SourceException ex)
                {
                  RuleValidator.AddInvalidElement(invalids, help, element3.Name, "v133");
                  break;
                }
              case CalculationType.LeftParenthesis:
                if (nextElement2.CalType != CalculationType.LeftParenthesis && nextElement2.CalType != CalculationType.Field && (nextElement2.CalType != CalculationType.Function || nextElement2.FuncType != FunctionType.Name) && nextElement2.CalType != CalculationType.Number)
                  RuleValidator.AddInvalidElement(invalids, help, element3.Name, "v115");
                ++num1;
                if (element1 == null)
                {
                  element1 = element3;
                  break;
                }
                break;
              case CalculationType.RightParenthesis:
                if (nextElement2.Type != ElementType.RightBracket && nextElement2.CalType != CalculationType.RightParenthesis && (nextElement2.CalType != CalculationType.Addition && nextElement2.CalType != CalculationType.Multiplication) && (nextElement2.CalType != CalculationType.Division && nextElement2.CalType != CalculationType.Subtraction))
                  RuleValidator.AddInvalidElement(invalids, help, element3.Name, "v114");
                ++num2;
                element2 = element3;
                break;
              case CalculationType.Multiplication:
              case CalculationType.Division:
              case CalculationType.Addition:
              case CalculationType.Subtraction:
                if (nextElement2.CalType != CalculationType.Field && (nextElement2.CalType != CalculationType.Function || nextElement2.FuncType != FunctionType.Name) && (nextElement2.CalType != CalculationType.Number && nextElement2.CalType != CalculationType.LeftParenthesis))
                {
                  RuleValidator.AddInvalidElement(invalids, help, element3.Name, "v113");
                  break;
                }
                break;
              case CalculationType.Number:
                Decimal result = new Decimal(-1, -1, -1, true, (byte) 0);
                if (!Decimal.TryParse(element3.Value, RuleValidator.defaultNumericStyles, (IFormatProvider) Thread.CurrentThread.CurrentCulture, out result))
                {
                  RuleValidator.AddInvalidElement(invalids, help, element3.Name, "v119");
                }
                else
                {
                  Decimal num3 = result;
                  Decimal? max = element3.Max;
                  if ((!(num3 > max.GetValueOrDefault()) ? 0 : (max.HasValue ? 1 : 0)) == 0)
                  {
                    Decimal num4 = result;
                    Decimal? min = element3.Min;
                    if ((!(num4 < min.GetValueOrDefault()) ? 0 : (min.HasValue ? 1 : 0)) == 0)
                      goto label_35;
                  }
                  RuleValidator.AddInvalidElement(invalids, help, element3.Name, "v121");
                }
label_35:
                if (nextElement2.Type != ElementType.RightBracket && nextElement2.CalType != CalculationType.RightParenthesis && (nextElement2.CalType != CalculationType.Addition && nextElement2.CalType != CalculationType.Multiplication) && (nextElement2.CalType != CalculationType.Division && nextElement2.CalType != CalculationType.Subtraction))
                {
                  RuleValidator.AddInvalidElement(invalids, help, element3.Name, "v114");
                  break;
                }
                break;
              case CalculationType.Function:
                RuleValidator.ValidateFunction(element3, nextElement2, invalids, source, help, ref lastPropertyName, ref lastToken, ref lastFunctionId, true, false, true, ref index2, ref count, ref paramCount);
                break;
              default:
                throw new InvalidRuleException(InvalidRuleException.ErrorIds.UnexpectedOrderOfCalculationNodes, new string[0]);
            }
            ++i;
          }
        }
      }
      if (!flag)
        throw new InvalidRuleException(InvalidRuleException.ErrorIds.UnexpectedOrderOfCalculationNodes, new string[0]);
      if (num1 != num2)
        RuleValidator.AddInvalidElement(invalids, help, num1 > num2 ? element1.Name : element2.Name, "v109");
      --i;
    }

    private static void ValidateLevelClauses(List<Element> items, List<InvalidElement> list, XmlDocument help, ref int index)
    {
      Element element1 = (Element) null;
      while (index < items.Count)
      {
        Element element2 = items[index];
        switch (element2.Type)
        {
          case ElementType.Flow:
            if (element2.Value == "if" || element2.Value == "elseIf")
            {
              ++index;
              RuleValidator.ValidateLevelClauses(items, list, help, ref index);
              break;
            }
            break;
          case ElementType.Clause:
            if (element2.Value == "then")
              return;
            if (element1 == null)
            {
              element1 = element2;
              break;
            }
            if (element2.Value != element1.Value)
            {
              RuleValidator.AddInvalidElement(list, help, element1.Name, "v132");
              RuleValidator.AddInvalidElement(list, help, element2.Name, "v132");
              break;
            }
            break;
          case ElementType.LeftParenthesis:
          case ElementType.LeftSource:
            ++index;
            RuleValidator.ValidateLevelClauses(items, list, help, ref index);
            break;
          case ElementType.RightParenthesis:
            return;
          case ElementType.RightSource:
            return;
        }
        ++index;
      }
    }

    private static void ValidateFunction(Element item, Element next, List<InvalidElement> invalids, XmlNode source, XmlDocument help, ref string lastPropertyName, ref string lastToken, ref string lastFunctionId, bool calculation, bool actionSection, bool noActionsAllowed, ref int index, ref int count, ref int paramCount)
    {
      XmlNode pars = (XmlNode) null;
      DateTime result1 = DateTime.MinValue;
      Decimal result2 = new Decimal(-1, -1, -1, true, (byte) 0);
      switch (item.FuncType)
      {
        case FunctionType.Name:
          if (calculation && item.Type != ElementType.Calculation)
            throw new InvalidRuleException(InvalidRuleException.ErrorIds.InvalidOrderOfNodes, new string[0]);
          index = -1;
          paramCount = 0;
          lastPropertyName = item.Value;
          lastToken = item.Token;
          try
          {
            SourceLoader.GetFunctionByToken(source, lastToken);
            lastFunctionId = string.IsNullOrEmpty(item.Name) ? item.Value : item.Name;
            if (next == null)
            {
              RuleValidator.AddInvalidElement(invalids, help, item.Name, "v101");
              break;
            }
            if (next.FuncType == item.FuncType)
            {
              RuleValidator.AddInvalidElement(invalids, help, item.Name, "v110");
              break;
            }
            if (next.FuncType == FunctionType.Param || next.FuncType == FunctionType.End)
              break;
            RuleValidator.AddInvalidElement(invalids, help, item.Name, "v125");
            break;
          }
          catch (SourceException ex)
          {
            item.NotFound = true;
            RuleValidator.AddInvalidElement(invalids, help, item.Name, "v133");
            break;
          }
        case FunctionType.Param:
          ++index;
          ++paramCount;
          if (next == null)
          {
            RuleValidator.AddInvalidElement(invalids, help, item.Name, "v101");
            break;
          }
          if (next.FuncType == item.FuncType)
          {
            RuleValidator.AddInvalidElement(invalids, help, item.Name, "v110");
            break;
          }
          if (next.FuncType != FunctionType.Comma && next.FuncType != FunctionType.End)
            RuleValidator.AddInvalidElement(invalids, help, item.Name, "v127");
          if (source != null)
          {
            try
            {
              pars = SourceLoader.GetParamNode(SourceLoader.GetFunctionByToken(source, lastToken));
              if (RuleValidator.GetInputParamDataType(pars.ChildNodes, index) != item.Oper)
                RuleValidator.AddInvalidElement(invalids, help, item.Name, "v129");
            }
            catch (SourceException ex)
            {
              pars = (XmlNode) null;
            }
          }
          if (pars == null || item.InpType != InputType.Input)
            break;
          switch (item.Oper)
          {
            case OperatorType.String:
              Decimal num1 = (Decimal) item.Value.Length;
              Decimal? max1 = item.Max;
              if ((!(num1 > max1.GetValueOrDefault()) ? 0 : (max1.HasValue ? 1 : 0)) == 0)
                return;
              RuleValidator.AddInvalidElement(invalids, help, item.Name, "v122");
              return;
            case OperatorType.Numeric:
              if (!Decimal.TryParse(item.Value, RuleValidator.defaultNumericStyles, (IFormatProvider) Thread.CurrentThread.CurrentCulture, out result2))
              {
                RuleValidator.AddInvalidElement(invalids, help, item.Name, "v119");
                return;
              }
              Decimal num2 = result2;
              Decimal? max2 = item.Max;
              if ((!(num2 > max2.GetValueOrDefault()) ? 0 : (max2.HasValue ? 1 : 0)) == 0)
              {
                Decimal num3 = result2;
                Decimal? min = item.Min;
                if ((!(num3 < min.GetValueOrDefault()) ? 0 : (min.HasValue ? 1 : 0)) == 0)
                  return;
              }
              RuleValidator.AddInvalidElement(invalids, help, item.Name, "v121");
              return;
            case OperatorType.Date:
              if (DateTime.TryParse(item.Value, (IFormatProvider) CultureInfo.CreateSpecificCulture("en-US"), DateTimeStyles.None, out result1))
                return;
              RuleValidator.AddInvalidElement(invalids, help, item.Name, "v117");
              return;
            case OperatorType.Time:
              if (DateTime.TryParse("1/1/2010 " + item.Value, (IFormatProvider) CultureInfo.CreateSpecificCulture("en-US"), DateTimeStyles.None, out result1))
                return;
              RuleValidator.AddInvalidElement(invalids, help, item.Name, "v118");
              return;
            case OperatorType.Bool:
              return;
            case OperatorType.Numeric | OperatorType.Bool:
              return;
            case OperatorType.Enum:
              Type enumType = (Type) null;
              if (lastFunctionId != null)
              {
                XmlNode paramByIndex = RuleValidator.GetParamByIndex(pars, paramCount);
                string str = paramByIndex.Attributes["assembly"] == null ? string.Empty : ", " + paramByIndex.Attributes["assembly"].Value;
                enumType = Type.GetType(paramByIndex.Attributes["class"].Value + str, false);
              }
              else
                RuleValidator.AddInvalidElement(invalids, help, item.Name, "v145");
              if (!(enumType == (Type) null) && System.Enum.IsDefined(enumType, System.Enum.Parse(enumType, item.Value)))
                return;
              RuleValidator.AddInvalidElement(invalids, help, item.Name, "v145");
              return;
            default:
              return;
          }
        case FunctionType.Comma:
          if (next == null)
          {
            RuleValidator.AddInvalidElement(invalids, help, item.Name, "v101");
            break;
          }
          if (next.FuncType == item.FuncType)
          {
            RuleValidator.AddInvalidElement(invalids, help, item.Name, "v110");
            break;
          }
          if (next.FuncType == FunctionType.Param)
            break;
          RuleValidator.AddInvalidElement(invalids, help, item.Name, "v128");
          break;
        case FunctionType.End:
          if (calculation && item.Type != ElementType.Calculation)
            throw new InvalidRuleException(InvalidRuleException.ErrorIds.UnecpectedCalculationType, new string[0]);
          count = paramCount = 0;
          XmlNode xmlNode = (XmlNode) null;
          if (source != null)
          {
            try
            {
              xmlNode = SourceLoader.GetParamNode(SourceLoader.GetFunctionByToken(source, lastToken));
            }
            catch (SourceException ex)
            {
              xmlNode = (XmlNode) null;
            }
            count = xmlNode == null ? 0 : RuleValidator.GetInputParamCount(xmlNode.ChildNodes);
          }
          if (item.IsFuncValue)
          {
            if (actionSection)
            {
              if (next != null)
              {
                if (next.Type != ElementType.Clause && next.Type != ElementType.Flow)
                {
                  RuleValidator.AddInvalidElement(invalids, help, lastFunctionId, "v137");
                  RuleValidator.AddInvalidElement(invalids, help, item.Name, "v137");
                }
                else if (next.Type == ElementType.Clause && next.Value != "and")
                {
                  RuleValidator.AddInvalidElement(invalids, help, lastFunctionId, "v111");
                  RuleValidator.AddInvalidElement(invalids, help, item.Name, "v111");
                }
                else if (next.Type == ElementType.Flow && next.Value != "elseIf" & next.Value != "else")
                {
                  RuleValidator.AddInvalidElement(invalids, help, lastFunctionId, "v138");
                  RuleValidator.AddInvalidElement(invalids, help, item.Name, "v138");
                }
              }
            }
            else if (!noActionsAllowed)
            {
              if (next == null)
              {
                RuleValidator.AddInvalidElement(invalids, help, lastFunctionId, "v101");
                RuleValidator.AddInvalidElement(invalids, help, item.Name, "v101");
              }
              else if (next.Type == item.Type)
              {
                RuleValidator.AddInvalidElement(invalids, help, lastFunctionId, "v110");
                RuleValidator.AddInvalidElement(invalids, help, item.Name, "v110");
              }
              else if (next.Type != ElementType.Clause && next.Type != ElementType.RightParenthesis && next.Type != ElementType.RightSource)
              {
                RuleValidator.AddInvalidElement(invalids, help, lastFunctionId, "v104");
                RuleValidator.AddInvalidElement(invalids, help, item.Name, "v104");
              }
            }
            else if (next != null)
            {
              if (next.Type == item.Type)
              {
                RuleValidator.AddInvalidElement(invalids, help, lastFunctionId, "v110");
                RuleValidator.AddInvalidElement(invalids, help, item.Name, "v110");
              }
              else if (next.Type != ElementType.Clause && next.Type != ElementType.RightParenthesis && next.Type != ElementType.RightSource)
              {
                RuleValidator.AddInvalidElement(invalids, help, lastFunctionId, "v104");
                RuleValidator.AddInvalidElement(invalids, help, item.Name, "v104");
              }
            }
          }
          else if (next == null)
          {
            RuleValidator.AddInvalidElement(invalids, help, lastFunctionId, "v101");
            RuleValidator.AddInvalidElement(invalids, help, item.Name, "v101");
          }
          else if (next.FuncType == item.FuncType)
          {
            RuleValidator.AddInvalidElement(invalids, help, lastFunctionId, "v110");
            RuleValidator.AddInvalidElement(invalids, help, item.Name, "v110");
          }
          else if (calculation)
          {
            if (next.Type != ElementType.RightBracket && next.CalType != CalculationType.RightParenthesis && (next.CalType != CalculationType.Addition && next.CalType != CalculationType.Multiplication) && (next.CalType != CalculationType.Division && next.CalType != CalculationType.Subtraction))
              RuleValidator.AddInvalidElement(invalids, help, item.Name, "v114");
          }
          else if (next.Type != ElementType.Operator)
          {
            RuleValidator.AddInvalidElement(invalids, help, lastFunctionId, "v102");
            RuleValidator.AddInvalidElement(invalids, help, item.Name, "v102");
          }
          else if (item.Oper != next.Oper)
          {
            RuleValidator.AddInvalidElement(invalids, help, lastFunctionId, "v107");
            RuleValidator.AddInvalidElement(invalids, help, item.Name, "v107");
          }
          if (xmlNode != null && count != index + 1)
          {
            RuleValidator.AddInvalidElement(invalids, help, lastFunctionId, "v128");
            RuleValidator.AddInvalidElement(invalids, help, item.Name, "v128");
          }
          index = -1;
          break;
      }
    }

    private static void DoEnsureIgnoredProperties(List<Element> items, XmlDocument sourceXml)
    {
      XmlNode source = SourceLoader.GetSourceNode(sourceXml, sourceXml.DocumentElement.ChildNodes[0].Attributes["name"] == null ? (string) null : sourceXml.DocumentElement.ChildNodes[0].Attributes["name"].Value);
      for (int index = 0; index < items.Count; ++index)
      {
        Element element = items[index];
        switch (element.Type)
        {
          case ElementType.Field:
            if (!element.IsRule)
            {
              try
              {
                XmlNode fieldByPropertyName = SourceLoader.GetFieldByPropertyName(source, element.Value);
                switch (element.Oper)
                {
                  case OperatorType.String:
                    if (fieldByPropertyName.Attributes["stringComparison"] != null)
                    {
                      element.StringComparison = (StringComparison) System.Enum.Parse(typeof (StringComparison), fieldByPropertyName.Attributes["stringComparison"].Value, true);
                      continue;
                    }
                    continue;
                  case OperatorType.Enum:
                    if (element.En != null)
                    {
                      element.Assembly = fieldByPropertyName.Attributes["assembly"].Value;
                      continue;
                    }
                    continue;
                  case OperatorType.Collection:
                    if (fieldByPropertyName.ChildNodes[0].Name == "value")
                    {
                      if (Converter.ClientStringToClientType(fieldByPropertyName.ChildNodes[0].Attributes["type"].Value) == OperatorType.Enum)
                      {
                        if (element.En != null)
                        {
                          element.Assembly = fieldByPropertyName.ChildNodes[0].Attributes["assembly"].Value;
                          continue;
                        }
                        continue;
                      }
                      continue;
                    }
                    continue;
                  default:
                    continue;
                }
              }
              catch (SourceException ex)
              {
                break;
              }
            }
            else
              break;
          case ElementType.Function:
          case ElementType.Action:
            if (element.FuncType == FunctionType.Name)
            {
              XmlNode function = (XmlNode) null;
              if (element.Type == ElementType.Function)
              {
                try
                {
                  function = SourceLoader.GetFunctionByToken(source, element.Token);
                }
                catch (SourceException ex)
                {
                }
              }
              else
              {
                try
                {
                  function = SourceLoader.GetActionByToken(source, element.Token);
                }
                catch (SourceException ex)
                {
                }
              }
              if (function != null && function.Attributes["class"] != null)
              {
                element.Class = function.Attributes["class"].Value;
                if (function.Attributes["assembly"] != null)
                  element.Assembly = function.Attributes["assembly"].Value;
              }
              if (function != null && element.Type == ElementType.Function)
              {
                XmlNode returnNode = SourceLoader.GetReturnNode(function);
                switch (returnNode.Attributes["type"].Value)
                {
                  case "bool":
                    element.Oper = OperatorType.Bool;
                    continue;
                  case "date":
                    element.Oper = OperatorType.Date;
                    element.Format = Encoder.Desanitize(returnNode.Attributes["format"].Value);
                    continue;
                  case "time":
                    element.Oper = OperatorType.Time;
                    element.Format = Encoder.Desanitize(returnNode.Attributes["format"].Value);
                    continue;
                  case "enum":
                    element.Oper = OperatorType.Enum;
                    element.ReturnEnumClass = returnNode.Attributes["class"].Value;
                    element.ReturnEnumAssembly = returnNode.Attributes["assembly"].Value;
                    continue;
                  case "string":
                    element.Oper = OperatorType.String;
                    element.Max = new Decimal?((Decimal) long.Parse(returnNode.Attributes["maxLength"].Value));
                    if (returnNode.Attributes["stringComparison"] != null)
                    {
                      element.StringComparison = (StringComparison) System.Enum.Parse(typeof (StringComparison), returnNode.Attributes["stringComparison"].Value, true);
                      continue;
                    }
                    continue;
                  default:
                    element.Oper = OperatorType.Numeric;
                    element.Max = new Decimal?((Decimal) long.Parse(returnNode.Attributes["max"].Value));
                    element.Min = new Decimal?((Decimal) long.Parse(returnNode.Attributes["min"].Value));
                    element.Dec = returnNode.Attributes["allowDecimal"].Value == "true";
                    element.Cal = returnNode.Attributes["allowCalculation"].Value == "true";
                    continue;
                }
              }
              else
                break;
            }
            else
              break;
          case ElementType.Value:
            if (element.InpType == InputType.Field)
            {
              try
              {
                XmlNode fieldByPropertyName = SourceLoader.GetFieldByPropertyName(source, element.Value);
                if (element.Oper == OperatorType.String)
                {
                  if (fieldByPropertyName.Attributes["stringComparison"] != null)
                  {
                    element.StringComparison = (StringComparison) System.Enum.Parse(typeof (StringComparison), fieldByPropertyName.Attributes["stringComparison"].Value, true);
                    break;
                  }
                  break;
                }
                break;
              }
              catch (SourceException ex)
              {
                break;
              }
            }
            else
              break;
          case ElementType.LeftSource:
          case ElementType.RightSource:
            source = SourceLoader.GetSourceNodeByToken(sourceXml, element.Value);
            break;
        }
      }
      RuleValidator.DoEnsureIgnoredParameters(items, sourceXml);
    }

    private static void DoEnsureIgnoredParameters(List<Element> items, XmlDocument sourceXml)
    {
      XmlNode source = SourceLoader.GetSourceNode(sourceXml, sourceXml.DocumentElement.ChildNodes[0].Attributes["name"] == null ? (string) null : sourceXml.DocumentElement.ChildNodes[0].Attributes["name"].Value);
      Dictionary<int, Element> dictionary = new Dictionary<int, Element>();
      XmlNode xmlNode1 = (XmlNode) null;
      string token = (string) null;
      int key1 = 0;
      for (int index = 0; index < items.Count; ++index)
      {
        int num;
        key1 = key1 == 0 ? index + 1 : (num = key1 + 1);
        Element element = items[index];
        switch (element.Type)
        {
          case ElementType.Calculation:
          case ElementType.Function:
          case ElementType.Action:
            switch (element.FuncType)
            {
              case FunctionType.Name:
                token = element.Token == null ? element.Value : element.Token;
                XmlNode function;
                if (element.Type == ElementType.Function)
                {
                  try
                  {
                    function = SourceLoader.GetFunctionByToken(source, token);
                  }
                  catch (SourceException ex)
                  {
                    function = (XmlNode) null;
                  }
                }
                else
                {
                  try
                  {
                    function = SourceLoader.GetActionByToken(source, token);
                  }
                  catch (SourceException ex)
                  {
                    function = (XmlNode) null;
                  }
                }
                xmlNode1 = SourceLoader.GetParamNode(function);
                if (xmlNode1 != null)
                {
                  IEnumerator enumerator = xmlNode1.ChildNodes.GetEnumerator();
                  try
                  {
                    while (enumerator.MoveNext())
                    {
                      XmlNode xmlNode2 = (XmlNode) enumerator.Current;
                      switch (xmlNode2.Name)
                      {
                        case "source":
                          dictionary.Add(key1, new Element()
                          {
                            Type = element.Type,
                            FuncType = FunctionType.Param,
                            ParameterType = ParameterType.Source
                          });
                          ++key1;
                          continue;
                        case "constant":
                          dictionary.Add(key1, new Element()
                          {
                            Type = element.Type,
                            FuncType = FunctionType.Param,
                            ParameterType = ParameterType.Constant,
                            Oper = Converter.ClientStringToClientType(xmlNode2.Attributes["type"].Value),
                            Value = xmlNode2.Attributes["value"].Value
                          });
                          ++key1;
                          continue;
                        case "input":
                        case "collection":
                          ++key1;
                          continue;
                        default:
                          continue;
                      }
                    }
                    continue;
                  }
                  finally
                  {
                    IDisposable disposable = enumerator as IDisposable;
                    if (disposable != null)
                      disposable.Dispose();
                  }
                }
                else
                  continue;
              case FunctionType.Param:
                element.ParameterType = ParameterType.Input;
                if (element.Oper == OperatorType.Enum)
                {
                  if (element.InpType == InputType.Field)
                  {
                    xmlNode1 = SourceLoader.GetFieldByPropertyName(source, element.Value);
                  }
                  else
                  {
                    try
                    {
                      foreach (XmlNode childNode in SourceLoader.GetParamNode(element.Type != ElementType.Action ? SourceLoader.GetFunctionByToken(source, token) : SourceLoader.GetActionByToken(source, token)).ChildNodes)
                      {
                        if (childNode.NodeType != XmlNodeType.Comment && childNode.Name == "input" && (childNode.Attributes["type"].Value == "enum" && childNode.Attributes["class"].Value == element.En))
                        {
                          xmlNode1 = childNode;
                          break;
                        }
                      }
                    }
                    catch (SourceException ex)
                    {
                    }
                  }
                  element.Class = xmlNode1.Attributes["class"].Value;
                  if (xmlNode1.Attributes["assembly"] != null)
                    element.Assembly = xmlNode1.Attributes["assembly"].Value;
                }
                --key1;
                continue;
              default:
                continue;
            }
          case ElementType.LeftSource:
          case ElementType.RightSource:
            source = SourceLoader.GetSourceNodeByToken(sourceXml, element.Value);
            break;
        }
      }
      foreach (int key2 in dictionary.Keys)
        items.Insert(key2, dictionary[key2]);
    }

    private static void DoEnsureValues(List<Element> items)
    {
      Element element1 = (Element) null;
      for (int index = 0; index < items.Count; ++index)
      {
        Element element2 = items[index];
        switch (element2.Type)
        {
          case ElementType.Field:
            element1 = element2;
            break;
          case ElementType.Function:
          case ElementType.Action:
            if (element2.FuncType == FunctionType.Name)
            {
              element1 = element2;
              break;
            }
            if (element2.FuncType == FunctionType.Param && element2.InpType == InputType.Input)
            {
              switch (element2.Oper)
              {
                case OperatorType.Numeric:
                case OperatorType.Enum:
                  element2.Value = RuleValidator.TrimNumeric(element2.Value);
                  continue;
                case OperatorType.Date:
                  element2.Value = RuleValidator.TrimDate(element2.Value);
                  continue;
                case OperatorType.Time:
                  element2.Value = RuleValidator.TrimTime(element2.Value, element2.Format);
                  continue;
                default:
                  continue;
              }
            }
            else
              break;
          case ElementType.Value:
            if (element2.InpType != InputType.Field)
            {
              switch (element2.Oper)
              {
                case OperatorType.Numeric:
                  element2.Value = RuleValidator.TrimNumeric(element2.Value);
                  break;
                case OperatorType.Date:
                  element2.Value = RuleValidator.TrimDate(element2.Value);
                  break;
                case OperatorType.Time:
                  element2.Value = RuleValidator.TrimTime(element2.Value, element1.Format);
                  break;
                case OperatorType.Enum:
                  if (element1.Type == ElementType.Function || element1.Type == ElementType.Action || element1.Type == ElementType.Field && element1.En != null)
                  {
                    element2.Value = RuleValidator.TrimNumeric(element2.Value);
                    break;
                  }
                  break;
              }
            }
            element1 = (Element) null;
            break;
          case ElementType.Calculation:
            if (element2.CalType == CalculationType.Number)
            {
              element2.Value = RuleValidator.TrimNumeric(element2.Value);
              break;
            }
            break;
        }
      }
    }

    private static Element GetNextElement(List<Element> items, int index)
    {
      for (int index1 = index + 1; index1 < items.Count; ++index1)
      {
        Element element = items[index1];
        if (element.Type != ElementType.NewLine && element.Type != ElementType.HtmlTag && element.Type != ElementType.Tab)
          return element;
      }
      return (Element) null;
    }

    private static bool IsInActionSection(List<Element> items, int index)
    {
      for (int index1 = index; index1 > -1; --index1)
      {
        Element element = items[index1];
        if (element.Type == ElementType.Operator || element.Type == ElementType.LeftParenthesis || element.Type == ElementType.RightParenthesis || element.Type == ElementType.Flow && element.Value != "else")
          return false;
        if (element.Type == ElementType.Setter || element.Type == ElementType.Action || element.Type == ElementType.Clause && element.Value == "then" || element.Type == ElementType.Flow && element.Value == "else")
          return true;
      }
      return false;
    }

    private static XmlNode GetParamByIndex(XmlNode pars, int index)
    {
      int num = 0;
      foreach (XmlNode childNode in pars.ChildNodes)
      {
        if (childNode.Name == "input" || childNode.Name == "collection")
          ++num;
        if (num == index)
          return childNode;
      }
      throw new InvalidRuleException(InvalidRuleException.ErrorIds.UnexpectedNumberOfParameters, new string[0]);
    }

    private static int GetInputParamCount(XmlNodeList pars)
    {
      int num = 0;
      foreach (XmlNode par in pars)
      {
        if (par.Name == "input" || par.Name == "collection")
          ++num;
      }
      return num;
    }

    private static int GetInputParamCount(List<CodeEffects.Rule.Client.Parameter> pars)
    {
      int num = 0;
      foreach (CodeEffects.Rule.Client.Parameter par in pars)
      {
        if (par.Type == ParameterType.Input)
          ++num;
      }
      return num;
    }

    private static OperatorType GetInputParamDataType(XmlNodeList pars, int index)
    {
      int num = -1;
      for (int index1 = 0; index1 < pars.Count; ++index1)
      {
        XmlNode xmlNode = pars[index1];
        if (xmlNode.Name == "input" || xmlNode.Name == "collection")
          ++num;
        if (num == index)
          return Converter.ClientStringToClientType(xmlNode.Name == "collection" ? xmlNode.Name : xmlNode.Attributes["type"].Value);
      }
      return OperatorType.None;
    }

    private static void AddInvalidElement(List<InvalidElement> list, XmlDocument help, string clientID, string tag)
    {
      if (RuleValidator.ClientIdExists(list, clientID))
        return;
      list.Add(new InvalidElement(clientID, RuleValidator.GetValidationMessage(help, tag)));
    }

    private static bool ClientIdExists(List<InvalidElement> list, string clientID)
    {
      return list.Find((Predicate<InvalidElement>) (el => el.ClientID == clientID)) != null;
    }

    private static string TrimNumeric(string numeric)
    {
      string str = numeric.Replace(",", ".");
      if (str.Length > 1 && str.StartsWith("0"))
        str = str.Substring(1, str.Length - 1);
      if (str.Length > 1 && str.StartsWith("."))
        str = "0" + str;
      if (str == "." || str == "-." || str == "-0")
        str = "0";
      if (str.Length > 1 && str.EndsWith("."))
        str = str.Substring(0, str.Length - 1);
      return str;
    }

    private static string TrimDate(string date)
    {
      return DateTime.Parse(date, (IFormatProvider) CultureInfo.CreateSpecificCulture("en-US"), DateTimeStyles.None).ToString("yyyy-MM-ddTHH:mm:ss.ffff");
    }

    private static string TrimTime(string time, string format)
    {
      if (string.IsNullOrWhiteSpace(format))
        format = "HH:mm:ss";
      return DateTime.Parse("1/1/2000 " + time, (IFormatProvider) CultureInfo.CreateSpecificCulture("en-US"), DateTimeStyles.None).ToString(format.Contains("s") ? "HH:mm:ss" : "HH:mm");
    }

    private static string GetNumericDisplayString(string value)
    {
      return Decimal.Parse(value.Replace(",", "."), (IFormatProvider) CultureInfo.CreateSpecificCulture("en-US")).ToString("G", (IFormatProvider) Thread.CurrentThread.CurrentCulture);
    }

    private static string GetDateValueString(string value)
    {
      return DateTime.Parse(value).ToString("M/d/yyyy H:m:s", (IFormatProvider) CultureInfo.CreateSpecificCulture("en-US"));
    }
  }
}
