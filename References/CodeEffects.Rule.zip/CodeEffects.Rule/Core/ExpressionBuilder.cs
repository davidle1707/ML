﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Core.ExpressionBuilder
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using System;
using System.Linq.Expressions;
using System.Xml.Linq;

namespace CodeEffects.Rule.Core
{
  internal class ExpressionBuilder : ExpressionBuilderBase
  {
    public ExpressionBuilder(Type sourceType, GetRuleInternalDelegate getRule)
      : base(sourceType, getRule)
    {
    }

    internal LambdaExpression GetPredicateExpression(XElement rule)
    {
      return Expression.Lambda(this.GetSafeExpressionBody(rule, false), new ParameterExpression[1]{ this.source });
    }

    internal Delegate CompileRule(XElement rule)
    {
      return this.GetPredicateExpression(rule).Compile();
    }

    internal Delegate CompileRule(LambdaExpression bodyExpression)
    {
      return bodyExpression.Compile();
    }
  }
}
