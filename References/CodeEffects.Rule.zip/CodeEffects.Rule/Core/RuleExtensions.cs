﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Core.RuleExtensions
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.Linq;
using System.Data.Linq.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Xml.Linq;

namespace CodeEffects.Rule.Core
{
  public static class RuleExtensions
  {
    public static IEnumerable Filter(this IEnumerable source, Type type, string rulesetXml, string ruleId = null, GetRuleDelegate getRule = null)
    {
      Evaluator evaluator = new Evaluator(type, rulesetXml, getRule, -1);
      List<object> objectList = new List<object>();
      Vector.DelayIfDemo();
      evaluator.SuspendDemoDelay = true;
      foreach (object source1 in source)
      {
        if (evaluator.Evaluate(source1, ruleId))
          objectList.Add(source1);
      }
      return (IEnumerable) objectList;
    }

    public static IEnumerable<TSource> Filter<TSource>(this IEnumerable<TSource> source, string rulesetXml, string ruleId = null, GetRuleDelegate getRule = null)
    {
      Evaluator<TSource> evaluator = new Evaluator<TSource>(rulesetXml, getRule, -1);
      Func<TSource, bool> predicate = evaluator.GetPredicate(ruleId);
      Vector.DelayIfDemo();
      evaluator.SuspendDemoDelay = true;
      return source.Where<TSource>(predicate);
    }

    [Obsolete("Consider using a Filter overload with the ruleId parameter instead.")]
    public static IEnumerable<TSource> Filter<TSource>(this IEnumerable<TSource> source, string rulesetXml, int ruleIndex, GetRuleDelegate getRule = null)
    {
      XElement xelement = XElement.Parse(rulesetXml);
      if (source == null || xelement == null)
        throw new ArgumentNullException();
      XNamespace ns = xelement.GetDefaultNamespace();
      IEnumerable<XElement> source1 = xelement.Element(ns + "codeeffects").Elements().Where<XElement>((Func<XElement, bool>) (x => x.Name == ns + "rule"));
      if (ruleIndex >= source1.Count<XElement>() || ruleIndex < 0)
        throw new IndexOutOfRangeException("Rule index is out of range.");
      string ruleId = (string) source1.ElementAt<XElement>(ruleIndex).Attribute((XName) "id");
      if (string.IsNullOrEmpty(ruleId))
        throw new ArgumentNullException("Rule must have non-empty 'id' attribute.");
      return source.Filter<TSource>(rulesetXml, ruleId, getRule);
    }

    public static IQueryable Filter(this IQueryable source, Type type, string rulesetXml, EvaluationParameters parameters)
    {
      if (source == null || string.IsNullOrWhiteSpace(rulesetXml))
        throw new ArgumentNullException();
      Evaluator evaluator = new Evaluator(type, rulesetXml, parameters);
      LambdaExpression lambdaExpression = evaluator.GetPredicateExpression(parameters.RuleId);
      LinqProviderType linqProviderType = parameters.LINQProviderType;
      if (linqProviderType == LinqProviderType.Default)
        linqProviderType = RuleExtensions.GetProviderType(source);
      if (linqProviderType == LinqProviderType.SQL || linqProviderType == LinqProviderType.Entities)
        lambdaExpression = (LambdaExpression) RuleExtensions.ReplaceIndexOfMethod((Expression) lambdaExpression);
      Vector.DelayIfDemo();
      evaluator.SuspendDemoDelay = true;
      typeof (IQueryable<>).MakeGenericType(type);
      Expression expression = (Expression) Expression.Call((Expression) null, ((IEnumerable<MethodInfo>) typeof (Queryable).GetMethods()).Where<MethodInfo>((Func<MethodInfo, bool>) (method =>
      {
        if (method.Name == "Where")
          return ((IEnumerable<ParameterInfo>) method.GetParameters()).Where<ParameterInfo>((Func<ParameterInfo, bool>) (parameter =>
          {
            if (parameter.ParameterType.Name.StartsWith("Expression"))
              return ((IEnumerable<Type>) parameter.ParameterType.GetGenericArguments()).Where<Type>((Func<Type, bool>) (genericArg => ((IEnumerable<Type>) genericArg.GetGenericArguments()).Count<Type>() == 2)).Any<Type>();
            return false;
          })).Any<ParameterInfo>();
        return false;
      })).FirstOrDefault<MethodInfo>().MakeGenericMethod(type), new Expression[2]{ source.Expression, (Expression) Expression.Quote((Expression) lambdaExpression) });
      return source.Provider.CreateQuery(expression);
    }

    public static IQueryable Filter(this IQueryable source, Type type, string rulesetXml, string ruleId = null, GetRuleDelegate getRule = null)
    {
      EvaluationParameters parameters = new EvaluationParameters() { RuleId = ruleId, RuleGetter = getRule, LINQProviderType = LinqProviderType.Default, PerformNullChecks = false };
      return source.Filter(type, rulesetXml, parameters);
    }

    public static IQueryable<TSource> Filter<TSource>(this IQueryable<TSource> source, string rulesetXml, EvaluationParameters parameters)
    {
      Evaluator<TSource> evaluator = new Evaluator<TSource>(rulesetXml, parameters);
      Expression<Func<TSource, bool>> predicate = evaluator.GetPredicateExpression(parameters.RuleId);
      LinqProviderType linqProviderType = parameters.LINQProviderType;
      if (linqProviderType == LinqProviderType.Default)
        linqProviderType = RuleExtensions.GetProviderType((IQueryable) source);
      if (linqProviderType == LinqProviderType.SQL || linqProviderType == LinqProviderType.Entities)
        predicate = (Expression<Func<TSource, bool>>) RuleExtensions.ReplaceIndexOfMethod((Expression) predicate);
      Vector.DelayIfDemo();
      evaluator.SuspendDemoDelay = true;
      return source.Where<TSource>(predicate);
    }

    public static IQueryable<TSource> Filter<TSource>(this IQueryable<TSource> source, string rulesetXml, string ruleId = null, GetRuleDelegate getRule = null)
    {
      EvaluationParameters parameters = new EvaluationParameters() { RuleId = ruleId, RuleGetter = getRule, LINQProviderType = LinqProviderType.Default, PerformNullChecks = false };
      return source.Filter<TSource>(rulesetXml, parameters);
    }

    [Obsolete("Consider using a Filter overload with the ruleId parameter instead.")]
    public static IQueryable<TSource> Filter<TSource>(this IQueryable<TSource> source, string rulesetXml, int ruleIndex, GetRuleDelegate getRule = null)
    {
      XElement xelement = XElement.Parse(rulesetXml);
      if (source == null || xelement == null)
        throw new ArgumentNullException();
      XNamespace ns = xelement.GetDefaultNamespace();
      IEnumerable<XElement> source1 = xelement.Element(ns + "codeeffects").Elements().Where<XElement>((Func<XElement, bool>) (x => x.Name == ns + "rule"));
      if (ruleIndex >= source1.Count<XElement>() || ruleIndex < 0)
        throw new IndexOutOfRangeException("Rule index is out of range.");
      string ruleId = (string) source1.ElementAt<XElement>(ruleIndex).Attribute((XName) "id");
      if (string.IsNullOrEmpty(ruleId))
        throw new ArgumentNullException("Rule must have non-empty 'id' attribute.");
      return RuleExtensions.Filter<TSource>(source, rulesetXml, ruleId, getRule);
    }

    public static bool Evaluate<TSource>(this TSource source, string rulesetXml, string ruleId = null, GetRuleDelegate getRule = null)
    {
      XElement xelement = XElement.Parse(rulesetXml);
      if ((object) source == null || xelement == null)
        throw new ArgumentNullException();
      Func<TSource, bool> predicate = new Evaluator<TSource>(rulesetXml, getRule, -1).GetPredicate(ruleId);
      Vector.DelayIfDemo();
      return predicate(source);
    }

    public static bool Evaluate<TSource>(this TSource source, string rulesetXml, int ruleIndex, GetRuleDelegate getRule)
    {
      XElement xelement = XElement.Parse(rulesetXml);
      if ((object) source == null || xelement == null)
        throw new ArgumentNullException();
      Func<TSource, bool> predicate = new Evaluator<TSource>(rulesetXml, getRule, -1).GetPredicate(ruleIndex);
      Vector.DelayIfDemo();
      return predicate(source);
    }

    private static LinqProviderType GetProviderType(IQueryable source)
    {
      FieldInfo field = source.GetType().GetField("context", BindingFlags.Instance | BindingFlags.NonPublic);
      if (field != (FieldInfo) null && field.FieldType.IsAssignableFrom(typeof (DataContext)) && ((DataContext) field.GetValue((object) source)).Mapping.ProviderType.IsAssignableFrom(typeof (SqlProvider)))
        return LinqProviderType.SQL;
      return source.Provider.GetType().Name == "ObjectQueryProvider" || source.Provider.GetType().Name == "DbQueryProvider" ? LinqProviderType.Entities : LinqProviderType.Default;
    }

    internal static Expression ReplaceIndexOfMethod(Expression ruleLambdaExpression)
    {
      return new ConversionVisitor().Visit(ruleLambdaExpression);
    }
  }
}
