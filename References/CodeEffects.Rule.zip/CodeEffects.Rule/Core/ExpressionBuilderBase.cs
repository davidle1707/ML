﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Core.ExpressionBuilderBase
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using CodeEffects.Rule.Common;
using Microsoft.CSharp.RuntimeBinder;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Dynamic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Web.Script.Serialization;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace CodeEffects.Rule.Core
{
  internal class ExpressionBuilderBase
  {
    protected static readonly string[] mathOperators = new string[4]{ "add", "subtract", "multiply", "divide" };
    protected Type sourceType;
    protected ParameterExpression source;
    protected GetRuleInternalDelegate getRule;

    public int MaxIterations { get; set; }

    public bool PerformNullChecks { get; set; }

    public EvaluationScope EvaluationScope { get; set; }

    public bool ShortCircuit { get; set; }

    protected ExpressionBuilderBase(Type sourceType, GetRuleInternalDelegate getRule)
    {
      this.sourceType = sourceType;
      this.source = Expression.Parameter(sourceType, "x");
      this.getRule = getRule;
      this.PerformNullChecks = true;
    }

    protected Expression GetSafeExpressionBody(XElement rule, bool addSourceNullCheck)
    {
      Expression ifFalse = this.Build(rule.Element(rule.GetDefaultNamespace() + "definition").Elements());
      Expression expression;
      if (ifFalse.NodeType == ExpressionType.Loop)
        expression = ifFalse;
      else if (ifFalse.NodeType == ExpressionType.Conditional)
      {
        ConditionalExpression conditionalExpression = (ConditionalExpression) ifFalse;
        ParameterExpression parameterExpression = Expression.Variable(typeof (bool), "result");
        expression = (Expression) Expression.Block((IEnumerable<ParameterExpression>) new ParameterExpression[1]
        {
          parameterExpression
        }, new Expression[3]
        {
          (Expression) Expression.Assign((Expression) parameterExpression, conditionalExpression.Test),
          (Expression) Expression.IfThenElse((Expression) parameterExpression, conditionalExpression.IfTrue, conditionalExpression.IfFalse),
          (Expression) parameterExpression
        });
      }
      else
        expression = !addSourceNullCheck || this.source.Type.IsValueType ? ifFalse : (Expression) Expression.Condition((Expression) Expression.Equal((Expression) this.source, (Expression) Expression.Constant((object) null)), (Expression) Expression.Constant((object) false), ifFalse);
      return expression;
    }

    internal Expression Build(IEnumerable<XElement> elements)
    {
      switch (elements.Count<XElement>())
      {
        case 1:
          return this.Build(elements.First<XElement>());
        case 0:
          throw new InvalidRuleException(InvalidRuleException.ErrorIds.InvalidDefinitionStructure, new string[0]);
        default:
          if (!elements.All<XElement>((Func<XElement, bool>) (x => x.Name.LocalName == "if")))
            throw new InvalidRuleException(InvalidRuleException.ErrorIds.InvalidNumberOfIfElements, new string[0]);
          return this.BuildIfBlock(elements);
      }
    }

    internal Expression Build(XElement element)
    {
      if (element == null)
        return (Expression) null;
      string localName = element.Name.LocalName;
      switch (localName)
      {
        case "and":
        case "or":
          return this.BuildMultiBooleanOperator(element, localName);
        case "not":
          return this.BuildNotOperator(element);
        case "condition":
          return this.BuildCondition(element);
        case "property":
          return this.BuildPropertyAccessor(element);
        case "value":
          return this.BuildValue(element);
        case "self":
          return (Expression) this.source;
        case "expression":
          return this.BuildExpression(element.Elements().First<XElement>());
        case "method":
          return this.BuildMethod(element);
        case "rule":
          return this.BuildRule(element);
        case "if":
          return this.BuildIfRule(element);
        case "while":
          return this.BuildWhileRule(element);
        case "then":
        case "else":
          return this.BuildBlock(element);
        case "set":
          return this.BuildSetter(element);
        default:
          return (Expression) Expression.Empty();
      }
    }

    private Expression BuildBlock(XElement element)
    {
      if (element.Elements().Count<XElement>() <= 1)
        return this.Build(element.Elements().FirstOrDefault<XElement>());
      List<Expression> expressionList = new List<Expression>();
      foreach (XElement element1 in element.Elements())
        expressionList.Add(this.Build(element1));
      return (Expression) Expression.Block((IEnumerable<Expression>) expressionList);
    }

    private Expression BuildSetter(XElement element)
    {
      if (element.Elements().Count<XElement>() != 2)
        throw new ArgumentException("A Set element must have two child elements");
      Expression left = this.Build(element.Elements().First<XElement>());
      Expression expression = this.Build(element.Elements().Skip<XElement>(1).First<XElement>());
      return (Expression) Expression.Assign(left, (Expression) Expression.Convert(expression, left.Type));
    }

    private Expression BuildWhileRule(XElement element)
    {
      XNamespace defaultNamespace = element.GetDefaultNamespace();
      XElement xelement = element.Element(defaultNamespace + "clause");
      XElement element1 = element.Element(defaultNamespace + "then");
      Expression right = this.Build(xelement.Elements().First<XElement>());
      Expression expression = this.Build(element1);
      LabelTarget labelTarget = Expression.Label();
      ParameterExpression parameterExpression1 = Expression.Variable(typeof (int));
      ParameterExpression parameterExpression2 = Expression.Variable(typeof (bool));
      Expression test = this.MaxIterations != -1 ? (Expression) Expression.AndAlso((Expression) Expression.LessThanOrEqual((Expression) parameterExpression1, (Expression) Expression.Constant((object) this.MaxIterations)), right) : right;
      return (Expression) Expression.Block(typeof (bool), (IEnumerable<ParameterExpression>) new ParameterExpression[2]{ parameterExpression2, parameterExpression1 }, (Expression) Expression.Assign((Expression) parameterExpression2, (Expression) Expression.Constant((object) false)), (Expression) Expression.Assign((Expression) parameterExpression1, (Expression) Expression.Constant((object) 0)), (Expression) Expression.Loop((Expression) Expression.Block((IEnumerable<ParameterExpression>) new ParameterExpression[2]{ parameterExpression2, parameterExpression1 }, new Expression[2]{ (Expression) Expression.Assign((Expression) parameterExpression1, (Expression) Expression.Increment((Expression) parameterExpression1)), (Expression) Expression.IfThenElse(test, (Expression) Expression.Block(expression, (Expression) Expression.Assign((Expression) parameterExpression2, (Expression) Expression.Constant((object) true))), (Expression) Expression.Break(labelTarget)) }), labelTarget), (Expression) parameterExpression2);
    }

    private Expression BuildIfBlock(IEnumerable<XElement> elements)
    {
      List<Expression> expressionList = new List<Expression>();
      ParameterExpression parameterExpression = Expression.Variable(typeof (bool), "result");
      LabelTarget target = Expression.Label();
      bool flag = this.EvaluationScope == EvaluationScope.All;
      expressionList.Add((Expression) Expression.Assign((Expression) parameterExpression, (Expression) Expression.Constant((object) flag)));
      foreach (XElement element in elements)
      {
        ConditionalExpression conditionalExpression = (ConditionalExpression) this.Build(element);
        expressionList.Add((Expression) Expression.IfThenElse(conditionalExpression.Test, flag ? conditionalExpression.IfTrue : (this.ShortCircuit ? (Expression) Expression.Block(conditionalExpression.IfTrue, (Expression) Expression.Assign((Expression) parameterExpression, (Expression) Expression.Constant((object) true)), (Expression) Expression.Goto(target)) : (Expression) Expression.Block(conditionalExpression.IfTrue, (Expression) Expression.Assign((Expression) parameterExpression, (Expression) Expression.Constant((object) true)))), flag ? (this.ShortCircuit ? (Expression) Expression.Block(conditionalExpression.IfFalse, (Expression) Expression.Assign((Expression) parameterExpression, (Expression) Expression.Constant((object) false)), (Expression) Expression.Goto(target)) : (Expression) Expression.Block(conditionalExpression.IfFalse, (Expression) Expression.Assign((Expression) parameterExpression, (Expression) Expression.Constant((object) false)))) : conditionalExpression.IfFalse));
      }
      expressionList.Add((Expression) Expression.Label(target));
      expressionList.Add((Expression) parameterExpression);
      return (Expression) Expression.Block((IEnumerable<ParameterExpression>) new ParameterExpression[1]{ parameterExpression }, expressionList.ToArray());
    }

    private Expression BuildIfRule(XElement element)
    {
      XNamespace defaultNamespace = element.GetDefaultNamespace();
      XElement xelement = element.Element(defaultNamespace + "clause");
      XElement element1 = element.Element(defaultNamespace + "then");
      XElement element2 = element.Element(defaultNamespace + "else");
      Expression test = this.Build(xelement.Elements().First<XElement>());
      Expression ifTrue = this.Build(element1);
      if (element2 == null)
        return (Expression) Expression.IfThen(test, ifTrue);
      Expression ifFalse = this.Build(element2);
      return (Expression) Expression.IfThenElse(test, ifTrue, ifFalse);
    }

    private Expression BuildMethod(XElement element)
    {
      XAttribute xattribute1 = element.Attribute((XName) "name");
      XAttribute xattribute2 = element.Attribute((XName) "instance");
      XAttribute xattribute3 = element.Attribute((XName) "type");
      string name = xattribute1.Value;
      List<Expression> source = new List<Expression>();
      List<Type> typeList = new List<Type>();
      foreach (XElement element1 in element.Elements())
      {
        Expression expression = this.Build(element1);
        typeList.Add(expression.Type);
        source.Add(expression);
      }
      if (xattribute2 != null && (string) xattribute2 == "true")
      {
        if (source.Count == 0)
          throw new ArgumentException("Method elements marked with instance='true' must have at least one child element to be the instance.");
        Expression instance = source[0];
        Type type = instance.Type;
        MethodInfo method = type.GetMethod(name, BindingFlags.Instance | BindingFlags.Public, (System.Reflection.Binder) null, typeList.Skip<Type>(1).ToArray<Type>(), (ParameterModifier[]) null);
        if (method == (MethodInfo) null)
          method = this.FindGenericOverload(type, typeList.Skip<Type>(1).ToList<Type>(), BindingFlags.Instance | BindingFlags.Public);
        return (Expression) Expression.Call(instance, method, source.Skip<Expression>(1).ToArray<Expression>());
      }
      Type type1 = xattribute3 == null ? this.sourceType : Type.GetType(xattribute3.Value);
      MethodInfo method1 = type1.GetMethod(name, typeList.ToArray());
      if (method1 == (MethodInfo) null)
        method1 = this.FindGenericOverload(type1, typeList, BindingFlags.Public);
      if (method1 == (MethodInfo) null)
        throw new MissingMethodException("Method '" + name + "' not found.");
      if (method1.IsStatic)
        return (Expression) Expression.Call(method1, (IEnumerable<Expression>) source);
      if (type1.Equals(this.sourceType))
        return (Expression) Expression.Call((Expression) this.source, method1, (IEnumerable<Expression>) source);
      return (Expression) Expression.Call((Expression) Expression.New(type1), method1, (IEnumerable<Expression>) source);
    }

    private MethodInfo FindGenericOverload(Type type, List<Type> paramTypes, BindingFlags bindingFlags = BindingFlags.Public)
    {
      if (paramTypes.Any<Type>((Func<Type, bool>) (x =>
      {
        if (!x.IsGenericType)
          return false;
        return typeof (IEnumerable<>).MakeGenericType(x.GetGenericArguments()[0]).IsAssignableFrom(x);
      })))
      {
        Type[] genericCollectionItemTypes = paramTypes.Where<Type>((Func<Type, bool>) (x =>
        {
          if (!x.IsGenericType || x.GetGenericArguments().Length != 1)
            return false;
          return typeof (IEnumerable<>).MakeGenericType(x.GetGenericArguments()[0]).IsAssignableFrom(x);
        })).Select<Type, Type>((Func<Type, Type>) (x => x.GetGenericArguments()[0])).ToArray<Type>();
        foreach (MethodInfo methodInfo1 in ((IEnumerable<MethodInfo>) type.GetMethods()).Where<MethodInfo>((Func<MethodInfo, bool>) (x =>
        {
          if (x.ContainsGenericParameters)
            return x.GetGenericArguments().Length == genericCollectionItemTypes.Length;
          return false;
        })).ToList<MethodInfo>())
        {
          BindingFlags bindingFlags1 = BindingFlags.Default;
          if (methodInfo1.IsPublic)
            bindingFlags1 |= BindingFlags.Public;
          BindingFlags bindingFlags2 = !methodInfo1.IsStatic ? bindingFlags1 | BindingFlags.Instance : bindingFlags1 | BindingFlags.Static;
          if (methodInfo1.IsPrivate)
            bindingFlags2 |= BindingFlags.NonPublic;
          if ((bindingFlags2 & bindingFlags) == bindingFlags)
          {
            MethodInfo methodInfo2 = methodInfo1.MakeGenericMethod(genericCollectionItemTypes);
            if (((IEnumerable<ParameterInfo>) methodInfo2.GetParameters()).Select<ParameterInfo, Type>((Func<ParameterInfo, Type>) (x => x.ParameterType)).SequenceEqual<Type>((IEnumerable<Type>) paramTypes))
              return methodInfo2;
          }
        }
      }
      return (MethodInfo) null;
    }

    private Expression BuildExpression(XElement expressionBody)
    {
      string localName = expressionBody.Name.LocalName;
      Expression[] expressions = (Expression[]) null;
      if (((IEnumerable<string>) ExpressionBuilderBase.mathOperators).Contains<string>(localName))
      {
        expressions = expressionBody.Elements().Select<XElement, Expression>((Func<XElement, Expression>) (x => this.BuildExpression(x))).ToArray<Expression>();
        ExpressionBuilderBase.CastToCommonType(expressions);
      }
      switch (localName)
      {
        case "add":
          return (Expression) Expression.Add(expressions[0], expressions[1]);
        case "subtract":
          return (Expression) Expression.Subtract(expressions[0], expressions[1]);
        case "multiply":
          return (Expression) Expression.Multiply(expressions[0], expressions[1]);
        case "divide":
          return (Expression) Expression.Divide(expressions[0], expressions[1]);
        default:
          return this.Build(expressionBody);
      }
    }

    private Expression BuildValue(XElement element)
    {
      string typeName = (string) element.Attribute((XName) "type") ?? "string";
      if (element.IsEmpty)
      {
        switch (typeName)
        {
          case "bool":
            return (Expression) Expression.Constant((object) false);
          case "time":
            return (Expression) Expression.Constant((object) new TimeSpan());
          case "date":
          case "datetime":
            return (Expression) Expression.Constant((object) new DateTime());
          case "integer":
            return (Expression) Expression.Constant((object) 0);
          case "numeric":
            return (Expression) Expression.Constant((object) new Decimal(0));
          case "double":
            return (Expression) Expression.Constant((object) 0.0);
          case "string":
            return (Expression) Expression.Constant((object) null, typeof (string));
          default:
            Type type1 = Type.GetType(typeName, true, true);
            if (ExpressionBuilderBase.IsGenericNullable(type1))
              return (Expression) Expression.Constant((object) null, type1);
            return (Expression) Expression.Constant((object) null, type1);
        }
      }
      else
      {
        if (string.IsNullOrWhiteSpace(element.Value))
        {
          if (typeName == "string")
            return (Expression) Expression.Constant((object) element.Value);
          throw new ArgumentException("Value elements of value types may not contain empty content. Consider empty element to get default values, i.e. <value type='int'/>");
        }
        switch (typeName)
        {
          case "bool":
            return (Expression) Expression.Constant((object) bool.Parse(element.Value));
          case "time":
            return (Expression) Expression.Constant((object) TimeSpan.Parse(element.Value, (IFormatProvider) CultureInfo.InvariantCulture));
          case "date":
          case "datetime":
            return (Expression) Expression.Constant((object) DateTime.Parse(element.Value, (IFormatProvider) CultureInfo.InvariantCulture));
          case "integer":
            return (Expression) Expression.Constant((object) int.Parse(element.Value, (IFormatProvider) CultureInfo.InvariantCulture));
          case "numeric":
            return (Expression) Expression.Constant((object) Decimal.Parse(element.Value, (IFormatProvider) CultureInfo.InvariantCulture));
          case "double":
            return (Expression) Expression.Constant((object) double.Parse(element.Value, (IFormatProvider) CultureInfo.InvariantCulture));
          case "string":
            return (Expression) Expression.Constant((object) element.Value);
          default:
            Type type2 = Type.GetType(typeName, true, true);
            if (type2.IsEnum)
              return (Expression) Expression.Constant(Enum.Parse(type2, element.Value), type2);
            if (ExpressionBuilderBase.IsGenericNullable(type2))
            {
              Type underlyingType = Nullable.GetUnderlyingType(type2);
              MethodInfo method1 = underlyingType.GetMethod("Parse", BindingFlags.Static | BindingFlags.Public, (System.Reflection.Binder) null, new Type[2]{ typeof (string), typeof (IFormatProvider) }, (ParameterModifier[]) null);
              if (method1 != (MethodInfo) null)
              {
                try
                {
                  return (Expression) Expression.Convert((Expression) Expression.Constant(method1.Invoke((object) null, new object[2]{ (object) element.Value, (object) CultureInfo.InvariantCulture })), typeof (Nullable<>).MakeGenericType(underlyingType));
                }
                catch
                {
                }
              }
              MethodInfo method2 = underlyingType.GetMethod("Parse", BindingFlags.Static | BindingFlags.Public, (System.Reflection.Binder) null, new Type[1]{ typeof (string) }, (ParameterModifier[]) null);
              if (method2 != (MethodInfo) null)
              {
                try
                {
                  return (Expression) Expression.Convert((Expression) Expression.Constant(method2.Invoke((object) null, new object[1]{ (object) element.Value })), typeof (Nullable<>).MakeGenericType(underlyingType));
                }
                catch
                {
                }
              }
            }
            else
            {
              MethodInfo method1 = type2.GetMethod("Parse", BindingFlags.Static | BindingFlags.Public, (System.Reflection.Binder) null, new Type[2]{ typeof (string), typeof (IFormatProvider) }, (ParameterModifier[]) null);
              if (method1 != (MethodInfo) null)
              {
                try
                {
                  return (Expression) Expression.Constant(method1.Invoke((object) null, new object[2]{ (object) element.Value, (object) CultureInfo.InvariantCulture }));
                }
                catch
                {
                }
              }
              MethodInfo method2 = type2.GetMethod("Parse", BindingFlags.Static | BindingFlags.Public, (System.Reflection.Binder) null, new Type[1]{ typeof (string) }, (ParameterModifier[]) null);
              if (method2 != (MethodInfo) null)
              {
                try
                {
                  return (Expression) Expression.Constant(method2.Invoke((object) null, new object[1]{ (object) element.Value }));
                }
                catch
                {
                }
              }
            }
            try
            {
              using (StringReader stringReader = new StringReader(element.FirstNode.ToString(SaveOptions.DisableFormatting)))
                return (Expression) Expression.Constant(new XmlSerializer(type2, element.GetDefaultNamespace().NamespaceName).Deserialize((TextReader) stringReader), type2);
            }
            catch
            {
            }
            try
            {
              return (Expression) Expression.Constant(new JavaScriptSerializer().Deserialize(element.Value, type2), type2);
            }
            catch
            {
            }
            throw new ArgumentException("All attempts to deserialize have failed: Parse, Xml, and JSON.");
        }
      }
    }

    private Expression BuildExistsExpression(XElement existsElement)
    {
      string typeName = (string) existsElement.Attribute((XName) "itemType");
      Type sourceType = string.IsNullOrWhiteSpace(typeName) ? (Type) null : Type.GetType(typeName);
      Expression expression = this.Build(existsElement.Elements().First<XElement>());
      Type @interface = expression.Type.GetInterface("IEnumerable`1");
      if (@interface != (Type) null)
      {
        if (sourceType != (Type) null)
          expression = (Expression) Expression.TypeAs(expression, typeof (IEnumerable<>).MakeGenericType(sourceType));
        else
          sourceType = @interface.GetGenericArguments()[0];
      }
      else if (expression.Type.GetInterface("IEnumerable") != (Type) null)
        expression = (Expression) Expression.Call(typeof (Enumerable), "Cast", new Type[1]{ sourceType }, new Expression[1]
        {
          expression
        });
      ExpressionBuilder expressionBuilder = new ExpressionBuilder(sourceType, this.getRule);
      LambdaExpression lambdaExpression = Expression.Lambda(expressionBuilder.Build(existsElement.Elements(existsElement.GetDefaultNamespace() + "where").Elements<XElement>().First<XElement>()), new ParameterExpression[1]{ expressionBuilder.source });
      return (Expression) Expression.Call(typeof (Enumerable), "Any", new Type[1]{ sourceType }, new Expression[2]{ expression, (Expression) lambdaExpression });
    }

    private Expression BuildCondition(XElement conditionElement)
    {
      XAttribute xattribute = conditionElement.Attribute((XName) "type");
      string a = xattribute != null ? xattribute.Value : (string) null;
      XElement[] array = conditionElement.Elements().ToArray<XElement>();
      Expression[] expressions = new Expression[array.Length];
      for (int index = 0; index < expressions.Length; ++index)
        expressions[index] = this.Build(array[index]);
      List<Expression> expressionList = new List<Expression>();
      for (int index = 0; index < expressions.Length; ++index)
        expressionList.Add(expressions[index]);
      Expression left = this.BuildPropertyNullChecks(expressionList.ToArray());
      if (!typeof (IEnumerable).IsAssignableFrom(expressions[0].Type) && !string.Equals(a, "isNull", StringComparison.OrdinalIgnoreCase) && (!string.Equals(a, "isNotNull", StringComparison.OrdinalIgnoreCase) && expressions.Length > 0))
        ExpressionBuilderBase.CastToCommonType(expressions);
      Expression right;
      switch (a)
      {
        case "equal":
          right = this.BuildEqualsMethodExpression(conditionElement, expressions);
          break;
        case "notEqual":
          right = (Expression) Expression.Not(this.BuildEqualsMethodExpression(conditionElement, expressions));
          break;
        case "less":
          Tuple<Expression, Expression> tuple1 = this.BuildBinaryComparisonMethodExpression(conditionElement, expressions);
          right = (Expression) Expression.LessThan(tuple1.Item1, tuple1.Item2);
          break;
        case "lessOrEqual":
          Tuple<Expression, Expression> tuple2 = this.BuildBinaryComparisonMethodExpression(conditionElement, expressions);
          right = (Expression) Expression.LessThanOrEqual(tuple2.Item1, tuple2.Item2);
          break;
        case "greater":
          Tuple<Expression, Expression> tuple3 = this.BuildBinaryComparisonMethodExpression(conditionElement, expressions);
          right = (Expression) Expression.GreaterThan(tuple3.Item1, tuple3.Item2);
          break;
        case "greaterOrEqual":
          Tuple<Expression, Expression> tuple4 = this.BuildBinaryComparisonMethodExpression(conditionElement, expressions);
          right = (Expression) Expression.GreaterThanOrEqual(tuple4.Item1, tuple4.Item2);
          break;
        case "isNull":
          right = this.BuildIsEmptyExpression(conditionElement, expressions);
          break;
        case "isNotNull":
          right = (Expression) Expression.Not(this.BuildIsEmptyExpression(conditionElement, expressions));
          break;
        case "startsWith":
          right = this.BuildStartsOrEndsWithExpression("StartsWith", conditionElement, expressions);
          break;
        case "doesNotStartWith":
          right = (Expression) Expression.Not(this.BuildStartsOrEndsWithExpression("StartsWith", conditionElement, expressions));
          break;
        case "endsWith":
          right = this.BuildStartsOrEndsWithExpression("EndsWith", conditionElement, expressions);
          break;
        case "doesNotEndWith":
          right = (Expression) Expression.Not(this.BuildStartsOrEndsWithExpression("EndsWith", conditionElement, expressions));
          break;
        case "contains":
          right = this.BuildContainsExpression(conditionElement, expressions);
          break;
        case "doesNotContain":
          right = (Expression) Expression.Not(this.BuildContainsExpression(conditionElement, expressions));
          break;
        case "between":
          right = (Expression) Expression.AndAlso((Expression) Expression.GreaterThanOrEqual(expressions[0], expressions[1]), (Expression) Expression.LessThan(expressions[0], expressions[2]));
          break;
        default:
          throw new ArgumentException(string.Format("Condition elements do not support this operator type: '{0}'", (object) a));
      }
      if (left != null && this.PerformNullChecks)
        right = (Expression) Expression.AndAlso(left, right);
      return right;
    }

    private Expression BuildIsEmptyExpression(XElement conditionElement, Expression[] expressions)
    {
      Expression left = (Expression) Expression.Equal(expressions[0], (Expression) Expression.Constant((object) null));
      if (expressions[0].Type != typeof (string) && typeof (IEnumerable).IsAssignableFrom(expressions[0].Type))
      {
        Expression expression = expressions[0];
        Type type = typeof (object);
        if (!expressions[0].Type.IsGenericType && !expressions[0].Type.IsArray)
        {
          conditionElement.Elements().First<XElement>();
          expression = (Expression) Expression.Call((Expression) null, this.GetExtensionMethod(typeof (Enumerable), "Cast.*IEnumerable").MakeGenericMethod(type), new Expression[1]
          {
            expression
          });
        }
        else
          type = !expressions[0].Type.IsArray ? expressions[0].Type.GetGenericArguments()[0] : expressions[0].Type.GetElementType();
        MethodCallExpression methodCallExpression = Expression.Call((Expression) null, this.GetExtensionMethod(typeof (Enumerable), "Count.*IEnumerable`1\\[TSource\\]\\)").MakeGenericMethod(type), new Expression[1]{ expression });
        left = (Expression) Expression.OrElse(left, (Expression) Expression.Equal((Expression) methodCallExpression, (Expression) Expression.Constant((object) 0)));
      }
      return left;
    }

    private Expression BuildStartsOrEndsWithExpression(string methodName, XElement conditionElement, Expression[] expressions)
    {
      if (!string.Equals(methodName, "startsWith", StringComparison.OrdinalIgnoreCase) && !string.Equals(methodName, "endsWith", StringComparison.OrdinalIgnoreCase) && (!string.Equals(methodName, "doesNotStartWith", StringComparison.OrdinalIgnoreCase) && !string.Equals(methodName, "doesNotEndWith", StringComparison.OrdinalIgnoreCase)))
        throw new Exception(string.Format("Method {0} is not supported as condition operator.", (object) methodName));
      Expression condition;
      if (expressions[0].Type == typeof (string))
      {
        for (int index = 0; index < expressions.Length; ++index)
        {
          if (expressions[index].NodeType == ExpressionType.Constant && ((ConstantExpression) expressions[index]).Value == null)
            return (Expression) Expression.Constant((object) false);
        }
        StringComparison result;
        if (!Enum.TryParse<StringComparison>((string) conditionElement.Attribute((XName) "stringComparison"), out result))
          result = StringComparison.Ordinal;
        condition = (Expression) Expression.Call(expressions[0], methodName, (Type[]) null, new Expression[2]
        {
          expressions[1],
          (Expression) Expression.Constant((object) result)
        });
        if (this.PerformNullChecks)
          condition = this.AddLocalNullChecks(condition, expressions);
      }
      else
      {
        Expression right;
        if (typeof (IEnumerable).IsAssignableFrom(expressions[0].Type))
        {
          Expression expression = expressions[0];
          Type type;
          if (!expressions[0].Type.IsGenericType && !expressions[0].Type.IsArray)
          {
            XElement xelement = conditionElement.Elements().First<XElement>();
            type = xelement.Attribute((XName) "itemType") == null ? expressions[1].Type : Type.GetType((string) xelement.Attribute((XName) "itemType"));
            expression = (Expression) Expression.Call((Expression) null, this.GetExtensionMethod(typeof (Enumerable), "Cast.*IEnumerable").MakeGenericMethod(type), new Expression[1]
            {
              expression
            });
          }
          else
            type = !expressions[0].Type.IsArray ? expressions[0].Type.GetGenericArguments()[0] : expressions[0].Type.GetElementType();
          MethodCallExpression methodCallExpression = Expression.Call((Expression) null, (string.Equals(methodName, "startsWith", StringComparison.OrdinalIgnoreCase) || string.Equals(methodName, "doesNotStartWith", StringComparison.OrdinalIgnoreCase) ? this.GetExtensionMethod(typeof (Enumerable), "First.*IEnumerable`1\\[TSource\\]\\)") : this.GetExtensionMethod(typeof (Enumerable), "Last.*IEnumerable`1\\[TSource\\]\\)")).MakeGenericMethod(type), new Expression[1]{ expression });
          right = (Expression) Expression.AndAlso((Expression) Expression.Call((Expression) null, this.GetExtensionMethod(typeof (Enumerable), "Any.*IEnumerable`1\\[TSource\\]\\)").MakeGenericMethod(type), new Expression[1]
          {
            expression
          }), (Expression) Expression.Equal((Expression) methodCallExpression, expressions[1]));
        }
        else
        {
          if (!(expressions[0].Type.GetMethod(methodName) != (MethodInfo) null))
            throw new Exception(string.Format("Type {0} does not support {1}", (object) expressions[0].Type.FullName, (object) methodName));
          right = (Expression) Expression.Call(expressions[0], methodName, (Type[]) null, new Expression[1]
          {
            expressions[1]
          });
        }
        condition = (Expression) Expression.AndAlso((Expression) Expression.NotEqual(expressions[0], (Expression) Expression.Constant((object) null)), right);
      }
      return condition;
    }

    private Expression BuildContainsExpression(XElement conditionElement, Expression[] expressions)
    {
      Expression condition;
      if (expressions[0].Type == typeof (string))
      {
        for (int index = 0; index < expressions.Length; ++index)
        {
          if (expressions[index].NodeType == ExpressionType.Constant && ((ConstantExpression) expressions[index]).Value == null)
            return (Expression) Expression.Constant((object) false);
        }
        StringComparison result;
        if (!Enum.TryParse<StringComparison>((string) conditionElement.Attribute((XName) "stringComparison"), out result))
          result = StringComparison.Ordinal;
        condition = (Expression) Expression.NotEqual((Expression) Expression.Call(expressions[0], "IndexOf", (Type[]) null, new Expression[2]
        {
          expressions[1],
          (Expression) Expression.Constant((object) result)
        }), (Expression) Expression.Constant((object) -1));
        if (this.PerformNullChecks)
          condition = this.AddLocalNullChecks(condition, expressions);
      }
      else
      {
        Expression right;
        if (typeof (IEnumerable).IsAssignableFrom(expressions[0].Type))
        {
          Expression expression = expressions[0];
          Type type;
          if (!expressions[0].Type.IsGenericType && !expressions[0].Type.IsArray)
          {
            XElement xelement = conditionElement.Elements().First<XElement>();
            type = xelement.Attribute((XName) "itemType") == null ? expressions[1].Type : Type.GetType((string) xelement.Attribute((XName) "itemType"));
            expression = (Expression) Expression.Call((Expression) null, this.GetExtensionMethod(typeof (Enumerable), "Cast.*IEnumerable").MakeGenericMethod(type), new Expression[1]
            {
              expression
            });
          }
          else
            type = !expressions[0].Type.IsArray ? expressions[0].Type.GetGenericArguments()[0] : expressions[0].Type.GetElementType();
          right = (Expression) Expression.Call((Expression) null, this.GetExtensionMethod(typeof (Enumerable), "Contains.*IEnumerable`1\\[TSource\\].*TSource\\)").MakeGenericMethod(type), new Expression[2]
          {
            expression,
            expressions[1]
          });
        }
        else
        {
          if (!(expressions[0].Type.GetMethod("Contains") != (MethodInfo) null))
            throw new Exception(string.Format("Type {0} does not support Contains", (object) expressions[0].Type.FullName));
          right = (Expression) Expression.Call(expressions[0], "Contains", (Type[]) null, new Expression[1]
          {
            expressions[1]
          });
        }
        condition = (Expression) Expression.AndAlso((Expression) Expression.NotEqual(expressions[0], (Expression) Expression.Constant((object) null)), right);
      }
      return condition;
    }

    private Expression AddLocalNullChecks(Expression condition, Expression[] expressions)
    {
      if (expressions[0].NodeType != ExpressionType.Constant)
        condition = expressions[1].NodeType == ExpressionType.Constant ? (Expression) Expression.AndAlso((Expression) Expression.NotEqual(expressions[0], (Expression) Expression.Constant((object) null)), condition) : (Expression) Expression.AndAlso((Expression) Expression.AndAlso((Expression) Expression.NotEqual(expressions[0], (Expression) Expression.Constant((object) null)), (Expression) Expression.NotEqual(expressions[1], (Expression) Expression.Constant((object) null))), condition);
      else if (expressions[1].NodeType != ExpressionType.Constant)
        condition = (Expression) Expression.AndAlso((Expression) Expression.NotEqual(expressions[1], (Expression) Expression.Constant((object) null)), condition);
      return condition;
    }

    private Expression BuildEqualsMethodExpression(XElement conditionElement, Expression[] expressions)
    {
      Expression expression;
      if (expressions[0].Type != typeof (string))
      {
        expression = (Expression) Expression.Equal(expressions[0], expressions[1]);
      }
      else
      {
        StringComparison result;
        if (!Enum.TryParse<StringComparison>((string) conditionElement.Attribute((XName) "stringComparison"), out result))
          result = StringComparison.Ordinal;
        expression = (Expression) Expression.Call(typeof (string), "Equals", (Type[]) null, new Expression[3]
        {
          expressions[0],
          expressions[1],
          (Expression) Expression.Constant((object) result)
        });
      }
      return expression;
    }

    private Tuple<Expression, Expression> BuildBinaryComparisonMethodExpression(XElement conditionElement, Expression[] expressions)
    {
      if (expressions[0].Type != typeof (string))
        return new Tuple<Expression, Expression>(expressions[0], expressions[1]);
      StringComparison result;
      if (!Enum.TryParse<StringComparison>((string) conditionElement.Attribute((XName) "stringComparison"), out result))
        result = StringComparison.Ordinal;
      return new Tuple<Expression, Expression>((Expression) Expression.Call(typeof (string), "Compare", (Type[]) null, new Expression[3]{ expressions[0], expressions[1], (Expression) Expression.Constant((object) result) }), (Expression) Expression.Constant((object) 0));
    }

    private Expression BuildStringMethodExpression(string methodName, XElement conditionElement, Expression[] expressions)
    {
      Expression condition;
      if (expressions[0].Type != typeof (string))
      {
        condition = (Expression) Expression.Call(expressions[0], methodName, (Type[]) null, new Expression[1]
        {
          expressions[1]
        });
      }
      else
      {
        for (int index = 0; index < expressions.Length; ++index)
        {
          if (expressions[index].NodeType == ExpressionType.Constant && ((ConstantExpression) expressions[index]).Value == null)
            return (Expression) Expression.Constant((object) false);
        }
        StringComparison result;
        if (!Enum.TryParse<StringComparison>((string) conditionElement.Attribute((XName) "stringComparison"), out result))
          result = StringComparison.Ordinal;
        condition = (Expression) Expression.Call(expressions[0], methodName, (Type[]) null, new Expression[2]
        {
          expressions[1],
          (Expression) Expression.Constant((object) result)
        });
        if (this.PerformNullChecks)
          condition = this.AddLocalNullChecks(condition, expressions);
      }
      return condition;
    }

    private static int NumericTypeRank(Type type)
    {
      if (type == typeof (int) || type == typeof (byte) || (type == typeof (sbyte) || type == typeof (short)) || (type == typeof (ushort) || type == typeof (char)))
        return 0;
      if (type == typeof (uint) || type == typeof (long))
        return 1;
      if (type == typeof (Decimal))
        return 2;
      if (type == typeof (float))
        return 3;
      return type == typeof (double) ? 4 : -1;
    }

    private static void CastToCommonType(Expression[] expressions)
    {
      Type type1 = expressions[0].Type.GetNonNullableType();
      int num1 = ExpressionBuilderBase.NumericTypeRank(type1);
      if (num1 > ExpressionBuilderBase.NumericTypeRank(typeof (byte)))
      {
        type1 = typeof (byte);
        num1 = ExpressionBuilderBase.NumericTypeRank(type1);
      }
      bool flag = ExpressionBuilderBase.IsGenericNullable(type1);
      for (int index = 0; index < expressions.Length; ++index)
      {
        Type type2 = expressions[index].Type;
        if (ExpressionBuilderBase.IsGenericNullable(type2))
        {
          type2 = type2.GetNonNullableType();
          flag = true;
        }
        if (type2 == typeof (byte) || type2 == typeof (sbyte) || (type2 == typeof (short) || type2 == typeof (ushort)) || type2 == typeof (char))
          type2 = typeof (int);
        else if (type2 == typeof (uint))
          type2 = typeof (long);
        int num2 = ExpressionBuilderBase.NumericTypeRank(type2);
        if (num2 >= 0 && num1 < num2 || num2 < 0 && TypeUtils.IsImplicitlyConvertible(type1, type2))
        {
          type1 = type2;
          num1 = num2;
        }
      }
      for (int index = 0; index < expressions.Length; ++index)
      {
        Type type2 = expressions[index].Type;
        if (flag)
        {
          if (!ExpressionBuilderBase.IsGenericNullable(type2) || type2.GetNonNullableType() != type1)
            expressions[index] = (Expression) Expression.Convert(expressions[index], typeof (Nullable<>).MakeGenericType(type1));
        }
        else if (type2 != type1)
          expressions[index] = (Expression) Expression.Convert(expressions[index], type1);
      }
    }

    public static bool IsGenericNullable(Type type)
    {
      if (type.IsGenericType)
        return type.GetGenericTypeDefinition() == typeof (Nullable<>);
      return false;
    }

    private Expression BuildPropertyNullChecks(params Expression[] expressions)
    {
      Expression left1 = (Expression) null;
      Stack<Expression> expressionStack = new Stack<Expression>();
      List<string> stringList = new List<string>();
      for (int index = 0; index < expressions.Length; ++index)
      {
        if (expressions[index].NodeType == ExpressionType.MemberAccess)
        {
          for (Expression expression = ((MemberExpression) expressions[index]).Expression; expression.NodeType == ExpressionType.MemberAccess; expression = ((MemberExpression) expression).Expression)
            expressionStack.Push(expression);
          while (expressionStack.Count > 0)
          {
            Expression left2 = expressionStack.Pop();
            if (!stringList.Contains(left2.ToString()))
            {
              stringList.Add(left2.ToString());
              left1 = left1 != null ? (Expression) Expression.AndAlso(left1, (Expression) Expression.NotEqual(left2, (Expression) Expression.Constant((object) null))) : (Expression) Expression.NotEqual(left2, (Expression) Expression.Constant((object) null));
            }
          }
        }
      }
      return left1;
    }

    private Expression GetMemberExpression(Expression source, string name)
    {
      if (typeof (IDynamicMetaObjectProvider).IsAssignableFrom(source.Type))
        return (Expression) Expression.Dynamic(Microsoft.CSharp.RuntimeBinder.Binder.GetMember(CSharpBinderFlags.None, name, source.Type, (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]{ CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null) }), typeof (object), source);
      try
      {
        return (Expression) Expression.PropertyOrField(source, name);
      }
      catch (AmbiguousMatchException ex)
      {
        MemberInfo[] member = source.Type.GetMember(name);
        return (Expression) Expression.MakeMemberAccess(source, member[0]);
      }
    }

    private Expression BuildPropertyAccessor(XElement element)
    {
      if (string.IsNullOrWhiteSpace((string) element.Attribute((XName) "name")))
        throw new ArgumentException("A property element must have a non-empty name attribute");
      string[] strArray = element.Attribute((XName) "name").Value.Split('.');
      Expression source = this.GetMemberExpression((Expression) this.source, strArray[0]);
      for (int index = 1; index < strArray.Length; ++index)
        source = this.GetMemberExpression(source, strArray[index]);
      if (typeof (IDynamicMetaObjectProvider).IsAssignableFrom(this.source.Type))
        source = (Expression) Expression.Dynamic(Microsoft.CSharp.RuntimeBinder.Binder.Convert(CSharpBinderFlags.None, source.Type, this.source.Type), source.Type, source);
      return source;
    }

    private Expression BuildMultiBooleanOperator(XElement element, string elementName)
    {
      Expression[] array = element.Elements().Select<XElement, Expression>((Func<XElement, Expression>) (x => this.Build(x))).ToArray<Expression>();
      if (array.Length < 1)
        throw new ArgumentException("A multi-boolean operator (AND, OR, etc.) must have at least one child element.");
      Expression left = array[0];
      for (int index = 1; index < array.Length; ++index)
        left = !(elementName == "and") ? (Expression) Expression.OrElse(left, array[index]) : (Expression) Expression.AndAlso(left, array[index]);
      return left;
    }

    private XElement LoadRule(XElement element, string id)
    {
      if (element == null)
        throw new ArgumentNullException("element", "Cannot do anything when xml is empty.");
      if (string.IsNullOrWhiteSpace(id))
        throw new ArgumentNullException("id", "Missing rule id.");
      XNamespace defaultNamespace1 = element.GetDefaultNamespace();
      XElement xelement = element.AncestorsAndSelf(defaultNamespace1 + "codeeffects").Elements<XElement>(defaultNamespace1 + "rule").Where<XElement>((Func<XElement, bool>) (x => (string) x.Attribute((XName) "id") == id)).FirstOrDefault<XElement>();
      if (xelement == null && this.getRule != null)
      {
        xelement = this.getRule(id);
        if (xelement != null)
        {
          XNamespace defaultNamespace2 = xelement.GetDefaultNamespace();
          if (xelement.Name == defaultNamespace2 + "codeeffects")
            xelement = xelement.Elements(defaultNamespace2 + "rule").Where<XElement>((Func<XElement, bool>) (x => (string) x.Attribute((XName) "id") == id)).FirstOrDefault<XElement>();
          else if (xelement.Name != defaultNamespace2 + "rule")
            throw new Exception("Invalid rule xml. Expected either the <rule> node or the <codeeffects>, received <" + (object) xelement.Name + "> instead.");
        }
      }
      if (xelement == null)
        throw new InvalidRuleException(InvalidRuleException.ErrorIds.RuleNotFound, new string[1]{ id });
      return xelement;
    }

    private Expression BuildRule(XElement element)
    {
      element.GetDefaultNamespace();
      string id = (string) element.Attribute((XName) "id");
      XElement rule = this.LoadRule(element, id);
      XElement element1 = element.Elements().FirstOrDefault<XElement>();
      Expression context = (Expression) null;
      if (element1 != null)
        context = this.Build(element1);
      if (context != null)
      {
        Type type = Type.GetType((string) rule.Attribute((XName) "type"));
        ParameterExpression parameterExpression = this.source;
        this.source = Expression.Parameter(type, "x");
        this.sourceType = type;
        bool performNullChecks = this.PerformNullChecks;
        if (typeof (IQueryable).IsAssignableFrom(context.Type))
          this.PerformNullChecks = false;
        Expression safeExpressionBody = this.GetSafeExpressionBody(rule, false);
        this.PerformNullChecks = performNullChecks;
        LambdaExpression ruleLambdaExpression = Expression.Lambda(safeExpressionBody, new ParameterExpression[1]{ this.source });
        Expression expression = typeof (IQueryable).IsAssignableFrom(context.Type) || typeof (IEnumerable).IsAssignableFrom(context.Type) ? this.BuildCollectionOperator((string) element.Attribute((XName) "operator"), context, ruleLambdaExpression, type) : safeExpressionBody;
        this.source = parameterExpression;
        this.sourceType = parameterExpression.Type;
        return expression;
      }
      XNamespace defaultNamespace = rule.GetDefaultNamespace();
      return this.Build(rule.Elements(defaultNamespace + "definition").Elements<XElement>().FirstOrDefault<XElement>());
    }

    private Expression BuildCollectionOperator(string @operator, Expression context, LambdaExpression ruleLambdaExpression, Type itemType)
    {
      Type type = context.Type;
      Expression left = (Expression) Expression.NotEqual(context, (Expression) Expression.Constant((object) null));
      ExpressionBuilderBase.CollectionTypeEnum collectionTypeEnum;
      MethodInfo extensionMethod1;
      if (typeof (IQueryable).IsAssignableFrom(type))
      {
        collectionTypeEnum = ExpressionBuilderBase.CollectionTypeEnum.Queryable;
        extensionMethod1 = this.GetExtensionMethod(typeof (Queryable), "Any.*IQueryable`1\\[TSource\\]\\)");
        ruleLambdaExpression = (LambdaExpression) RuleExtensions.ReplaceIndexOfMethod((Expression) ruleLambdaExpression);
      }
      else
      {
        if (!typeof (IEnumerable).IsAssignableFrom(type))
          throw new Exception(string.Format("Operator {0} is only supported for collections that implement IEnumerable, IEnumerable<T>, IQueryable, and IQueryable<T>. Type '{1}' is not supported.", (object) @operator, (object) type.AssemblyQualifiedName));
        collectionTypeEnum = ExpressionBuilderBase.CollectionTypeEnum.Enumerable;
        extensionMethod1 = this.GetExtensionMethod(typeof (Enumerable), "Any.*IEnumerable`1\\[TSource\\]\\)");
      }
      switch (@operator)
      {
        case "exists":
        case "doesNotExist":
          string pattern1 = "Any.*IQueryable`1.*Expression`1.*Func`2";
          string pattern2 = "Any.*IEnumerable`1.*Func`2";
          Expression[] expressionArray;
          if (collectionTypeEnum == ExpressionBuilderBase.CollectionTypeEnum.Queryable)
            expressionArray = new Expression[2]
            {
              context,
              (Expression) Expression.Quote((Expression) ruleLambdaExpression)
            };
          else
            expressionArray = new Expression[2]
            {
              context,
              (Expression) ruleLambdaExpression
            };
          MethodInfo extensionMethod2;
          if (collectionTypeEnum == ExpressionBuilderBase.CollectionTypeEnum.Queryable)
          {
            extensionMethod2 = this.GetExtensionMethod(typeof (Queryable), pattern1);
          }
          else
          {
            extensionMethod2 = this.GetExtensionMethod(typeof (Enumerable), pattern2);
            if (!context.Type.IsGenericType && !context.Type.IsArray)
            {
              context = (Expression) Expression.Call((Expression) null, this.GetExtensionMethod(typeof (Enumerable), "Cast.*IEnumerable").MakeGenericMethod(itemType), new Expression[1]{ context });
              expressionArray[0] = context;
            }
          }
          MethodCallExpression methodCallExpression1 = Expression.Call((Expression) null, extensionMethod2.MakeGenericMethod(itemType), expressionArray);
          Expression expression;
          if (@operator == "exists" || @operator == "doesNotExist")
          {
            expression = !this.PerformNullChecks ? (Expression) methodCallExpression1 : (Expression) Expression.AndAlso(left, (Expression) methodCallExpression1);
          }
          else
          {
            MethodCallExpression methodCallExpression2 = Expression.Call((Expression) null, extensionMethod1.MakeGenericMethod(itemType), new Expression[1]{ context });
            if (this.PerformNullChecks)
              expression = (Expression) Expression.AndAlso((Expression) Expression.AndAlso(left, (Expression) methodCallExpression2), (Expression) Expression.Invoke((Expression) ruleLambdaExpression, new Expression[1]
              {
                (Expression) methodCallExpression1
              }));
            else
              expression = (Expression) Expression.AndAlso((Expression) methodCallExpression2, (Expression) Expression.Invoke((Expression) ruleLambdaExpression, new Expression[1]
              {
                (Expression) methodCallExpression1
              }));
          }
          if (@operator == "doesNotExist")
            expression = (Expression) Expression.Not(expression);
          return expression;
        default:
          throw new Exception(string.Format("Operator {0} is not surrpoted for collections", (object) @operator));
      }
    }

    private MethodInfo GetExtensionMethod(Type type, string pattern)
    {
      Regex rx = new Regex(pattern);
      return ((IEnumerable<MethodInfo>) type.GetMethods()).Where<MethodInfo>((Func<MethodInfo, bool>) (x => rx.IsMatch(x.ToString()))).FirstOrDefault<MethodInfo>();
    }

    private MethodInfo GetExtensionMethod(string name, Type type)
    {
      if (type == typeof (IQueryable))
        return ((IEnumerable<MethodInfo>) typeof (Queryable).GetMethods()).Where<MethodInfo>((Func<MethodInfo, bool>) (method =>
        {
          if (method.Name == name)
            return ((IEnumerable<ParameterInfo>) method.GetParameters()).Where<ParameterInfo>((Func<ParameterInfo, bool>) (parameter =>
            {
              if (parameter.ParameterType.Name.StartsWith("Expression"))
                return ((IEnumerable<Type>) parameter.ParameterType.GetGenericArguments()).Where<Type>((Func<Type, bool>) (genericArg => ((IEnumerable<Type>) genericArg.GetGenericArguments()).Count<Type>() == 2)).Any<Type>();
              return false;
            })).Any<ParameterInfo>();
          return false;
        })).FirstOrDefault<MethodInfo>();
      if (type == typeof (IEnumerable))
        return ((IEnumerable<MethodInfo>) typeof (Enumerable).GetMethods()).Where<MethodInfo>((Func<MethodInfo, bool>) (method =>
        {
          if (method.Name == name)
            return ((IEnumerable<ParameterInfo>) method.GetParameters()).Where<ParameterInfo>((Func<ParameterInfo, bool>) (parameter =>
            {
              if (parameter.ParameterType.Name.StartsWith("Func"))
                return ((IEnumerable<Type>) parameter.ParameterType.GetGenericArguments()).Count<Type>() == 2;
              return false;
            })).Any<ParameterInfo>();
          return false;
        })).FirstOrDefault<MethodInfo>();
      throw new Exception("Unsupported Type. Only IQueryable or IEnumerable are supported");
    }

    private Type GetItemType(Type type)
    {
      if (type.IsArray)
        return type.GetElementType();
      type.IsAssignableFrom(typeof (IEnumerable));
      if (type.IsAssignableFrom(typeof (IEnumerable<>)))
        return type.GetGenericArguments()[0];
      type.IsAssignableFrom(typeof (IQueryable));
      if (type.IsAssignableFrom(typeof (IQueryable<>)))
        return type.GetGenericArguments()[0];
      throw new Exception("Unsupported type: not an Array, IEnumerable<>, or IQueryable<>. Cannot determine item's type");
    }

    private Expression BuildNotOperator(XElement element)
    {
      return (Expression) Expression.Not(this.Build(element.Elements().First<XElement>()));
    }

    private enum CollectionTypeEnum
    {
      NotSupported,
      Queryable,
      Enumerable,
    }
  }
}
