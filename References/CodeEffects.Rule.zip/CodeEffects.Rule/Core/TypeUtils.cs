﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Core.TypeUtils
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using System;
using System.Linq.Expressions;
using System.Reflection;

namespace CodeEffects.Rule.Core
{
  internal static class TypeUtils
  {
    private static readonly Assembly _mscorlib = typeof (object).Assembly;
    private static readonly Assembly _systemCore = typeof (Expression).Assembly;
    private const BindingFlags AnyStatic = BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic;
    internal const MethodAttributes PublicStatic = MethodAttributes.Public | MethodAttributes.Static;

    internal static bool AreEquivalent(Type t1, Type t2)
    {
      if (!(t1 == t2))
        return t1.IsEquivalentTo(t2);
      return true;
    }

    internal static bool AreReferenceAssignable(Type dest, Type src)
    {
      if (TypeUtils.AreEquivalent(dest, src))
        return true;
      if (!dest.IsValueType && !src.IsValueType)
        return dest.IsAssignableFrom(src);
      return false;
    }

    internal static bool CanCache(this Type t)
    {
      Assembly assembly = t.Assembly;
      if (assembly != TypeUtils._mscorlib && assembly != TypeUtils._systemCore)
        return false;
      if (t.IsGenericType)
      {
        foreach (Type genericArgument in t.GetGenericArguments())
        {
          if (!genericArgument.CanCache())
            return false;
        }
      }
      return true;
    }

    internal static MethodInfo FindConversionOperator(MethodInfo[] methods, Type typeFrom, Type typeTo, bool implicitOnly)
    {
      foreach (MethodInfo method in methods)
      {
        if ((method.Name == "op_Implicit" || !implicitOnly && method.Name == "op_Explicit") && (TypeUtils.AreEquivalent(method.ReturnType, typeTo) && TypeUtils.AreEquivalent(method.GetParametersCached()[0].ParameterType, typeFrom)))
          return method;
      }
      return (MethodInfo) null;
    }

    internal static Type FindGenericType(Type definition, Type type)
    {
      for (; type != (Type) null && type != typeof (object); type = type.BaseType)
      {
        if (type.IsGenericType && TypeUtils.AreEquivalent(type.GetGenericTypeDefinition(), definition))
          return type;
        if (definition.IsInterface)
        {
          foreach (Type @interface in type.GetInterfaces())
          {
            Type genericType = TypeUtils.FindGenericType(definition, @interface);
            if (genericType != (Type) null)
              return genericType;
          }
        }
      }
      return (Type) null;
    }

    internal static MethodInfo GetBooleanOperator(Type type, string name)
    {
      do
      {
        MethodInfo methodValidated = type.GetMethodValidated(name, BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic, (Binder) null, new Type[1]{ type }, (ParameterModifier[]) null);
        if (methodValidated != (MethodInfo) null && methodValidated.IsSpecialName && !methodValidated.ContainsGenericParameters)
          return methodValidated;
        type = type.BaseType;
      }
      while (type != (Type) null);
      return (MethodInfo) null;
    }

    internal static Type GetNonNullableType(this Type type)
    {
      if (type.IsNullableType())
        return type.GetGenericArguments()[0];
      return type;
    }

    internal static Type GetNonRefType(this Type type)
    {
      if (!type.IsByRef)
        return type;
      return type.GetElementType();
    }

    internal static Type GetNullableType(Type type)
    {
      if (!type.IsValueType || type.IsNullableType())
        return type;
      return typeof (Nullable<>).MakeGenericType(type);
    }

    internal static MethodInfo GetUserDefinedCoercionMethod(Type convertFrom, Type convertToType, bool implicitOnly)
    {
      Type nonNullableType1 = convertFrom.GetNonNullableType();
      Type nonNullableType2 = convertToType.GetNonNullableType();
      MethodInfo[] methods1 = nonNullableType1.GetMethods(BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
      MethodInfo conversionOperator1 = TypeUtils.FindConversionOperator(methods1, convertFrom, convertToType, implicitOnly);
      if (conversionOperator1 != (MethodInfo) null)
        return conversionOperator1;
      MethodInfo[] methods2 = nonNullableType2.GetMethods(BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
      MethodInfo conversionOperator2 = TypeUtils.FindConversionOperator(methods2, convertFrom, convertToType, implicitOnly);
      if (conversionOperator2 != (MethodInfo) null)
        return conversionOperator2;
      if (!TypeUtils.AreEquivalent(nonNullableType1, convertFrom) || !TypeUtils.AreEquivalent(nonNullableType2, convertToType))
      {
        MethodInfo conversionOperator3 = TypeUtils.FindConversionOperator(methods1, nonNullableType1, nonNullableType2, implicitOnly);
        if (conversionOperator3 == (MethodInfo) null)
          conversionOperator3 = TypeUtils.FindConversionOperator(methods2, nonNullableType1, nonNullableType2, implicitOnly);
        if (conversionOperator3 != (MethodInfo) null)
          return conversionOperator3;
      }
      return (MethodInfo) null;
    }

    internal static bool HasBuiltInEqualityOperator(Type left, Type right)
    {
      if ((!left.IsInterface || right.IsValueType) && (!right.IsInterface || left.IsValueType) && (left.IsValueType || right.IsValueType || !TypeUtils.AreReferenceAssignable(left, right) && !TypeUtils.AreReferenceAssignable(right, left)))
      {
        if (!TypeUtils.AreEquivalent(left, right))
          return false;
        Type nonNullableType = left.GetNonNullableType();
        if (!(nonNullableType == typeof (bool)) && !TypeUtils.IsNumeric(nonNullableType) && !nonNullableType.IsEnum)
          return false;
      }
      return true;
    }

    internal static bool HasIdentityPrimitiveOrNullableConversion(Type source, Type dest)
    {
      if (TypeUtils.AreEquivalent(source, dest) || source.IsNullableType() && TypeUtils.AreEquivalent(dest, source.GetNonNullableType()) || dest.IsNullableType() && TypeUtils.AreEquivalent(source, dest.GetNonNullableType()))
        return true;
      if (TypeUtils.IsConvertible(source) && TypeUtils.IsConvertible(dest))
        return dest.GetNonNullableType() != typeof (bool);
      return false;
    }

    internal static bool HasReferenceConversion(Type source, Type dest)
    {
      if (source == typeof (void) || dest == typeof (void))
        return false;
      Type nonNullableType1 = source.GetNonNullableType();
      Type nonNullableType2 = dest.GetNonNullableType();
      return nonNullableType1.IsAssignableFrom(nonNullableType2) || nonNullableType2.IsAssignableFrom(nonNullableType1) || (source.IsInterface || dest.IsInterface) || (TypeUtils.IsLegalExplicitVariantDelegateConversion(source, dest) || source == typeof (object) || dest == typeof (object));
    }

    internal static bool HasReferenceEquality(Type left, Type right)
    {
      if (left.IsValueType || right.IsValueType)
        return false;
      if (!left.IsInterface && !right.IsInterface && !TypeUtils.AreReferenceAssignable(left, right))
        return TypeUtils.AreReferenceAssignable(right, left);
      return true;
    }

    internal static bool IsArithmetic(Type type)
    {
      type = type.GetNonNullableType();
      if (!type.IsEnum)
      {
        switch (Type.GetTypeCode(type))
        {
          case TypeCode.Int16:
          case TypeCode.UInt16:
          case TypeCode.Int32:
          case TypeCode.UInt32:
          case TypeCode.Int64:
          case TypeCode.UInt64:
          case TypeCode.Single:
          case TypeCode.Double:
            return true;
        }
      }
      return false;
    }

    internal static bool IsBool(Type type)
    {
      return type.GetNonNullableType() == typeof (bool);
    }

    private static bool IsContravariant(Type t)
    {
      return GenericParameterAttributes.None != (t.GenericParameterAttributes & GenericParameterAttributes.Contravariant);
    }

    internal static bool IsConvertible(Type type)
    {
      type = type.GetNonNullableType();
      if (type.IsEnum)
        return true;
      switch (Type.GetTypeCode(type))
      {
        case TypeCode.Boolean:
        case TypeCode.Char:
        case TypeCode.SByte:
        case TypeCode.Byte:
        case TypeCode.Int16:
        case TypeCode.UInt16:
        case TypeCode.Int32:
        case TypeCode.UInt32:
        case TypeCode.Int64:
        case TypeCode.UInt64:
        case TypeCode.Single:
        case TypeCode.Double:
          return true;
        default:
          return false;
      }
    }

    private static bool IsCovariant(Type t)
    {
      return GenericParameterAttributes.None != (t.GenericParameterAttributes & GenericParameterAttributes.Covariant);
    }

    private static bool IsDelegate(Type t)
    {
      return t.IsSubclassOf(typeof (Delegate));
    }

    internal static bool IsFloatingPoint(Type type)
    {
      type = type.GetNonNullableType();
      switch (Type.GetTypeCode(type))
      {
        case TypeCode.Single:
        case TypeCode.Double:
          return true;
        default:
          return false;
      }
    }

    private static bool IsImplicitBoxingConversion(Type source, Type destination)
    {
      if (source.IsValueType && (destination == typeof (object) || destination == typeof (ValueType)))
        return true;
      if (source.IsEnum)
        return destination == typeof (Enum);
      return false;
    }

    internal static bool IsImplicitlyConvertible(Type source, Type destination)
    {
      if (!TypeUtils.AreEquivalent(source, destination) && !TypeUtils.IsImplicitNumericConversion(source, destination) && (!TypeUtils.IsImplicitReferenceConversion(source, destination) && !TypeUtils.IsImplicitBoxingConversion(source, destination)))
        return TypeUtils.IsImplicitNullableConversion(source, destination);
      return true;
    }

    private static bool IsImplicitNullableConversion(Type source, Type destination)
    {
      if (destination.IsNullableType())
        return TypeUtils.IsImplicitlyConvertible(source.GetNonNullableType(), destination.GetNonNullableType());
      return false;
    }

    private static bool IsImplicitNumericConversion(Type source, Type destination)
    {
      TypeCode typeCode1 = Type.GetTypeCode(source);
      TypeCode typeCode2 = Type.GetTypeCode(destination);
      switch (typeCode1)
      {
        case TypeCode.Char:
          switch (typeCode2)
          {
            case TypeCode.UInt16:
            case TypeCode.Int32:
            case TypeCode.UInt32:
            case TypeCode.Int64:
            case TypeCode.UInt64:
            case TypeCode.Single:
            case TypeCode.Double:
            case TypeCode.Decimal:
              return true;
            default:
              return false;
          }
        case TypeCode.SByte:
          switch (typeCode2)
          {
            case TypeCode.Int16:
            case TypeCode.Int32:
            case TypeCode.Int64:
            case TypeCode.Single:
            case TypeCode.Double:
            case TypeCode.Decimal:
              return true;
            default:
              return false;
          }
        case TypeCode.Byte:
          switch (typeCode2)
          {
            case TypeCode.Int16:
            case TypeCode.UInt16:
            case TypeCode.Int32:
            case TypeCode.UInt32:
            case TypeCode.Int64:
            case TypeCode.UInt64:
            case TypeCode.Single:
            case TypeCode.Double:
            case TypeCode.Decimal:
              return true;
            default:
              return false;
          }
        case TypeCode.Int16:
          switch (typeCode2)
          {
            case TypeCode.Int32:
            case TypeCode.Int64:
            case TypeCode.Single:
            case TypeCode.Double:
            case TypeCode.Decimal:
              return true;
            default:
              return false;
          }
        case TypeCode.UInt16:
          switch (typeCode2)
          {
            case TypeCode.Int32:
            case TypeCode.UInt32:
            case TypeCode.Int64:
            case TypeCode.UInt64:
            case TypeCode.Single:
            case TypeCode.Double:
            case TypeCode.Decimal:
              return true;
            default:
              return false;
          }
        case TypeCode.Int32:
          switch (typeCode2)
          {
            case TypeCode.Int64:
            case TypeCode.Single:
            case TypeCode.Double:
            case TypeCode.Decimal:
              return true;
            default:
              return false;
          }
        case TypeCode.UInt32:
          switch (typeCode2)
          {
            case TypeCode.UInt32:
            case TypeCode.UInt64:
            case TypeCode.Single:
            case TypeCode.Double:
            case TypeCode.Decimal:
              return true;
            default:
              return false;
          }
        case TypeCode.Int64:
        case TypeCode.UInt64:
          switch (typeCode2)
          {
            case TypeCode.Single:
            case TypeCode.Double:
            case TypeCode.Decimal:
              return true;
            default:
              return false;
          }
        case TypeCode.Single:
          return typeCode2 == TypeCode.Double;
        default:
          return false;
      }
    }

    private static bool IsImplicitReferenceConversion(Type source, Type destination)
    {
      return destination.IsAssignableFrom(source);
    }

    internal static bool IsInteger(Type type)
    {
      type = type.GetNonNullableType();
      if (!type.IsEnum)
      {
        switch (Type.GetTypeCode(type))
        {
          case TypeCode.SByte:
          case TypeCode.Byte:
          case TypeCode.Int16:
          case TypeCode.UInt16:
          case TypeCode.Int32:
          case TypeCode.UInt32:
          case TypeCode.Int64:
          case TypeCode.UInt64:
            return true;
        }
      }
      return false;
    }

    internal static bool IsIntegerOrBool(Type type)
    {
      type = type.GetNonNullableType();
      if (!type.IsEnum)
      {
        switch (Type.GetTypeCode(type))
        {
          case TypeCode.Boolean:
          case TypeCode.SByte:
          case TypeCode.Byte:
          case TypeCode.Int16:
          case TypeCode.UInt16:
          case TypeCode.Int32:
          case TypeCode.UInt32:
          case TypeCode.Int64:
          case TypeCode.UInt64:
            return true;
        }
      }
      return false;
    }

    private static bool IsInvariant(Type t)
    {
      return GenericParameterAttributes.None == (t.GenericParameterAttributes & GenericParameterAttributes.VarianceMask);
    }

    internal static bool IsLegalExplicitVariantDelegateConversion(Type source, Type dest)
    {
      if (!TypeUtils.IsDelegate(source) || !TypeUtils.IsDelegate(dest) || (!source.IsGenericType || !dest.IsGenericType))
        return false;
      Type genericTypeDefinition = source.GetGenericTypeDefinition();
      if (dest.GetGenericTypeDefinition() != genericTypeDefinition)
        return false;
      Type[] genericArguments1 = genericTypeDefinition.GetGenericArguments();
      Type[] genericArguments2 = source.GetGenericArguments();
      Type[] genericArguments3 = dest.GetGenericArguments();
      for (int index = 0; index < genericArguments1.Length; ++index)
      {
        Type type1 = genericArguments2[index];
        Type type2 = genericArguments3[index];
        if (!TypeUtils.AreEquivalent(type1, type2))
        {
          Type t = genericArguments1[index];
          if (TypeUtils.IsInvariant(t))
            return false;
          if (TypeUtils.IsCovariant(t))
          {
            if (!TypeUtils.HasReferenceConversion(type1, type2))
              return false;
          }
          else if (TypeUtils.IsContravariant(t) && (type1.IsValueType || type2.IsValueType))
            return false;
        }
      }
      return true;
    }

    internal static bool IsNullableType(this Type type)
    {
      if (type.IsGenericType)
        return type.GetGenericTypeDefinition() == typeof (Nullable<>);
      return false;
    }

    internal static bool IsNumeric(Type type)
    {
      type = type.GetNonNullableType();
      if (!type.IsEnum)
      {
        switch (Type.GetTypeCode(type))
        {
          case TypeCode.Char:
          case TypeCode.SByte:
          case TypeCode.Byte:
          case TypeCode.Int16:
          case TypeCode.UInt16:
          case TypeCode.Int32:
          case TypeCode.UInt32:
          case TypeCode.Int64:
          case TypeCode.UInt64:
          case TypeCode.Single:
          case TypeCode.Double:
            return true;
        }
      }
      return false;
    }

    internal static bool IsSameOrSubclass(Type type, Type subType)
    {
      if (!TypeUtils.AreEquivalent(type, subType))
        return subType.IsSubclassOf(type);
      return true;
    }

    internal static bool IsUnsigned(Type type)
    {
      type = type.GetNonNullableType();
      switch (Type.GetTypeCode(type))
      {
        case TypeCode.Char:
        case TypeCode.Byte:
        case TypeCode.UInt16:
        case TypeCode.UInt32:
        case TypeCode.UInt64:
          return true;
        default:
          return false;
      }
    }

    internal static bool IsUnsignedInt(Type type)
    {
      type = type.GetNonNullableType();
      if (!type.IsEnum)
      {
        switch (Type.GetTypeCode(type))
        {
          case TypeCode.UInt16:
          case TypeCode.UInt32:
          case TypeCode.UInt64:
            return true;
        }
      }
      return false;
    }

    internal static bool IsValidInstanceType(MemberInfo member, Type instanceType)
    {
      Type declaringType = member.DeclaringType;
      if (TypeUtils.AreReferenceAssignable(declaringType, instanceType))
        return true;
      if (instanceType.IsValueType)
      {
        if (TypeUtils.AreReferenceAssignable(declaringType, typeof (object)) || TypeUtils.AreReferenceAssignable(declaringType, typeof (ValueType)) || instanceType.IsEnum && TypeUtils.AreReferenceAssignable(declaringType, typeof (Enum)))
          return true;
        if (declaringType.IsInterface)
        {
          foreach (Type @interface in instanceType.GetInterfaces())
          {
            if (TypeUtils.AreReferenceAssignable(declaringType, @interface))
              return true;
          }
        }
      }
      return false;
    }

    internal static void ValidateType(Type type)
    {
      if (type.IsGenericTypeDefinition)
        throw new ArgumentException(string.Format("Type {0} is a generic type definition", (object) type));
      if (type.ContainsGenericParameters)
        throw new ArgumentException(string.Format("Type {0} contains generic parameters", (object) type));
    }
  }
}
