﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Core.TypeExtensions
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using System;
using System.Reflection;
using System.Reflection.Emit;

namespace CodeEffects.Rule.Core
{
  internal static class TypeExtensions
  {
    private static readonly CacheDict<MethodBase, ParameterInfo[]> _ParamInfoCache = new CacheDict<MethodBase, ParameterInfo[]>(75);

    internal static Delegate CreateDelegate(this MethodInfo methodInfo, Type delegateType)
    {
      DynamicMethod dynamicMethod = methodInfo as DynamicMethod;
      if ((MethodInfo) dynamicMethod != (MethodInfo) null)
        return dynamicMethod.CreateDelegate(delegateType);
      return Delegate.CreateDelegate(delegateType, methodInfo);
    }

    internal static Delegate CreateDelegate(this MethodInfo methodInfo, Type delegateType, object target)
    {
      DynamicMethod dynamicMethod = methodInfo as DynamicMethod;
      if ((MethodInfo) dynamicMethod != (MethodInfo) null)
        return dynamicMethod.CreateDelegate(delegateType, target);
      return Delegate.CreateDelegate(delegateType, target, methodInfo);
    }

    internal static MethodInfo GetMethodValidated(this Type type, string name, BindingFlags bindingAttr, Binder binder, Type[] types, ParameterModifier[] modifiers)
    {
      MethodInfo method = type.GetMethod(name, bindingAttr, binder, types, modifiers);
      if (!method.MatchesArgumentTypes(types))
        return (MethodInfo) null;
      return method;
    }

    internal static ParameterInfo[] GetParametersCached(this MethodBase method)
    {
      ParameterInfo[] parameterInfoArray = (ParameterInfo[]) null;
      lock (TypeExtensions._ParamInfoCache)
      {
        if (!TypeExtensions._ParamInfoCache.TryGetValue(method, out parameterInfoArray))
        {
          parameterInfoArray = method.GetParameters();
          Type local_1 = method.DeclaringType;
          if (local_1 != (Type) null)
          {
            if (local_1.CanCache())
              TypeExtensions._ParamInfoCache[method] = parameterInfoArray;
          }
        }
      }
      return parameterInfoArray;
    }

    internal static Type GetReturnType(this MethodBase mi)
    {
      if (!mi.IsConstructor)
        return ((MethodInfo) mi).ReturnType;
      return mi.DeclaringType;
    }

    internal static bool IsByRefParameter(this ParameterInfo pi)
    {
      if (!pi.ParameterType.IsByRef)
        return (pi.Attributes & ParameterAttributes.Out) == ParameterAttributes.Out;
      return true;
    }

    private static bool MatchesArgumentTypes(this MethodInfo mi, Type[] argTypes)
    {
      if (mi == (MethodInfo) null || argTypes == null)
        return false;
      ParameterInfo[] parameters = mi.GetParameters();
      if (parameters.Length != argTypes.Length)
        return false;
      for (int index = 0; index < parameters.Length; ++index)
      {
        if (!TypeUtils.AreReferenceAssignable(parameters[index].ParameterType, argTypes[index]))
          return false;
      }
      return true;
    }
  }
}
