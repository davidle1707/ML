﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Core.Converter
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using CodeEffects.Rule.Client;
using CodeEffects.Rule.Common;
using CodeEffects.Rule.Models;

namespace CodeEffects.Rule.Core
{
  internal sealed class Converter
  {
    private Converter()
    {
    }

    internal static string ThemeTypeToResourceName(ThemeType theme)
    {
      switch (theme)
      {
        case ThemeType.White:
          return "CodeEffects.Rule.Resources.Styles.White.css";
        case ThemeType.Green:
          return "CodeEffects.Rule.Resources.Styles.Green.css";
        case ThemeType.Red:
          return "CodeEffects.Rule.Resources.Styles.Red.css";
        case ThemeType.Black:
          return "CodeEffects.Rule.Resources.Styles.Black.css";
        case ThemeType.Blue:
          return "CodeEffects.Rule.Resources.Styles.Blue.css";
        case ThemeType.Navy:
          return "CodeEffects.Rule.Resources.Styles.Navy.css";
        default:
          return "CodeEffects.Rule.Resources.Styles.Gray.css";
      }
    }

    internal static string ClientTypeToClientString(OperatorType type)
    {
      switch (type)
      {
        case OperatorType.String:
          return "string";
        case OperatorType.Numeric:
          return "numeric";
        case OperatorType.Date:
          return "date";
        case OperatorType.Time:
          return "time";
        case OperatorType.Bool:
          return "bool";
        case OperatorType.Enum:
          return "enum";
        case OperatorType.Collection:
          return "collection";
        default:
          throw new MalformedXmlException(MalformedXmlException.ErrorIds.UnknownDataType, new string[0]);
      }
    }

    internal static OperatorType ClientStringToClientType(string val)
    {
      switch (val.ToLower())
      {
        case "string":
          return OperatorType.String;
        case "numeric":
          return OperatorType.Numeric;
        case "date":
          return OperatorType.Date;
        case "time":
          return OperatorType.Time;
        case "enum":
          return OperatorType.Enum;
        case "bool":
          return OperatorType.Bool;
        case "collection":
          return OperatorType.Collection;
        default:
          throw new MalformedXmlException(MalformedXmlException.ErrorIds.UnknownDataType, new string[0]);
      }
    }

    internal static string FeatureLocationToString(FeatureLocation location)
    {
      switch (location)
      {
        case FeatureLocation.Client:
          return "client";
        case FeatureLocation.Server:
          return "server";
        default:
          throw new MalformedXmlException(MalformedXmlException.ErrorIds.UnknownDataSourceLocationType, new string[0]);
      }
    }

    internal static FeatureLocation StringToFeatureLocation(string location)
    {
      switch (location)
      {
        case "client":
          return FeatureLocation.Client;
        case "server":
          return FeatureLocation.Server;
        default:
          throw new MalformedXmlException(MalformedXmlException.ErrorIds.UnknownDataSourceLocationString, new string[0]);
      }
    }

    internal static CodeEffects.Rule.Common.ValueInputType StringToValueInputType(string type)
    {
      switch (type)
      {
        case "fields":
          return CodeEffects.Rule.Common.ValueInputType.Fields;
        case "user":
          return CodeEffects.Rule.Common.ValueInputType.User;
        default:
          return CodeEffects.Rule.Common.ValueInputType.All;
      }
    }

    internal static string ValueInputTypeToString(CodeEffects.Rule.Common.ValueInputType type)
    {
      switch (type)
      {
        case CodeEffects.Rule.Common.ValueInputType.Fields:
          return "fields";
        case CodeEffects.Rule.Common.ValueInputType.User:
          return "user";
        default:
          return "all";
      }
    }

    internal static string InputTypeToString(InputType type)
    {
      switch (type)
      {
        case InputType.Field:
          return "field";
        case InputType.Input:
          return "input";
        default:
          throw new MalformedXmlException(MalformedXmlException.ErrorIds.UnknownInputType, new string[0]);
      }
    }

    internal static InputType StringToInputType(string val)
    {
      switch (val.ToLower())
      {
        case "field":
          return InputType.Field;
        case "input":
          return InputType.Input;
        default:
          throw new MalformedXmlException(MalformedXmlException.ErrorIds.UnknownInputType, new string[0]);
      }
    }

    internal static CalculationType StringToCalculationType(string val)
    {
      switch (val.ToLower())
      {
        case "add":
          return CalculationType.Addition;
        case "divide":
          return CalculationType.Division;
        case "multiply":
          return CalculationType.Multiplication;
        case "subtract":
          return CalculationType.Subtraction;
        default:
          throw new MalformedXmlException(MalformedXmlException.ErrorIds.UnknownInputType, new string[0]);
      }
    }

    internal static ParameterType StringToParameterType(string val)
    {
      switch (val.ToLower())
      {
        case "source":
          return ParameterType.Source;
        case "input":
          return ParameterType.Input;
        case "constant":
          return ParameterType.Constant;
        case "collection":
          return ParameterType.Collection;
        default:
          throw new MalformedXmlException(MalformedXmlException.ErrorIds.UnknownParameterType, new string[0]);
      }
    }

    internal static CollectionType StringToCollectionType(string val)
    {
      switch (val)
      {
        case "reference":
          return CollectionType.Reference;
        case "value":
          return CollectionType.Value;
        case "generic":
          return CollectionType.Generic;
        default:
          throw new MalformedXmlException(MalformedXmlException.ErrorIds.UnknownCollectionType, new string[0]);
      }
    }

    internal static string SelectionTypeToString(SelectionType type)
    {
      switch (type)
      {
        case SelectionType.Exists:
          return "exists";
        case SelectionType.DoesNotExist:
          return "doesNotExist";
        default:
          throw new MalformedXmlException(MalformedXmlException.ErrorIds.InvalidSelectionType, new string[0]);
      }
    }

    internal static SelectionType StringToSelectionType(string val)
    {
      switch (val)
      {
        case "doesNotExist":
          return SelectionType.DoesNotExist;
        case "exists":
          return SelectionType.Exists;
        default:
          throw new MalformedXmlException(MalformedXmlException.ErrorIds.InvalidSelectionType, new string[0]);
      }
    }
  }
}
