﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Core.Build
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

namespace CodeEffects.Rule.Core
{
  internal sealed class Build
  {
    internal static bool Limits
    {
      get
      {
        return true;
      }
    }

    internal static bool Wildcard
    {
      get
      {
        return true;
      }
    }

    internal static bool Compiled
    {
      get
      {
        return true;
      }
    }

    internal static string Pattern
    {
      get
      {
        return "instantcrmnow.com";
      }
    }

    internal static string Number
    {
      get
      {
        return "b53c95f7-f905-470c-9b49-111a3bb4a6e0";
      }
    }

    private Build()
    {
    }
  }
}
