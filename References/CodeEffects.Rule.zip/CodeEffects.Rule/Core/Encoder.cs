﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Core.Encoder
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;

namespace CodeEffects.Rule.Core
{
  internal static class Encoder
  {
    internal static string Sanitize(string str)
    {
      if (string.IsNullOrWhiteSpace(str))
        return str;
      return str.Replace("'", "&#39;").Replace("\"", "&quot;").Replace("\\", "&#92;");
    }

    internal static string Desanitize(string str)
    {
      return str;
    }

    internal static string ClearXml(string str)
    {
      if (string.IsNullOrWhiteSpace(str))
        return str;
      return str.Replace("&quot;", "\"").Replace("&#92;", "\\");
    }

    internal static string GetHashToken(MethodInfo m)
    {
      return Encoder.GetHashToken(m.DeclaringType.FullName + m.ToString());
    }

    internal static string GetHashToken(string value)
    {
      using (MD5 md5 = MD5.Create())
      {
        byte[] hash = md5.ComputeHash(Encoding.Unicode.GetBytes(value));
        return string.Join(string.Empty, ((IEnumerable<byte>) hash).Select<byte, string>((Func<byte, string>) (x => x.ToString("X2"))).ToArray<string>());
      }
    }
  }
}
