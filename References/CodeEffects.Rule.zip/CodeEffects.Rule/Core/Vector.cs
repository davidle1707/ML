﻿// Decompiled with JetBrains decompiler
// Type: CodeEffects.Rule.Core.Vector
// Assembly: CodeEffects.Rule, Version=4.2.0.9, Culture=neutral, PublicKeyToken=baf0273d08cca81d
// MVID: F5692375-672F-432A-9D67-02B7808F8E64
// Assembly location: D:\CodeEffects.Rule.dll

using System.Text.RegularExpressions;
using System.Threading;

namespace CodeEffects.Rule.Core
{
  internal sealed class Vector
  {
    internal static bool Compiled
    {
      get
      {
        try
        {
          if (!Build.Limits)
            return true;
          return Build.Compiled;
        }
        catch
        {
          return false;
        }
      }
    }

    internal static void DelayIfDemo()
    {
      if (Vector.Compiled)
        return;
      Thread.Sleep(1000);
    }

    internal static bool IsDemo(string requestHost, string serverName, bool isLocal)
    {
      try
      {
        if (isLocal || !Build.Limits)
          return false;
        if (!Vector.Compiled)
          return true;
        return !Vector.Match(requestHost) && !Vector.Match(serverName);
      }
      catch
      {
        return true;
      }
    }

    private static bool Match(string input)
    {
      if (!Build.Limits)
        return true;
      if (string.IsNullOrEmpty(Build.Pattern))
        return false;
      if (Build.Wildcard)
        return Regex.IsMatch(input, string.Format("^([\\w\\-]+\\.)*({0})$", (object) Build.Pattern.Replace(".", "\\.")), RegexOptions.IgnoreCase);
      return input.ToLower() == Build.Pattern.ToLower();
    }
  }
}
