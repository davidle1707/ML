using StructureMap.LegacyAttributeSupport;
using StructureMap.Testing.Widget;

namespace StructureMap.Testing.Widget2
{
    [Pluggable("Default")]
    public class DefaultRule : Rule
    {
    }
}