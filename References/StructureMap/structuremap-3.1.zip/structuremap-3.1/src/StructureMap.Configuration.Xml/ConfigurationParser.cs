using System;
using System.Collections.Generic;
using System.IO;
using System.Xml;
using StructureMap.Building;
using StructureMap.Diagnostics;
using StructureMap.Graph;

namespace StructureMap.Configuration.Xml
{
    public class ConfigurationParser : XmlConstants, IPluginGraphConfiguration
    {
        private readonly XmlNode _structureMapNode;
        public string Description = string.Empty;
        private string _filePath = string.Empty;

        public ConfigurationParser(XmlNode structureMapNode)
        {
            _structureMapNode = structureMapNode;
        }

        public string Id
        {
            get
            {
                XmlAttribute att = _structureMapNode.Attributes["Id"];
                return att == null ? string.Empty : att.Value;
            }
        }


        public string FilePath
        {
            get { return _filePath; }
            set { _filePath = value; }
        }

        public static ConfigurationParser FromFile(string filename)
        {
            var document = new XmlDocument();
            document.Load(filename);

            XmlNode structureMapNode = document.SelectSingleNode("//" + STRUCTUREMAP);
            if (structureMapNode == null)
            {
                // TODO -- make sure there's a UT on this
                throw new StructureMapConfigurationException("Cannot find required <StructureMap> node in file '{0}'", filename);
            }

            return new ConfigurationParser(structureMapNode) {FilePath = filename};
        }

        public static XmlAttributeInstanceMemento CreateMemento(XmlNode node)
        {
            var clonedNode = node.CloneNode(true);
            return new XmlAttributeInstanceMemento(clonedNode);
        }

        public void ForEachFile(Action<string> action)
        {
            string includePath = getIncludePath();

            // Find the text in every child node of _structureMapNode and
            // perform an action with that text
            _structureMapNode.ForTextInChild("Include/@File").Do(fileName => {
                string includedFile = Path.Combine(includePath, fileName);
                action(includedFile);
            });
        }

        private string getIncludePath()
        {
            if (string.IsNullOrEmpty(_filePath))
            {
                return string.Empty;
            }

            return Path.GetDirectoryName(_filePath);
        }

        public void ParseRegistries(IGraphBuilder builder)
        {
            _structureMapNode.ForTextInChild("Registry/@Type").Do(builder.AddRegistry);
        }


        private XmlExtensions.XmlNodeExpression forEachNode(string xpath)
        {
            return _structureMapNode.ForEachChild(xpath);
        }

        public void Parse(IGraphBuilder builder)
        {
            var instanceParser = new InstanceParser(builder);

            forEachNode("Alias").Do(instanceParser.ParseAlias);
            forEachNode(DEFAULT_INSTANCE).Do(instanceParser.ParseDefaultElement);
            forEachNode(ADD_INSTANCE_NODE).Do(instanceParser.ParseInstanceElement);
        }

        void IPluginGraphConfiguration.Configure(PluginGraph graph)
        {
            var builder = new GraphBuilder(graph);

            ParseRegistries(builder);
            Parse(builder);
        }

        public void Register(PluginGraphBuilder builder)
        {
            // no-op for now
        }

        public static IEnumerable<ConfigurationParser> FromApplicationConfig()
        {
            IList<XmlNode> appConfigNodes = StructureMapConfigurationSection.GetStructureMapConfiguration();
            foreach (XmlNode appConfigNode in appConfigNodes)
            {
                yield return new ConfigurationParser(appConfigNode);

            }
        }
    }
}