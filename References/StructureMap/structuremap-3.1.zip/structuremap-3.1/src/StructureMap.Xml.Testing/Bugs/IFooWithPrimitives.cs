﻿namespace StructureMap.Xml.Testing.Bugs
{
    public interface IFooWithPrimitives
    {
        bool IsTest { get; }
        string TestValue { get; }
    }
}