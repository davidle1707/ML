using System.Reflection;

[assembly: AssemblyTitle("StructureMap.Testing.Widget3")]