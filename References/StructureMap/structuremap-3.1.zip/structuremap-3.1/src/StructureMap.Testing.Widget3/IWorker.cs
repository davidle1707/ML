namespace StructureMap.Testing.Widget3
{
    
    public interface IWorker
    {
    }
}