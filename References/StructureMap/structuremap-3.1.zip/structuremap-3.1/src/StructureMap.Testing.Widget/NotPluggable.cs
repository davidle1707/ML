namespace StructureMap.Testing.Widget
{
    public class NotPluggable
    {
        private readonly string name;

        public NotPluggable(string name)
        {
            this.name = name;
        }
    }
}