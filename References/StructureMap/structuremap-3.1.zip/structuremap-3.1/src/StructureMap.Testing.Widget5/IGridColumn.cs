namespace StructureMap.Testing.Widget5
{
    public interface IGridColumn
    {
    }
}