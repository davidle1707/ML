namespace StructureMap.Testing.Widget5
{
    public enum FontStyleEnum
    {
        BodyText,
        Header1,
        Header2
    }
}