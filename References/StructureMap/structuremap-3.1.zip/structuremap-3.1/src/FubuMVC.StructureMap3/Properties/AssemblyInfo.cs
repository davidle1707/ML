﻿using System.Reflection;
using FubuMVC.Core;

[assembly: AssemblyTitle("FubuMVC.StructureMap3")]
[assembly: FubuModule]
