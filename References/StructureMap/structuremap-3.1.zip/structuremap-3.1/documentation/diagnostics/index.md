<!--Title: Diagnostics-->

Improving StructureMap's ability to diagnose and explain both configuration and runtime problems was a very big goal
for the latest major release (3.0).

<[TableOfContents]>

