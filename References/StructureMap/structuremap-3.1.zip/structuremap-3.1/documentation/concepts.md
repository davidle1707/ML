<!--Title: Software Design Concepts-->
<!--Url: software-design-concepts-->

TODO(adapt old blog posts here)

## Dependency Injection

## Inversion of Control


## Service Locator

