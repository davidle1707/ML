<!--Title: Integrating StructureMap into Common .Net Frameworks-->

I'm thinking that this page needs to cover:

* ASP.Net MVC <= 5
* Web API
* NHibernate - not sure how popular this is anymore, but I had a question about it in the past couple weeks
* EF <-- maybe the highest priority
* RavenDb
* MVC6
* NancyFx
* NServiceBus
* What else?
