<!--Title: StructureMap Assumptions-->
<!--Url: structuremap-assumptions-->

TODO(Write some content!)

