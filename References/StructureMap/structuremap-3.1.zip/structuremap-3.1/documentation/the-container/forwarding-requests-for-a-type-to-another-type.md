<!--Title: Forwarding Requests for a Type to Another Type-->
<!--Url: forwarding-requests-for-a-type-to-another-type-->


TODO(Write some content!)


