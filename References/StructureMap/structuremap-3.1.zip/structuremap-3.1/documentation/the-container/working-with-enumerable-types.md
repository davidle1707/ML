<!--Title: Working with Enumerable Types-->
<!--Url: working-with-enumerable-types-->

TODO(Write some content!)

