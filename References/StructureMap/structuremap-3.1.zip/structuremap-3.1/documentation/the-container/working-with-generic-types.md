<!--Title: Working with Generic Types-->
<!--Url: working-with-generic-types-->

TODO(Write some content!)

