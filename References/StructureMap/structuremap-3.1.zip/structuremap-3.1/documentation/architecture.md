<!--Title: Internals and Architecture-->

TODO(Write content!)

