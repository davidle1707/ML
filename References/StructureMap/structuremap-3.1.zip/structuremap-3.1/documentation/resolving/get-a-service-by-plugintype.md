<!--Title: Get a Service by PluginType-->
<!--Url: get-a-service-by-plugintype-->


Requesting the default configured object of a plugin type is done through the `IContainer.GetInstance()` method shown below:

<[sample:GetInstance]>

