<!--Title: Get a Service by Plugin Type and Name-->
<!--Url: get-a-service-by-plugin-type-and-name-->


You can also request a named configuration for a given PluginType by using the overloads of `IContainer.GetInstance()` that take in a name like this:

<[sample:GetInstance-by-name]>

