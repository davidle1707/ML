<!--Title: Try Geting an Optional Service by Plugin Type and Name-->
<!--Url: try-geting-an-optional-service-by-plugin-type-and-name-->


TODO(Write some content!)


