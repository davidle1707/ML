<!--Title: Interception and Decorators-->
<!--Url: interception-and-decorators-->


TODO(Write some content!)


