
Code Effects Software � 2018



Thank you for purchasing the Enterprise License, full version!


Here is what you need to know about your Code Effects package:

-- The ProductKey.txt file contains your Product Key. Use this key should you ever need to rebuild your copy of Code Effects assembly using the Code Effects Downloader.

-- The CodeEffects.Rule.dll file is your copy of Code Effects. It is ready to use. Just reference it in your code (.NET 4.0 and up) and begin programming. No installation is required.

-- Copy the CodeEffects.Rule.xml file into the /bin directory of your project in order to have full IntelliSense support of Code Effects assembly in Visual Studio. Do not rename this file.

-- By referencing or otherwise using the Code Effects assembly, your organization agrees to be bound by Code Effects' EULA. The EULA.htm file is included in the package.

-- Code Effects demo projects are available for download at https://CodeEffects.com/Doc/Business-Rule-Demo-Project.

-- Your Code Effects license includes free Standard email support. Any employee of your organization is welcome to ask any Code Effects-related question or express any concern. Use our Support page located at https://CodeEffects.com/Support or email us at public.support@mail.codeeffects.com. Our official business hours are from 9:00 AM to 5:00 PM (US Eastern time) every day except weekends and U.S. holidays.

-- Code Effects provides online documentation located at https://CodeEffects.com/Doc. This is a great place to learn everything about Code Effects.

-- You can subscribe to our product notifications at our Support page at https://CodeEffects.com/Support. We don't send out junk email, and we don't sell/give your address to anybody unless it's required by law. You can find our Privacy Policy at http://CodeEffects.com



Code Effects Software, LLC

3070 Windward Plaza, Suite F406
Alpharetta, GA 30005, USA
public.support@mail.codeeffects.com
CodeEffects.com