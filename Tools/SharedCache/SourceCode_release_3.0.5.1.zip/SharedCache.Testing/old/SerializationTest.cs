﻿//#region Copyright (c) Roni Schuetz, Switzerland. All Rights Reserved
//// * --------------------------------------------------------------------- *
//// *                              Roni Schuetz                             *
//// *              Copyright (c) 2008 All Rights reserved                   *
//// *                                                                       *
//// * Shared Cache high-performance, distributed caching and    *
//// * replicated caching system, generic in nature, but intended to         *
//// * speeding up dynamic web and / or win applications by alleviating      *
//// * database load.                                                        *
//// *                                                                       *
//// * This Software is written by Roni Schuetz (schuetz AT gmail DOT com)   *
//// *                                                                       *
//// * This library is free software; you can redistribute it and/or         *
//// * modify it under the terms of the GNU Lesser General Public License    *
//// * as published by the Free Software Foundation; either version 2.1      *
//// * of the License, or (at your option) any later version.                *
//// *                                                                       *
//// * This library is distributed in the hope that it will be useful,       *
//// * but WITHOUT ANY WARRANTY; without even the implied warranty of        *
//// * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU      *
//// * Lesser General Public License for more details.                       *
//// *                                                                       *
//// * You should have received a copy of the GNU Lesser General Public      *
//// * License along with this library; if not, write to the Free            *
//// * Software Foundation, Inc., 59 Temple Place, Suite 330,                *
//// * Boston, MA 02111-1307 USA                                             *
//// *                                                                       *
//// *       THIS COPYRIGHT NOTICE MAY NOT BE REMOVED FROM THIS FILE.        *
//// * --------------------------------------------------------------------- *
//#endregion 
//using Microsoft.VisualStudio.TestTools.UnitTesting;
//using System;
//using System.Text;
//using System.Collections.Generic;
//using F = SharedCache.WinServiceCommon.Formatters;
//namespace SharedCache.Testing
//{
//  /// <summary>
//  ///This is a test class for SharedCache.WinServiceCommon.Formatters.Serialization and is intended
//  ///to contain all SharedCache.WinServiceCommon.Formatters.Serialization Unit Tests
//  ///</summary>
//  [TestClass()]
//  public class SerializationTest
//  {
//    /// <summary>
//    /// Sample class to test serialization and deserialization.
//    /// </summary>
//    [Serializable]
//    private class SampleSerializeableClass
//    {
//      public string name = string.Empty;
//      public SampleSerializeableClass(string name)
//      {
//        this.name = name;
//      }
//    }

//    /// <summary>
//    ///A test for BinarySerialize (object) and BinaryDeSerialize&lt;&gt; (byte[])
//    ///</summary>
//    [TestMethod()]
//    public void BinarySerializeAndDeSerializeTest()
//    {
//      string name = @"Shared Cache";
//      SampleSerializeableClass sample = new SampleSerializeableClass(name);
//      byte[] actual = F.Serialization.BinarySerialize(sample);
//      SampleSerializeableClass expected = F.Serialization.BinaryDeSerialize<SampleSerializeableClass>(actual);
//      Assert.IsNotNull(expected, @"expected deserialized object is null!");
//      Assert.IsInstanceOfType(expected, typeof(SampleSerializeableClass), @"Type Of is failed");
//      Assert.AreEqual<string>(expected.name, sample.name, "Formatters.Serialization.BinarySerialize did not return the expected value.");
//    }
//  }
//}
