﻿//#region Copyright (c) Roni Schuetz - All Rights Reserved
//// * --------------------------------------------------------------------- *
//// *                              Roni Schuetz                             *
//// *              Copyright (c) 2008 All Rights reserved                   *
//// *                                                                       *
//// * Shared Cache high-performance, distributed caching and    *
//// * replicated caching system, generic in nature, but intended to         *
//// * speeding up dynamic web and / or win applications by alleviating      *
//// * database load.                                                        *
//// *                                                                       *
//// * This Software is written by Roni Schuetz (schuetz AT gmail DOT com)   *
//// *                                                                       *
//// * This library is free software; you can redistribute it and/or         *
//// * modify it under the terms of the GNU Lesser General Public License    *
//// * as published by the Free Software Foundation; either version 2.1      *
//// * of the License, or (at your option) any later version.                *
//// *                                                                       *
//// * This library is distributed in the hope that it will be useful,       *
//// * but WITHOUT ANY WARRANTY; without even the implied warranty of        *
//// * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU      *
//// * Lesser General Public License for more details.                       *
//// *                                                                       *
//// * You should have received a copy of the GNU Lesser General Public      *
//// * License along with this library; if not, write to the Free            *
//// * Software Foundation, Inc., 59 Temple Place, Suite 330,                *
//// * Boston, MA 02111-1307 USA                                             *
//// *                                                                       *
//// *       THIS COPYRIGHT NOTICE MAY NOT BE REMOVED FROM THIS FILE.        *
//// * --------------------------------------------------------------------- *
//#endregion 

//using Microsoft.VisualStudio.TestTools.UnitTesting;
//using System;
//using System.Text;
//using System.Collections.Generic;
//using SharedCache.WinServiceCommon;
//using System.IO;
//namespace SharedCache.Testing
//{
//  /// <summary>
//  ///This is a test class for SharedCache.WinServiceCommon.IndexusMessage and is intended
//  ///to contain all SharedCache.WinServiceCommon.IndexusMessage Unit Tests
//  ///</summary>
//  [TestClass()]
//  public class IndexusMessageTest
//  {
//    [ClassInitialize()]
//    public static void LoadServerAsConsole(TestContext context)
//    {
//      StartUpEnvironment.LoadServerAsConsole(context);
//    }
//    [ClassCleanup()]
//    public static void UnLoadServerAsConsole()
//    {
//      StartUpEnvironment.UnLoadServerAsConsole();
//    }

//    private TestContext testContextInstance;

//    /// <summary>
//    ///Gets or sets the test context which provides
//    ///information about and functionality for the current test run.
//    ///</summary>
//    public TestContext TestContext
//    {
//      get
//      {
//        return testContextInstance;
//      }
//      set
//      {
//        testContextInstance = value;
//      }
//    }
//    #region Additional test attributes
//    // 
//    //You can use the following additional attributes as you write your tests:
//    //
//    //Use ClassInitialize to run code before running the first test in the class
//    //
//    //[ClassInitialize()]
//    //public static void MyClassInitialize(TestContext testContext)
//    //{
//    //}
//    //
//    //Use ClassCleanup to run code after all tests in a class have run
//    //
//    //[ClassCleanup()]
//    //public static void MyClassCleanup()
//    //{
//    //}
//    //
//    //Use TestInitialize to run code before running each test
//    //
//    //[TestInitialize()]
//    //public void MyTestInitialize()
//    //{
//    //}
//    //
//    //Use TestCleanup to run code after each test has run
//    //
//    //[TestCleanup()]
//    //public void MyTestCleanup()
//    //{
//    //}
//    //
//    #endregion

//    public void ValidateIndexusMessage(IndexusMessage msg)
//    {
//      Assert.AreEqual<IndexusMessage.ActionValue>(IndexusMessage.ActionValue.Successful, msg.Action);
//      Assert.AreEqual<IndexusMessage.CacheItemPriority>(IndexusMessage.CacheItemPriority.High, msg.ItemPriority);
//      Assert.AreEqual<IndexusMessage.StatusValue>(IndexusMessage.StatusValue.Request, msg.Status);
//      Assert.IsTrue(!string.IsNullOrEmpty(msg.Key));
//      Assert.IsTrue(msg.Payload.Length > 0);
//      Assert.IsTrue(!string.IsNullOrEmpty(msg.Hostname));
//      Assert.IsTrue(msg.Expires != DateTime.MinValue);
//      Assert.IsTrue(msg.Id > 0);
//      Assert.IsTrue(msg.Length > 0);
//      Assert.IsTrue(msg.SendTimeout > 0);
//      Assert.IsTrue(msg.Timestamp > DateTime.Now.AddMinutes(-2) && msg.Timestamp != DateTime.MaxValue);
//      Assert.IsTrue(msg.Ttl > 20);
//    }
//    public IndexusMessage GetNewMsg()
//    {
//      return new IndexusMessage(
//          new Random().Next(),
//          IndexusMessage.ActionValue.Successful,
//          IndexusMessage.StatusValue.Request,
//          new KeyValuePair<string, byte[]>(key, data),
//          "127.0.0.1",
//          IndexusMessage.CacheItemPriority.High
//        );
//    }

//    private string key = "Shared Cache";
//    private byte[] data = new byte[] { 1, 2, 4, 8 };

//    /// <summary>
//    ///A test for Action
//    ///</summary>
//    [TestMethod()]
//    public void ActionTest()
//    {
//      IndexusMessage target = new IndexusMessage();
//      IndexusMessage.ActionValue val = IndexusMessage.ActionValue.Successful;
//      target.Action = val;
//      Assert.AreEqual(val, target.Action, "SharedCache.WinServiceCommon.IndexusMessage.Action was not set correctly.");
//    }

//    /// <summary>
//    ///A test for Copy (IndexusMessage)
//    ///</summary>
//    [DeploymentItem("SharedCache.WinServiceCommon.dll")]
//    [TestMethod()]
//    public void CopyTest()
//    {
//      IndexusMessage target = new IndexusMessage();
//      MergeSystem_Indexus_WinServiceCommon_IndexusMessageAccessor accessor = new MergeSystem_Indexus_WinServiceCommon_IndexusMessageAccessor(target);
//      IndexusMessage msg = GetNewMsg();
//      accessor.Copy(msg);
//      ValidateIndexusMessage(target);
//    }
			
//    [TestMethod()]
//    public void ExpiresTest()
//    {
//      IndexusMessage target = new IndexusMessage();
//      DateTime val = DateTime.Now;
//      target.Expires = val;
//      Assert.AreEqual(val, target.Expires, "SharedCache.WinServiceCommon.IndexusMessage.Expires was not set correctly.");
//    }

//    /// <summary>
//    ///A test for Hostname
//    ///</summary>
//    [TestMethod()]
//    public void HostnameTest()
//    {
//      IndexusMessage target = new IndexusMessage();
//      string val = @"127.0.0.1";
//      target.Hostname = val;
//      Assert.AreEqual(val, target.Hostname, "SharedCache.WinServiceCommon.IndexusMessage.Hostname was not set correctly.");
//    }

//    /// <summary>
//    ///A test for Id
//    ///</summary>
//    [TestMethod()]
//    public void IdTest()
//    {
//      IndexusMessage target = new IndexusMessage();
//      int val = new Random().Next();
//      target.Id = val;
//      Assert.AreEqual(val, target.Id, "SharedCache.WinServiceCommon.IndexusMessage.Id was not set correctly.");
//    }

//    /// <summary>
//    ///A test for IndexusMessage ()
//    ///</summary>
//    [TestMethod()]
//    public void ConstructorTest()
//    {
//      IndexusMessage target = new IndexusMessage();
//      Assert.IsNotNull(target);
//      Assert.IsTrue(target.Id > 0);
//      Assert.IsTrue(target.Length > 0);
//    }

//    /// <summary>
//    ///A test for IndexusMessage (CacheItemPriority)
//    ///</summary>
//    [TestMethod()]
//    public void ConstructorTest1()
//    {
//      IndexusMessage.CacheItemPriority priority = IndexusMessage.CacheItemPriority.High;
//      IndexusMessage target = new IndexusMessage(priority);
//      Assert.AreEqual<IndexusMessage.CacheItemPriority>(priority, target.ItemPriority);
//    }

//    /// <summary>
//    ///A test for IndexusMessage (IndexusMessage)
//    ///</summary>
//    [TestMethod()]
//    public void ConstructorTest2()
//    {
//      IndexusMessage target = new IndexusMessage(this.GetNewMsg());
//      ValidateIndexusMessage(target);
//    }

//    /// <summary>
//    ///A test for IndexusMessage (int)
//    ///</summary>
//    [TestMethod()]
//    public void ConstructorTest3()
//    {
//      int id = 755;
//      IndexusMessage target = new IndexusMessage(id);
//      Assert.AreEqual<int>(id, target.Id);
//    }

//    /// <summary>
//    ///A test for IndexusMessage (int, ActionValue)
//    ///</summary>
//    [TestMethod()]
//    public void ConstructorTest4()
//    {
//      int id = 1258;
//      IndexusMessage.ActionValue value = IndexusMessage.ActionValue.Ping;
//      IndexusMessage target = new IndexusMessage(id, value);
//      Assert.AreEqual<int>(id, target.Id);
//      Assert.AreEqual<IndexusMessage.ActionValue>(value, target.Action);
//    }

//    /// <summary>
//    ///A test for IndexusMessage (int, ActionValue, KeyValuePair&lt;string,byte[]&gt;)
//    ///</summary>
//    [TestMethod()]
//    public void ConstructorTest5()
//    {
//      int id = 23521;
//      IndexusMessage.ActionValue action = IndexusMessage.ActionValue.Get;
//      KeyValuePair<string, byte[]> value = new KeyValuePair<string, byte[]>(key, data);
//      IndexusMessage target = new IndexusMessage(id, action, value);
//      Assert.AreEqual<int>(id, target.Id);
//      Assert.AreEqual<IndexusMessage.ActionValue>(action, target.Action);
//      Assert.IsTrue(!string.IsNullOrEmpty(target.Key));
//      Assert.IsTrue(target.Payload.Length > 0);
//    }

//    /// <summary>
//    ///A test for IndexusMessage (int, ActionValue, KeyValuePair&lt;string,byte[]&gt;, CacheItemPriority)
//    ///</summary>
//    [TestMethod()]
//    public void ConstructorTest6()
//    {
//      int id = 111;
//      IndexusMessage.ActionValue action = IndexusMessage.ActionValue.GetAllKeys;
//      KeyValuePair<string, byte[]> value = new KeyValuePair<string, byte[]>(key, data);
//      IndexusMessage.CacheItemPriority priority = IndexusMessage.CacheItemPriority.BelowNormal;
//      IndexusMessage target = new IndexusMessage(id, action, value, priority);
//      Assert.AreEqual<int>(id, target.Id);
//      Assert.AreEqual<IndexusMessage.ActionValue>(action, target.Action);
//      Assert.IsTrue(!string.IsNullOrEmpty(target.Key));
//      Assert.IsTrue(target.Payload.Length > 0);
//      Assert.AreEqual<IndexusMessage.CacheItemPriority>(priority, target.ItemPriority);
//    }

//    /// <summary>
//    ///A test for IndexusMessage (int, ActionValue, KeyValuePair&lt;string,byte[]&gt;, DateTime)
//    ///</summary>
//    [TestMethod()]
//    public void ConstructorTest7()
//    {
//      int id = 12221;
//      IndexusMessage.ActionValue action = IndexusMessage.ActionValue.Add;
//      KeyValuePair<string, byte[]> value = new KeyValuePair<string, byte[]>(key, data);
//      DateTime expire = DateTime.Now.AddMinutes(+123);
//      IndexusMessage target = new IndexusMessage(id, action, value, expire);
//      Assert.AreEqual<int>(id, target.Id);
//      Assert.AreEqual<IndexusMessage.ActionValue>(action, target.Action);
//      Assert.IsTrue(!string.IsNullOrEmpty(target.Key));
//      Assert.IsTrue(target.Payload.Length > 0);
//      Assert.IsTrue(target.Expires > DateTime.Now);
//    }

//    /// <summary>
//    ///A test for IndexusMessage (int, ActionValue, StatusValue, KeyValuePair&lt;string,byte[]&gt;)
//    ///</summary>
//    [TestMethod()]
//    public void ConstructorTest8()
//    {
//      int id = 33321;
//      IndexusMessage.ActionValue action = IndexusMessage.ActionValue.Remove;
//      IndexusMessage.StatusValue status = IndexusMessage.StatusValue.Response;
//      KeyValuePair<string, byte[]> value = new KeyValuePair<string, byte[]>(key, data);
//      IndexusMessage target = new IndexusMessage(id, action, status, value);
//      Assert.AreEqual<int>(id, target.Id);
//      Assert.AreEqual<IndexusMessage.ActionValue>(action, target.Action);
//      Assert.AreEqual<IndexusMessage.StatusValue>(status, target.Status);
//      Assert.IsTrue(!string.IsNullOrEmpty(target.Key));
//      Assert.IsTrue(target.Payload.Length > 0);
//    }

//    /// <summary>
//    ///A test for IndexusMessage (int, ActionValue, StatusValue, KeyValuePair&lt;string,byte[]&gt;, string)
//    ///</summary>
//    [TestMethod()]
//    public void ConstructorTest9()
//    {
//      int id = 555512;
//      IndexusMessage.ActionValue action = IndexusMessage.ActionValue.Statistic;
//      IndexusMessage.StatusValue status = IndexusMessage.StatusValue.Request;
//      KeyValuePair<string, byte[]> value = new KeyValuePair<string, byte[]>(key, data);
//      string hostname = "127.0.0.1";
//      IndexusMessage target = new IndexusMessage(id, action, status, value, hostname);
//      Assert.AreEqual<int>(id, target.Id);
//      Assert.AreEqual<IndexusMessage.ActionValue>(action, target.Action);
//      Assert.AreEqual<IndexusMessage.StatusValue>(status, target.Status);
//      Assert.IsTrue(!string.IsNullOrEmpty(target.Key));
//      Assert.IsTrue(target.Payload.Length > 0);
//      Assert.IsTrue(!string.IsNullOrEmpty(target.Hostname));
//    }

//    /// <summary>
//    ///A test for IndexusMessage (int, ActionValue, StatusValue, KeyValuePair&lt;string,byte[]&gt;, string, CacheItemPriority)
//    ///</summary>
//    [TestMethod()]
//    public void ConstructorTest10()
//    {
//      int id = 665456;
//      IndexusMessage.ActionValue action = IndexusMessage.ActionValue.Remove;
//      IndexusMessage.StatusValue status = IndexusMessage.StatusValue.Response;
//      KeyValuePair<string, byte[]> value = new KeyValuePair<string, byte[]>(key, data);
//      string hostname = "127.0.0.1";
//      IndexusMessage.CacheItemPriority priority = IndexusMessage.CacheItemPriority.AboveNormal;
//      IndexusMessage target = new IndexusMessage(id, action, status, value, hostname, priority);
//      Assert.AreEqual<int>(id, target.Id);
//      Assert.AreEqual<IndexusMessage.ActionValue>(action, target.Action);
//      Assert.AreEqual<IndexusMessage.StatusValue>(status, target.Status);
//      Assert.AreEqual<IndexusMessage.CacheItemPriority>(priority, target.ItemPriority);
//      Assert.IsTrue(!string.IsNullOrEmpty(target.Key));
//      Assert.IsTrue(target.Payload.Length > 0);
//      Assert.IsTrue(!string.IsNullOrEmpty(target.Hostname));
//    }

//    /// <summary>
//    ///A test for IndexusMessage (int, ActionValue, StatusValue, string, byte[], string, CacheItemPriority)
//    ///</summary>
//    [TestMethod()]
//    public void ConstructorTest11()
//    {
//      int id = 12;
//      IndexusMessage.ActionValue action = IndexusMessage.ActionValue.Successful;
//      IndexusMessage.StatusValue status = IndexusMessage.StatusValue.Response;
//      string key = "Shared Cache";
//      byte[] payload = new byte[] { 1,2,4,8};
//      string hostname = "127.0.0.1";
//      IndexusMessage.CacheItemPriority priority = IndexusMessage.CacheItemPriority.Low; // TODO: Initialize to an appropriate value
//      IndexusMessage target = new IndexusMessage(id, action, status, DateTime.Now, key, payload, hostname, priority);
//      Assert.AreEqual<int>(id, target.Id);
//      Assert.AreEqual<IndexusMessage.ActionValue>(action, target.Action);
//      Assert.AreEqual<IndexusMessage.StatusValue>(status, target.Status);
//      Assert.AreEqual<IndexusMessage.CacheItemPriority>(priority, target.ItemPriority);
//      Assert.IsTrue(!string.IsNullOrEmpty(target.Key));
//      Assert.IsTrue(target.Payload.Length > 0);
//      Assert.IsTrue(!string.IsNullOrEmpty(target.Hostname));			
//    }

//    /// <summary>
//    ///A test for IndexusMessage (int, ActionValue, string, byte[], CacheItemPriority)
//    ///</summary>
//    [TestMethod()]
//    public void ConstructorTest12()
//    {
//      int id = 12541145;
//      IndexusMessage.ActionValue action = IndexusMessage.ActionValue.Error;
//      string key1 = key;
//      byte[] payload = data;
//      IndexusMessage.CacheItemPriority priority = IndexusMessage.CacheItemPriority.BelowNormal;
//      IndexusMessage target = new IndexusMessage(id, action, key1, payload, priority);
//      Assert.AreEqual<int>(id, target.Id);
//      Assert.AreEqual<IndexusMessage.CacheItemPriority>(priority, target.ItemPriority);
//      Assert.IsTrue(!string.IsNullOrEmpty(target.Key));
//      Assert.IsTrue(target.Payload.Length > 0);
//    }

//    /// <summary>
//    ///A test for IndexusMessage (int, ActionValue, string, byte[], DateTime)
//    ///</summary>
//    [TestMethod()]
//    public void ConstructorTest13()
//    {
//      DateTime d = DateTime.Now;
//      int id = 85785585;
//      IndexusMessage.ActionValue action = IndexusMessage.ActionValue.GetAllKeys;
//      string key1 = key;
//      byte[] payload = data;
//      DateTime expire = d;
//      IndexusMessage target = new IndexusMessage(id, action, key1, payload, expire);
//      Assert.AreEqual<int>(id, target.Id);
//      Assert.AreEqual<IndexusMessage.ActionValue>(action, target.Action);
//      Assert.IsTrue(!string.IsNullOrEmpty(target.Key));
//      Assert.IsTrue(target.Payload.Length > 0);
//      Assert.IsTrue(target.Expires != DateTime.MaxValue && target.Expires != DateTime.MinValue && target.Expires == d);
//    }

//    /// <summary>
//    ///A test for IndexusMessage (MemoryStream)
//    ///</summary>
//    [TestMethod()]
//    public void ConstructorTest14()
//    {
//      MemoryStream ms = new MemoryStream(GetNewMsg().GetBytes());
//      IndexusMessage target = new IndexusMessage(ms);
//      ValidateIndexusMessage(target);
//    }

//    /// <summary>
//    ///A test for ItemPriority
//    ///</summary>
//    [TestMethod()]
//    public void ItemPriorityTest()
//    {
//      IndexusMessage target = new IndexusMessage();
//      IndexusMessage.CacheItemPriority val = IndexusMessage.CacheItemPriority.BelowNormal;
//      target.ItemPriority = val;
//      Assert.AreEqual(val, target.ItemPriority, "SharedCache.WinServiceCommon.IndexusMessage.ItemPriority was not set correctly.");
//    }

//    /// <summary>
//    ///A test for Key
//    ///</summary>
//    [TestMethod()]
//    public void KeyTest()
//    {
//      IndexusMessage target = new IndexusMessage();
//      string val = key;
//      target.Key = val;
//      Assert.AreEqual(val, target.Key, "SharedCache.WinServiceCommon.IndexusMessage.Key was not set correctly.");
//    }

//    /// <summary>
//    ///A test for Length
//    ///</summary>
//    [TestMethod()]
//    public void LengthTest()
//    {
//      IndexusMessage target = new IndexusMessage();
//      int val = new Random().Next();
//      target.Length = val;
//      Assert.AreEqual(val, target.Length, "SharedCache.WinServiceCommon.IndexusMessage.Length was not set correctly.");
//    }

//    /// <summary>
//    ///A test for Payload
//    ///</summary>
//    [TestMethod()]
//    public void PayloadTest()
//    {
//      IndexusMessage target = new IndexusMessage();
//      byte[] val = data;
//      target.Payload = val;
//      CollectionAssert.AreEqual(val, target.Payload, "SharedCache.WinServiceCommon.IndexusMessage.Payload was not set correctly.");
//    }

//    /// <summary>
//    ///A test for Send ()
//    ///</summary>
//    [TestMethod()]
//    public void SendTest()
//    {
//      IndexusMessage target = new IndexusMessage();
//      bool expected = false;
//      bool actual;
//      actual = target.Send();
//      Assert.AreEqual(expected, actual, "SharedCache.WinServiceCommon.IndexusMessage.Send did not return the expected value.");
//    }

//    /// <summary>
//    ///A test for SendTimeout
//    ///</summary>
//    [TestMethod()]
//    public void SendTimeoutTest()
//    {
//      IndexusMessage target = new IndexusMessage();
//      int val = 55;
//      target.SendTimeout = val;
//      Assert.AreEqual(val, target.SendTimeout, "SharedCache.WinServiceCommon.IndexusMessage.SendTimeout was not set correctly.");
//    }
//    /// <summary>
//    ///A test for GetBytes ()
//    ///</summary>
//    [TestMethod()]
//    public void GetBytesSetBytesTest()
//    {

//      IndexusMessage target = this.GetNewMsg();
//      byte[] actual;
//      actual = target.GetBytes();

//      IndexusMessage msg = new IndexusMessage(new MemoryStream(actual));
//      ValidateIndexusMessage(msg);

			
//    }

//    /// <summary>
//    ///A test for Status
//    ///</summary>
//    [TestMethod()]
//    public void StatusTest() 
//    {
//      IndexusMessage target = new IndexusMessage();
//      IndexusMessage.StatusValue val = IndexusMessage.StatusValue.Response;
//      target.Status = val;
//      Assert.AreEqual(val, target.Status, "SharedCache.WinServiceCommon.IndexusMessage.Status was not set correctly.");
//    }

//    /// <summary>
//    ///A test for Timestamp
//    ///</summary>
//    [TestMethod()]
//    public void TimestampTest()
//    {
//      IndexusMessage target = new IndexusMessage();
//      DateTime val = DateTime.Now;
//      target.Timestamp = val;
//      Assert.AreEqual(val, target.Timestamp, "SharedCache.WinServiceCommon.IndexusMessage.Timestamp was not set correctly.");
//    }
	
//    /// <summary>
//    ///A test for Ttl
//    ///</summary>
//    [TestMethod()]
//    public void TtlTest()
//    {
//      IndexusMessage target = new IndexusMessage();
//      short val = 125;
//      target.Ttl = val;
//      Assert.AreEqual(val, target.Ttl, "SharedCache.WinServiceCommon.IndexusMessage.Ttl was not set correctly.");
//    }

//  }


//}
