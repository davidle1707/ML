﻿//#region Copyright (c) Roni Schuetz, Switzerland. All Rights Reserved
//// * --------------------------------------------------------------------- *
//// *                              Roni Schuetz                             *
//// *              Copyright (c) 2008 All Rights reserved                   *
//// *                                                                       *
//// * Shared Cache high-performance, distributed caching and    *
//// * replicated caching system, generic in nature, but intended to         *
//// * speeding up dynamic web and / or win applications by alleviating      *
//// * database load.                                                        *
//// *                                                                       *
//// * This Software is written by Roni Schuetz (schuetz AT gmail DOT com)   *
//// *                                                                       *
//// * This library is free software; you can redistribute it and/or         *
//// * modify it under the terms of the GNU Lesser General Public License    *
//// * as published by the Free Software Foundation; either version 2.1      *
//// * of the License, or (at your option) any later version.                *
//// *                                                                       *
//// * This library is distributed in the hope that it will be useful,       *
//// * but WITHOUT ANY WARRANTY; without even the implied warranty of        *
//// * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU      *
//// * Lesser General Public License for more details.                       *
//// *                                                                       *
//// * You should have received a copy of the GNU Lesser General Public      *
//// * License along with this library; if not, write to the Free            *
//// * Software Foundation, Inc., 59 Temple Place, Suite 330,                *
//// * Boston, MA 02111-1307 USA                                             *
//// *                                                                       *
//// *       THIS COPYRIGHT NOTICE MAY NOT BE REMOVED FROM THIS FILE.        *
//// * --------------------------------------------------------------------- *
//#endregion 
//using Microsoft.VisualStudio.TestTools.UnitTesting;
//using System;
//using System.Text;
//using System.Collections.Generic;
//using F = SharedCache.WinServiceCommon.Formatters;
//namespace SharedCache.Testing
//{
//  /// <summary>
//  ///This is a test class for SharedCache.WinServiceCommon.Formatters.DateTimeUnix and is intended
//  ///to contain all SharedCache.WinServiceCommon.Formatters.DateTimeUnix Unit Tests
//  ///</summary>
//  [TestClass()]
//  public class DateTimeUnixTest
//  {
//    /// <summary>
//    /// Test DateTime boundries to convert to unix time and return.
//    /// </summary>
//    [TestMethod()]
//    public void DateTimeUnixCheckBoundryTest()
//    {
//      DateTime max = DateTime.MaxValue;
//      DateTime min = DateTime.MinValue;
//      DateTime today = DateTime.Now;
//      DateTime temp = today;
//      long lMax = 0;
//      long lMin = 0;
//      long lToday = 0;

//      lMax = F.DateTimeUnix.UnixTimeFromDateTime(max);
//      lMin = F.DateTimeUnix.UnixTimeFromDateTime(min);
//      lToday = F.DateTimeUnix.UnixTimeFromDateTime(today);
			
//      DateTime afterTestMax = F.DateTimeUnix.DateTimeFromUnixTime(lMax);
//      DateTime afterTestMin = F.DateTimeUnix.DateTimeFromUnixTime(lMin);
//      DateTime afterTestToday = F.DateTimeUnix.DateTimeFromUnixTime(lToday);

//      // we dont mind about milliseconds 
//      Assert.AreEqual<int>(DateTime.MaxValue.Year, afterTestMax.Year, @"Problem with Max DateTime");
//      Assert.AreEqual<int>(DateTime.MaxValue.Month, afterTestMax.Month, @"Problem with Max DateTime");
//      Assert.AreEqual<int>(DateTime.MaxValue.Day, afterTestMax.Day, @"Problem with Max DateTime");
//      Assert.AreEqual<int>(DateTime.MaxValue.Hour, afterTestMax.Hour, @"Problem with Max DateTime");
//      Assert.AreEqual<int>(DateTime.MaxValue.Minute, afterTestMax.Minute, @"Problem with Max DateTime");
//      Assert.AreEqual<int>(DateTime.MaxValue.Second, afterTestMax.Second, @"Problem with Max DateTime");

//      // Min. is not a problem to check it directly due milliseconds are 0
//      Assert.AreEqual(DateTime.MinValue.Ticks, afterTestMin.Ticks, @"Problem with Min DateTime");

//      // we dont mind about milliseconds 
//      Assert.AreEqual<int>(temp.Year, afterTestToday.Year, @"Problem with Now DateTime");
//      Assert.AreEqual<int>(temp.Month, afterTestToday.Month, @"Problem with Now DateTime");
//      Assert.AreEqual<int>(temp.Day, afterTestToday.Day, @"Problem with Now DateTime");
//      Assert.AreEqual<int>(temp.Hour, afterTestToday.Hour, @"Problem with Now DateTime");
//      Assert.AreEqual<int>(temp.Minute, afterTestToday.Minute, @"Problem with Now DateTime");
//      Assert.AreEqual<int>(temp.Second, afterTestToday.Second, @"Problem with Now DateTime");
//    }
//  }
//}
