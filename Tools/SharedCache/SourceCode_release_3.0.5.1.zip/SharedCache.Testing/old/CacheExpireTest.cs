﻿//#region Copyright (c) Roni Schuetz, Switzerland. All Rights Reserved
//// * --------------------------------------------------------------------- *
//// *                              Roni Schuetz                             *
//// *              Copyright (c) 2008 All Rights reserved                   *
//// *                                                                       *
//// * Shared Cache high-performance, distributed caching and    *
//// * replicated caching system, generic in nature, but intended to         *
//// * speeding up dynamic web and / or win applications by alleviating      *
//// * database load.                                                        *
//// *                                                                       *
//// * This Software is written by Roni Schuetz (schuetz AT gmail DOT com)   *
//// *                                                                       *
//// * This library is free software; you can redistribute it and/or         *
//// * modify it under the terms of the GNU Lesser General Public License    *
//// * as published by the Free Software Foundation; either version 2.1      *
//// * of the License, or (at your option) any later version.                *
//// *                                                                       *
//// * This library is distributed in the hope that it will be useful,       *
//// * but WITHOUT ANY WARRANTY; without even the implied warranty of        *
//// * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU      *
//// * Lesser General Public License for more details.                       *
//// *                                                                       *
//// * You should have received a copy of the GNU Lesser General Public      *
//// * License along with this library; if not, write to the Free            *
//// * Software Foundation, Inc., 59 Temple Place, Suite 330,                *
//// * Boston, MA 02111-1307 USA                                             *
//// *                                                                       *
//// *       THIS COPYRIGHT NOTICE MAY NOT BE REMOVED FROM THIS FILE.        *
//// * --------------------------------------------------------------------- *
//#endregion 
//using Microsoft.VisualStudio.TestTools.UnitTesting;
//using System;
//using System.Text;
//using System.Collections.Generic;
//using SharedCache.WinServiceCommon;
//namespace SharedCache.Testing
//{
//  /// <summary>
//  ///This is a test class for SharedCache.WinServiceCommon.CacheExpire and is intended
//  ///to contain all SharedCache.WinServiceCommon.CacheExpire Unit Tests
//  ///</summary>
//  [TestClass()]
//  public class CacheExpireTest
//  {


//    private TestContext testContextInstance;

//    /// <summary>
//    ///Gets or sets the test context which provides
//    ///information about and functionality for the current test run.
//    ///</summary>
//    public TestContext TestContext
//    {
//      get
//      {
//        return testContextInstance;
//      }
//      set
//      {
//        testContextInstance = value;
//      }
//    }
//    #region Additional test attributes
//    // 
//    //You can use the following additional attributes as you write your tests:
//    //
//    //Use ClassInitialize to run code before running the first test in the class
//    //
//    //[ClassInitialize()]
//    //public static void MyClassInitialize(TestContext testContext)
//    //{
//    //}
//    //
//    //Use ClassCleanup to run code after all tests in a class have run
//    //
//    //[ClassCleanup()]
//    //public static void MyClassCleanup()
//    //{
//    //}
//    //
//    //Use TestInitialize to run code before running each test
//    //
//    //[TestInitialize()]
//    //public void MyTestInitialize()
//    //{
//    //}
//    //
//    //Use TestCleanup to run code after each test has run
//    //
//    //[TestCleanup()]
//    //public void MyTestCleanup()
//    //{
//    //}
//    //
//    #endregion


//    /// <summary>
//    ///A test for CacheExpire (bool)
//    ///</summary>
//    [TestMethod()]
//    public void CacheExpireConstructorTest()
//    {
//      bool enable = false;
//      CacheExpire target = new CacheExpire(enable);
//      Assert.AreEqual<bool>(enable, target.Enable);
//    }

//    /// <summary>
//    ///A test for CleanUp ()
//    ///</summary>
//    [TestMethod()]
//    public void CleanUpTest()
//    {
//      bool enable = false;
//      CacheExpire target = new CacheExpire(enable);
//      target.DumpCacheItemAt("abc", DateTime.Now.AddMinutes(-2));
//      List<string> actual = target.CleanUp();
//      Assert.IsTrue(actual.Count > 0);
//      Assert.AreSame("abc", actual[0]);
//    }

//    /// <summary>
//    ///A test for Clear ()
//    ///</summary>
//    [TestMethod()]
//    public void ClearTest()
//    {
//      // TODO: find out how i'm able to access over the private accessor 
//      // to the expireTable data!!!
//      bool enable = false;
//      CacheExpire target = new CacheExpire(enable);
//      target.DumpCacheItemAt("abc", DateTime.Now.AddMinutes(-2));
//      target.Clear();
//    }

//    /// <summary>
//    ///A test for DumpCacheItemAt (string, DateTime)
//    ///</summary>
//    [TestMethod()]
//    public void DumpCacheItemAtTest()
//    {
//      bool enable = false;
//      CacheExpire target = new CacheExpire(enable);
//      target.DumpCacheItemAt("abc", DateTime.Now.AddMinutes(-2));
//      target.DumpCacheItemAt("abc", DateTime.Now.AddMinutes(-2));
//      List<string> dumpList = target.CleanUp();
//      Assert.AreEqual<int>(1, dumpList.Count, "Count is not correct");
//    }

//    /// <summary>
//    ///A test for Enable
//    ///</summary>
//    [TestMethod()]
//    public void EnableTest()
//    {
//      bool enable = false;
//      CacheExpire target = new CacheExpire(enable);
//      Assert.IsFalse(target.Enable);
//      enable = true;
//      target = new CacheExpire(enable);
//      Assert.IsTrue(target.Enable);
//    }

//    /// <summary>
//    ///A test for Remove (string)
//    ///</summary>
//    [TestMethod()]
//    public void RemoveTest()
//    {
			
//      bool enable = false;
//      CacheExpire target = new CacheExpire(enable);
//      target.DumpCacheItemAt("abc", DateTime.Now.AddMinutes(-2));
//      List<string> dumpList = target.CleanUp();
			
//      Assert.AreEqual<int>(1, dumpList.Count, "Count is not correct");
//      target.Remove(@"abc");
			
//      dumpList = target.CleanUp();
//      Assert.AreEqual<int>(0, dumpList.Count, "Count is not correct");
//    }

//  }


//}
