﻿//#region Copyright (c) Roni Schuetz, Switzerland. All Rights Reserved
//// * --------------------------------------------------------------------- *
//// *                              Roni Schuetz                             *
//// *              Copyright (c) 2008 All Rights reserved                   *
//// *                                                                       *
//// * Shared Cache high-performance, distributed caching and    *
//// * replicated caching system, generic in nature, but intended to         *
//// * speeding up dynamic web and / or win applications by alleviating      *
//// * database load.                                                        *
//// *                                                                       *
//// * This Software is written by Roni Schuetz (schuetz AT gmail DOT com)   *
//// *                                                                       *
//// * This library is free software; you can redistribute it and/or         *
//// * modify it under the terms of the GNU Lesser General Public License    *
//// * as published by the Free Software Foundation; either version 2.1      *
//// * of the License, or (at your option) any later version.                *
//// *                                                                       *
//// * This library is distributed in the hope that it will be useful,       *
//// * but WITHOUT ANY WARRANTY; without even the implied warranty of        *
//// * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU      *
//// * Lesser General Public License for more details.                       *
//// *                                                                       *
//// * You should have received a copy of the GNU Lesser General Public      *
//// * License along with this library; if not, write to the Free            *
//// * Software Foundation, Inc., 59 Temple Place, Suite 330,                *
//// * Boston, MA 02111-1307 USA                                             *
//// *                                                                       *
//// *       THIS COPYRIGHT NOTICE MAY NOT BE REMOVED FROM THIS FILE.        *
//// * --------------------------------------------------------------------- *
//#endregion 
//using Microsoft.VisualStudio.TestTools.UnitTesting;
//using System;
//using System.Text;
//using System.Collections.Generic;
//using SharedCache.WinServiceCommon;
//namespace SharedCache.Testing
//{
//  /// <summary>
//  ///This is a test class for SharedCache.WinServiceCommon.Cache and is intended
//  ///to contain all SharedCache.WinServiceCommon.Cache Unit Tests
//  ///</summary>
//  [TestClass()]
//  public class CacheTest
//  {
//    /// <summary>
//    ///A test for Add (KeyValuePair&lt;string,byte[]&gt;)
//    ///</summary>
//    [TestMethod()]
//    public void AddTest()
//    {
//      Cache target = new Cache();
//      KeyValuePair<string, byte[]> kpv = new KeyValuePair<string, byte[]>(@"Shared Cache", new byte[] { 1, 2, 4, 8 }); 
//      target.Add(kpv);
//      Assert.IsTrue(target.GetAllKeys().Count > 0);
//    }

//    /// <summary>
//    ///A test for Add (string, byte[])
//    ///</summary>
//    [TestMethod()]
//    public void AddTest1()
//    {
//      Cache target = new Cache();
//      string key = @"Shared Cache";
//      byte[] value = new byte[] { 1, 2, 4, 8 };
//      target.Add(key, value);
//      Assert.IsTrue(target.GetAllKeys().Count > 0);
//    }

//    /// <summary>
//    ///A test for Amount ()
//    ///</summary>
//    [TestMethod()]
//    public void AmountTest()
//    {
//      Cache target = new Cache();
//      target.Add("test1", new byte[] { 1, 2, 4, 8 });
//      target.Add("test2", new byte[] { 1, 2, 4, 8 });
//      target.Add("test3", new byte[] { 1, 2, 4, 8 });
//      target.Add("test4", new byte[] { 1, 2, 4, 8 });
//      long expected = 4;
//      long actual;
//      actual = target.Amount();
//      Assert.AreEqual(expected, actual, "Cache.Amount did not return the expected value.");
//    }

//    /// <summary>
//    ///A test for Cache ()
//    ///</summary>
//    [TestMethod()]
//    public void CacheConstructorTest()
//    {
//      Cache target = new Cache();
//      Assert.IsNotNull(target);
//    }

//    /// <summary>
//    ///A test for Cache (int)
//    ///</summary>
//    [TestMethod()]
//    public void CacheConstructorTestWithSize()
//    {
//      int initialSize = 2;
//      Cache target = new Cache(initialSize);
			

//    }

//    /// <summary>
//    ///A test for CacheCleanup
//    ///</summary>
//    [TestMethod()]
//    public void CacheCleanupTest()
//    {
//      Cache target = new Cache();
//      Assert.IsNotNull(target.CacheCleanup, "CacheCleanup is NULL!");
//    }

//    /// <summary>
//    ///A test for CalculatedCacheSize
//    ///</summary>
//    [TestMethod()]
//    public void CalculatedCacheSizeTest()
//    {
//      Cache target = new Cache();
//      FillCache(target, 1);
//      long result = 4;
//      Assert.AreEqual<long>(result, target.CalculatedCacheSize, "Cache.CalculatedCacheSize was not set correctly.");
//      FillCache(target, 2);
//      result = 12;
//      Assert.AreEqual<long>(result, target.CalculatedCacheSize, "Cache.CalculatedCacheSize was not set correctly.");
//    }

//    /// <summary>
//    /// Fills the cache.
//    /// </summary>
//    /// <param name="target">The target.</param>
//    /// <param name="amount">The amount.</param>
//    public static void FillCache(Cache target, int amount)
//    {
//      for (int i = 0; i < amount; ++i)
//      {
//        target.Add(Guid.NewGuid().ToString(), new byte[] { 1, 2, 3, 4 });
//      }
//    }

//    /// <summary>
//    ///A test for Clear ()
//    ///</summary>
//    [TestMethod()]
//    public void ClearTest()
//    {
//      Cache target = new Cache();
//      FillCache(target, 200);
//      target.Clear();
//      long afterClear = 0;
//      Assert.AreEqual<long>(afterClear, target.CalculatedCacheSize, "Size is not the same after clear");
//      Assert.AreEqual<int>(0, target.GetAllKeys().Count);
//    }

//    /// <summary>
//    ///A test for Get (string)
//    ///</summary>
//    [TestMethod()]
//    public void GetTest()
//    {
//      string key = @"Shared Cache";
//      Cache target = new Cache();
//      FillCache(target, 100);
//      byte [] expected = new byte[] {1,4,8};
//      target.Add(key, expected);
//      FillCache(target, 100);
//      byte [] actual = target.Get(key);
//      CollectionAssert.AreEqual(expected, actual, "Cache.Get did not return the expected value.");
//    }

//    /// <summary>
//    ///A test for GetAllKeys ()
//    ///</summary>
//    [TestMethod()]
//    public void GetAllKeysTest()
//    {
//      Cache target = new Cache();
//      FillCache(target, 300);
//      List<string> actual= target.GetAllKeys();
//      Assert.AreEqual(300, actual.Count, @"Cache does not contain same count like expected.");
//      foreach (string n in actual)
//        Assert.IsTrue(!string.IsNullOrEmpty(n), @"Item Key is null or empty!!");
//    }

//    /// <summary>
//    ///A test for Insert (string, byte[])
//    ///</summary>
//    [TestMethod()]
//    public void InsertTest()
//    {
//      string key = @"Shared Cache";
//      Cache target = new Cache();
//      FillCache(target, 300);
//      byte[] value = new byte[] { 1, 2, 4, 8 };
			
//      long size = target.CalculatedCacheSize + value.Length;
//      target.Insert(key, value);			
//      Assert.AreEqual<long>(size, target.CalculatedCacheSize);
//    }

//    /// <summary>
//    ///A test for Remove (string)
//    ///</summary>
//    [TestMethod()]
//    public void RemoveTest()
//    {
//      string key = @"Shared Cache";
//      Cache target = new Cache();
//      FillCache(target, 300);
//      byte[] value = new byte[] { 1, 2, 4, 8 };
//      target.Add(key, value);
//      long size = target.CalculatedCacheSize - value.Length;
//      target.Remove(key);
//      Assert.AreEqual<long>(size, target.CalculatedCacheSize, @"A problem appears in remove test.");
//    }

//    /// <summary>
//    ///A test for Size ()
//    ///</summary>
//    [TestMethod()]
//    public void SizeTest()
//    {
//      string key = @"Shared Cache";
//      Cache target = new Cache();
//      FillCache(target, 300);
//      byte[] value = new byte[] { 1, 2, 4, 8 };
//      target.Add(key, value);
//      long size = target.CalculatedCacheSize - value.Length;
//      target.Remove(key);
//      Assert.AreEqual<long>(size, target.Size(), @"size is not correct.");
//    }

//  }


//}
