﻿//#region Copyright (c) Roni Schuetz, Switzerland. All Rights Reserved
//// * --------------------------------------------------------------------- *
//// *                              Roni Schuetz                             *
//// *              Copyright (c) 2008 All Rights reserved                   *
//// *                                                                       *
//// * Shared Cache high-performance, distributed caching and    *
//// * replicated caching system, generic in nature, but intended to         *
//// * speeding up dynamic web and / or win applications by alleviating      *
//// * database load.                                                        *
//// *                                                                       *
//// * This Software is written by Roni Schuetz (schuetz AT gmail DOT com)   *
//// *                                                                       * 
//// * This library is free software; you can redistribute it and/or         *
//// * modify it under the terms of the GNU Lesser General Public License    *
//// * as published by the Free Software Foundation; either version 2.1      *
//// * of the License, or (at your option) any later version.                *
//// *                                                                       *
//// * This library is distributed in the hope that it will be useful,       *
//// * but WITHOUT ANY WARRANTY; without even the implied warranty of        *
//// * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU      *
//// * Lesser General Public License for more details.                       *
//// *                                                                       *
//// * You should have received a copy of the GNU Lesser General Public      *
//// * License along with this library; if not, write to the Free            *
//// * Software Foundation, Inc., 59 Temple Place, Suite 330,                *
//// * Boston, MA 02111-1307 USA                                             *
//// *                                                                       *
//// *       THIS COPYRIGHT NOTICE MAY NOT BE REMOVED FROM THIS FILE.        *
//// * --------------------------------------------------------------------- *
//#endregion 
//using Microsoft.VisualStudio.TestTools.UnitTesting;
//using System;
//using System.Text;
//using System.Collections.Generic;
//using SharedCache.WinServiceCommon;
//namespace SharedCache.Testing
//{
//  /// <summary>
//  ///This is a test class for SharedCache.WinServiceCommon.CacheCleanup and is intended
//  ///to contain all SharedCache.WinServiceCommon.CacheCleanup Unit Tests
//  ///</summary>
//  [TestClass()]
//  public class CacheCleanupTest
//  {
//    #region 
//    /// <summary>
//    /// Fills the clean up cache with some basic data
//    /// </summary>
//    /// <param name="target">The target.</param>
//    /// <param name="amount">The amount.</param>
//    private static void FillCleanUp(CacheCleanup target, int amount)
//    {
//      if (amount <= 0)
//        amount = 1;

//      List<IndexusMessage> msgs = new List<IndexusMessage>();

//      for (int i = 0; i < amount; ++i)
//      {
//        IndexusMessage msg = new IndexusMessage(i);
//        msg.Key = Guid.NewGuid().ToString();
//        msg.Payload = new byte[] { 1, 2, 3, 4 };
//        msgs.Add(msg);
//      }

//      foreach (IndexusMessage m in msgs)
//        target.Update(m);
//    }

//    private TestContext testContextInstance;

//    /// <summary>
//    ///Gets or sets the test context which provides
//    ///information about and functionality for the current test run.
//    ///</summary>
//    public TestContext TestContext
//    {
//      get
//      {
//        return testContextInstance;
//      }
//      set
//      {
//        testContextInstance = value;
//      }
//    }
//    #endregion
//    #region Additional test attributes
//    // 
//    //You can use the following additional attributes as you write your tests:
//    //
//    //Use ClassInitialize to run code before running the first test in the class
//    //
//    //[ClassInitialize()]
//    //public static void MyClassInitialize(TestContext testContext)
//    //{
//    //}
//    //
//    //Use ClassCleanup to run code after all tests in a class have run
//    //
//    //[ClassCleanup()]
//    //public static void MyClassCleanup()
//    //{
//    //}
//    //
//    //Use TestInitialize to run code before running each test
//    //
//    //[TestInitialize()]
//    //public void MyTestInitialize()
//    //{
//    //}
//    //
//    //Use TestCleanup to run code after each test has run
//    //
//    //[TestCleanup()]
//    //public void MyTestCleanup()
//    //{
//    //}
//    //
//    #endregion
		
//    /// <summary>
//    ///A test for CacheAmountOfObjects
//    ///the value of: -1048576 comes because the test config file set to -1
//    ///</summary>
//    [TestMethod()]
//    public void CacheAmountOfObjectsTest()
//    {
//      CacheCleanup target = new CacheCleanup();
//      FillCleanUp(target, 25);
//      Assert.AreEqual<long>(-1048576, target.CacheAmountOfObjects, "CacheCleanup.CacheAmountOfObjects was not set correctly.");
//    }

//    /// <summary>
//    ///A test for CacheCleanup ()
//    ///</summary>
//    [TestMethod()]
//    public void ConstructorTest()
//    {
//      CacheCleanup target = new CacheCleanup();

//      Assert.IsNotNull(target);
//      Assert.AreNotEqual<long>(0, target.CacheAmountOfObjects);
//      Assert.AreNotEqual<long>(0, target.CacheFillFactor);
//      Assert.IsNotNull(target.CleanupList);
//    }

//    /// <summary>
//    ///A test for CacheFillFactor
//    ///</summary>
//    [TestMethod()]
//    public void CacheFillFactorTest()
//    {
//      CacheCleanup target = new CacheCleanup();
//      long factor =95;
//      Assert.AreEqual(factor, target.CacheFillFactor, "CacheCleanup.CacheFillFactor was not set correctly.");
//    }

//    /// <summary>
//    ///A test for CalculateHybridChecksum (Cleanup, Enums.ServiceCacheCleanUp)
//    ///</summary>
//    [TestMethod()]
//    public void CalculateHybridChecksumTest()
//    {
//      Cleanup c = new Cleanup();
//      c.HitRatio = 55;
//      c.ObjectSize = 4568;
//      c.Prio = IndexusMessage.CacheItemPriority.AboveNormal;
//      c.Span = new TimeSpan(0, 0, 20);
//      c.UsageDatetime = DateTime.Now.AddMinutes(-1);

//      Enums.ServiceCacheCleanUp currentConfiguration = Enums.ServiceCacheCleanUp.CACHEITEMPRIORITY;

//      long expected = 0;
//      long actual;

//      actual = SharedCache.WinServiceCommon.CacheCleanup.CalculateHybridChecksum(c, currentConfiguration);

//      Assert.AreEqual(expected, actual, "CacheCleanup.CalculateHybridChecksum did not return the expected value.");

//      actual = SharedCache.WinServiceCommon.CacheCleanup.CalculateHybridChecksum(c, Enums.ServiceCacheCleanUp.HYBRID);

//      Assert.AreNotEqual(0, actual, "CacheCleanup.CalculateHybridChecksum did not return the expected value.");

//    }

//    /// <summary>
//    ///A test for CleanupCacheConfiguration
//    ///</summary>
//    [TestMethod()]
//    public void CleanupCacheConfigurationTest()
//    {
//      CacheCleanup target = new CacheCleanup();
//      Enums.ServiceCacheCleanUp val = Enums.ServiceCacheCleanUp.CACHEITEMPRIORITY;
//      target.CleanupCacheConfiguration = val;
//      Assert.AreEqual(val, target.CleanupCacheConfiguration, "SharedCache.WinServiceCommon.CacheCleanup.CleanupCacheConfiguration was not set correctly.");
//    }

//    /// <summary>
//    ///A test for Clear ()
//    ///</summary>
//    [TestMethod()]
//    public void ClearTest()
//    {
//      CacheCleanup target = new CacheCleanup();
//      FillCleanUp(target, 20);
//      target.Clear();
//      Assert.AreEqual(0, target.CleanupList.Count);
//    }

//    /// <summary>
//    ///A test for GetAccessStatList ()
//    ///</summary>
//    [TestMethod()]
//    public void GetAccessStatListTest()
//    {
//      CacheCleanup target = new CacheCleanup();
//      FillCleanUp(target, 30);
			
//      System.Collections.Generic.Dictionary<string, long> actual;
//      actual = target.GetAccessStatList();
//      Assert.AreEqual(20, actual.Count, "CacheCleanup.GetAccessStatList did not return the expected value.");
//    }

//    /// <summary>
//    ///A test for HybridChecksum (long)
//    ///</summary>
//    [TestMethod()]
//    public void HybridChecksumTest()
//    {
//      long para = 500123512; 
//      long expected = 28513;
//      long actual;
//      actual = SharedCache.WinServiceCommon.CacheCleanup.HybridChecksum(para);
//      Assert.AreEqual(expected, actual, "CacheCleanup.HybridChecksum did not return the expected value.");
//    }

//    /// <summary>
//    ///A test for Purge (long)
//    ///</summary>
//    [TestMethod()]
//    public void PurgeTest()
//    {			
//      CacheCleanup target = new CacheCleanup();
//      FillCleanUp(target, 300);
//      long actualCacheSize = 1024;
//      List<string> ret = target.Purge(actualCacheSize);
//      Assert.AreNotEqual(0, ret.Count);			
//    }

//    /// <summary>
//    ///A test for PurgeIsRunning
//    ///</summary>
//    [TestMethod()]
//    public void PurgeIsRunningTest()
//    {
//      CacheCleanup target = new CacheCleanup();
//      Assert.AreEqual<bool>(false, target.PurgeIsRunning);
//    }

//    /// <summary>
//    ///A test for Remove (string)
//    ///</summary>
//    [TestMethod()]
//    public void RemoveTest()
//    {
//      CacheCleanup target = new CacheCleanup();
//      FillCleanUp(target, 10);
//      target.CleanupList.Add(
//        new Cleanup(
//            "5", 
//            IndexusMessage.CacheItemPriority.AboveNormal, 
//            new TimeSpan(), 
//            5, 
//            DateTime.Now, 
//            120, 
//            33
//          )
//        );
//      string key = "5";
//      target.Remove(key);
//      Assert.AreEqual<int>(10, target.CleanupList.Count, "Did not removed data properly");			
//    }

//    /// <summary>
//    ///A test for Update (IndexusMessage)
//    ///</summary>
//    [TestMethod()]
//    public void UpdateTest()
//    {
//      CacheCleanup target = new CacheCleanup();
//      FillCleanUp(target, 30);
//      IndexusMessage msg = new IndexusMessage(
//          5, 
//          IndexusMessage.ActionValue.Add, 
//          "abc", 
//          new byte[] { 1, 2, 3, 4 }, 
//          DateTime.Now.AddMinutes(5)
//        );
//      target.Update(msg);
//      int count = target.CleanupList.Count;
//      msg.Key = "222";
//      target.Update(msg);
//      Assert.AreEqual<int>(32, target.CleanupList.Count, @"Liste does not contain same amount.");
//      target.Remove("abc");
//      Assert.AreEqual<int>(31, target.CleanupList.Count, @"Liste does not contain same amount.");

//    }

//  }


//}
