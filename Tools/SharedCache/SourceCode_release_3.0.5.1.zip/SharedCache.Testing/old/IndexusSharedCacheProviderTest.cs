﻿using SharedCache.WinServiceCommon.Provider.Cache;
using Microsoft.VisualStudio.TestTools.UnitTesting;
namespace SharedCache.Testing
{
    
    
    /// <summary>
    ///This is a test class for IndexusSharedCacheProviderTest and is intended
    ///to contain all IndexusSharedCacheProviderTest Unit Tests
    ///</summary>
	[TestClass()]
	public class IndexusSharedCacheProviderTest
	{


		private TestContext testContextInstance;

		/// <summary>
		///Gets or sets the test context which provides
		///information about and functionality for the current test run.
		///</summary>
		public TestContext TestContext
		{
			get
			{
				return testContextInstance;
			}
			set
			{
				testContextInstance = value;
			}
		}

		#region Additional test attributes
		// 
		//You can use the following additional attributes as you write your tests:
		//
		//Use ClassInitialize to run code before running the first test in the class
		//[ClassInitialize()]
		//public static void MyClassInitialize(TestContext testContext)
		//{
		//}
		//
		//Use ClassCleanup to run code after all tests in a class have run
		//[ClassCleanup()]
		//public static void MyClassCleanup()
		//{
		//}
		//
		//Use TestInitialize to run code before running each test
		//[TestInitialize()]
		//public void MyTestInitialize()
		//{
		//}
		//
		//Use TestCleanup to run code after each test has run
		//[TestCleanup()]
		//public void MyTestCleanup()
		//{
		//}
		//
		#endregion


		/// <summary>
		///A test for ServersList
		///</summary>
		[TestMethod()]
		public void ServersListTest()
		{
			SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider target = new SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider(); // TODO: Initialize to an appropriate value
			System.Collections.Generic.List<SharedCache.WinServiceCommon.Configuration.Client.IndexusServerSetting> actual;
			actual = target.ServersList;
			Assert.Inconclusive("Verify the correctness of this test method.");
		}

		/// <summary>
		///A test for Servers
		///</summary>
		[TestMethod()]
		public void ServersTest()
		{
			SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider target = new SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider(); // TODO: Initialize to an appropriate value
			string[] actual;
			actual = target.Servers;
			Assert.Inconclusive("Verify the correctness of this test method.");
		}

		/// <summary>
		///A test for ReplicatedServersList
		///</summary>
		[TestMethod()]
		public void ReplicatedServersListTest()
		{
			SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider target = new SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider(); // TODO: Initialize to an appropriate value
			System.Collections.Generic.List<SharedCache.WinServiceCommon.Configuration.Client.IndexusServerSetting> actual;
			actual = target.ReplicatedServersList;
			Assert.Inconclusive("Verify the correctness of this test method.");
		}

		/// <summary>
		///A test for ReplicatedServers
		///</summary>
		[TestMethod()]
		public void ReplicatedServersTest()
		{
			SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider target = new SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider(); // TODO: Initialize to an appropriate value
			string[] actual;
			actual = target.ReplicatedServers;
			Assert.Inconclusive("Verify the correctness of this test method.");
		}

		/// <summary>
		///A test for Hashing
		///</summary>
		[TestMethod()]
		public void HashingTest()
		{
			SharedCache.WinServiceCommon.Enums.HashingAlgorithm actual;
			actual = SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider.Hashing;
			Assert.Inconclusive("Verify the correctness of this test method.");
		}

		/// <summary>
		///A test for Count
		///</summary>
		[TestMethod()]
		public void CountTest()
		{
			SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider target = new SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider(); // TODO: Initialize to an appropriate value
			long actual;
			actual = target.Count;
			Assert.Inconclusive("Verify the correctness of this test method.");
		}

		/// <summary>
		///A test for WcfRegexGet
		///</summary>
		[TestMethod()]
		public void WcfRegexGetTest()
		{
			SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider target = new SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider(); // TODO: Initialize to an appropriate value
			string regularExpression = string.Empty; // TODO: Initialize to an appropriate value
			System.Collections.Generic.IDictionary<string, byte[]> expected = null; // TODO: Initialize to an appropriate value
			System.Collections.Generic.IDictionary<string, byte[]> actual;
			actual = target.WcfRegexGet(regularExpression);
			Assert.AreEqual(expected, actual);
			Assert.Inconclusive("Verify the correctness of this test method.");
		}

		/// <summary>
		///A test for WcfMultiGet
		///</summary>
		[TestMethod()]
		public void WcfMultiGetTest()
		{
			SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider target = new SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider(); // TODO: Initialize to an appropriate value
			System.Collections.Generic.List<string> keys = null; // TODO: Initialize to an appropriate value
			System.Collections.Generic.IDictionary<string, byte[]> expected = null; // TODO: Initialize to an appropriate value
			System.Collections.Generic.IDictionary<string, byte[]> actual;
			actual = target.WcfMultiGet(keys);
			Assert.AreEqual(expected, actual);
			Assert.Inconclusive("Verify the correctness of this test method.");
		}

		/// <summary>
		///A test for WcfGet
		///</summary>
		public void WcfGetTest1Helper<T>()
		{
			SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider target = new SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider(); // TODO: Initialize to an appropriate value
			string key = string.Empty; // TODO: Initialize to an appropriate value
			T expected = default(T); // TODO: Initialize to an appropriate value
			T actual;
			actual = target.WcfGet<T>(key);
			Assert.AreEqual(expected, actual);
			Assert.Inconclusive("Verify the correctness of this test method.");
		}
		/// <summary>
		/// A test for WcfGet
		/// </summary>
		[TestMethod()]
		public void WcfGetTest1()
		{
			WcfGetTest1Helper<Microsoft.VisualStudio.TestTools.UnitTesting.GenericParameterHelper>();
		}

		/// <summary>
		///A test for WcfGet
		///</summary>
		[TestMethod()]
		public void WcfGetTest()
		{
			SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider target = new SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider(); // TODO: Initialize to an appropriate value
			string key = string.Empty; // TODO: Initialize to an appropriate value
			object expected = null; // TODO: Initialize to an appropriate value
			object actual;
			actual = target.WcfGet(key);
			Assert.AreEqual(expected, actual);
			Assert.Inconclusive("Verify the correctness of this test method.");
		}

		/// <summary>
		///A test for WcfAdd
		///</summary>
		[TestMethod()]
		public void WcfAddTest4()
		{
			SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider target = new SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider(); // TODO: Initialize to an appropriate value
			string key = string.Empty; // TODO: Initialize to an appropriate value
			object payload = null; // TODO: Initialize to an appropriate value
			System.DateTime expires = new System.DateTime(); // TODO: Initialize to an appropriate value
			target.WcfAdd(key, payload, expires);
			Assert.Inconclusive("A method that does not return a value cannot be verified.");
		}

		/// <summary>
		///A test for WcfAdd
		///</summary>
		[TestMethod()]
		public void WcfAddTest3()
		{
			SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider target = new SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider(); // TODO: Initialize to an appropriate value
			string key = string.Empty; // TODO: Initialize to an appropriate value
			object payload = null; // TODO: Initialize to an appropriate value
			target.WcfAdd(key, payload);
			Assert.Inconclusive("A method that does not return a value cannot be verified.");
		}

		/// <summary>
		///A test for WcfAdd
		///</summary>
		[TestMethod()]
		public void WcfAddTest2()
		{
			SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider target = new SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider(); // TODO: Initialize to an appropriate value
			string key = string.Empty; // TODO: Initialize to an appropriate value
			object payload = null; // TODO: Initialize to an appropriate value
			SharedCache.WinServiceCommon.IndexusMessage.CacheItemPriority prio = new SharedCache.WinServiceCommon.IndexusMessage.CacheItemPriority(); // TODO: Initialize to an appropriate value
			target.WcfAdd(key, payload, prio);
			Assert.Inconclusive("A method that does not return a value cannot be verified.");
		}

		/// <summary>
		///A test for WcfAdd
		///</summary>
		[TestMethod()]
		public void WcfAddTest1()
		{
			SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider target = new SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider(); // TODO: Initialize to an appropriate value
			string key = string.Empty; // TODO: Initialize to an appropriate value
			object payload = null; // TODO: Initialize to an appropriate value
			System.DateTime expires = new System.DateTime(); // TODO: Initialize to an appropriate value
			SharedCache.WinServiceCommon.IndexusMessage.CacheItemPriority prio = new SharedCache.WinServiceCommon.IndexusMessage.CacheItemPriority(); // TODO: Initialize to an appropriate value
			target.WcfAdd(key, payload, expires, prio);
			Assert.Inconclusive("A method that does not return a value cannot be verified.");
		}

		/// <summary>
		///A test for WcfAdd
		///</summary>
		[TestMethod()]
		public void WcfAddTest()
		{
			SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider target = new SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider(); // TODO: Initialize to an appropriate value
			string key = string.Empty; // TODO: Initialize to an appropriate value
			object payload = null; // TODO: Initialize to an appropriate value
			string host = string.Empty; // TODO: Initialize to an appropriate value
			target.WcfAdd(key, payload, host);
			Assert.Inconclusive("A method that does not return a value cannot be verified.");
		}

		/// <summary>
		///A test for ServerNodeVersionSharedCache
		///</summary>
		[TestMethod()]
		public void ServerNodeVersionSharedCacheTest()
		{
			SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider target = new SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider(); // TODO: Initialize to an appropriate value
			System.Collections.Generic.IDictionary<string, string> expected = null; // TODO: Initialize to an appropriate value
			System.Collections.Generic.IDictionary<string, string> actual;
			actual = target.ServerNodeVersionSharedCache();
			Assert.AreEqual(expected, actual);
			Assert.Inconclusive("Verify the correctness of this test method.");
		}

		/// <summary>
		///A test for ServerNodeVersionClr
		///</summary>
		[TestMethod()]
		public void ServerNodeVersionClrTest()
		{
			SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider target = new SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider(); // TODO: Initialize to an appropriate value
			System.Collections.Generic.IDictionary<string, string> expected = null; // TODO: Initialize to an appropriate value
			System.Collections.Generic.IDictionary<string, string> actual;
			actual = target.ServerNodeVersionClr();
			Assert.AreEqual(expected, actual);
			Assert.Inconclusive("Verify the correctness of this test method.");
		}

		/// <summary>
		///A test for Remove
		///</summary>
		[TestMethod()]
		public void RemoveTest()
		{
			SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider target = new SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider(); // TODO: Initialize to an appropriate value
			string key = string.Empty; // TODO: Initialize to an appropriate value
			target.Remove(key);
			Assert.Inconclusive("A method that does not return a value cannot be verified.");
		}

		/// <summary>
		///A test for RegexRemove
		///</summary>
		[TestMethod()]
		public void RegexRemoveTest()
		{
			SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider target = new SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider(); // TODO: Initialize to an appropriate value
			string regularExpression = string.Empty; // TODO: Initialize to an appropriate value
			bool expected = false; // TODO: Initialize to an appropriate value
			bool actual;
			actual = target.RegexRemove(regularExpression);
			Assert.AreEqual(expected, actual);
			Assert.Inconclusive("Verify the correctness of this test method.");
		}

		/// <summary>
		///A test for RegexGet
		///</summary>
		[TestMethod()]
		public void RegexGetTest()
		{
			SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider target = new SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider(); // TODO: Initialize to an appropriate value
			string regularExpression = string.Empty; // TODO: Initialize to an appropriate value
			System.Collections.Generic.IDictionary<string, byte[]> expected = null; // TODO: Initialize to an appropriate value
			System.Collections.Generic.IDictionary<string, byte[]> actual;
			actual = target.RegexGet(regularExpression);
			Assert.AreEqual(expected, actual);
			Assert.Inconclusive("Verify the correctness of this test method.");
		}

		/// <summary>
		///A test for Ping
		///</summary>
		[TestMethod()]
		public void PingTest()
		{
			SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider target = new SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider(); // TODO: Initialize to an appropriate value
			string host = string.Empty; // TODO: Initialize to an appropriate value
			bool expected = false; // TODO: Initialize to an appropriate value
			bool actual;
			actual = target.Ping(host);
			Assert.AreEqual(expected, actual);
			Assert.Inconclusive("Verify the correctness of this test method.");
		}

		/// <summary>
		///A test for MultiGet
		///</summary>
		[TestMethod()]
		public void MultiGetTest()
		{
			SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider target = new SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider(); // TODO: Initialize to an appropriate value
			System.Collections.Generic.List<string> keys = null; // TODO: Initialize to an appropriate value
			System.Collections.Generic.IDictionary<string, byte[]> expected = null; // TODO: Initialize to an appropriate value
			System.Collections.Generic.IDictionary<string, byte[]> actual;
			actual = target.MultiGet(keys);
			Assert.AreEqual(expected, actual);
			Assert.Inconclusive("Verify the correctness of this test method.");
		}

		/// <summary>
		///A test for MultiDelete
		///</summary>
		[TestMethod()]
		public void MultiDeleteTest()
		{
			SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider target = new SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider(); // TODO: Initialize to an appropriate value
			System.Collections.Generic.List<string> keys = null; // TODO: Initialize to an appropriate value
			target.MultiDelete(keys);
			Assert.Inconclusive("A method that does not return a value cannot be verified.");
		}

		/// <summary>
		///A test for MultiAdd
		///</summary>
		[TestMethod()]
		public void MultiAddTest()
		{
			SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider target = new SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider(); // TODO: Initialize to an appropriate value
			System.Collections.Generic.IDictionary<string, byte[]> data = null; // TODO: Initialize to an appropriate value
			target.MultiAdd(data);
			Assert.Inconclusive("A method that does not return a value cannot be verified.");
		}

		/// <summary>
		///A test for GetStats
		///</summary>
		[TestMethod()]
		public void GetStatsTest1()
		{
			SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider target = new SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider(); // TODO: Initialize to an appropriate value
			string host = string.Empty; // TODO: Initialize to an appropriate value
			SharedCache.WinServiceCommon.IndexusStatistic expected = null; // TODO: Initialize to an appropriate value
			SharedCache.WinServiceCommon.IndexusStatistic actual;
			actual = target.GetStats(host);
			Assert.AreEqual(expected, actual);
			Assert.Inconclusive("Verify the correctness of this test method.");
		}

		/// <summary>
		///A test for GetStats
		///</summary>
		[TestMethod()]
		public void GetStatsTest()
		{
			SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider target = new SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider(); // TODO: Initialize to an appropriate value
			SharedCache.WinServiceCommon.IndexusStatistic expected = null; // TODO: Initialize to an appropriate value
			SharedCache.WinServiceCommon.IndexusStatistic actual;
			actual = target.GetStats();
			Assert.AreEqual(expected, actual);
			Assert.Inconclusive("Verify the correctness of this test method.");
		}

		/// <summary>
		///A test for GetServerForKey
		///</summary>
		[TestMethod()]
		public void GetServerForKeyTest()
		{
			SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider target = new SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider(); // TODO: Initialize to an appropriate value
			string key = string.Empty; // TODO: Initialize to an appropriate value
			string expected = string.Empty; // TODO: Initialize to an appropriate value
			string actual;
			actual = target.GetServerForKey(key);
			Assert.AreEqual(expected, actual);
			Assert.Inconclusive("Verify the correctness of this test method.");
		}

		/// <summary>
		///A test for GetAllKeys
		///</summary>
		[TestMethod()]
		public void GetAllKeysTest1()
		{
			SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider target = new SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider(); // TODO: Initialize to an appropriate value
			string host = string.Empty; // TODO: Initialize to an appropriate value
			System.Collections.Generic.List<string> expected = null; // TODO: Initialize to an appropriate value
			System.Collections.Generic.List<string> actual;
			actual = target.GetAllKeys(host);
			Assert.AreEqual(expected, actual);
			Assert.Inconclusive("Verify the correctness of this test method.");
		}

		/// <summary>
		///A test for GetAllKeys
		///</summary>
		[TestMethod()]
		public void GetAllKeysTest()
		{
			SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider target = new SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider(); // TODO: Initialize to an appropriate value
			System.Collections.Generic.List<string> expected = null; // TODO: Initialize to an appropriate value
			System.Collections.Generic.List<string> actual;
			actual = target.GetAllKeys();
			Assert.AreEqual(expected, actual);
			Assert.Inconclusive("Verify the correctness of this test method.");
		}

		/// <summary>
		///A test for GetAbsoluteTimeExpiration
		///</summary>
		[TestMethod()]
		public void GetAbsoluteTimeExpirationTest()
		{
			SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider target = new SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider(); // TODO: Initialize to an appropriate value
			System.Collections.Generic.List<string> keys = null; // TODO: Initialize to an appropriate value
			System.Collections.Generic.IDictionary<string, System.DateTime> expected = null; // TODO: Initialize to an appropriate value
			System.Collections.Generic.IDictionary<string, System.DateTime> actual;
			actual = target.GetAbsoluteTimeExpiration(keys);
			Assert.AreEqual(expected, actual);
			Assert.Inconclusive("Verify the correctness of this test method.");
		}

		/// <summary>
		///A test for Get
		///</summary>
		[TestMethod()]
		public void GetTest1()
		{
			SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider target = new SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider(); // TODO: Initialize to an appropriate value
			string key = string.Empty; // TODO: Initialize to an appropriate value
			object expected = null; // TODO: Initialize to an appropriate value
			object actual;
			actual = target.Get(key);
			Assert.AreEqual(expected, actual);
			Assert.Inconclusive("Verify the correctness of this test method.");
		}

		/// <summary>
		///A test for Get
		///</summary>
		public void GetTestHelper<T>()
		{
			SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider target = new SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider(); // TODO: Initialize to an appropriate value
			string key = string.Empty; // TODO: Initialize to an appropriate value
			T expected = default(T); // TODO: Initialize to an appropriate value
			T actual;
			actual = target.Get<T>(key);
			Assert.AreEqual(expected, actual);
			Assert.Inconclusive("Verify the correctness of this test method.");
		}

		[TestMethod()]
		public void GetTest()
		{
			GetTestHelper<Microsoft.VisualStudio.TestTools.UnitTesting.GenericParameterHelper>();
		}

		/// <summary>
		///A test for ExtendTtl
		///</summary>
		[TestMethod()]
		public void ExtendTtlTest()
		{
			SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider target = new SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider(); // TODO: Initialize to an appropriate value
			string key = string.Empty; // TODO: Initialize to an appropriate value
			System.DateTime expires = new System.DateTime(); // TODO: Initialize to an appropriate value
			target.ExtendTtl(key, expires);
			Assert.Inconclusive("A method that does not return a value cannot be verified.");
		}

		/// <summary>
		///A test for Clear
		///</summary>
		[TestMethod()]
		public void ClearTest()
		{
			SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider target = new SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider(); // TODO: Initialize to an appropriate value
			target.Clear();
			Assert.Inconclusive("A method that does not return a value cannot be verified.");
		}

		/// <summary>
		///A test for Add
		///</summary>
		[TestMethod()]
		public void AddTest9()
		{
			SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider target = new SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider(); // TODO: Initialize to an appropriate value
			string key = string.Empty; // TODO: Initialize to an appropriate value
			object payload = null; // TODO: Initialize to an appropriate value
			System.DateTime expires = new System.DateTime(); // TODO: Initialize to an appropriate value
			target.Add(key, payload, expires);
			Assert.Inconclusive("A method that does not return a value cannot be verified.");
		}

		/// <summary>
		///A test for Add
		///</summary>
		[TestMethod()]
		public void AddTest8()
		{
			SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider target = new SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider(); // TODO: Initialize to an appropriate value
			string key = string.Empty; // TODO: Initialize to an appropriate value
			byte[] payload = null; // TODO: Initialize to an appropriate value
			System.DateTime expires = new System.DateTime(); // TODO: Initialize to an appropriate value
			target.Add(key, payload, expires);
			Assert.Inconclusive("A method that does not return a value cannot be verified.");
		}

		/// <summary>
		///A test for Add
		///</summary>
		[TestMethod()]
		public void AddTest7()
		{
			SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider target = new SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider(); // TODO: Initialize to an appropriate value
			string key = string.Empty; // TODO: Initialize to an appropriate value
			byte[] payload = null; // TODO: Initialize to an appropriate value
			target.Add(key, payload);
			Assert.Inconclusive("A method that does not return a value cannot be verified.");
		}

		/// <summary>
		///A test for Add
		///</summary>
		[TestMethod()]
		public void AddTest6()
		{
			SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider target = new SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider(); // TODO: Initialize to an appropriate value
			string key = string.Empty; // TODO: Initialize to an appropriate value
			object payload = null; // TODO: Initialize to an appropriate value
			target.Add(key, payload);
			Assert.Inconclusive("A method that does not return a value cannot be verified.");
		}

		/// <summary>
		///A test for Add
		///</summary>
		[TestMethod()]
		public void AddTest5()
		{
			SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider target = new SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider(); // TODO: Initialize to an appropriate value
			string key = string.Empty; // TODO: Initialize to an appropriate value
			object payload = null; // TODO: Initialize to an appropriate value
			SharedCache.WinServiceCommon.IndexusMessage.CacheItemPriority prio = new SharedCache.WinServiceCommon.IndexusMessage.CacheItemPriority(); // TODO: Initialize to an appropriate value
			target.Add(key, payload, prio);
			Assert.Inconclusive("A method that does not return a value cannot be verified.");
		}

		/// <summary>
		///A test for Add
		///</summary>
		[TestMethod()]
		public void AddTest4()
		{
			SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider target = new SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider(); // TODO: Initialize to an appropriate value
			string key = string.Empty; // TODO: Initialize to an appropriate value
			object payload = null; // TODO: Initialize to an appropriate value
			System.DateTime expires = new System.DateTime(); // TODO: Initialize to an appropriate value
			SharedCache.WinServiceCommon.IndexusMessage.CacheItemPriority prio = new SharedCache.WinServiceCommon.IndexusMessage.CacheItemPriority(); // TODO: Initialize to an appropriate value
			target.Add(key, payload, expires, prio);
			Assert.Inconclusive("A method that does not return a value cannot be verified.");
		}

		/// <summary>
		///A test for Add
		///</summary>
		[TestMethod()]
		public void AddTest3()
		{
			SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider target = new SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider(); // TODO: Initialize to an appropriate value
			string key = string.Empty; // TODO: Initialize to an appropriate value
			byte[] payload = null; // TODO: Initialize to an appropriate value
			System.DateTime expires = new System.DateTime(); // TODO: Initialize to an appropriate value
			SharedCache.WinServiceCommon.IndexusMessage.CacheItemPriority prio = new SharedCache.WinServiceCommon.IndexusMessage.CacheItemPriority(); // TODO: Initialize to an appropriate value
			target.Add(key, payload, expires, prio);
			Assert.Inconclusive("A method that does not return a value cannot be verified.");
		}

		/// <summary>
		///A test for Add
		///</summary>
		[TestMethod()]
		public void AddTest2()
		{
			SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider target = new SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider(); // TODO: Initialize to an appropriate value
			string key = string.Empty; // TODO: Initialize to an appropriate value
			byte[] payload = null; // TODO: Initialize to an appropriate value
			string host = string.Empty; // TODO: Initialize to an appropriate value
			target.Add(key, payload, host);
			Assert.Inconclusive("A method that does not return a value cannot be verified.");
		}

		/// <summary>
		///A test for Add
		///</summary>
		[TestMethod()]
		public void AddTest1()
		{
			SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider target = new SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider(); // TODO: Initialize to an appropriate value
			string key = string.Empty; // TODO: Initialize to an appropriate value
			byte[] payload = null; // TODO: Initialize to an appropriate value
			SharedCache.WinServiceCommon.IndexusMessage.CacheItemPriority prio = new SharedCache.WinServiceCommon.IndexusMessage.CacheItemPriority(); // TODO: Initialize to an appropriate value
			target.Add(key, payload, prio);
			Assert.Inconclusive("A method that does not return a value cannot be verified.");
		}

		/// <summary>
		///A test for Add
		///</summary>
		[TestMethod()]
		public void AddTest()
		{
			SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider target = 
				new SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider(); 
			// TODO: Initialize to an appropriate value
			string key = string.Empty; // TODO: Initialize to an appropriate value
			object payload = null; // TODO: Initialize to an appropriate value
			string host = string.Empty; // TODO: Initialize to an appropriate value
			target.Add(key, payload, host);
			Assert.Inconclusive("A method that does not return a value cannot be verified.");
		}

		/// <summary>
		///A test for IndexusSharedCacheProvider Constructor
		///</summary>
		[TestMethod()]
		public void IndexusSharedCacheProviderConstructorTest()
		{
			SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider target = new SharedCache.WinServiceCommon.Provider.Cache.IndexusSharedCacheProvider();
			Assert.Inconclusive("TODO: Implement code to verify target");
		}
	}
}
