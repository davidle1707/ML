//#region Copyright (c) Roni Schuetz, Switzerland. All Rights Reserved
//// * --------------------------------------------------------------------- *
//// *                              Roni Schuetz                             *
//// *              Copyright (c) 2008 All Rights reserved                   *
//// *                                                                       *
//// * Shared Cache high-performance, distributed caching and    *
//// * replicated caching system, generic in nature, but intended to         *
//// * speeding up dynamic web and / or win applications by alleviating      *
//// * database load.                                                        *
//// *                                                                       *
//// * This Software is written by Roni Schuetz (schuetz AT gmail DOT com)   *
//// *                                                                       *
//// * This library is free software; you can redistribute it and/or         *
//// * modify it under the terms of the GNU Lesser General Public License    *
//// * as published by the Free Software Foundation; either version 2.1      *
//// * of the License, or (at your option) any later version.                *
//// *                                                                       *
//// * This library is distributed in the hope that it will be useful,       *
//// * but WITHOUT ANY WARRANTY; without even the implied warranty of        *
//// * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU      *
//// * Lesser General Public License for more details.                       *
//// *                                                                       *
//// * You should have received a copy of the GNU Lesser General Public      *
//// * License along with this library; if not, write to the Free            *
//// * Software Foundation, Inc., 59 Temple Place, Suite 330,                *
//// * Boston, MA 02111-1307 USA                                             *
//// *                                                                       *
//// *       THIS COPYRIGHT NOTICE MAY NOT BE REMOVED FROM THIS FILE.        *
//// * --------------------------------------------------------------------- *
//#endregion 
//using Microsoft.VisualStudio.TestTools.UnitTesting;
//using System;
//using System.Text;
//using System.Collections.Generic;
//using System.Net;
//using System.Net.Sockets;
//using System.Threading;
//using SharedCache.WinService;
//using SharedCache.WinServiceCommon;
//using System.Diagnostics;
//using System.IO;
//using System.Reflection;
//using System.Text;

//namespace SharedCache.Testing
//{
//  /// <summary>
//  /// Summary description for StartUpEnvironment
//  /// </summary>
//  public static class StartUpEnvironment
//  {
//    public static bool running = false;
//    private static Process serverProcess = new Process();
		
//    public static void LoadServerAsConsole(TestContext context)
//    {
//      if (running)
//        return;

//      running = true;
//      serverProcess.StartInfo.WorkingDirectory = Path.GetDirectoryName(Assembly.GetExecutingAssembly().CodeBase).Replace(@"file:\", "");
//      serverProcess.StartInfo.FileName = "SharedCache.WinService.exe";
//      serverProcess.StartInfo.UseShellExecute = true;
//      serverProcess.StartInfo.Arguments = "/local";
//      //serverProcess.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
//      serverProcess.Start();
//    }

//    public static void UnLoadServerAsConsole()
//    {
//      serverProcess.Dispose();
//      running = false;
//    }
//  }
//}
