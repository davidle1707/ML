﻿//#region Copyright (c) Roni Schuetz, Switzerland. All Rights Reserved
//// * --------------------------------------------------------------------- *
//// *                              Roni Schuetz                             *
//// *              Copyright (c) 2008 All Rights reserved                   *
//// *                                                                       *
//// * Shared Cache high-performance, distributed caching and    *
//// * replicated caching system, generic in nature, but intended to         *
//// * speeding up dynamic web and / or win applications by alleviating      *
//// * database load.                                                        *
//// *                                                                       *
//// * This Software is written by Roni Schuetz (schuetz AT gmail DOT com)   *
//// *                                                                       *
//// * This library is free software; you can redistribute it and/or         *
//// * modify it under the terms of the GNU Lesser General Public License    *
//// * as published by the Free Software Foundation; either version 2.1      *
//// * of the License, or (at your option) any later version.                *
//// *                                                                       *
//// * This library is distributed in the hope that it will be useful,       *
//// * but WITHOUT ANY WARRANTY; without even the implied warranty of        *
//// * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU      *
//// * Lesser General Public License for more details.                       *
//// *                                                                       *
//// * You should have received a copy of the GNU Lesser General Public      *
//// * License along with this library; if not, write to the Free            *
//// * Software Foundation, Inc., 59 Temple Place, Suite 330,                *
//// * Boston, MA 02111-1307 USA                                             *
//// *                                                                       *
//// *       THIS COPYRIGHT NOTICE MAY NOT BE REMOVED FROM THIS FILE.        *
//// * --------------------------------------------------------------------- *
//#endregion 
//using Microsoft.VisualStudio.TestTools.UnitTesting;
//using System;
//using System.Text;
//using System.Collections.Generic;
//using System.Net;
//using System.Net.Sockets;
//using System.Threading;
//using SharedCache.WinService;
//using SharedCache.WinServiceCommon;
//using System.Diagnostics;
//using System.IO;
//using System.Reflection;
//using System.Text;

//namespace SharedCache.Testing
//{
//  public static class TestSocket
//  {
//    static int testPort = 48889;
//    public static void ThreadProc() { }
//    public static Socket GetTestSocket()
//    {
//      Socket s;
//      // if a progrom is using this port test will fail.
//      IPEndPoint endpoint = SharedCache.WinServiceCommon.Handler.Network.GetServerAnyIPEndPoint(testPort);
//      s = new Socket(endpoint.Address.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
//      s.Connect("127.0.0.1", 48888);
//      return s;
//    }
//    public static void CloseSocket(Socket s)
//    {
//      // release socket
//      if (s != null)
//      {
//        s.Close(0);
//      }
//    }
//  }

//  /// <summary>
//  ///This is a test class for SharedCache.WinService.TcpServer.ConnectionInfo and is intended
//  ///to contain all SharedCache.WinService.TcpServer.ConnectionInfo Unit Tests
//  ///</summary>
//  [TestClass()]
//  public class ConnectionInfoTest
//  {
//    private TestContext testContextInstance;
//    /// <summary>
//    ///Gets or sets the test context which provides
//    ///information about and functionality for the current test run.
//    ///</summary>
//    public TestContext TestContext
//    {
//      get
//      {
//        return testContextInstance;
//      }
//      set
//      {
//        testContextInstance = value;
//      }
//    }
//    #region Additional test attributes
//    // 
//    //You can use the following additional attributes as you write your tests:
//    //
//    //Use ClassInitialize to run code before running the first test in the class
//    //
//    //[ClassInitialize()]
//    //public static void MyClassInitialize(TestContext testContext)
//    //{
//    //}
//    //
//    //Use ClassCleanup to run code after all tests in a class have run
//    //
//    //[ClassCleanup()]
//    //public static void MyClassCleanup()
//    //{
//    //}
//    //
//    //Use TestInitialize to run code before running each test
//    //
//    //[TestInitialize()]
//    //public void MyTestInitialize()
//    //{
//    //}
//    //
//    //Use TestCleanup to run code after each test has run
//    //
//    //[TestCleanup()]
//    //public void MyTestCleanup()
//    //{
//    //}
//    //
//    #endregion

//    /// <summary>
//    /// Empty method to init a new thread.
//    /// </summary>
//    public static void ThreadProc() { }

//    /// <summary>
//    ///A test for ConnectionInfo ()
//    ///</summary>
//    [DeploymentItem("SharedCache.WinService.exe")]
//    [TestMethod()]
//    public void ConstructorConnectionInfoTest()
//    {
//      object target = MergeSystem_Indexus_WinService_TcpServer_ConnectionInfoAccessor.CreatePrivate();
//      MergeSystem_Indexus_WinService_TcpServer_ConnectionInfoAccessor acc = new MergeSystem_Indexus_WinService_TcpServer_ConnectionInfoAccessor(target);

//      Thread t = new Thread(new ThreadStart(ThreadProc));
//      acc.Thread = t;

//      // validate the data
//      Assert.IsNotNull(acc);

//      // if a progrom is using this port test will fail.
//      IPEndPoint endpoint = SharedCache.WinServiceCommon.Handler.Network.GetServerAnyIPEndPoint(48889);
//      Socket serverSocket = new Socket(endpoint.Address.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
//      acc.Socket = serverSocket;

//      Assert.IsTrue(acc.Socket.Available == 0);

//      serverSocket.Bind(endpoint);
//      serverSocket.Listen((int)SocketOptionName.MaxConnections);

//      Assert.IsInstanceOfType(acc.Socket, typeof(System.Net.Sockets.Socket));
//      Assert.IsInstanceOfType(acc.Thread, typeof(System.Threading.Thread));

//      // release socket
//      acc.Socket.Close(0);
//    }
//  }
//  /// <summary>
//  ///This is a test class for SharedCache.WinService.TcpServer and is intended
//  ///to contain all SharedCache.WinService.TcpServer Unit Tests
//  ///</summary>
//  [TestClass()]
//  public class TcpServerTest
//  {

//    [ClassInitialize()]
//    public static void LoadServerAsConsole(TestContext context)
//    {
//      StartUpEnvironment.LoadServerAsConsole(context);
//    }
//    [ClassCleanup()]
//    public static void UnLoadServerAsConsole()
//    {
//      StartUpEnvironment.UnLoadServerAsConsole();
//    }

//    private TestContext testContextInstance;

//    /// <summary>
//    ///Gets or sets the test context which provides
//    ///information about and functionality for the current test run.
//    ///</summary>
//    public TestContext TestContext
//    {
//      get
//      {
//        return testContextInstance;
//      }
//      set
//      {
//        testContextInstance = value;
//      }
//    }
//    #region Additional test attributes
//    // 
//    //You can use the following additional attributes as you write your tests:
//    //
//    //Use ClassInitialize to run code before running the first test in the class
//    //
//    //[ClassInitialize()]
//    //public static void MyClassInitialize(TestContext testContext)
//    //{
//    //}
//    //
//    //Use ClassCleanup to run code after all tests in a class have run
//    //
//    //[ClassCleanup()]
//    //public static void MyClassCleanup()
//    //{
//    //}
//    //
//    //Use TestInitialize to run code before running each test
//    //
//    //[TestInitialize()]
//    //public void MyTestInitialize()
//    //{
//    //}
//    //
//    //Use TestCleanup to run code after each test has run
//    //
//    //[TestCleanup()]
//    //public void MyTestCleanup()
//    //{
//    //}
//    //
//    #endregion

//    private string key = "test";
//    private byte[] data = new byte[] { 1, 2, 4, 8 };

//    //[TestMethod()]
//    //public void ProcessMessageAddTest()
//    //{
//    //  IndexusMessage msg = new IndexusMessage(new Random().Next(), IndexusMessage.ActionValue.Add, IndexusMessage.StatusValue.Request, new KeyValuePair<string, byte[]>(key, data));
//    //  Assert.IsTrue(msg.Send());
//    //  Assert.AreEqual<IndexusMessage.ActionValue>(IndexusMessage.ActionValue.Successful, msg.Action);
//    //}

//    [TestMethod()]
//    public void ProcessMessageAddWithResponseTest()
//    {
//      IndexusMessage msg = new IndexusMessage();
//      msg.Action = IndexusMessage.ActionValue.Add;
//      msg.Status = IndexusMessage.StatusValue.Response;
//      msg.Key = key;
//      msg.Payload = data;
			
//      Assert.IsFalse(msg.Send());
//      Assert.AreEqual<IndexusMessage.ActionValue>(IndexusMessage.ActionValue.Error, msg.Action);
//    }
//  }
//}
