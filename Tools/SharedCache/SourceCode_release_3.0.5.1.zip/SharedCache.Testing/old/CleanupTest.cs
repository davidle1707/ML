﻿//#region Copyright (c) Roni Schuetz, Switzerland. All Rights Reserved
//// * --------------------------------------------------------------------- *
//// *                              Roni Schuetz                             *
//// *              Copyright (c) 2008 All Rights reserved                   *
//// *                                                                       *
//// * Shared Cache high-performance, distributed caching and    *
//// * replicated caching system, generic in nature, but intended to         *
//// * speeding up dynamic web and / or win applications by alleviating      *
//// * database load.                                                        *
//// *                                                                       *
//// * This Software is written by Roni Schuetz (schuetz AT gmail DOT com)   *
//// *                                                                       *
//// * This library is free software; you can redistribute it and/or         *
//// * modify it under the terms of the GNU Lesser General Public License    *
//// * as published by the Free Software Foundation; either version 2.1      *
//// * of the License, or (at your option) any later version.                *
//// *                                                                       *
//// * This library is distributed in the hope that it will be useful,       *
//// * but WITHOUT ANY WARRANTY; without even the implied warranty of        *
//// * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU      *
//// * Lesser General Public License for more details.                       *
//// *                                                                       *
//// * You should have received a copy of the GNU Lesser General Public      *
//// * License along with this library; if not, write to the Free            *
//// * Software Foundation, Inc., 59 Temple Place, Suite 330,                *
//// * Boston, MA 02111-1307 USA                                             *
//// *                                                                       *
//// *       THIS COPYRIGHT NOTICE MAY NOT BE REMOVED FROM THIS FILE.        *
//// * --------------------------------------------------------------------- *
//#endregion 
//using Microsoft.VisualStudio.TestTools.UnitTesting;
//using System;
//using System.Text;
//using System.Collections.Generic;
//using SharedCache.WinServiceCommon;
//namespace SharedCache.Testing
//{
//  /// <summary>
//  ///This is a test class for SharedCache.WinServiceCommon.Cleanup and is intended
//  ///to contain all SharedCache.WinServiceCommon.Cleanup Unit Tests
//  ///</summary>
//  [TestClass()]
//  public class CleanupTest
//  {


//    private TestContext testContextInstance;

//    /// <summary>
//    ///Gets or sets the test context which provides
//    ///information about and functionality for the current test run.
//    ///</summary>
//    public TestContext TestContext
//    {
//      get
//      {
//        return testContextInstance;
//      }
//      set
//      {
//        testContextInstance = value;
//      }
//    }
//    #region Additional test attributes
//    // 
//    //You can use the following additional attributes as you write your tests:
//    //
//    //Use ClassInitialize to run code before running the first test in the class
//    //
//    //[ClassInitialize()]
//    //public static void MyClassInitialize(TestContext testContext)
//    //{
//    //}
//    //
//    //Use ClassCleanup to run code after all tests in a class have run
//    //
//    //[ClassCleanup()]
//    //public static void MyClassCleanup()
//    //{
//    //}
//    //
//    //Use TestInitialize to run code before running each test
//    //
//    //[TestInitialize()]
//    //public void MyTestInitialize()
//    //{
//    //}
//    //
//    //Use TestCleanup to run code after each test has run
//    //
//    //[TestCleanup()]
//    //public void MyTestCleanup()
//    //{
//    //}
//    //
//    #endregion


//    /// <summary>
//    ///A test for Cleanup ()
//    ///</summary>
//    [TestMethod()]
//    public void CleanUpConstructorTestWithoutParam()
//    {
//      Cleanup target = new Cleanup();
//      Assert.IsNotNull(target);
//    }

//    /// <summary>
//    ///A test for Cleanup (string, IndexusMessage.CacheItemPriority, TimeSpan, long, DateTime, long, int)
//    ///</summary>
//    [TestMethod()]
//    public void CleanUpConstructorTestWithParam()
//    {
//      DateTime gen = DateTime.Now.AddMinutes(-1);
//      long hits = 99;

//      string key = @"Shared Cache";
//      IndexusMessage.CacheItemPriority prio = IndexusMessage.CacheItemPriority.Low;
//      TimeSpan span = new TimeSpan(5,3,22);
//      long hitRatio = hits;
//      DateTime usageDatetime = gen;
//      long objectSize = hits * 2;
//      int hybridPoint = int.Parse(hits.ToString()); 
//      Cleanup target = new Cleanup(key, prio, span, hitRatio, usageDatetime, objectSize, hybridPoint);

//      Assert.AreEqual<string>(key, target.Key);
//      Assert.AreEqual(IndexusMessage.CacheItemPriority.Low, target.Prio);
//      Assert.AreEqual<TimeSpan>(new TimeSpan(5, 3, 22), target.Span);
//      Assert.AreEqual<long>(hits, target.HitRatio);
//      Assert.AreEqual<DateTime>(gen, target.UsageDatetime);
//      Assert.AreEqual<long>(hits * 2, target.ObjectSize);
//      Assert.AreEqual<long>(hits, target.HybridPoint);
//    }

//    /// <summary>
//    ///A test for CleanupCacheConfiguration
//    ///</summary>
//    [TestMethod()]
//    public void CleanupCacheConfigurationTest()
//    {
//      Cleanup target = new Cleanup();
//      Enums.ServiceCacheCleanUp val = Enums.ServiceCacheCleanUp.CACHEITEMPRIORITY;
//      target.CleanupCacheConfiguration = val;
//      Assert.AreEqual(val, target.CleanupCacheConfiguration, "Cleanup.CleanupCacheConfiguration was not set correctly.");
//    }

//    /// <summary>
//    ///A test for CompareTo (Cleanup)
//    ///</summary>
//    [TestMethod()]
//    public void CompareToTest()
//    {
//      DateTime now = DateTime.Now.AddMinutes(-1);
//      Cleanup target = new Cleanup("abc1", IndexusMessage.CacheItemPriority.Normal, new TimeSpan(5, 3, 23), 4, now, 1232, 0);
//      Cleanup other = new Cleanup("abc1", IndexusMessage.CacheItemPriority.Normal, new TimeSpan(5, 3, 23), 4, now, 1232, 0);
			
//      int expected = 0;
//      int actual;

//      actual = target.CompareTo(other);
//      Assert.AreEqual(expected, actual, "Cleanup.CompareTo did not return the expecte d value.");
//    }

//    /// <summary>
//    ///A test for HitRatio
//    ///</summary>
//    [TestMethod()]
//    public void HitRatioTest()
//    {
//      Cleanup target = new Cleanup();
//      long val = 20;
//      target.HitRatio = val;
//      Assert.AreEqual(val, target.HitRatio, "SharedCache.WinServiceCommon.Cleanup.HitRatio was not set correctly.");
//    }

//    /// <summary>
//    ///A test for HybridPoint
//    ///</summary>
//    [TestMethod()]
//    public void HybridPointTest()
//    {
//      Cleanup target = new Cleanup();
//      long val = 20;
//      target.HybridPoint = val;
//      Assert.AreEqual(val, target.HybridPoint, "SharedCache.WinServiceCommon.Cleanup.HybridPoint was not set correctly.");
//    }

//    /// <summary>
//    ///A test for Key
//    ///</summary>
//    [TestMethod()]
//    public void KeyTest()
//    {
//      string val = @"Shared Cache";
//      Cleanup target = new Cleanup(val, IndexusMessage.CacheItemPriority.AboveNormal, new TimeSpan(), 88, DateTime.Now, 1024, -1);			
//      Assert.AreEqual<string>(val, target.Key, "SharedCache.WinServiceCommon.Cleanup.Key was not set correctly.");
//    }

//    /// <summary>
//    ///A test for ObjectSize
//    ///</summary>
//    [TestMethod()]
//    public void ObjectSizeTest()
//    {
//      Cleanup target = new Cleanup();
//      long val = 1024;
//      target.ObjectSize = val;
//      Assert.AreEqual(val, target.ObjectSize, "SharedCache.WinServiceCommon.Cleanup.ObjectSize was not set correctly.");
//    }

//    /// <summary>
//    ///A test for Prio
//    ///</summary>
//    [TestMethod()]
//    public void PrioTest()
//    {
//      Cleanup target = new Cleanup();
//      IndexusMessage.CacheItemPriority val = IndexusMessage.CacheItemPriority.AboveNormal;
//      target.Prio = val;
//      Assert.AreEqual(val, target.Prio, "SharedCache.WinServiceCommon.Cleanup.Prio was not set correctly.");
//    }

//    /// <summary>
//    ///A test for Sorting
//    ///</summary>
//    [TestMethod()]
//    public void SortingTest()
//    {
//      Cleanup.SortingOrder val = Cleanup.SortingOrder.Asc;
//      Cleanup.Sorting = val;
//      Assert.AreEqual(val, Cleanup.Sorting, "SharedCache.WinServiceCommon.Cleanup.Sorting was not set correctly.");
//    }

//    /// <summary>
//    ///A test for SortListForCleanup (List&lt;Cleanup&gt;)
//    ///</summary>
//    [DeploymentItem("SharedCache.WinServiceCommon.dll")]
//    [TestMethod()]
//    public void SortListForCleanupTest()
//    {
//      long am = 22;
//      Cleanup target = new Cleanup();

//      MergeSystem_Indexus_WinServiceCommon_CleanupAccessor accessor = new MergeSystem_Indexus_WinServiceCommon_CleanupAccessor(target);
//      List<Cleanup> listToSort = new List<Cleanup>();
//      for (int i = 0; i < am; ++i)
//      {
//        listToSort.Add(
//          new Cleanup(
//             i.ToString(), 
//             IndexusMessage.CacheItemPriority.Normal, 
//             new TimeSpan(1, i, i), 
//             long.Parse(i.ToString()), 
//             DateTime.Now.AddMinutes(double.Parse(i.ToString())), 
//             i * 128, -1
//            )
//          );
//      }

//      accessor.SortListForCleanup(listToSort);
//      Assert.AreEqual<long>(am - 1, listToSort[0].HitRatio);
//      Assert.AreEqual<long>(0, listToSort[listToSort.Count -1].HitRatio);
//    }

//    /// <summary>
//    ///A test for Span
//    ///</summary>
//    [TestMethod()]
//    public void SpanTest()
//    {
//      Cleanup target = new Cleanup();
//      TimeSpan val = new TimeSpan(5,12,25);
//      target.Span = val;
//      Assert.AreEqual(val, target.Span, "SharedCache.WinServiceCommon.Cleanup.Span was not set correctly.");
//    }

//    /// <summary>
//    ///A test for UsageDatetime
//    ///</summary>
//    [TestMethod()]
//    public void UsageDatetimeTest()
//    {
//      Cleanup target = new Cleanup();
//      DateTime val = DateTime.Now.AddMinutes(30);
//      target.UsageDatetime = val;
//      Assert.AreEqual(val, target.UsageDatetime, "SharedCache.WinServiceCommon.Cleanup.UsageDatetime was not set correctly.");
//    }

//  }


//}
