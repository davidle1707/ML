﻿//#region Copyright (c) Roni Schuetz, Switzerland. All Rights Reserved
//// * --------------------------------------------------------------------- *
//// *                              Roni Schuetz                             *
//// *              Copyright (c) 2008 All Rights reserved                   *
//// *                                                                       *
//// * Shared Cache high-performance, distributed caching and    *
//// * replicated caching system, generic in nature, but intended to         *
//// * speeding up dynamic web and / or win applications by alleviating      *
//// * database load.                                                        *
//// *                                                                       *
//// * This Software is written by Roni Schuetz (schuetz AT gmail DOT com)   *
//// *                                                                       *
//// * This library is free software; you can redistribute it and/or         *
//// * modify it under the terms of the GNU Lesser General Public License    *
//// * as published by the Free Software Foundation; either version 2.1      *
//// * of the License, or (at your option) any later version.                *
//// *                                                                       *
//// * This library is distributed in the hope that it will be useful,       *
//// * but WITHOUT ANY WARRANTY; without even the implied warranty of        *
//// * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU      *
//// * Lesser General Public License for more details.                       *
//// *                                                                       *
//// * You should have received a copy of the GNU Lesser General Public      *
//// * License along with this library; if not, write to the Free            *
//// * Software Foundation, Inc., 59 Temple Place, Suite 330,                *
//// * Boston, MA 02111-1307 USA                                             *
//// *                                                                       *
//// *       THIS COPYRIGHT NOTICE MAY NOT BE REMOVED FROM THIS FILE.        *
//// * --------------------------------------------------------------------- *
//#endregion 
//using Microsoft.VisualStudio.TestTools.UnitTesting;
//using System;
//using System.Text;
//using System.Collections.Generic;
//using COM = SharedCache.WinServiceCommon;

//namespace SharedCache.Testing
//{
//  /// <summary>
//  ///This is a test class for SharedCache.WinServiceCommon.Formatters.Compression and is intended
//  ///to contain all SharedCache.WinServiceCommon.Formatters.Compression Unit Tests
//  ///</summary>
//  [TestClass()]
//  public class CompressionTest
//  {
//    /// <summary>
//    ///A test for Compress (byte[])
//    ///</summary>
//    [TestMethod()]
//    public void CompressTest()
//    {
//      string text = @"SharedCache - high performance caching";

//      byte[] value = System.Text.Encoding.UTF8.GetBytes(text);
//      int lengthUnCompressed = text.Length;
//      byte [] actual;

//      // compressed size will be here bigger then the string is to short!
//      actual = COM.Formatters.Compression.Compress(value);
//      Assert.IsTrue(actual.Length > lengthUnCompressed);

//      text += " - General Overview: Shared Cache is high performance distributed and replication cache system build for .Net cache and enterprise application running in server farms. " + 
//        "Shared Cache provides distributed replicated cache to minimize the load factor. It consists the usage of two or more servers in a farm. It's replicated all data within the cluster. The big plus is simple, you have all your cache nodes on all different servers. In case one of your servers get restarted, it will receive all nodes automatically from its parent. " + 
//        "Shared Cache uses 100% managed code which is written .Net C#.";

//      value = System.Text.Encoding.UTF8.GetBytes(text);
//      lengthUnCompressed = text.Length;
//      actual = null;

//      // now compression takes action
//      actual = COM.Formatters.Compression.Compress(value);
//      Assert.IsTrue(actual.Length < lengthUnCompressed);

//    }

//    /// <summary>
//    ///A test for Decompress (byte[])
//    ///</summary>
//    [TestMethod()]
//    public void DecompressTest()
//    {
//      // that compression takes advantage we need a minimal size length
//      string text = @"SharedCache - high performance caching" + 
//        " - General Overview: Shared Cache is high performance distributed and replication cache system build for .Net cache and enterprise application running in server farms. " +
//        "Shared Cache provides distributed replicated cache to minimize the load factor. It consists the usage of two or more servers in a farm. It's replicated all data within the cluster. The big plus is simple, you have all your cache nodes on all different servers. In case one of your servers get restarted, it will receive all nodes automatically from its parent. " +
//        "Shared Cache uses 100% managed code which is written .Net C#.";
			
//      byte[] expected = null;
//      byte[] value = System.Text.Encoding.UTF8.GetBytes(text);
//      int lengthUnCompressed = text.Length;
//      byte[] actual;

//      actual = COM.Formatters.Compression.Compress(value);
//      expected = SharedCache.WinServiceCommon.Formatters.Compression.Decompress(actual);
//      CollectionAssert.AreEqual(expected, value, "SharedCache.WinServiceCommon.Formatters.Compression.Decompress did not return the expected value.");
//    }

//    /// <summary>
//    ///A test for CheckHeader (byte[]) and private method DecodeHeader;
//    ///</summary>
//    [TestMethod()]
//    public void CheckHeaderTest()
//    {
//      // that compression takes advantage we need a minimal size length
//      string text = @"SharedCache - high performance caching" +
//        " - General Overview: Shared Cache is high performance distributed and replication cache system build for .Net cache and enterprise application running in server farms. " +
//        "Shared Cache provides distributed replicated cache to minimize the load factor. It consists the usage of two or more servers in a farm. It's replicated all data within the cluster. The big plus is simple, you have all your cache nodes on all different servers. In case one of your servers get restarted, it will receive all nodes automatically from its parent. " +
//        "Shared Cache uses 100% managed code which is written .Net C#.";

//      byte[] expected = null;
//      byte[] value = System.Text.Encoding.UTF8.GetBytes(text);
//      int lengthUnCompressed = text.Length;
//      byte[] actual;

//      actual = COM.Formatters.Compression.Compress(value);
//      Assert.IsTrue(SharedCache.WinServiceCommon.Formatters.Compression.CheckHeader(actual), "SharedCache.WinServiceCommon.Formatters.Compression.CheckHeader did not return the expected value.");
//      expected = SharedCache.WinServiceCommon.Formatters.Compression.Decompress(actual);			
//      Assert.IsFalse(SharedCache.WinServiceCommon.Formatters.Compression.CheckHeader(expected), "SharedCache.WinServiceCommon.Formatters.Compression.CheckHeader did not return the expected value.");
//    }
//  }
//}
