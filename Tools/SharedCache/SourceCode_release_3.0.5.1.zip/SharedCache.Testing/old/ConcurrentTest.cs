//using System;
//using System.Collections;
//using System.Collections.Generic;
//using System.Text;
//using System.Threading;
//using Microsoft.VisualStudio.TestTools.UnitTesting;

//using SharedCache.WinServiceCommon.Provider.Cache;

//namespace SharedCache.Testing
//{
//  /// <summary>
//  /// Summary description for ConcurrentTest
//  /// </summary>
//  [TestClass]
//  public class ConcurrentTest
//  {
//    [ClassInitialize()]
//    public static void LoadServerAsConsole(TestContext context)
//    {
//      //StartUpEnvironment.LoadServerAsConsole(context);
//    }
//    [ClassCleanup()]
//    public static void UnLoadServerAsConsole()
//    {
//      //StartUpEnvironment.UnLoadServerAsConsole();
//    }
		
//    DateTime start = DateTime.MinValue;
//    DateTime end = DateTime.MinValue;

//    public static object bulkObject = new object();
//    public static long counter = 0;
//    public static int amount = 1000;


//    public void Add(object key)
//    {
//      IndexusDistributionCache.SharedCache.Add((string)key, new TestSizeObject(ObjectSize.One));

//      lock (bulkObject)
//      {
//        if (++counter == amount)
//        {
//          end = DateTime.Now;
//          Done("add");
//        }
//      }
//    }

//    public void Remove(object key)
//    {
//      IndexusDistributionCache.SharedCache.Remove((string)key);

//      lock (bulkObject)
//      {
//        if (++counter == amount)
//        {
//          end = DateTime.Now;
//          Done("remove");
//        }
//      }
//    }

//    public void Get(object key)
//    {
//      TestSizeObject a = IndexusDistributionCache.SharedCache.Get<TestSizeObject>((string)key);

//      lock (bulkObject)
//      {
//        if (++counter == amount)
//        {
//          end = DateTime.Now;
//          Done("get");
//        }
//      }
//    }

//    public void Done(string doing)
//    { 
//      TimeSpan span = end - start;
//      Console.WriteLine(span.Seconds + " " + span.Milliseconds);
//      System.Diagnostics.Debug.WriteLine(doing + ": " +span.Seconds + "s " + span.Milliseconds + "ms");
//    }

//    [TestMethod()]
//    public void RunPerfTest()
//    {
//      foreach (string n in IndexusDistributionCache.SharedCache.Servers)
//      {
//        Console.WriteLine(n);
//      }
//      start = DateTime.Now;
//      for (int i = 0; i < amount; ++i)
//      {				
//        ThreadPool.QueueUserWorkItem(this.Add, i.ToString());
//      }
//      Thread.Sleep(8000);
//      counter = 0;

//      start = DateTime.Now;
//      for (int i = 0; i < amount; ++i)
//      {
//        ThreadPool.QueueUserWorkItem(this.Get, i.ToString());
//      }
//      Thread.Sleep(8000);
//      counter = 0;

//      start = DateTime.Now;
//      for (int i = 0; i < amount; ++i)
//      {
//        ThreadPool.QueueUserWorkItem(this.Remove, i.ToString());
//      }
//      Thread.Sleep(8000);
//      counter = 0;
//    }
//  }
//  /// <summary>
//  /// defines object size
//  /// </summary>
//  public enum ObjectSize
//  {
//    /// <summary>
//    /// 1 kb
//    /// </summary>
//    One,
//    /// <summary>
//    /// 100 kb
//    /// </summary>
//    Hundert,
//    /// <summary>
//    /// 1 mb
//    /// </summary>
//    Thousend
//  }

//  /// <summary>
//  /// Test Size Object
//  /// </summary>
//  [Serializable]
//  public class TestSizeObject
//  {
//    /// <summary>
//    /// an byte array which contains object payload.
//    /// </summary>
//    public byte[] byteArray;
//    /// <summary>
//    /// object id
//    /// </summary>
//    public string Id = Guid.NewGuid().ToString();

//    /// <summary>
//    /// Initializes a new instance of the <see cref="TestSizeObject"/> class.
//    /// </summary>
//    public TestSizeObject()
//    { }

//    /// <summary>
//    /// Initializes a new instance of the <see cref="TestSizeObject"/> class.
//    /// </summary>
//    /// <param name="size">The size.</param>
//    public TestSizeObject(ObjectSize size)
//    {
//      switch (size)
//      {
//        case ObjectSize.One:
//          byteArray = new byte[1024];
//          break;
//        case ObjectSize.Hundert:
//          byteArray = new byte[1024 * 128];
//          break;
//        case ObjectSize.Thousend:
//          byteArray = new byte[1024 * 1024];
//          break;
//      }

//      Random r = new Random();
//      for (int i = 0; i < byteArray.Length; i++)
//      {
//        int bb = r.Next(65, 97);
//        byteArray[i] = Convert.ToByte(bb);
//      }
//    }
//  }


//}
