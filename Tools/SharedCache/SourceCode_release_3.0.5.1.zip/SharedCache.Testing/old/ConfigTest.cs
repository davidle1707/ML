﻿#region Copyright (c) Roni Schuetz, Switzerland. All Rights Reserved
// * --------------------------------------------------------------------- *
// *                              Roni Schuetz                             *
// *              Copyright (c) 2008 All Rights reserved                   *
// *                                                                       *
// * Shared Cache high-performance, distributed caching and    *
// * replicated caching system, generic in nature, but intended to         *
// * speeding up dynamic web and / or win applications by alleviating      *
// * database load.                                                        *
// *                                                                       *
// * This Software is written by Roni Schuetz (schuetz AT gmail DOT com)   *
// *                                                                       *
// * This library is free software; you can redistribute it and/or         *
// * modify it under the terms of the GNU Lesser General Public License    *
// * as published by the Free Software Foundation; either version 2.1      *
// * of the License, or (at your option) any later version.                *
// *                                                                       *
// * This library is distributed in the hope that it will be useful,       *
// * but WITHOUT ANY WARRANTY; without even the implied warranty of        *
// * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU      *
// * Lesser General Public License for more details.                       *
// *                                                                       *
// * You should have received a copy of the GNU Lesser General Public      *
// * License along with this library; if not, write to the Free            *
// * Software Foundation, Inc., 59 Temple Place, Suite 330,                *
// * Boston, MA 02111-1307 USA                                             *
// *                                                                       *
// *       THIS COPYRIGHT NOTICE MAY NOT BE REMOVED FROM THIS FILE.        *
// * --------------------------------------------------------------------- *
#endregion 
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Text;
using System.Collections.Generic;
using COM = SharedCache.WinServiceCommon;

namespace SharedCache.Testing
{
	/// <summary>
	///This is a test class for SharedCache.WinServiceCommon.Handler.Config and is intended
	///to contain all SharedCache.WinServiceCommon.Handler.Config Unit Tests
	///</summary>
	[TestClass()]
	public class ConfigTest
	{
		///// <summary>
		/////A test for GetDoubleValueFromConfigByKey (string)
		/////</summary>
		//[TestMethod()]
		//public void GetDoubleValueFromConfigByKeyTest()
		//{
		//  string key = "doubleValueNormal";
		//  double expected = 12345678.12;
		//  double actual;
		//  // correct data
		//  actual = COM.Handler.Config.GetDoubleValueFromConfigByKey(key);
		//  Assert.AreEqual(expected, actual, "SharedCache.WinServiceCommon.Handler.Config.GetDoubleValueFromConfigByKey did not return the expected value.");

		//  // get wrong key and receive default value (-1)
		//  actual = COM.Handler.Config.GetDoubleValueFromConfigByKey("stringValue");
		//  expected = -1.0;
		//  Assert.AreEqual(expected, actual, "SharedCache.WinServiceCommon.Handler.Config.GetDoubleValueFromConfigByKey did not return the expected default value.");
		//}

		///// <summary>
		/////A test for GetIntValueFromConfigByKey (string)
		/////</summary>
		//[TestMethod()]
		//public void GetIntValueFromConfigByKeyTest()
		//{
		//  string key = "intValueNormal";

		//  int expected = 99999999;
		//  int actual;

		//  actual = COM.Handler.Config.GetIntValueFromConfigByKey(key);
		//  Assert.AreEqual(expected, actual, "SharedCache.WinServiceCommon.Handler.Config.GetIntValueFromConfigByKey did not return the expected value.");

		//  // check default return value 
		//  actual = COM.Handler.Config.GetIntValueFromConfigByKey("stringValue");
		//  expected = -1;
		//  Assert.AreEqual(expected, actual, "SharedCache.WinServiceCommon.Handler.Config.GetIntValueFromConfigByKey did not return the expected default value.");
		//}

		///// <summary>
		/////A test for GetNumOfDefinedAppSettings ()
		/////</summary>
		//[TestMethod()]
		//public void GetNumOfDefinedAppSettingsTest()
		//{
		//  int expected = 0;
		//  int actual;

		//  actual = COM.Handler.Config.GetNumOfDefinedAppSettings();
		//  Assert.IsTrue(actual > expected, "SharedCache.WinServiceCommon.Handler.Config.GetNumOfDefinedAppSettings did not return the expected value.");
		//}

		///// <summary>
		/////A test for GetStringValueFromConfigByKey (string)
		/////</summary>
		//[TestMethod()]
		//public void GetStringValueFromConfigByKeyTest()
		//{
		//  string key = @"stringValue";

		//  string expected = "JustSomeString";
		//  string actual;

		//  actual = COM.Handler.Config.GetStringValueFromConfigByKey(key);
		//  Assert.AreEqual(expected, actual, "SharedCache.WinServiceCommon.Handler.Config.GetStringValueFromConfigByKey did not return the expected value.");

		//  // check default return value 
		//  actual = COM.Handler.Config.GetStringValueFromConfigByKey("stringValue1");
		//  expected = string.Empty;
		//  Assert.AreEqual(expected, actual, "SharedCache.WinServiceCommon.Handler.Config.GetIntValueFromConfigByKey did not return the expected default value.");
		//}


		///// <summary>
		/////A test for DisplayAppSettings ()
		/////</summary>
		//[TestMethod()]
		//public void DisplayAppSettingsTest()
		//{
		//  string actual;
		//  actual = SharedCache.WinServiceCommon.Handler.Config.DisplayAppSettings();
		//  Assert.IsNotNull(actual, "SharedCache.WinServiceCommon.Handler.Config.DisplayAppSettings did not return the expected value.");
		//}
	}


}
