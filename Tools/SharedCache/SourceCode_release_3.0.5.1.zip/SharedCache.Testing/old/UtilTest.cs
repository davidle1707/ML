﻿//#region Copyright (c) Roni Schuetz, Switzerland. All Rights Reserved
//// * --------------------------------------------------------------------- *
//// *                              Roni Schuetz                             *
//// *              Copyright (c) 2008 All Rights reserved                   *
//// *                                                                       *
//// * Shared Cache high-performance, distributed caching and    *
//// * replicated caching system, generic in nature, but intended to         *
//// * speeding up dynamic web and / or win applications by alleviating      *
//// * database load.                                                        *
//// *                                                                       *
//// * This Software is written by Roni Schuetz (schuetz AT gmail DOT com)   *
//// *                                                                       *
//// * This library is free software; you can redistribute it and/or         *
//// * modify it under the terms of the GNU Lesser General Public License    *
//// * as published by the Free Software Foundation; either version 2.1      *
//// * of the License, or (at your option) any later version.                *
//// *                                                                       *
//// * This library is distributed in the hope that it will be useful,       *
//// * but WITHOUT ANY WARRANTY; without even the implied warranty of        *
//// * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU      *
//// * Lesser General Public License for more details.                       *
//// *                                                                       *
//// * You should have received a copy of the GNU Lesser General Public      *
//// * License along with this library; if not, write to the Free            *
//// * Software Foundation, Inc., 59 Temple Place, Suite 330,                *
//// * Boston, MA 02111-1307 USA                                             *
//// *                                                                       *
//// *       THIS COPYRIGHT NOTICE MAY NOT BE REMOVED FROM THIS FILE.        *
//// * --------------------------------------------------------------------- *
//#endregion 
//using Microsoft.VisualStudio.TestTools.UnitTesting;
//using System;
//using System.Text;
//using System.Collections.Generic;
//namespace SharedCache.Testing
//{
//  /// <summary>
//  ///This is a test class for SharedCache.WinServiceCommon.Handler.Generic.Util and is intended
//  ///to contain all SharedCache.WinServiceCommon.Handler.Generic.Util Unit Tests
//  ///</summary>
//  [TestClass()]
//  public class UtilTest
//  {


//    private TestContext testContextInstance;

//    /// <summary>
//    ///Gets or sets the test context which provides
//    ///information about and functionality for the current test run.
//    ///</summary>
//    public TestContext TestContext
//    {
//      get
//      {
//        return testContextInstance;
//      }
//      set
//      {
//        testContextInstance = value;
//      }
//    }
//    #region Additional test attributes
//    // 
//    //You can use the following additional attributes as you write your tests:
//    //
//    //Use ClassInitialize to run code before running the first test in the class
//    //
//    //[ClassInitialize()]
//    //public static void MyClassInitialize(TestContext testContext)
//    //{
//    //}
//    //
//    //Use ClassCleanup to run code after all tests in a class have run
//    //
//    //[ClassCleanup()]
//    //public static void MyClassCleanup()
//    //{
//    //}
//    //
//    //Use TestInitialize to run code before running each test
//    //
//    //[TestInitialize()]
//    //public void MyTestInitialize()
//    //{
//    //}
//    //
//    //Use TestCleanup to run code after each test has run
//    //
//    //[TestCleanup()]
//    //public void MyTestCleanup()
//    //{
//    //}
//    //
//    #endregion


//    /// <summary>
//    ///A test for SortDictionary (Dictionary&lt;string,long&gt;)
//    ///</summary>
//    [TestMethod]
//    // ExpectedException(typeof(System.ArgumentException))
//    public void SortDictionaryDefaultDefaultTest()
//    {
//      System.Collections.Generic.Dictionary<string, long> data = new Dictionary<string, long>();
//      data.Add("a", 0);
//      data.Add("b", 2);
//      data.Add("c", 3);
//      data.Add("d", 1);

//      List<long> result = new List<long>();
//      result.Add(3);
//      result.Add(2);
//      result.Add(1);
//      result.Add(0);

//      System.Collections.Generic.Dictionary<string, long> expected = null;
//      System.Collections.Generic.Dictionary<string, long> actual;

//      actual = SharedCache.WinServiceCommon.Handler.Generic.Util.SortDictionaryDesc(data);
//      int cntr=0;
//      foreach (KeyValuePair<string, long> kvp in actual)
//      {
//        Assert.AreEqual<long>(result[cntr++], kvp.Value, @"Descending - Value Sorting does not match!");
//      }			
//    }

//    /// <summary>
//    /// Sorts the dictionary asc default test.
//    /// </summary>
//    [TestMethod]
//    public void SortDictionaryAscDefaultTest()
//    {
//      System.Collections.Generic.Dictionary<string, long> data = new Dictionary<string, long>();
//      data.Add("a", 0);
//      data.Add("b", 2);
//      data.Add("c", 3);
//      data.Add("d", 1);

//      List<long> result = new List<long>();
//      result.Add(0);
//      result.Add(1);
//      result.Add(2);
//      result.Add(3);
			
//      Dictionary<string, long> actual;
			
//      actual = SharedCache.WinServiceCommon.Handler.Generic.Util.SortDictionaryAsc(data);
//      int cntr = 0;
//      foreach (KeyValuePair<string, long> kvp in actual)
//      {
//        Assert.AreEqual<long>(result[cntr++], kvp.Value, @"Ascending - Value Sorting does not match!");
//      }			

//    }
//  }
//}
